-- Takes the queue role back to empty: the grants, then the work items with
-- their two policies.

ALTER DEFAULT PRIVILEGES FOR ROLE free_journalism_migration IN SCHEMA queue
    REVOKE USAGE, SELECT ON SEQUENCES FROM free_journalism_runtime, free_journalism_system;
ALTER DEFAULT PRIVILEGES FOR ROLE free_journalism_migration IN SCHEMA queue
    REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM free_journalism_runtime, free_journalism_system;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA queue FROM free_journalism_runtime, free_journalism_system;
REVOKE ALL ON ALL TABLES IN SCHEMA queue FROM free_journalism_runtime, free_journalism_system;
REVOKE USAGE ON SCHEMA queue FROM free_journalism_runtime, free_journalism_system;

DROP TABLE queue.work_items;
