from .manager import JournalistsManagerInterface

__all__ = ["JournalistsManagerInterface"]
