"""The Free Journalism command line app."""
