// Pure: what the journalists screen says. The desk's journalists and the
// person's permissions in, rows and refusals out. No React, no fetch.
import type { JournalistView, MeView } from "@free_journalism/client";

export const DISPLAY_NAME_MAX_LENGTH = 200;

export interface JournalistRow {
  id: string;
  name: string;
  added: string;
}

/** A day as the list shows it: the date alone. */
export function formatDay(iso: string): string {
  return iso.slice(0, 10);
}

/** The rows in the order the server pages them, oldest first. */
export function journalistRows(journalists: JournalistView[]): JournalistRow[] {
  return journalists.map((journalist) => ({
    id: journalist.id,
    name: journalist.display_name,
    added: formatDay(journalist.created_at),
  }));
}

/** A viewer reads the desk's journalists; a member and above adds them. */
export function canAddJournalists(me: MeView | undefined): boolean {
  return me?.permissions.includes("write") ?? false;
}

/** Why a display name is refused before it is sent, or null. */
export function checkDisplayName(name: string): string | null {
  const trimmed = name.trim();
  if (trimmed === "") return "Enter the name readers will know the journalist by.";
  if (trimmed.length > DISPLAY_NAME_MAX_LENGTH) return `Keep the name to ${DISPLAY_NAME_MAX_LENGTH} characters.`;
  return null;
}

/** "1 journalist", "3 journalists". */
export function journalistsLine(count: number): string {
  return `${count} ${count === 1 ? "journalist" : "journalists"}`;
}
