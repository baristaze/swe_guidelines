# ADR 0085: SMS is Twilio's, only to a number that opted in, through an integration and its twin

**Status**: accepted (2026-09-30)

## Context

The product sends an optional SMS for a high-priority notification, only
to a person who explicitly opted in. The spec names Twilio. The
guideline puts a hosted service behind an interface with a real client
and a twin (Twins for External Services).

## Decision

**Twilio sends the SMS.** Messages go through Twilio's Messaging API
from a Messaging Service, so the sending numbers are Twilio's to rotate.

**One integration reaches it.** `integrations/sms/` holds
`SmsSenderInterface`: send one message to a number, with an idempotency
key; start and check a number's verification; and check a delivery
(`verify_delivery`) of Twilio's status callback by its
`X-Twilio-Signature`. Its impls are `twilio.py`, over the pinned
`twilio` SDK with a timeout from settings; `twin.py`, which keeps every
message in memory or on disk, accepts the verification code `000000`,
and signs its own synthetic status callbacks with Twilio's scheme; and
`absent.py`, where every call is `ProviderUnavailable`.
`FREE_JOURNALISM_SMS_PROVIDER` picks `twilio`, `twin`, or `none`; the
twin is refused at boot outside `local` and `test`. It lands with the
`notifications` namespace.

**The twin stands in wherever no account is configured.** Tests, CI,
and the local stack run the twin; there is no Twilio account and no
credential until a person sets `FREE_JOURNALISM_TWILIO_ACCOUNT_SID`,
`FREE_JOURNALISM_TWILIO_AUTH_TOKEN`, and
`FREE_JOURNALISM_TWILIO_MESSAGING_SERVICE_SID` for an environment.

**A number is used only after it is verified and opted in.** A person
adds a number, proves it with a code, and opts in per kind of
high-priority notification. A `STOP` reply that Twilio reports ends the
opt-in. The send is a work item, as email's is
([ADR 0084](0084-email-is-postmarks.md)), and its text never carries
what a source sent.

## Consequences

SMS is off for everyone until they opt in, so its cost is bounded by the
people who ask for it. The number is personal data of the person's own
org, erased with their account.
