#!/bin/sh
# Shared entrypoint for every Free Journalism image. The image's CMD names the
# console script and its subcommand; this file only prepares the process.
set -eu

# Fail fast on a missing database URL: every process needs storage, and the
# system scope reads on a login of its own. A missing one would fall back to
# the local default and point those reads at another database.
: "${FREE_JOURNALISM_DATABASE_URL:?FREE_JOURNALISM_DATABASE_URL must be set}"
: "${FREE_JOURNALISM_DATABASE_SYSTEM_URL:?FREE_JOURNALISM_DATABASE_SYSTEM_URL must be set}"

exec "$@"
