import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import type { AddJournalistRequest, JournalistPageView, JournalistView } from "@free_journalism/client";
import { api } from "../app/api";
import { keys } from "./keys";

/** A page size, not a ceiling: the list follows the cursor to the end. */
const JOURNALISTS_PAGE_SIZE = 200;

/** Every journalist of the desk, page after page, oldest first. The pages
 * loaded so far are returned as they arrive. */
export function useJournalists() {
  const query = useInfiniteQuery({
    queryKey: keys.journalists.list(JOURNALISTS_PAGE_SIZE),
    initialPageParam: null as string | null,
    getNextPageParam: (last: JournalistPageView) => last.next_cursor,
    queryFn: ({ pageParam, signal }) => {
      const cursor = pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : "";
      return api.get<JournalistPageView>(`/v1/journalists?limit=${JOURNALISTS_PAGE_SIZE}${cursor}`, { signal });
    },
  });
  const { hasNextPage, isFetchingNextPage, isFetchNextPageError, fetchNextPage } = query;
  // A page that failed is not asked for again on its own, as the member list's.
  const walking = hasNextPage && !isFetchNextPageError;
  useEffect(() => {
    if (walking && !isFetchingNextPage) void fetchNextPage();
  }, [walking, isFetchingNextPage, fetchNextPage]);
  return {
    ...query,
    data: query.data?.pages.flatMap((page) => page.items) as JournalistView[] | undefined,
    isPending: query.isPending || walking,
  };
}

/** Adds a journalist to the desk, once however often the request is sent. */
export function useAddJournalist() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: AddJournalistRequest) =>
      api.post<JournalistView>("/v1/journalists", body, { idempotencyKey: crypto.randomUUID() }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: keys.journalists.all }),
  });
}
