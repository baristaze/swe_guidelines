# Journalists

The journalists a desk holds, and the profile readers know each one by.
This is one of the kinds of thing
[Free Journalism is made of](../../../../README.md).

## What it holds

- **Journalist**: one journalist's profile at their desk: the display
  name readers see, who made the profile and when, and who changed it
  last. A desk is an org, and an org may hold more than one journalist,
  so a newsroom is a desk with several.

What a profile will also hold, as the product grows: a bio, the places
and topics the journalist covers, their published links and current
investigations, and the badge the platform gives a journalist it has
verified.

## What can happen

- **Add a journalist** to the desk. A member of the desk makes the
  profile, with its display name. Sending the same request twice makes
  one profile.
- **List** the desk's journalists, oldest first, a page at a time.
- **Read** one journalist's profile.
- **Change** a profile's display name. Who made the profile, and when,
  never change.
- **Sweep.** When a desk is deleted, its journalists go with it once the
  desk's retention has passed.

## The rules

- **A profile is its desk's.** A journalist of another desk is answered
  as one that never existed.
- **Viewers read; members write.** A viewer of the desk reads its
  journalists; a member, an admin, or the owner adds and changes them.
- **Changes carry ids.** What the platform announces about a change to
  a profile names the profile's id, never its name.
- **Following, supporting, and sending information are not here.** Each
  names a journalist, and none is needed for another: a reader who
  follows need not pay, and a source who sends need not follow.
