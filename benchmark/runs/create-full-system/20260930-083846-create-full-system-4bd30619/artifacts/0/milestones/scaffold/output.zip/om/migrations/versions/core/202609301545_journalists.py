"""Journalists: a journalist's profile at their desk, with its fence.

Revision ID: 202609301545
Revises: 202609280000
"""

from free_journalism.om.storage.migrate import run_sql
from free_journalism.om.storage.roles import DatabaseRole

revision = "202609301545"
down_revision = "202609280000"
branch_labels = None
depends_on = None


def upgrade() -> None:
    run_sql(DatabaseRole.CORE, "202609301545_journalists.up.sql")


def downgrade() -> None:
    run_sql(DatabaseRole.CORE, "202609301545_journalists.down.sql")
