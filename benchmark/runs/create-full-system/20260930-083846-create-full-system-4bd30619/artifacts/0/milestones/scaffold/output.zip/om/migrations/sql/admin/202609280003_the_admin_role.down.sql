-- Takes the admin role back to empty: the grants, then the size tally.

ALTER DEFAULT PRIVILEGES FOR ROLE free_journalism_migration IN SCHEMA admin
    REVOKE USAGE, SELECT ON SEQUENCES FROM free_journalism_runtime, free_journalism_system;
ALTER DEFAULT PRIVILEGES FOR ROLE free_journalism_migration IN SCHEMA admin
    REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM free_journalism_runtime, free_journalism_system;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA admin FROM free_journalism_runtime, free_journalism_system;
REVOKE ALL ON ALL TABLES IN SCHEMA admin FROM free_journalism_runtime, free_journalism_system;
REVOKE USAGE ON SCHEMA admin FROM free_journalism_runtime, free_journalism_system;

DROP TABLE admin.platform_sizes;
