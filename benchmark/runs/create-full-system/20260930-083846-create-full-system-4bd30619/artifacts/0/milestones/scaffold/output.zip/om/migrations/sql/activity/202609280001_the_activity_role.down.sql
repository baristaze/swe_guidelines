-- Takes the activity role back to empty: the grants, then the stream and its
-- cursors with their policies.

ALTER DEFAULT PRIVILEGES FOR ROLE free_journalism_migration IN SCHEMA activity
    REVOKE USAGE, SELECT ON SEQUENCES FROM free_journalism_runtime, free_journalism_system;
ALTER DEFAULT PRIVILEGES FOR ROLE free_journalism_migration IN SCHEMA activity
    REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM free_journalism_runtime, free_journalism_system;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA activity FROM free_journalism_runtime, free_journalism_system;
REVOKE ALL ON ALL TABLES IN SCHEMA activity FROM free_journalism_runtime, free_journalism_system;
REVOKE USAGE ON SCHEMA activity FROM free_journalism_runtime, free_journalism_system;

DROP TABLE activity.event_cursors;
DROP TABLE activity.events;
