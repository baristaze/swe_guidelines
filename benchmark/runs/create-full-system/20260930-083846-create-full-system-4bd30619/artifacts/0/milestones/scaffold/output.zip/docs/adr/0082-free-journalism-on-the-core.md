# ADR 0082: Free Journalism on the core: a journalist's desk is an org

**Status**: accepted (2026-09-30)

## Context

Free Journalism is a platform for supporting independent journalists
directly and for giving communities a safe channel to bring them
information. Its first release proves three loops: people follow and
financially support journalists; people send useful local information to
journalists; journalists use their inbox and write back.

The core it is built on holds tenancy with an operator plane, events and
audit, the outbox, idempotency, the work queue, orchestrations, and
files. Every row belongs to one org, and nothing in one org sees another
(The Second Fence). The product has to say what its people and places
are in those terms before its first namespace lands, since every table
after it is fenced by the answer.

Three facts of the product constrain the answer. A reader follows and
supports many journalists, each in their own place. A source may send
information with no account at all. A report is encrypted on the
sender's device for each recipient journalist, and the platform never
holds its plaintext or a journalist's private key.

## Decision

**An org is a journalist's desk.** A journalist's profile, their
updates, their inbox, their notes, their investigations, and the support
paid to them belong to the org the journalist works in. At first that is
the journalist's personal org, which the core makes at the first
sign-in. A newsroom, a team org holding several journalists, is outside
the first release, and nothing here rules it out: an org may hold more
than one journalist profile.

**A member is a person who works a desk.** The journalist is the owner
of their org. An assistant or an editor a journalist invites later is a
member with the core's role ladder. A reader is never a member of a
journalist's org.

**A reader is an identity, and their follows and support are the
journalist's rows.** A follow and a support payment land in the
journalist's org, naming the reader's identity. The journalist reads
them by org; the reader reads their own across desks through the
identity scope the core already fences (`ScopeKind.IDENTITY`), never by
reading another org. A reader's personal org holds only what is theirs
alone: their notification settings and their notification centre.

**A source is not an identity.** A report is sent through a public
route that takes no account. Each recipient journalist's org gets a
delivery row: its own wrapped copy of the report key and a reference to
the one ciphertext. The ciphertext is kept once, in the object store,
under a key no org owns, and removed when the last delivery that names
it is purged. A source who wants replies holds a follow-up secret their
device made; the platform keeps only its digest. The source's contact
method, if they give one, is encrypted to the recipients like the
report, so the platform keeps no source identity in the clear. Logs,
events, and telemetry of a source route carry no address, no user agent,
and no identifier of the sender.

**The platform never decrypts a report.** What the platform cannot read
it cannot process: metadata stripping (a photo's EXIF) and the choice of
what to send are the sender's client's, before encryption. The malware
check of an attachment of a report is the recipient's client's, by the
attachment's digest ([ADR 0086](0086-the-malware-scanner.md)). A report
becomes public only by a journalist's editorial action, which publishes
something new under the journalist's name; the report itself stays
private.

**An operator is the platform's trust and safety staff.** Journalist
verification, abuse and threat reports, blocks, and the retention of
sensitive submissions are worked on the operator plane, through
`/v1/admin/*` with an operator token
([ADR 0010](0010-operators-work-through-the-api.md)). An operator never
reads a report's contents, which the platform cannot decrypt, and every
journalist-side open of a report is an audit entry in the desk's stream.

**The core's pieces the product uses:**

| Piece | Used for |
|-------|----------|
| Tenancy | desks as orgs, readers and journalists as identities, sign-in through WorkOS AuthKit ([ADR 0028](0028-sign-in-is-the-identity-providers.md)) |
| Files | profile pictures and the media of a journalist's updates, which the platform sees; the ciphertext of a report and its attachments, which it does not |
| Orchestrations | a journalist's verification and onboarding, and their payouts account's onboarding at Stripe ([ADR 0083](0083-payments-are-stripes.md)) |
| Work queue | every notification delivery ([ADR 0084](0084-email-is-postmarks.md), [ADR 0085](0085-sms-is-twilios.md)), the malware scan ([ADR 0086](0086-the-malware-scanner.md)), the payment provider's webhooks, and the purge of a report past its retention |
| Events and audit | the journalist-side access trail of sensitive reports; the pushes that keep a journalist's inbox current |

**The first namespaces**, in the order the loops need them:

| Namespace | Holds | Loop |
|-----------|-------|------|
| `journalists` | the journalist's profile: display name, then bio, coverage areas, topics, links, and the verification badge | all three |
| `community` | follows and a journalist's updates to followers | follow and support |
| `support` | one-time and monthly support, receipts, refunds, and the desk's payouts account | follow and support |
| `reports` | a sent report's deliveries, their journalist-side state (`new`, `reviewing`, `follow-up`, `useful`, `archived`), notes, links to an investigation, and the source follow-up thread | send, and write back |
| `notifications` | the in-app centre, a person's channels and opt-ins, and the deliveries to email and SMS | all three |
| `safety` | verification requests, abuse and threat reports, blocks, rate limits past the gateway's, and retention settings | all three |

`journalists` lands first, with its `Journalist` entity: a `core`-role,
`org`-scoped row that is `Trackable`, since a journalist edits their
profile. It is not `SoftDeletable`: the first release closes no profile
on its own, and a profile goes with its desk, when the org is deleted
and the sweep purges the tenant. Closing a profile while the desk stays
is a delete operation, and the mixin, when a loop needs it. It carries
no version: one journalist edits their own
profile, so a lost update between two tabs of one person is accepted
until a desk has several editors. It has no unique key besides its id,
and its manager owns no field yet; the verification badge is a
manager-owned field when verification lands. The link from a journalist
to the person who writes as them, and the public directory a reader
browses across desks, come with verification: the directory is a read
model the journalists namespace publishes, never a read across orgs.

## Consequences

A reader who supports ten journalists has rows in ten orgs, each fenced
by the desk's `org_id` and readable to the reader only through the
identity scope. A screen that lists "journalists I follow" is an
identity-scoped read and never a join across tenants.

A source cannot be found through the platform: no row, log, or event
names them. What gives way is support: a source who loses their
follow-up secret cannot be recovered, and an operator cannot tell who
sent a report, even under a legal demand.

Anything that needs a report's plaintext (search over its text, a
server-side preview, a scan of its attachments by the platform) happens
on the journalist's client or does not happen. The inbox's server-side
search and filter run over what the platform may see: tags the
journalist sets, the delivery's state, its dates, and the approximate
location when the sender chose to send it in the clear.

A newsroom is a team org with several journalist profiles and its own
members, and needs no change to the tables the first release lands.
