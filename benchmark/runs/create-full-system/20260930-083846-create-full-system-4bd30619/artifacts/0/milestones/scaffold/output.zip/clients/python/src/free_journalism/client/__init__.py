"""The one Python client of the Free Journalism API. `types` is the facade over the
generated `schema`, `client` the one transport client, `realtime` the channel."""
