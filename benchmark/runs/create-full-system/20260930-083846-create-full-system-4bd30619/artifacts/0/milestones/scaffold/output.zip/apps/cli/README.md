# Free Journalism CLI

Free Journalism from the terminal. A command does one thing and returns; `listen`
stays and prints every change in the org as it happens.

```bash
uv run free_journalism login --org ajax        # confirm the code in the browser
uv run free_journalism login --dev-email bob@example.test --org ajax   # local stack only
uv run free_journalism whoami
uv run free_journalism orgs                    # * marks the session's org
uv run free_journalism switch fabrikam         # the old session ends
uv run free_journalism upload spec.pdf         # --type, --json
uv run free_journalism listen                  # who did what to which record
uv run free_journalism logout
```

## Conventions

- A dumb client: every command calls the API through `free_journalism.client` and
  shows the answer. A refusal prints the API's code, message, and request id.
- Exit codes: 0 done, 1 the API refused, 2 usage, 3 not signed in, 4 the
  API is unreachable. A setting the environment got wrong is usage.
- The session lives in `$FREE_JOURNALISM_HOME/session.json` (default `~/.config/free_journalism`,
  mode 600) and goes only to the API that issued it. `FREE_JOURNALISM_TOKEN` wins over
  it. `FREE_JOURNALISM_API_URL` or `--api` names the API. `FREE_JOURNALISM_HTTP_TIMEOUT_SECONDS`,
  `FREE_JOURNALISM_HTTP_RETRIES`, and `FREE_JOURNALISM_HTTP_RETRY_BACKOFF_SECONDS` tune the client.

## Test

```bash
uv run pytest -q apps/cli/tests
```
