import { AppNav } from "../../app/AppNav";
import { Banner, Button, Card, ErrorText, Muted, Page, Table, TextField } from "../../design/kit";
import { tokens } from "../../design/tokens";
import { journalistsLine } from "./journalistsModel";
import { useJournalistsVm } from "./useJournalistsVm";

export function JournalistsPage() {
  const vm = useJournalistsVm();
  return (
    <Page title="Journalists" nav={<AppNav />}>
      {vm.loadError ? <Banner>{vm.loadError.message}</Banner> : null}
      <Card title="The desk's journalists" id="journalists">
        {vm.loading ? (
          <Muted>Loading</Muted>
        ) : vm.rows.length === 0 ? (
          <Muted>No journalist works at this desk yet.</Muted>
        ) : (
          <>
            <Muted>{journalistsLine(vm.rows.length)}</Muted>
            <Table headers={["Name", "Added"]} rows={vm.rows.map((row) => [row.name, row.added])} />
          </>
        )}
        {vm.mayAdd ? (
          <form
            onSubmit={(event) => {
              event.preventDefault();
              void vm.submit();
            }}
            style={{ display: "flex", flexWrap: "wrap", gap: tokens.space.sm, alignItems: "end", marginTop: tokens.space.md }}
          >
            <TextField label="Display name" value={vm.name} onChange={vm.setName} />
            <Button type="submit" disabled={vm.adding}>
              {vm.adding ? "Adding…" : "Add journalist"}
            </Button>
          </form>
        ) : null}
        {vm.error ? <ErrorText>{vm.error}</ErrorText> : null}
      </Card>
    </Page>
  );
}
