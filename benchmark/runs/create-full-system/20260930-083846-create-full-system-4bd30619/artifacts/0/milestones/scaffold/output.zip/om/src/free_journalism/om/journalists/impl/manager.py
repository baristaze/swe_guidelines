from uuid import UUID

from free_journalism.om.base import PROVENANCE_FIELDS, Platform, utcnow
from free_journalism.om.context import Permission, TenantContext
from free_journalism.om.exceptions import NotFound, TenantMismatch
from free_journalism.om.journalists.manager import JournalistsManagerInterface
from free_journalism.om.journalists.storage import JournalistsStorageInterface
from free_journalism.om.journalists.types.journalist import Journalist
from free_journalism.om.journalists.types.page import JournalistPage
from free_journalism.om.outbox import OutboxRelayInterface
from free_journalism.om.outbox.types.row import outbox_row
from free_journalism.om.tenancy import TenancyManagerInterface


class JournalistsOptions(Platform):
    max_limit: int = 200
    purge_batch: int = 1000  # profiles one purge statement deletes at most


class JournalistsManagerImpl(JournalistsManagerInterface):
    def __init__(
        self,
        storage: JournalistsStorageInterface,
        tenancy: TenancyManagerInterface,
        relay: OutboxRelayInterface,
        options: JournalistsOptions,
    ) -> None:
        self._storage = storage
        self._tenancy = tenancy
        self._relay = relay
        self._options = options

    async def create_journalist(self, ctx: TenantContext, journalist: Journalist) -> Journalist:
        ctx.require(Permission.WRITE)
        now = utcnow()
        created = Journalist.model_validate(
            {
                **journalist.model_dump(),
                "created_at": now,
                "updated_at": now,
                "created_by": ctx.user_id,
                "updated_by": ctx.user_id,
            }
        )
        rows = (outbox_row(ctx, "journalists.journalist.created", created.id, {}),)  # ids only
        if not await self._storage.create_journalist(ctx.org_id, created, rows):
            # A retry under the same id: the row as stored is the answer.
            existing = await self._storage.read_journalist(ctx.org_id, created.id)
            if existing is None:
                raise TenantMismatch(f"journalist {created.id} is not in {ctx.org_id}")
            return existing
        await self._relay.relay_all(ctx.org_id, rows)
        return created

    async def get_journalist(self, ctx: TenantContext, journalist_id: UUID) -> Journalist:
        ctx.require(Permission.READ)
        journalist = await self._storage.read_journalist(ctx.org_id, journalist_id)
        if journalist is None:
            raise NotFound(f"journalist {journalist_id} not found")
        return journalist

    async def get_journalists(
        self, ctx: TenantContext, after: UUID | None, limit: int
    ) -> JournalistPage:
        ctx.require(Permission.READ)
        limit = max(1, min(limit, self._options.max_limit))
        rows = await self._storage.read_journalists(ctx.org_id, after, limit + 1)
        return JournalistPage(items=tuple(rows[:limit]), has_more=len(rows) > limit)

    async def update_journalist(self, ctx: TenantContext, journalist: Journalist) -> Journalist:
        ctx.require(Permission.WRITE)
        current = await self.get_journalist(ctx, journalist.id)
        changes = journalist.model_dump(
            exclude=set(PROVENANCE_FIELDS) | set(Journalist.MANAGER_OWNED_FIELDS)
        )
        updated = Journalist.model_validate(
            {
                **current.model_dump(),
                **changes,
                "updated_at": utcnow(),
                "updated_by": ctx.user_id,
            }
        )
        rows = (outbox_row(ctx, "journalists.journalist.updated", updated.id, {}),)
        await self._storage.write_journalist(ctx.org_id, updated, rows)
        await self._relay.relay_all(ctx.org_id, rows)
        return updated

    async def purge_tenant(self, ctx: TenantContext) -> int:
        ctx.require(Permission.WRITE)
        if not await self._tenancy.tenant_expired(ctx):
            return 0
        return await self._storage.purge_tenant(ctx.org_id, self._options.purge_batch)
