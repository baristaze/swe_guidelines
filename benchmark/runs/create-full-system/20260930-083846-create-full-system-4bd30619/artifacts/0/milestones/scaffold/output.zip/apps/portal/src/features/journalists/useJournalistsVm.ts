import { useMemo, useState } from "react";
import { errorMessage } from "../../app/errorMessage";
import { useAddJournalist, useJournalists } from "../../queries/journalists";
import { useMe } from "../../queries/tenancy";
import { useNoticesStore } from "../../store/notices";
import { canAddJournalists, checkDisplayName, journalistRows } from "./journalistsModel";

/** The desk's journalists, and the form a member adds one with. A push of
 * `journalists.journalist.*` refreshes the list on every open screen. */
export function useJournalistsVm() {
  const me = useMe();
  const journalists = useJournalists();
  const add = useAddJournalist();
  const notify = useNoticesStore((s) => s.notify);
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);

  const rows = useMemo(() => journalistRows(journalists.data ?? []), [journalists.data]);

  const submit = async () => {
    setError(null);
    const refused = checkDisplayName(name);
    if (refused) {
      setError(refused);
      return;
    }
    try {
      await add.mutateAsync({ display_name: name.trim() });
      setName("");
    } catch (caught) {
      notify(errorMessage(caught, "The journalist was not added."));
    }
  };

  return {
    loading: journalists.isPending,
    loadError: journalists.error,
    rows,
    mayAdd: canAddJournalists(me.data),
    name,
    setName,
    error,
    adding: add.isPending,
    submit,
  };
}
