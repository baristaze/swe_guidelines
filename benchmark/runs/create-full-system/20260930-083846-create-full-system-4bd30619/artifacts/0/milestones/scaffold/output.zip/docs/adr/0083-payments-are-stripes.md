# ADR 0083: Payments are Stripe's, through an integration and its twin

**Status**: accepted (2026-09-30)

## Context

Readers support journalists once or monthly, with suggested or custom
amounts. Journalists are paid out. The platform takes a fee, set apart
from the processor's fee. Readers see their payment history and
receipts, cancel a monthly support, and are refunded.

Holding card data, running payouts to people in many countries, and
keeping a recurring charge are products of their own. The guideline puts
a hosted service behind an interface with a real client and a
deterministic twin (Twins for External Services), refuses the twin
outside a local environment (What a Process Refuses), and checks an
inbound delivery at the edge before a worker applies it, as the identity
provider's webhook is checked
([ADR 0028](0028-sign-in-is-the-identity-providers.md)).

## Decision

**Stripe takes the money.** A support is a Stripe Checkout session: a
one-time payment, or a subscription for a monthly support. The portal
sends the reader to Stripe's hosted page; no card number reaches the
platform. A journalist's desk gets a Stripe Connect account (Express),
onboarded through Stripe's hosted onboarding as an orchestration that
parks until Stripe reports the account can take charges. A charge is a
destination charge to the desk's account, and the platform's fee is its
application fee, set by `FREE_JOURNALISM_PLATFORM_FEE_BASIS_POINTS`
apart from the processor's fee, which Stripe takes from the charge.

**One integration reaches it.** `integrations/payments/` holds
`PaymentsProviderInterface`: start a checkout, cancel a subscription,
refund a charge, create and link a connected account, and check a
delivery (`verify_delivery`). Its impls are `stripe.py`, over the
pinned `stripe` SDK; `twin.py`, which answers every call in memory,
mints ids that start with `twin_`, walks a checkout to paid on its own,
and signs its synthetic deliveries with Stripe's `Stripe-Signature`
scheme; and `absent.py`, where every call is `ProviderUnavailable`.
`FREE_JOURNALISM_PAYMENTS_PROVIDER` picks `stripe`, `twin`, or `none`
(the default); the twin is refused at boot outside `local` and `test`.
The integration lands with the `support` namespace, which is the only
caller.

**The twin stands in wherever no account is configured.** Tests, CI,
and the local stack run the twin. The real client is proven against
recorded fixtures of Stripe's wire shapes. There is no live account and
no key until a person makes one and sets `FREE_JOURNALISM_STRIPE_API_KEY`
and `FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET` as secrets of an environment.

**Stripe's word is final on money, and the desk's rows record it.**
`POST /webhooks/payments` checks the signature over the timestamp and
the body before anything is queued, and queues the delivery on
`Queues.WEBHOOKS`, keyed by a UUID v5 over Stripe's event id
([ADR 0027](0027-what-a-delivery-creates-takes-an-id-derived-from-it.md)).
The maintenance worker applies it to the desk's `support` rows: a paid
checkout becomes a payment and a receipt, a lapsed subscription ends the
patron badge, a refund marks the payment refunded. A route never marks a
payment paid on the browser's word.

## Consequences

Support is as available as Stripe is: when it cannot be reached, a
checkout answers `503`, and the rest of the product runs.

The platform keeps amounts, currencies, Stripe's ids, and states, never
card data, so it is outside the card industry's audit scope beyond
Stripe's hosted pages.

A journalist in a country Stripe Connect does not serve cannot be paid
out through the platform. Changing the processor is a new impl of the
interface and a migration of the connected accounts, not a change of
the `support` namespace.
