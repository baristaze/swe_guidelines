"""The Free Journalism object model: the single source of truth for the domain."""
