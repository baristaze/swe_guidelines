# ADR 0084: Email is Postmark's, sent by the worker through an integration and its twin

**Status**: accepted (2026-09-30)

## Context

The product sends email for a follow, a journalist's update, a support
receipt, and a reply to a source. The spec names Postmark or Resend for
transactional email, and asks that delivery not be coupled to the
application's logic. The guideline puts a hosted service behind an
interface with a real client and a twin (Twins for External Services),
and puts work that follows a write on the work queue, as a second outbox
row of the same write (The Work Queue).

## Decision

**Postmark sends the email.** Postmark is chosen over Resend for its
separate transactional message stream, its bounce and spam-complaint
webhooks, and its long record on deliverability of transactional mail.
Resend would serve as well; it is a second impl of the same interface if
it is ever wanted.

**One integration reaches it.** `integrations/email/` holds
`EmailSenderInterface`: send one message from a template, by a
recipient address and a template's variables, with an idempotency key;
and check a delivery (`verify_delivery`) of the bounce and complaint
webhook. Its impls are `postmark.py`, over Postmark's HTTP API with a
timeout from settings; `twin.py`, which keeps every sent message in
memory or on disk under the local stack's data folder, where the local
stack and the tests read them, and signs its own synthetic bounce
deliveries; and `absent.py`, where every send is `ProviderUnavailable`.
`FREE_JOURNALISM_EMAIL_PROVIDER` picks `postmark`, `twin`, or `none`;
the twin is refused at boot outside `local` and `test`. It lands with
the `notifications` namespace.

**The twin stands in wherever no account is configured.** Tests, CI,
and the local stack run the twin; there is no Postmark account and no
server token until a person sets `FREE_JOURNALISM_POSTMARK_SERVER_TOKEN`
as an environment's secret.

**A manager never sends an email.** A change that notifies writes a
work row of kind `SEND_NOTIFICATION` beside its own row, carrying ids
and never an address or a message's text. The maintenance worker claims
it, reads the recipient's address and the notification through their
managers, and sends it, with the work item's id as Postmark's
idempotency key, so a retried send is one email. A bounce or a
complaint marks the address undeliverable in `notifications`.

**An email never carries what a source sent.** A reply to a source
notifies them that a reply waits, with no text of it; the reply is read
in the follow-up thread, decrypted on the source's device.

## Consequences

An email is late by the queue's latency, never lost with its write: the
row and the work row commit together, and a failed send is retried and
dead-lettered by the queue.

When Postmark is down, the queue holds the sends, and nothing else of
the product waits on it.
