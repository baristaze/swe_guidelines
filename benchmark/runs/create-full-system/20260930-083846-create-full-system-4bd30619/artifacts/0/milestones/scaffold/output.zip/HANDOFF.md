# Handoff

Run of `arch-scaffold-new free_journalism --codeowners acme --first
journalists Journalist display_name:str` over `target/product-spec.md`
(the Independent Journalism Platform), guideline `0.45.0`.

## Done

- Name `free_journalism`, given in the arguments.
- Copied the scaffold with `new.py` (935 files, pinned at v0.45.0). The
  base was not recorded, since the plugin is not a clean checkout, so the
  repository has no commit yet; `arch-upgrade-scaffold` grafts the base on
  its first move. `make setup` and `make check` were green on the copy.
- Docker runs. `.env` copied from `.env.example`; every port knob was
  free, so no value in `.env` changed.
- ADRs:
  - 0082: the product on the core. A desk is an org, a reader is an
    identity, a source is neither. The platform never decrypts a report.
    Lists the first namespaces.
  - 0083: Stripe (Checkout, Connect Express, the platform fee as the
    application fee), `integrations/payments/`, with a twin.
  - 0084: Postmark (chosen over Resend), `integrations/email/`, with a
    twin; sends go through the work queue.
  - 0085: Twilio, `integrations/sms/`, with a twin; only to a verified
    number that opted in.
  - 0086: the malware scanner, `integrations/scanning/`, with a twin.
    Files the platform can read are scanned whole; a report's attachments
    are checked by digest on the journalist's client. The real provider
    is chosen when the real client is written, against the conditions
    the ADR states.
- The README opening, the llms.txt summary, and `.github/CODEOWNERS`
  (`@acme` on every rule).
- The `journalists` namespace and its `Journalist` entity (`core` role,
  `org` scope, `Trackable`, no version, no unique key besides the id, no
  manager-owned field):
  - the OM type, the table, and the migration `core/202609301545_journalists`
    with its `tenant_fence` policy;
  - the Postgres and memory storage, the manager (create, get, list,
    update, purge_tenant), and the roots;
  - the worker's per-tenant purge;
  - the API routes (`/v1/journalists`, `/v1/journalists/{id}`);
  - the regenerated clients;
  - the portal screen `/journalists`, linked from Home;
  - the contract, unit, integration, API, and portal tests.
- Gates, first run, all green: `make infra-up`, `make migrate`,
  `make openapi` (once, before the screen), `make check`,
  `make migrate-check`, `make test-integration`.

## Decided

Each decision is in the ADRs above. The entity's choices are in ADR 0082:
not `SoftDeletable`, since a profile goes with its desk, and no version.

## Left

- Nothing is committed. The first commit is the person's to make.
- The namespaces 0082 lists, in order: `community`, `support`, `reports`,
  `notifications`, `safety`. Each integration lands with the namespace
  that needs it (0083 to 0086).
- The public directory of journalists across desks, and the link from a
  journalist to the person who writes as them, both come with
  verification (ADR 0082).
- The placeholder GitHub repository `free-journalism-org/free_journalism`
  in `deployment/cloud/environments.json` and in the site's test is the
  person's to set.
