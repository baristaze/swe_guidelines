-- Takes the journalists table back out: its policy, then the table with its
-- index.

DROP POLICY tenant_fence ON core.journalists;
DROP TABLE core.journalists;
