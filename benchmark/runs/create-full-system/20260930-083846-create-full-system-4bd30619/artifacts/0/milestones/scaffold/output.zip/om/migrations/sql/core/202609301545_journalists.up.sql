-- Journalists: a journalist's profile at their desk, the org (ADR 0082).
--
-- The table opens with its mixin header in house-style order: the id, the
-- tenant, the provenance. Its policy is the core role's `tenant_fence` on
-- `org_id`, forced on the table's owner too, with the system login's clause
-- for the sweep. The grants come from the role's first migration, by default
-- privilege.

CREATE TABLE core.journalists (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid NOT NULL,
    display_name text NOT NULL,
    CONSTRAINT pk_journalists PRIMARY KEY (id)
);
CREATE INDEX ix_journalists_org_id_id ON core.journalists (org_id, id);

ALTER TABLE core.journalists ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.journalists FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON core.journalists
    USING (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    )
    WITH CHECK (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    );
