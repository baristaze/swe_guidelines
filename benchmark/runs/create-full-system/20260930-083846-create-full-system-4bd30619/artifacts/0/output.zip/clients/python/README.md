# Free Journalism Python client

The one Python client of the Free Journalism API. Every Python consumer goes through
it, and nothing else in Python calls `/v1/*`.

- `schema.py` is generated from `clients/typescript/openapi.json` by
  `make openapi`. Never edit it by hand.
- `types.py` is the facade consumers import: the views and enums by name.
- `client.py` is the one transport. Every call carries the bearer (a
  source's call, none), the app headers, and a timeout. A creating call
  carries an idempotency key. A failure that can differ is retried with
  jittered backoff. A refusal is an `ApiError` with its code and request id.
  TLS uses the system trust store.
- `envelopes.py`, `stream.py`, and `realtime.py` are the socket's frames,
  the placement rule, and the channel, which yields every change once, in
  stream order.
- `sealing.py` seals a report and a thread's messages on the device, below.

```python
async with ApiClient(url, app="cli", app_version="cli@0.1.0", token=token) as api:
    stored = await api.upload(await api.start_upload("spec.pdf", "application/pdf", size), data)
    async for change in Channel(api):
        print(change.kind, change.target_id, change.actor_id)
```

## Sealing, and the source's calls

`sealing.py` is the device side of a report's envelope encryption (ADR 0082:
the platform never decrypts a report). Every report gets a fresh 256-bit key
and is encrypted once with AES-256-GCM; that key is wrapped to each
journalist's X25519 public key (an ephemeral key pair per wrap, HKDF-SHA256,
AES-256-GCM). A thread's message is the same wrap to one key. Keys are the
standard base64 of 32 bytes. Anything that fails to open is one
`SealingError`.

- `generate_key_pair()`: a journalist's pair (the public half goes on the
  profile through `add_journalist` or `update_journalist`), or the source's
  pair a reply is sealed to.
- `seal_report` / `open_report`, `seal_message` / `open_message`.
- `new_follow_up()`: the source's secret, kept on the device, and its digest,
  sent with the report. `report_digest` is what the journalist's device
  checks a downloaded report against.

A source holds no account, so its calls carry no bearer whatever token the
client holds (ADR 0087): `public_journalist`, `send_report` (seal and `PUT`
in one; `put_report` for bytes sealed already), `source_thread`, and
`send_follow_up`, the last two with the secret in `X-Follow-Up-Secret`.
What a source sends is a `PUT` of an id its device minted, so a send that
failed is sent again with the same ids.

```python
source = ApiClient(url, app="cli", app_version="cli@0.1.0")
ann = await source.public_journalist(desk_id, journalist_id)
follow_up, reply_key = new_follow_up(), generate_key_pair()
sent = await source.send_report(uuid7(), report, [ann], follow_up=follow_up, reply_key=reply_key)
ref = sent.deliveries[0]
thread = await source.source_thread(ref.org_id, ref.delivery_id, follow_up.secret)
replies = [open_message(m.ciphertext, reply_key.private_key) for m in thread.items]
```

The desk's side runs on its session: `inbox` (by state and tag), `delivery`,
`sealed_report` (the bytes, to check against `report_digest` and open with
`open_report`), `update_delivery`, `messages`, and `reply`, sealed to the
delivery's `source_public_key`.

```bash
uv run pytest -q clients/python/tests
```
