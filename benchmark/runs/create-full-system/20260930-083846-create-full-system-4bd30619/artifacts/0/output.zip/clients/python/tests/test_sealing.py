"""The device's sealing: a report opens for each of its recipients and for
nobody else, a changed byte opens for no one, and the follow-up secret's
digest is what the API compares."""

import base64
import hashlib

import pytest

from free_journalism.client.sealing import (
    FollowUp,
    SealingError,
    follow_up_digest,
    generate_key_pair,
    new_follow_up,
    open_message,
    open_report,
    report_digest,
    seal_message,
    seal_report,
)

REPORT = b'{"subject": "The bridge", "description": "The inspection was skipped."}'


def _flip(data: bytes, at: int) -> bytes:
    return data[:at] + bytes([data[at] ^ 1]) + data[at + 1 :]


def _flip_b64(value: str, at: int) -> str:
    return base64.b64encode(_flip(base64.b64decode(value), at)).decode()


def test_a_report_opens_for_each_of_three_recipients_with_their_own_key() -> None:
    pairs = {label: generate_key_pair() for label in ("ann", "bob", "cem")}
    sealed = seal_report(REPORT, {label: pair.public_key for label, pair in pairs.items()})
    assert set(sealed.wrapped_keys) == {"ann", "bob", "cem"}
    assert REPORT not in sealed.ciphertext
    for label, pair in pairs.items():
        assert (
            open_report(sealed.ciphertext, sealed.wrapped_keys[label], pair.private_key) == REPORT
        )


def test_one_recipients_key_does_not_open_anothers_wrapped_key() -> None:
    ann, bob, eve = generate_key_pair(), generate_key_pair(), generate_key_pair()
    sealed = seal_report(REPORT, {"ann": ann.public_key, "bob": bob.public_key})
    with pytest.raises(SealingError):
        open_report(sealed.ciphertext, sealed.wrapped_keys["ann"], bob.private_key)
    with pytest.raises(SealingError):
        open_report(sealed.ciphertext, sealed.wrapped_keys["bob"], eve.private_key)


@pytest.mark.parametrize("at", [0, 12, -1])
def test_a_tampered_ciphertext_is_refused(at: int) -> None:
    ann = generate_key_pair()
    sealed = seal_report(REPORT, {"ann": ann.public_key})
    tampered = _flip(sealed.ciphertext, at % len(sealed.ciphertext))
    with pytest.raises(SealingError):
        open_report(tampered, sealed.wrapped_keys["ann"], ann.private_key)
    with pytest.raises(SealingError):
        open_report(sealed.ciphertext[:20], sealed.wrapped_keys["ann"], ann.private_key)


@pytest.mark.parametrize("at", [0, 32, 50, -1])
def test_a_tampered_wrapped_key_is_refused(at: int) -> None:
    """The ephemeral key, the nonce, the sealed key, and the tag each hold."""
    ann = generate_key_pair()
    sealed = seal_report(REPORT, {"ann": ann.public_key})
    wrapped = sealed.wrapped_keys["ann"]
    tampered = _flip_b64(wrapped, at % len(base64.b64decode(wrapped)))
    with pytest.raises(SealingError):
        open_report(sealed.ciphertext, tampered, ann.private_key)


@pytest.mark.parametrize("wrapped", ["", "not base64!", base64.b64encode(b"short").decode()])
def test_a_malformed_wrapped_key_is_the_same_error(wrapped: str) -> None:
    ann = generate_key_pair()
    sealed = seal_report(REPORT, {"ann": ann.public_key})
    with pytest.raises(SealingError):
        open_report(sealed.ciphertext, wrapped, ann.private_key)


def test_every_report_gets_a_fresh_key() -> None:
    ann = generate_key_pair()
    first = seal_report(REPORT, {"ann": ann.public_key})
    second = seal_report(REPORT, {"ann": ann.public_key})
    assert first.ciphertext != second.ciphertext
    assert first.wrapped_keys["ann"] != second.wrapped_keys["ann"]
    with pytest.raises(SealingError):  # one report's key opens no other report
        open_report(second.ciphertext, first.wrapped_keys["ann"], ann.private_key)


def test_a_report_needs_a_recipient_with_a_real_key() -> None:
    with pytest.raises(SealingError):
        seal_report(REPORT, {})
    with pytest.raises(SealingError):
        seal_report(REPORT, {"ann": base64.b64encode(b"x" * 16).decode()})
    with pytest.raises(SealingError):
        seal_report(REPORT, {"ann": "not a key at all, and not base64 either!!!!"})


def test_a_message_opens_for_its_one_recipient() -> None:
    source, journalist = generate_key_pair(), generate_key_pair()
    sealed = seal_message(b"Can you send the minutes?", source.public_key)
    base64.b64decode(sealed, validate=True)  # standard base64 on the wire
    assert open_message(sealed, source.private_key) == b"Can you send the minutes?"
    with pytest.raises(SealingError):
        open_message(sealed, journalist.private_key)
    with pytest.raises(SealingError):
        open_message(_flip_b64(sealed, 40), source.private_key)


def test_the_follow_up_digest_is_the_sha256_the_api_compares() -> None:
    follow_up = new_follow_up()
    assert isinstance(follow_up, FollowUp)
    assert len(follow_up.secret) == 43 and "=" not in follow_up.secret
    base64.urlsafe_b64decode(follow_up.secret + "=")
    assert follow_up.digest == hashlib.sha256(follow_up.secret.encode()).hexdigest()
    assert follow_up_digest(follow_up.secret) == follow_up.digest
    assert new_follow_up().secret != follow_up.secret
    assert follow_up.secret not in repr(follow_up)


def test_the_report_digest_is_the_sha256_of_the_ciphertext() -> None:
    sealed = seal_report(REPORT, {"ann": generate_key_pair().public_key})
    assert report_digest(sealed.ciphertext) == hashlib.sha256(sealed.ciphertext).hexdigest()


def test_keys_are_44_characters_of_standard_base64_of_32_bytes() -> None:
    pair = generate_key_pair()
    for key in (pair.public_key, pair.private_key):
        assert len(key) == 44
        assert len(base64.b64decode(key, validate=True)) == 32
    assert pair.private_key not in repr(pair)
    assert generate_key_pair().public_key != pair.public_key
