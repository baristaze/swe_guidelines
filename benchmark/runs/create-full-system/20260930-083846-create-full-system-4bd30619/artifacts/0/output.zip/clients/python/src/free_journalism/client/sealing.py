"""The device side of the report's envelope encryption: what a source's device
seals and what a journalist's device opens. The platform holds none of the
keys and never runs this code on a report (ADR 0082).

The scheme:

- Every report gets a fresh random 256-bit report key. The whole report, the
  caller's bytes (subject, description, attachments, tags, the optional
  location and time, the optional contact: the caller builds that document),
  is encrypted once with AES-256-GCM under it, with a 12-byte random nonce.
  The ciphertext is `nonce || ct+tag`.
- The report key is wrapped separately to each recipient's X25519 public
  key. Each wrap makes an ephemeral X25519 key pair; the shared secret goes
  through HKDF-SHA256 (info `WRAP_INFO`, salt `ephemeral public || recipient
  public`) to a 256-bit key-encryption key, and AES-256-GCM seals the report
  key under it. A wrapped key is `base64(ephemeral public || nonce ||
  ct+tag)`.
- A message of the follow-up thread is the same wrap over the message's own
  bytes, to one recipient, in base64 on the wire.
- Keys on the wire are the standard base64 of their 32 raw bytes, 44
  characters, which is what the API validates.

The follow-up secret is 32 random bytes in URL-safe base64 without padding;
the API keeps and compares only the SHA-256, in lower-case hex, of its UTF-8
bytes. A report's digest is the SHA-256 of its ciphertext, which the
delivery carries so the journalist's device checks what it downloaded.

Any failure to open is one `SealingError`, whatever the cause: a wrong key,
a tampered byte, and a malformed input all read the same."""

import base64
import binascii
import hashlib
import secrets
from collections.abc import Mapping
from dataclasses import dataclass, field

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

WRAP_INFO = b"free-journalism report key v1"
"""The HKDF label of a wrap; a later scheme names another, so no key
derived under one is ever taken for a key of the other."""
KEY_BYTES = 32
"""An X25519 key, a report key, and a key-encryption key are all 32 bytes."""
NONCE_BYTES = 12
TAG_BYTES = 16
FOLLOW_UP_SECRET_BYTES = 32


class SealingError(Exception):
    """Something could not be sealed or opened. One error for every cause, so
    a caller learns nothing from which check failed."""


@dataclass(frozen=True)
class KeyPair:
    """An X25519 key pair in standard base64. The private half never leaves
    the device that made it; the public half is what a journalist's profile
    or a source's report carries."""

    private_key: str = field(repr=False)
    public_key: str


@dataclass(frozen=True)
class SealedReport:
    """A report sealed once, and its key wrapped to each recipient, under the
    label the caller chose for that recipient."""

    ciphertext: bytes
    wrapped_keys: dict[str, str]


@dataclass(frozen=True)
class FollowUp:
    """The source's follow-up secret, which stays on their device and rides
    in `X-Follow-Up-Secret`, and its digest, which the report carries."""

    secret: str = field(repr=False)
    digest: str


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _unb64(value: str) -> bytes:
    try:
        return base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as error:
        raise SealingError("not standard base64") from error


def _public_key(value: str) -> X25519PublicKey:
    raw = _unb64(value)
    if len(raw) != KEY_BYTES:
        raise SealingError("a public key is 32 bytes")
    return X25519PublicKey.from_public_bytes(raw)


def _private_key(value: str) -> X25519PrivateKey:
    raw = _unb64(value)
    if len(raw) != KEY_BYTES:
        raise SealingError("a private key is 32 bytes")
    return X25519PrivateKey.from_private_bytes(raw)


def _raw(key: X25519PublicKey) -> bytes:
    return key.public_bytes_raw()


def _kek(shared: bytes, ephemeral_public: bytes, recipient_public: bytes) -> bytes:
    return HKDF(
        algorithm=hashes.SHA256(),
        length=KEY_BYTES,
        salt=ephemeral_public + recipient_public,
        info=WRAP_INFO,
    ).derive(shared)


def _encrypt(key: bytes, plaintext: bytes) -> bytes:
    nonce = secrets.token_bytes(NONCE_BYTES)
    return nonce + AESGCM(key).encrypt(nonce, plaintext, None)


def _decrypt(key: bytes, sealed: bytes) -> bytes:
    if len(sealed) < NONCE_BYTES + TAG_BYTES:
        raise SealingError("too short to be sealed")
    try:
        return AESGCM(key).decrypt(sealed[:NONCE_BYTES], sealed[NONCE_BYTES:], None)
    except InvalidTag as error:
        raise SealingError("could not be opened") from error


def _wrap(plaintext: bytes, public_key: str) -> str:
    recipient = _public_key(public_key)
    ephemeral = X25519PrivateKey.generate()
    ephemeral_public = _raw(ephemeral.public_key())
    try:
        shared = ephemeral.exchange(recipient)
    except ValueError as error:  # a low-order point: no key agreement
        raise SealingError("not a usable public key") from error
    kek = _kek(shared, ephemeral_public, _raw(recipient))
    return _b64(ephemeral_public + _encrypt(kek, plaintext))


def _unwrap(wrapped: str, private_key: str) -> bytes:
    raw = _unb64(wrapped)
    if len(raw) < KEY_BYTES + NONCE_BYTES + TAG_BYTES:
        raise SealingError("too short to be a wrap")
    own = _private_key(private_key)
    ephemeral_public = raw[:KEY_BYTES]
    try:
        shared = own.exchange(X25519PublicKey.from_public_bytes(ephemeral_public))
    except ValueError as error:
        raise SealingError("could not be opened") from error
    kek = _kek(shared, ephemeral_public, _raw(own.public_key()))
    return _decrypt(kek, raw[KEY_BYTES:])


def generate_key_pair() -> KeyPair:
    """A fresh X25519 key pair: a journalist's, whose public half goes on
    their profile, or a source's, which a reply is sealed to."""
    private = X25519PrivateKey.generate()
    return KeyPair(
        private_key=_b64(private.private_bytes_raw()),
        public_key=_b64(_raw(private.public_key())),
    )


def seal_report(plaintext: bytes, recipients: Mapping[str, str]) -> SealedReport:
    """The report encrypted once under a fresh key, and that key wrapped to
    each recipient's public key, by the label the caller gave it (a
    journalist's id, say). At least one recipient; a key that is not a
    32-byte X25519 key in standard base64 is a `SealingError`."""
    if not recipients:
        raise SealingError("a report is sealed for at least one recipient")
    report_key = secrets.token_bytes(KEY_BYTES)
    wrapped = {label: _wrap(report_key, key) for label, key in recipients.items()}
    return SealedReport(ciphertext=_encrypt(report_key, plaintext), wrapped_keys=wrapped)


def open_report(ciphertext: bytes, wrapped_key: str, private_key: str) -> bytes:
    """The report's bytes, by the recipient's own wrapped key and private key.
    Any failure, another journalist's key among them, is a `SealingError`."""
    try:
        return _decrypt(_unwrap(wrapped_key, private_key), ciphertext)
    except SealingError:
        raise
    except ValueError as error:
        raise SealingError("could not be opened") from error


def seal_message(plaintext: bytes, public_key: str) -> str:
    """One message of the thread sealed to one public key, in base64: a
    journalist's reply to the source's key, or the source's to the
    journalist's."""
    return _wrap(plaintext, public_key)


def open_message(sealed: str, private_key: str) -> bytes:
    """A message sealed to this private key's public half; any failure is a
    `SealingError`."""
    try:
        return _unwrap(sealed, private_key)
    except SealingError:
        raise
    except ValueError as error:
        raise SealingError("could not be opened") from error


def follow_up_digest(secret: str) -> str:
    """The SHA-256, in lower-case hex, of the secret's UTF-8 bytes: what the
    report carries and what the API compares."""
    return hashlib.sha256(secret.encode("utf-8")).hexdigest()


def new_follow_up() -> FollowUp:
    """A fresh follow-up secret, 43 characters of URL-safe base64, and its
    digest."""
    secret = secrets.token_urlsafe(FOLLOW_UP_SECRET_BYTES)
    return FollowUp(secret=secret, digest=follow_up_digest(secret))


def report_digest(ciphertext: bytes) -> str:
    """The SHA-256, in lower-case hex, of a sealed report: the delivery's
    `report_digest`, which the journalist's device checks its download
    against before opening it."""
    return hashlib.sha256(ciphertext).hexdigest()
