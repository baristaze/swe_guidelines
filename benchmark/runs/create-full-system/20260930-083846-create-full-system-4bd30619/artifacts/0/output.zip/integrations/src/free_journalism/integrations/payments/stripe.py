"""The payments provider's real client: Stripe, through its Python SDK.

A support is a Stripe Checkout session on Stripe's hosted page: a one-time
support is a session in `payment` mode, and a monthly one a session in
`subscription` mode whose price recurs every month. The amount is an inline
price (`price_data`), so no product or price is kept at Stripe ahead of
time. The session carries the support's id as its `client_reference_id`,
and the support's and the desk's ids as its `metadata`, copied onto the
payment or the subscription it makes, so every delivery about it names
them again (ADR 0083).

The application fee is carried and not sent. Stripe takes an application
fee only on a charge made for a connected account, a destination charge
whose `transfer_data.destination` names the desk's Stripe Connect account,
and the desks' connected accounts come with Connect onboarding, which is
outside this first cut. Until a desk has one, a checkout is a charge on the
platform's own account, and Stripe refuses an application fee on it; when
the destination lands on `CheckoutRequest`, this impl sends it with the fee,
`payment_intent_data.application_fee_amount` for a one-time support and
`subscription_data.application_fee_percent` for a monthly one.

This process holds one credential: the platform account's secret key, a
restricted key that may write Checkout sessions in a deployed environment.
It never leaves this module, and no message names it.

The SDK's own HTTP client is replaced by one this impl owns, over the
process's `httpx` client, and every attempt is sent with the timeout from
settings. The SDK keeps its retries: it retries a failed connection, a 409,
and a server error, with a backoff of half a second doubling to five, and
sends one idempotency key with every attempt of a call, so a retried call
opens one session. Every SDK error is translated here; none crosses the
boundary. The API version is the one the pinned SDK names.

A call a request makes carries the request's deadline (ADR 0069), and goes
through an SDK client whose transport keeps to it: each attempt is sent
with the smaller of the timeout and what is left, and none goes out with
nothing left. The call itself is cut at the deadline, attempt or backoff,
and is then `ProviderUnavailable`, as a Stripe that does not answer is."""

import asyncio
from collections.abc import Mapping
from datetime import datetime, timedelta
from typing import Any, NoReturn, cast

import httpx
from stripe import (
    APIConnectionError,
    AuthenticationError,
    HTTPClient,
    IdempotencyError,
    InvalidRequestError,
    PermissionError,
    RateLimitError,
    StripeClient,
    StripeError,
)
from stripe.params.checkout import SessionCreateParams

from free_journalism.infra.deadline import DeadlineReached, bounded, seconds_left
from free_journalism.integrations.exceptions import (
    ProviderConflict,
    ProviderRefused,
    ProviderUnavailable,
)
from free_journalism.integrations.payments import (
    Cadence,
    Checkout,
    CheckoutRequest,
    PaymentDelivery,
    PaymentsProviderInterface,
)
from free_journalism.integrations.payments.deliveries import verified

STRIPE_API = "https://api.stripe.com"
PRODUCT_NAMES = {Cadence.ONE_TIME: "One-time support", Cadence.MONTHLY: "Monthly support"}
"""What the reader sees the line called on Stripe's page."""


class OwnedHttpx(HTTPClient):
    """The SDK's transport: the process's HTTP client, with the timeout from
    settings on every attempt, and, for the calls of one request, its
    deadline. An attempt goes out with the smaller of the timeout and what
    is left, and none goes out with nothing left. A failure to connect or to
    read is the SDK's connection error, which it retries. The client it
    borrows is the impl's, which closes it."""

    name = "httpx"

    def __init__(
        self, http: httpx.AsyncClient, timeout: float, deadline: datetime | None = None
    ) -> None:
        super().__init__()
        self._http = http
        self._timeout = timeout
        self._deadline = deadline

    def _attempt_timeout(self) -> float:
        left = seconds_left(self._deadline)
        if left is None:
            return self._timeout
        if left <= 0:
            raise DeadlineReached("no time is left for another attempt")
        return min(self._timeout, left)

    async def request_async(
        self, method: str, url: str, headers: Mapping[str, str], post_data: Any = None
    ) -> tuple[bytes, int, Mapping[str, str]]:
        timeout = self._attempt_timeout()
        try:
            response = await self._http.request(
                method, url, headers=dict(headers), content=post_data, timeout=timeout
            )
        except httpx.HTTPError as error:
            raise APIConnectionError(
                f"Stripe did not answer ({type(error).__name__})", should_retry=True
            ) from error
        return response.content, response.status_code, response.headers

    def sleep_async(self, secs: float) -> Any:
        return asyncio.sleep(secs)

    async def close_async(self) -> None:
        return None

    def close(self) -> None:
        return None


def _translate(error: Exception, doing: str) -> NoReturn:
    """Every SDK error as an integration exception, naming what was being
    done and never the key."""
    if isinstance(error, (AuthenticationError, PermissionError)):
        # The process's credential, not the reader's request: revoked,
        # rolled, or without the permission. A 503 until a person fixes it
        # (ADR 0051).
        raise ProviderUnavailable(
            f"{doing}: Stripe refused FREE_JOURNALISM_STRIPE_API_KEY ({error.http_status})"
        ) from None
    if isinstance(error, (RateLimitError, APIConnectionError)):
        raise ProviderUnavailable(f"{doing}: {type(error).__name__}") from None
    if isinstance(error, IdempotencyError):
        raise ProviderConflict(f"{doing}: {error.user_message or 'idempotency_error'}") from None
    if isinstance(error, InvalidRequestError):
        detail = error.code or error.user_message or "invalid_request_error"
        where = f" ({error.param})" if error.param else ""
        raise ProviderRefused(f"{doing}: {detail}{where}") from None
    if isinstance(error, StripeError):
        if error.http_status is None or error.http_status >= 500:
            raise ProviderUnavailable(
                f"{doing}: Stripe answered {error.http_status or 'nothing'}"
            ) from None
        raise ProviderRefused(f"{doing}: {error.code or error.http_status}") from None
    if isinstance(error, httpx.HTTPError):
        raise ProviderUnavailable(f"{doing}: {type(error).__name__}") from None
    raise error


def session_params(request: CheckoutRequest) -> SessionCreateParams:
    """The session Stripe is asked to open for a checkout: an inline price of
    the amount, once or every month, and the support's and the desk's ids on
    the session and on what it makes. The application fee is not among them
    (the module says why)."""
    metadata = {"support_id": str(request.reference), "org_id": str(request.org_id)}
    monthly = request.cadence is Cadence.MONTHLY
    price: dict[str, Any] = {
        "currency": request.currency,
        "unit_amount": request.amount,
        "product_data": {"name": PRODUCT_NAMES[request.cadence]},
    }
    if monthly:
        price["recurring"] = {"interval": "month"}
    params: dict[str, Any] = {
        "mode": "subscription" if monthly else "payment",
        "line_items": [{"price_data": price, "quantity": 1}],
        "success_url": request.success_url,
        "cancel_url": request.cancel_url,
        "client_reference_id": str(request.reference),
        "metadata": metadata,
    }
    if monthly:
        params["subscription_data"] = {"metadata": metadata}
    else:
        params["payment_intent_data"] = {"metadata": metadata}
    return cast(SessionCreateParams, params)


class PaymentsProviderStripeImpl(PaymentsProviderInterface):
    def __init__(
        self,
        *,
        api_key: str,
        timeout: timedelta,
        base_url: str = STRIPE_API,
        max_retries: int = 2,
        transport: httpx.AsyncBaseTransport | None = None,
        webhook_secret: str | None = None,
    ) -> None:
        if not api_key:
            # The SDK would fall back to a module-level key; this impl never
            # lets it choose a credential of its own.
            raise ValueError("Stripe needs its API key")
        self._api_key = api_key
        self._webhook_secret = webhook_secret
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout.total_seconds()
        self._max_retries = max_retries
        self._http = httpx.AsyncClient(timeout=self._timeout, transport=transport)

    def _sdk(self, deadline: datetime | None) -> StripeClient:
        """One client, one credential, over the process's HTTP client; under a
        request's deadline, every attempt keeps to it."""
        return StripeClient(
            self._api_key,
            base_addresses={"api": self._base_url},
            max_network_retries=self._max_retries,
            http_client=OwnedHttpx(self._http, self._timeout, deadline),
        )

    @property
    def configured(self) -> bool:
        return True

    async def open_checkout(
        self, request: CheckoutRequest, *, deadline: datetime | None = None
    ) -> Checkout:
        doing = "opening the checkout"
        try:
            async with bounded(deadline, lambda reason: ProviderUnavailable(f"{doing}: {reason}")):
                session = await self._sdk(deadline).v1.checkout.sessions.create_async(
                    session_params(request)
                )
        except (StripeError, httpx.HTTPError) as error:
            _translate(error, doing)
        if not session.url:
            raise ProviderRefused(f"{doing}: Stripe answered session {session.id} with no page")
        return Checkout(id=session.id, url=session.url)

    def verify_delivery(self, payload: bytes, signature: str) -> PaymentDelivery:
        if self._webhook_secret is None:
            raise ProviderUnavailable("FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET is not set")
        return verified(payload, signature, self._webhook_secret)

    def describe(self) -> str:
        mode = "live" if self._api_key.startswith(("sk_live_", "rk_live_")) else "test"
        return f"payments provider: Stripe ({self._base_url}, {mode} mode)"

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        await self._http.aclose()
