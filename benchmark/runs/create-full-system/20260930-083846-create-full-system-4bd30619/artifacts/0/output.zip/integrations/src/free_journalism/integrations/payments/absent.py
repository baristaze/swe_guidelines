"""The provider of a process whose environment names none: every call is
refused as unavailable, and no money is taken."""

from datetime import datetime
from typing import NoReturn

from free_journalism.integrations.exceptions import ProviderUnavailable
from free_journalism.integrations.payments import (
    Checkout,
    CheckoutRequest,
    PaymentDelivery,
    PaymentsProviderInterface,
)


class PaymentsProviderAbsentImpl(PaymentsProviderInterface):
    def __init__(self, reason: str = "no payments provider is configured") -> None:
        self._reason = reason

    def _refuse(self) -> NoReturn:
        raise ProviderUnavailable(self._reason)

    @property
    def configured(self) -> bool:
        return False

    async def open_checkout(
        self, request: CheckoutRequest, *, deadline: datetime | None = None
    ) -> Checkout:
        self._refuse()

    def verify_delivery(self, payload: bytes, signature: str) -> PaymentDelivery:
        self._refuse()

    def describe(self) -> str:
        return f"payments provider: none ({self._reason})"

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None
