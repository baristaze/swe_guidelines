"""The payments provider's twin: deterministic, in-process, and for a local
environment only (the configured root refuses it anywhere else). It keeps
every checkout it opened in memory, with the request it was opened for.

A test or a local process drives the reader's and the provider's side
through the twin's own methods: `complete` stands for a reader paying on the
hosted page, `expire` for a checkout left to lapse, and `signed_event` for
any other event about a checkout. Each answers the delivery the provider
would send, the body and its `Stripe-Signature` header, signed with the
twin's webhook secret, for the test to post to the webhook route. Every id
it mints says it is the twin's (`twin_`), so a row that holds one names its
provenance."""

import itertools
import json
from datetime import UTC, datetime

from free_journalism.integrations.payments import (
    Cadence,
    Checkout,
    CheckoutRequest,
    PaymentDelivery,
    PaymentsProviderInterface,
)
from free_journalism.integrations.payments.deliveries import (
    COMPLETED,
    EXPIRED,
    sign,
    verified,
)

TWIN_CHECKOUT = "https://checkout.twin.test"
TWIN_WEBHOOK_SECRET = "twin-payments-webhook-secret"
"""The secret the twin signs its deliveries with by default; never a real
endpoint's."""


class PaymentsProviderTwinImpl(PaymentsProviderInterface):
    def __init__(
        self, *, webhook_secret: str = TWIN_WEBHOOK_SECRET, clock: type[datetime] = datetime
    ) -> None:
        self._counter = itertools.count(1)
        self._secret = webhook_secret
        self._clock = clock
        self.checkouts: dict[str, CheckoutRequest] = {}
        """Every checkout the twin opened, by id, in order, with its request."""

    def _id(self, kind: str) -> str:
        return f"twin_{kind}_{next(self._counter):06d}"

    # The reader's and the provider's side, driven by a test or a local process.

    def complete(self, checkout_id: str) -> tuple[bytes, str]:
        """The reader paid: the delivery of the completed checkout, paid, a
        payment for a one-time checkout and a running subscription for a
        monthly one."""
        return self.signed_event(COMPLETED, checkout_id)

    def expire(self, checkout_id: str) -> tuple[bytes, str]:
        """The checkout lapsed unpaid: the delivery that says so."""
        return self.signed_event(EXPIRED, checkout_id)

    def signed_event(
        self, event_type: str, checkout_id: str, event_id: str | None = None
    ) -> tuple[bytes, str]:
        """An event about a checkout the twin opened, as the provider would
        deliver it: the body, in the provider's shape, and the signature
        header over it. The same `event_id` is the same delivery. KeyError
        for a checkout the twin never opened."""
        request = self.checkouts[checkout_id]
        monthly = request.cadence is Cadence.MONTHLY
        expired = event_type == EXPIRED
        session = {
            "id": checkout_id,
            "object": "checkout.session",
            "mode": "subscription" if monthly else "payment",
            "status": "expired" if expired else "complete",
            "payment_status": "paid" if event_type == COMPLETED else "unpaid",
            "amount_total": request.amount,
            "currency": request.currency,
            "client_reference_id": str(request.reference),
            "metadata": {"support_id": str(request.reference), "org_id": str(request.org_id)},
            "url": None,
        }
        event = {
            "id": event_id or self._id("evt"),
            "object": "event",
            "type": event_type,
            "created": int(self._clock.now(UTC).timestamp()),
            "livemode": False,
            "data": {"object": session},
        }
        payload = json.dumps(event).encode()
        return payload, sign(payload, self._secret)

    # The interface.

    @property
    def configured(self) -> bool:
        return True

    async def open_checkout(
        self, request: CheckoutRequest, *, deadline: datetime | None = None
    ) -> Checkout:
        checkout_id = self._id("cs")
        self.checkouts[checkout_id] = request
        return Checkout(id=checkout_id, url=f"{TWIN_CHECKOUT}/{checkout_id}")

    def verify_delivery(self, payload: bytes, signature: str) -> PaymentDelivery:
        return verified(payload, signature, self._secret)

    def describe(self) -> str:
        return "payments provider: the twin (in-process, local only)"

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None
