"""The integrations root that picks each provider from settings, and the
root over providers a caller already built. A twin is refused in a
deployed environment, the way the infra root refuses a local backend; the
caller says whether the environment is one, from the settings it booted
with."""

from datetime import timedelta

from free_journalism.integrations.exceptions import UnsafeIntegration
from free_journalism.integrations.identity import IdentityProviderInterface
from free_journalism.integrations.identity.absent import IdentityProviderAbsentImpl
from free_journalism.integrations.identity.twin import IdentityProviderTwinImpl
from free_journalism.integrations.identity.workos import IdentityProviderWorkOSImpl
from free_journalism.integrations.payments import PaymentsProviderInterface
from free_journalism.integrations.payments.absent import PaymentsProviderAbsentImpl
from free_journalism.integrations.payments.stripe import PaymentsProviderStripeImpl
from free_journalism.integrations.payments.twin import PaymentsProviderTwinImpl
from free_journalism.integrations.root import IntegrationsInterface
from free_journalism.integrations.settings import IntegrationsSettings


def refuse_unsafe(settings: IntegrationsSettings, environment: str, deployed: bool) -> None:
    """A twin in a deployed environment is refused at boot, naming the setting."""
    if deployed and settings.identity_provider == "twin":
        raise UnsafeIntegration(
            f"FREE_JOURNALISM_IDENTITY_PROVIDER=twin is refused when FREE_JOURNALISM_ENVIRONMENT={environment}"
        )
    if deployed and settings.payments_provider == "twin":
        raise UnsafeIntegration(
            f"FREE_JOURNALISM_PAYMENTS_PROVIDER=twin is refused when FREE_JOURNALISM_ENVIRONMENT={environment}"
        )


def identity_provider_for(settings: IntegrationsSettings) -> IdentityProviderInterface:
    if settings.identity_provider == "twin":
        return IdentityProviderTwinImpl()
    if settings.identity_provider == "workos":
        if not settings.workos_client_id:
            return IdentityProviderAbsentImpl("FREE_JOURNALISM_WORKOS_CLIENT_ID is not set")
        if settings.workos_api_key is None:
            return IdentityProviderAbsentImpl("FREE_JOURNALISM_WORKOS_API_KEY is not set")
        secret = settings.workos_webhook_secret
        return IdentityProviderWorkOSImpl(
            client_id=settings.workos_client_id,
            api_key=settings.workos_api_key.get_secret_value(),
            base_url=settings.workos_base_url,
            timeout=timedelta(seconds=settings.workos_timeout_seconds),
            webhook_secret=None if secret is None else secret.get_secret_value(),
        )
    return IdentityProviderAbsentImpl()


def payments_provider_for(settings: IntegrationsSettings) -> PaymentsProviderInterface:
    if settings.payments_provider == "twin":
        return PaymentsProviderTwinImpl()
    if settings.payments_provider == "stripe":
        if settings.stripe_api_key is None:
            return PaymentsProviderAbsentImpl("FREE_JOURNALISM_STRIPE_API_KEY is not set")
        secret = settings.stripe_webhook_secret
        return PaymentsProviderStripeImpl(
            api_key=settings.stripe_api_key.get_secret_value(),
            base_url=settings.stripe_base_url,
            timeout=timedelta(seconds=settings.stripe_timeout_seconds),
            webhook_secret=None if secret is None else secret.get_secret_value(),
        )
    return PaymentsProviderAbsentImpl()


class IntegrationsOverImpl(IntegrationsInterface):
    """The root over providers already built: a test's twins, or the absent
    providers of a process that signs nobody in and takes no money. The
    caller builds each, the absent ones included."""

    def __init__(
        self, identity: IdentityProviderInterface, payments: PaymentsProviderInterface
    ) -> None:
        self._identity = identity
        self._payments = payments

    def get_identity_provider(self) -> IdentityProviderInterface:
        return self._identity

    def get_payments_provider(self) -> PaymentsProviderInterface:
        return self._payments

    def describe(self) -> list[str]:
        return [self._identity.describe(), self._payments.describe()]

    async def start(self) -> None:
        await self._identity.start()
        await self._payments.start()

    async def close(self) -> None:
        await self._identity.close()
        await self._payments.close()


def absent_integrations() -> IntegrationsInterface:
    """The root of a process that signs nobody in and takes no money."""
    return IntegrationsOverImpl(IdentityProviderAbsentImpl(), PaymentsProviderAbsentImpl())


class IntegrationsConfiguredImpl(IntegrationsOverImpl):
    def __init__(self, settings: IntegrationsSettings, environment: str, deployed: bool) -> None:
        refuse_unsafe(settings, environment, deployed)
        super().__init__(identity_provider_for(settings), payments_provider_for(settings))
