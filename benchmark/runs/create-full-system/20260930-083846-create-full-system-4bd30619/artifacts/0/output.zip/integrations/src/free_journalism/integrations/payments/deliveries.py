"""An inbound delivery from the payments provider: its signature, and what
it says became of a checkout.

The provider signs `<timestamp>.<body>` with HMAC-SHA256 under the
endpoint's secret, the timestamp in whole seconds, and sends
`t=<timestamp>,v1=<signature>` in the `Stripe-Signature` header; while an
endpoint's secret rolls, the header carries one `v1` per live secret, and
any of them checking out is enough. The check here holds the documented
scheme and a replay window of five minutes, the SDK's own. The twin signs
with `sign`, so its deliveries and the real ones pass the same check, and a
test holds `sign` to the SDK's verifier.

What an event means is read here, once, for both: a completed checkout that
is paid is `PAID`, or `ACTIVE` for a subscription; one completed with its
payment still on its way (a bank debit, say) means nothing yet, and the
provider's `async_payment_succeeded` for it later is the payment; a failed
one is `FAILED`, and a lapsed one `EXPIRED`. Any other event has no
outcome, and the worker leaves it be."""

import hashlib
import hmac
import json
import time
import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any
from uuid import UUID

from free_journalism.integrations.exceptions import DeliveryRefused
from free_journalism.integrations.payments import PaymentDelivery, PaymentOutcome

SIGNATURE_HEADER = "Stripe-Signature"
TOLERANCE_SECONDS = 300
"""The SDK's default replay window, named so a reader finds it."""

DELIVERY_NAMESPACE = uuid.UUID("8a0f4c1e-2f6b-4e57-9c3d-6b1f0e7a9d24")
"""The namespace of a delivery's key: the same event id is the same key."""

COMPLETED = "checkout.session.completed"
PAID_LATER = "checkout.session.async_payment_succeeded"
FAILED = "checkout.session.async_payment_failed"
EXPIRED = "checkout.session.expired"
SETTLED = frozenset({"paid", "no_payment_required"})
"""The payment states of a completed checkout whose money is in."""


def sign(payload: bytes, secret: str, timestamp: int | None = None) -> str:
    """The header the provider would send with `payload`."""
    at = int(time.time()) if timestamp is None else timestamp
    digest = hmac.new(secret.encode(), f"{at}.".encode() + payload, hashlib.sha256).hexdigest()
    return f"t={at},v1={digest}"


def verified(payload: bytes, signature: str, secret: str) -> PaymentDelivery:
    """The delivery, once the check passes; `DeliveryRefused` otherwise. The
    reason names what failed and never the secret or the header."""
    if not signature:
        raise DeliveryRefused(f"no {SIGNATURE_HEADER} header")
    stamps: list[str] = []
    given: list[str] = []
    for part in signature.split(","):
        name, _, value = part.strip().partition("=")
        if name == "t":
            stamps.append(value)
        elif name == "v1":
            given.append(value)
    try:
        if len(stamps) != 1 or not given:
            raise ValueError
        at = int(stamps[0])
    except ValueError:
        raise DeliveryRefused("the signature header is not t=...,v1=...") from None
    # In whole seconds, as the header carries it: a timestamp of any length
    # is outside the window, never too large for a float.
    if abs(int(time.time()) - at) > TOLERANCE_SECONDS:
        raise DeliveryRefused("the signature's timestamp is outside the window")
    expected = hmac.new(secret.encode(), f"{at}.".encode() + payload, hashlib.sha256).hexdigest()
    # The compare takes ASCII text alone and raises on anything else. A
    # signature is hex, so a value with another character is a bad signature.
    if not any(one.isascii() and hmac.compare_digest(one, expected) for one in given):
        raise DeliveryRefused("the signature did not check out")
    try:
        event = json.loads(payload)
    except json.JSONDecodeError, UnicodeDecodeError:
        raise DeliveryRefused("the body is not JSON") from None
    if not isinstance(event, Mapping):
        raise DeliveryRefused("the body is not an event")
    return delivery_of(event)


def delivery_of(event: Mapping[str, Any]) -> PaymentDelivery:
    """What an event names: its own id, the checkout it is about, the desk
    and the support from the checkout's metadata, and the outcome."""
    try:
        event_id = str(event["id"])
        event_type = str(event["type"])
        stamp = event["created"]
        if not isinstance(stamp, int) or isinstance(stamp, bool):
            raise TypeError
        created = datetime.fromtimestamp(stamp, UTC)
    except KeyError, TypeError, ValueError, OverflowError, OSError:
        raise DeliveryRefused("the body is not an event") from None
    data = event.get("data")
    wrapped = data.get("object") if isinstance(data, Mapping) else None
    obj: Mapping[str, Any] = wrapped if isinstance(wrapped, Mapping) else {}
    raw_metadata = obj.get("metadata")
    metadata: Mapping[str, Any] = raw_metadata if isinstance(raw_metadata, Mapping) else {}
    session = obj.get("object") == "checkout.session"
    reference = _uuid(metadata.get("support_id"))
    if reference is None and session:
        reference = _uuid(obj.get("client_reference_id"))
    return PaymentDelivery(
        key=uuid.uuid5(DELIVERY_NAMESPACE, event_id),
        event_id=event_id,
        event_type=event_type,
        created=created,
        org_id=_uuid(metadata.get("org_id")),
        reference=reference,
        checkout_id=_text(obj.get("id")) if session else None,
        outcome=outcome_of(event_type, obj) if session else None,
    )


def outcome_of(event_type: str, session: Mapping[str, Any]) -> PaymentOutcome | None:
    """What an event about a checkout session says became of it."""
    paid = PaymentOutcome.ACTIVE if session.get("mode") == "subscription" else PaymentOutcome.PAID
    if event_type == COMPLETED:
        return paid if session.get("payment_status") in SETTLED else None
    if event_type == PAID_LATER:
        return paid
    if event_type == FAILED:
        return PaymentOutcome.FAILED
    if event_type == EXPIRED:
        return PaymentOutcome.EXPIRED
    return None


def _text(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _uuid(value: object) -> UUID | None:
    if not isinstance(value, str):
        return None
    try:
        return UUID(value)
    except ValueError:
        return None
