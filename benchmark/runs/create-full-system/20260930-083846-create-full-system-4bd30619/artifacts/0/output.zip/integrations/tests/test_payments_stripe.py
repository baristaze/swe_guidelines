"""The Stripe client over a fake transport: the session it asks Stripe to
open for each cadence, Stripe's recorded answers read into the
integration's own shapes, every error translated into its exceptions, and a
call a request makes kept to the request's deadline."""

import asyncio
import time
from collections.abc import Awaitable, Callable
from datetime import datetime, timedelta
from typing import Any
from urllib.parse import parse_qsl
from uuid import UUID

import httpx
import pytest

from free_journalism.infra.base import utcnow
from free_journalism.infra.deadline import PASSED
from free_journalism.integrations.exceptions import (
    ProviderConflict,
    ProviderRefused,
    ProviderUnavailable,
)
from free_journalism.integrations.payments import Cadence, CheckoutRequest
from free_journalism.integrations.payments.stripe import OwnedHttpx, PaymentsProviderStripeImpl

API_KEY = "[redacted]"
SUPPORT = UUID("0195f1a2-7b3c-7d4e-8f00-00000000000a")
DESK = UUID("0195f1a2-7b3c-7d4e-8f00-000000000001")
SESSION_ID = "cs_test_a1B2c3D4e5F6g7H8i9J0kLmNoPqRsTuVwXyZ"
PAGE = f"https://checkout.stripe.com/c/pay/{SESSION_ID}#fidkdWxOYHwnPyd1blpxYHZxWjA0"


def session(mode: str, *, url: str | None = PAGE) -> dict[str, Any]:
    """A Checkout session as Stripe answers its creation (API version
    2026-08-26.dahlia), trimmed of the fields that are null or empty."""
    return {
        "id": SESSION_ID,
        "object": "checkout.session",
        "amount_subtotal": 1500,
        "amount_total": 1500,
        "cancel_url": "https://app.free-journalism.example/support",
        "client_reference_id": str(SUPPORT),
        "created": 1790000000,
        "currency": "eur",
        "customer_creation": "if_required" if mode == "payment" else "always",
        "expires_at": 1790086400,
        "livemode": False,
        "metadata": {"org_id": str(DESK), "support_id": str(SUPPORT)},
        "mode": mode,
        "payment_method_collection": "always",
        "payment_method_types": ["card"],
        "payment_status": "unpaid",
        "status": "open",
        "submit_type": None,
        "success_url": "https://app.free-journalism.example/support/done",
        "ui_mode": "hosted",
        "url": url,
    }


def stripe_error(status: int, error_type: str, **fields: str) -> httpx.Response:
    """An error as Stripe answers it."""
    return httpx.Response(
        status,
        json={"error": {"type": error_type, **fields}},
        headers={"Request-Id": "req_test"},
    )


def request(cadence: Cadence = Cadence.ONE_TIME) -> CheckoutRequest:
    return CheckoutRequest(
        reference=SUPPORT,
        org_id=DESK,
        amount=1500,
        currency="eur",
        cadence=cadence,
        application_fee=75,
        success_url="https://app.free-journalism.example/support/done",
        cancel_url="https://app.free-journalism.example/support",
    )


class Sent:
    """The fake transport: every request it was handed, and its answer."""

    def __init__(
        self, answer: Callable[[httpx.Request, int], Awaitable[httpx.Response] | httpx.Response]
    ) -> None:
        self.requests: list[httpx.Request] = []
        self._answer = answer

    async def __call__(self, request: httpx.Request) -> httpx.Response:
        self.requests.append(request)
        answered = self._answer(request, len(self.requests))
        return await answered if isinstance(answered, Awaitable) else answered


def provider(
    sent: Sent,
    *,
    max_retries: int = 0,
    timeout: float = 5,
    base_url: str = "https://api.stripe.com",
) -> PaymentsProviderStripeImpl:
    return PaymentsProviderStripeImpl(
        api_key=API_KEY,
        timeout=timedelta(seconds=timeout),
        base_url=base_url,
        max_retries=max_retries,
        transport=httpx.MockTransport(sent),
    )


def form(request: httpx.Request) -> dict[str, str]:
    return dict(parse_qsl(request.content.decode()))


async def test_a_one_time_checkout_is_a_payment_session_with_its_ids() -> None:
    sent = Sent(lambda r, n: httpx.Response(200, json=session("payment")))
    made = provider(sent)
    checkout = await made.open_checkout(request())
    assert (checkout.id, checkout.url) == (SESSION_ID, PAGE)
    [call] = sent.requests
    assert (call.method, str(call.url)) == ("POST", "https://api.stripe.com/v1/checkout/sessions")
    assert call.headers["authorization"] == f"Bearer {API_KEY}"
    assert call.headers["stripe-version"] and call.headers["idempotency-key"]
    assert form(call) == {
        "mode": "payment",
        "line_items[0][price_data][currency]": "eur",
        "line_items[0][price_data][unit_amount]": "1500",
        "line_items[0][price_data][product_data][name]": "One-time support",
        "line_items[0][quantity]": "1",
        "success_url": "https://app.free-journalism.example/support/done",
        "cancel_url": "https://app.free-journalism.example/support",
        "client_reference_id": str(SUPPORT),
        "metadata[support_id]": str(SUPPORT),
        "metadata[org_id]": str(DESK),
        "payment_intent_data[metadata][support_id]": str(SUPPORT),
        "payment_intent_data[metadata][org_id]": str(DESK),
    }
    await made.close()


async def test_a_monthly_checkout_is_a_subscription_session_that_recurs_monthly() -> None:
    sent = Sent(lambda r, n: httpx.Response(200, json=session("subscription")))
    made = provider(sent)
    assert (await made.open_checkout(request(Cadence.MONTHLY))).id == SESSION_ID
    sent_form = form(sent.requests[0])
    assert sent_form["mode"] == "subscription"
    assert sent_form["line_items[0][price_data][recurring][interval]"] == "month"
    assert sent_form["line_items[0][price_data][product_data][name]"] == "Monthly support"
    assert sent_form["subscription_data[metadata][support_id]"] == str(SUPPORT)
    assert sent_form["subscription_data[metadata][org_id]"] == str(DESK)
    assert not any(name.startswith("payment_intent_data") for name in sent_form)


@pytest.mark.parametrize("cadence", list(Cadence))
async def test_the_application_fee_is_not_sent_until_a_desk_has_a_connected_account(
    cadence: Cadence,
) -> None:
    """Stripe refuses an application fee on a charge to the platform's own
    account, and no desk has a connected account yet."""
    mode = "subscription" if cadence is Cadence.MONTHLY else "payment"
    sent = Sent(lambda r, n: httpx.Response(200, json=session(mode)))
    await provider(sent).open_checkout(request(cadence))
    sent_form = form(sent.requests[0])
    assert not any("application_fee" in name or "transfer_data" in name for name in sent_form)


async def test_the_base_url_from_settings_is_where_the_client_calls() -> None:
    sent = Sent(lambda r, n: httpx.Response(200, json=session("payment")))
    made = provider(sent, base_url="http://stripe-mock:12111/")
    await made.open_checkout(request())
    assert str(sent.requests[0].url) == "http://stripe-mock:12111/v1/checkout/sessions"
    assert made.describe() == "payments provider: Stripe (http://stripe-mock:12111, test mode)"


@pytest.mark.parametrize(
    ("answer", "raised", "says"),
    [
        (
            stripe_error(
                401, "invalid_request_error", message=f"Invalid API Key provided: {API_KEY}"
            ),
            ProviderUnavailable,
            "refused FREE_JOURNALISM_STRIPE_API_KEY (401)",
        ),
        (
            stripe_error(403, "invalid_request_error", message="restricted key lacks permission"),
            ProviderUnavailable,
            "refused FREE_JOURNALISM_STRIPE_API_KEY (403)",
        ),
        (
            stripe_error(
                400,
                "invalid_request_error",
                code="parameter_invalid_integer",
                param="line_items[0][price_data][unit_amount]",
                message="Invalid integer",
            ),
            ProviderRefused,
            "parameter_invalid_integer (line_items[0][price_data][unit_amount])",
        ),
        (
            stripe_error(400, "idempotency_error", message="Keys for idempotent requests"),
            ProviderConflict,
            "Keys for idempotent requests",
        ),
        (
            stripe_error(429, "invalid_request_error", code="rate_limit"),
            ProviderUnavailable,
            "RateLimitError",
        ),
        (
            stripe_error(500, "api_error", message="Something went wrong"),
            ProviderUnavailable,
            "500",
        ),
        (stripe_error(402, "card_error", code="card_declined"), ProviderRefused, "card_declined"),
    ],
    ids=[
        "key refused",
        "key without permission",
        "invalid",
        "idempotency",
        "rate limit",
        "server",
        "other",
    ],
)
async def test_every_error_is_translated_and_never_names_the_key(
    answer: httpx.Response, raised: type[Exception], says: str
) -> None:
    sent = Sent(lambda r, n: answer)
    with pytest.raises(raised) as caught:
        await provider(sent).open_checkout(request())
    assert says in str(caught.value) and API_KEY not in str(caught.value)
    assert str(caught.value).startswith("opening the checkout: ")


async def test_a_stripe_out_of_reach_is_unavailable() -> None:
    def refuse(request: httpx.Request, n: int) -> httpx.Response:
        raise httpx.ConnectError("connection refused", request=request)

    with pytest.raises(ProviderUnavailable, match="APIConnectionError"):
        await provider(Sent(refuse)).open_checkout(request())


async def test_a_session_with_no_page_is_refused() -> None:
    sent = Sent(lambda r, n: httpx.Response(200, json=session("payment", url=None)))
    with pytest.raises(ProviderRefused, match="no page"):
        await provider(sent).open_checkout(request())


async def test_a_retried_call_opens_one_session_under_one_idempotency_key(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(OwnedHttpx, "_sleep_time_seconds", lambda self, n: 0.0)

    def once_down(request: httpx.Request, n: int) -> httpx.Response:
        if n == 1:
            return stripe_error(503, "api_error", message="try again")
        return httpx.Response(200, json=session("payment"))

    sent = Sent(once_down)
    assert (await provider(sent, max_retries=2).open_checkout(request())).id == SESSION_ID
    first, second = sent.requests
    assert first.headers["idempotency-key"] == second.headers["idempotency-key"]


def after(seconds: float) -> datetime:
    return utcnow() + timedelta(seconds=seconds)


async def test_every_attempt_carries_the_timeout_from_settings() -> None:
    sent = Sent(lambda r, n: httpx.Response(200, json=session("payment")))
    await provider(sent, timeout=7).open_checkout(request())
    assert sent.requests[0].extensions["timeout"]["read"] == 7


async def test_a_call_whose_deadline_passed_does_not_start() -> None:
    sent = Sent(lambda r, n: httpx.Response(200, json=session("payment")))
    with pytest.raises(ProviderUnavailable) as raised:
        await provider(sent).open_checkout(request(), deadline=after(-1))
    assert str(raised.value) == f"opening the checkout: {PASSED}"
    assert sent.requests == []


async def test_a_stripe_that_hangs_ends_at_the_deadline_not_after_its_retries() -> None:
    """At a ten second timeout and two retries a Stripe that hangs holds a
    call half a minute. Under a request's deadline the attempt goes out with
    what is left, and the call ends at the deadline, unavailable."""

    async def hang(request: httpx.Request, n: int) -> httpx.Response:
        await asyncio.sleep(3600)
        raise AssertionError("never answered")

    sent = Sent(hang)
    began = time.monotonic()
    with pytest.raises(ProviderUnavailable) as raised:
        await asyncio.wait_for(
            provider(sent, timeout=10, max_retries=2).open_checkout(request(), deadline=after(0.3)),
            5,
        )
    waited = time.monotonic() - began
    assert str(raised.value) in {
        f"opening the checkout: {PASSED}",
        "opening the checkout: no time is left for another attempt",
    }
    assert 0.25 <= waited < 1.0, waited
    assert len(sent.requests) <= 1
    assert all(0 < r.extensions["timeout"]["read"] <= 0.3 for r in sent.requests)


async def test_the_client_refuses_to_start_without_a_key() -> None:
    with pytest.raises(ValueError, match="API key"):
        PaymentsProviderStripeImpl(api_key="", timeout=timedelta(seconds=5))
    live = PaymentsProviderStripeImpl(api_key="rk_live_x", timeout=timedelta(seconds=5))
    assert "live mode" in live.describe() and "rk_live_x" not in live.describe()
    await live.start()
    await live.close()
