"""The payments provider's webhook deliveries: the signature over the body
and its timestamp, what an event says became of a checkout, and the one
check the twin and the real client share."""

import json
import time
from datetime import UTC, datetime, timedelta
from uuid import UUID, uuid5

import pytest
from stripe import WebhookSignature

from free_journalism.integrations.exceptions import DeliveryRefused, ProviderUnavailable
from free_journalism.integrations.payments import PaymentOutcome
from free_journalism.integrations.payments.deliveries import (
    DELIVERY_NAMESPACE,
    TOLERANCE_SECONDS,
    sign,
    verified,
)
from free_journalism.integrations.payments.stripe import PaymentsProviderStripeImpl

SECRET = "whsec_test"
SUPPORT = "0195f1a2-7b3c-7d4e-8f00-00000000000a"
DESK = "0195f1a2-7b3c-7d4e-8f00-000000000001"
CREATED = 1790000000


def event(
    event_type: str,
    *,
    mode: str = "payment",
    payment_status: str = "paid",
    metadata: object = None,
    event_id: str = "evt_1",
    obj: dict[str, object] | None = None,
) -> bytes:
    """An event in Stripe's shape, about a checkout session unless `obj`
    names another object."""
    session = obj or {
        "id": "cs_test_1",
        "object": "checkout.session",
        "mode": mode,
        "payment_status": payment_status,
        "client_reference_id": SUPPORT,
        "metadata": {"support_id": SUPPORT, "org_id": DESK} if metadata is None else metadata,
    }
    return json.dumps(
        {
            "id": event_id,
            "object": "event",
            "type": event_type,
            "created": CREATED,
            "livemode": False,
            "data": {"object": session},
        }
    ).encode()


def check(body: bytes) -> object:
    return verified(body, sign(body, SECRET), SECRET)


def test_sign_is_the_providers_scheme_as_its_sdk_checks_it() -> None:
    body = event("checkout.session.completed")
    assert WebhookSignature.verify_header(body, sign(body, SECRET), SECRET, TOLERANCE_SECONDS)


def test_the_sdks_own_signature_passes_the_check() -> None:
    """Stripe's header as its SDK writes it for a test, a timestamp and one
    `v1`, and one that carries a second `v1` and a `v0` while a secret rolls."""
    body = event("checkout.session.completed")
    at = int(time.time())
    digest = WebhookSignature._compute_signature(f"{at}.{body.decode()}", SECRET)
    assert verified(body, f"t={at},v1={digest}", SECRET).event_id == "evt_1"
    rolled = f"t={at},v1={'0' * 64},v1={digest},v0={'1' * 64}"
    assert verified(body, rolled, SECRET).event_id == "evt_1"


@pytest.mark.parametrize(
    ("mode", "outcome"),
    [("payment", PaymentOutcome.PAID), ("subscription", PaymentOutcome.ACTIVE)],
)
def test_a_paid_checkout_is_paid_once_or_active_monthly(mode: str, outcome: PaymentOutcome) -> None:
    delivery = verified(
        event("checkout.session.completed", mode=mode),
        sign(event("checkout.session.completed", mode=mode), SECRET),
        SECRET,
    )
    assert delivery.outcome is outcome
    assert (delivery.org_id, delivery.reference) == (UUID(DESK), UUID(SUPPORT))
    assert delivery.checkout_id == "cs_test_1"
    assert delivery.event_type == "checkout.session.completed"
    assert delivery.created == datetime.fromtimestamp(CREATED, UTC)


def test_a_checkout_completed_with_its_payment_on_the_way_is_paid_only_when_it_arrives() -> None:
    """A bank debit completes the checkout before the money is in: the
    completion means nothing yet, and the later success is the payment."""
    pending = event("checkout.session.completed", payment_status="unpaid")
    assert verified(pending, sign(pending, SECRET), SECRET).outcome is None
    for mode, outcome in (
        ("payment", PaymentOutcome.PAID),
        ("subscription", PaymentOutcome.ACTIVE),
    ):
        later = event("checkout.session.async_payment_succeeded", mode=mode)
        assert verified(later, sign(later, SECRET), SECRET).outcome is outcome


@pytest.mark.parametrize(
    ("event_type", "outcome"),
    [
        ("checkout.session.async_payment_failed", PaymentOutcome.FAILED),
        ("checkout.session.expired", PaymentOutcome.EXPIRED),
        ("checkout.session.created", None),
    ],
)
def test_a_failed_or_lapsed_checkout_says_so_and_another_event_says_nothing(
    event_type: str, outcome: PaymentOutcome | None
) -> None:
    body = event(event_type, payment_status="unpaid")
    delivery = verified(body, sign(body, SECRET), SECRET)
    assert delivery.outcome is outcome and delivery.checkout_id == "cs_test_1"


def test_an_event_about_another_object_names_no_checkout_and_no_outcome() -> None:
    body = event(
        "invoice.paid",
        obj={"id": "in_1", "object": "invoice", "metadata": {"org_id": DESK}},
    )
    delivery = verified(body, sign(body, SECRET), SECRET)
    assert (delivery.checkout_id, delivery.outcome, delivery.reference) == (None, None, None)
    assert delivery.org_id == UUID(DESK)


@pytest.mark.parametrize(
    "metadata",
    [{}, {"support_id": "not-a-uuid", "org_id": 7}, "not a mapping"],
    ids=["none", "unparseable", "not a mapping"],
)
def test_metadata_absent_or_unparseable_is_none_and_the_reference_falls_back(
    metadata: object,
) -> None:
    body = event("checkout.session.completed", metadata=metadata)
    delivery = verified(body, sign(body, SECRET), SECRET)
    assert delivery.org_id is None
    assert delivery.reference == UUID(SUPPORT)  # the session's client_reference_id


def test_every_copy_of_an_event_has_the_same_key() -> None:
    body = event("checkout.session.completed", event_id="evt_7")
    first = verified(body, sign(body, SECRET), SECRET)
    again = verified(body, sign(body, SECRET), SECRET)
    other = event("checkout.session.completed", event_id="evt_8")
    assert first.key == again.key != verified(other, sign(other, SECRET), SECRET).key
    assert first.key == uuid5(DELIVERY_NAMESPACE, "evt_7")


@pytest.mark.parametrize(
    "header",
    ["", "v1=abc", "t=abc,v1=def", "t=1", "t=1,t=2,v1=abc", "garbage"],
)
def test_a_missing_or_malformed_signature_is_refused(header: str) -> None:
    with pytest.raises(DeliveryRefused):
        verified(event("checkout.session.completed"), header, SECRET)


@pytest.mark.parametrize(
    "digest",
    ["\u00e9" * 64, "\uff11" * 64, "abc\udcff"],
    ids=["a byte past ASCII", "digits of another script", "a lone surrogate"],
)
def test_a_signature_outside_its_alphabet_is_a_bad_signature(digest: str) -> None:
    body = event("checkout.session.completed")
    with pytest.raises(DeliveryRefused, match="did not check out"):
        verified(body, f"t={int(time.time())},v1={digest}", SECRET)


def test_a_forged_signature_is_refused() -> None:
    body = event("checkout.session.completed")
    with pytest.raises(DeliveryRefused, match="did not check out"):
        verified(body, sign(body, "whsec_forger"), SECRET)
    with pytest.raises(DeliveryRefused, match="did not check out"):
        verified(body, f"t={int(time.time())},v1={'0' * 64}", SECRET)


def test_a_body_changed_after_signing_is_refused() -> None:
    body = event("checkout.session.completed", mode="subscription")
    header = sign(body, SECRET)
    with pytest.raises(DeliveryRefused, match="did not check out"):
        verified(body.replace(b"subscription", b"payment"), header, SECRET)


def test_a_stale_delivery_is_refused() -> None:
    body = event("checkout.session.completed")
    stale = int(time.time()) - TOLERANCE_SECONDS - 60
    with pytest.raises(DeliveryRefused, match="window"):
        verified(body, sign(body, SECRET, stale), SECRET)
    ahead = int(time.time()) + TOLERANCE_SECONDS + 60
    with pytest.raises(DeliveryRefused, match="window"):
        verified(body, sign(body, SECRET, ahead), SECRET)
    for far in (int("9" * 400), -int("9" * 400)):
        with pytest.raises(DeliveryRefused, match="window"):
            verified(body, sign(body, SECRET, far), SECRET)


@pytest.mark.parametrize(
    "body",
    [
        b"not json",
        b"[]",
        b'{"id": "evt_1"}',
        b'{"id": "evt_1", "type": "x", "created": "yesterday"}',
        b'{"id": "evt_1", "type": "x", "created": 1e400}',
        b'{"id": "evt_1", "type": "x", "created": 99999999999999999999}',
    ],
)
def test_a_signed_body_that_is_no_event_is_refused(body: bytes) -> None:
    with pytest.raises(DeliveryRefused):
        verified(body, sign(body, SECRET), SECRET)


def test_the_real_client_without_its_secret_refuses_every_delivery_as_unavailable() -> None:
    body = event("checkout.session.completed")
    unconfigured = PaymentsProviderStripeImpl(api_key="sk_test_x", timeout=timedelta(seconds=5))
    with pytest.raises(ProviderUnavailable, match="FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET"):
        unconfigured.verify_delivery(body, sign(body, SECRET))
    configured = PaymentsProviderStripeImpl(
        api_key="sk_test_x", timeout=timedelta(seconds=5), webhook_secret=SECRET
    )
    assert configured.verify_delivery(body, sign(body, SECRET)).outcome is PaymentOutcome.PAID
    with pytest.raises(DeliveryRefused):
        configured.verify_delivery(body, sign(body, "whsec_other"))
