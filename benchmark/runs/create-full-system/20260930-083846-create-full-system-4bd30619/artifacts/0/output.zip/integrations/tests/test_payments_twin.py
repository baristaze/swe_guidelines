"""The payments provider's twin opens checkouts in memory and plays the
reader's and the provider's side a test drives: each delivery it answers is
signed with its secret, and passes the check a real one does."""

from uuid import UUID

import pytest

from free_journalism.integrations.exceptions import DeliveryRefused
from free_journalism.integrations.payments import Cadence, CheckoutRequest, PaymentOutcome
from free_journalism.integrations.payments.deliveries import (
    SIGNATURE_HEADER,
    sign,
    verified,
)
from free_journalism.integrations.payments.twin import (
    TWIN_CHECKOUT,
    TWIN_WEBHOOK_SECRET,
    PaymentsProviderTwinImpl,
)

SUPPORT = UUID("0195f1a2-7b3c-7d4e-8f00-00000000000a")
DESK = UUID("0195f1a2-7b3c-7d4e-8f00-000000000001")


def request(cadence: Cadence = Cadence.ONE_TIME) -> CheckoutRequest:
    return CheckoutRequest(
        reference=SUPPORT,
        org_id=DESK,
        amount=1500,
        currency="eur",
        cadence=cadence,
        application_fee=75,
        success_url="http://localhost:55173/support/done",
        cancel_url="http://localhost:55173/support",
    )


async def test_a_checkout_is_recorded_with_its_request_and_a_twin_page() -> None:
    twin = PaymentsProviderTwinImpl()
    first = await twin.open_checkout(request())
    second = await twin.open_checkout(request(Cadence.MONTHLY))
    assert first.id.startswith("twin_") and first.id != second.id
    assert first.url == f"{TWIN_CHECKOUT}/{first.id}" == f"https://checkout.twin.test/{first.id}"
    assert twin.checkouts == {first.id: request(), second.id: request(Cadence.MONTHLY)}
    assert twin.configured and "twin" in twin.describe()


@pytest.mark.parametrize(
    ("cadence", "outcome"),
    [(Cadence.ONE_TIME, PaymentOutcome.PAID), (Cadence.MONTHLY, PaymentOutcome.ACTIVE)],
)
async def test_completing_a_checkout_delivers_it_paid(
    cadence: Cadence, outcome: PaymentOutcome
) -> None:
    twin = PaymentsProviderTwinImpl()
    checkout = await twin.open_checkout(request(cadence))
    body, signature = twin.complete(checkout.id)
    delivery = twin.verify_delivery(body, signature)
    assert delivery.outcome is outcome
    assert (delivery.org_id, delivery.reference, delivery.checkout_id) == (
        DESK,
        SUPPORT,
        checkout.id,
    )
    assert delivery.event_type == "checkout.session.completed"
    assert delivery.event_id.startswith("twin_evt_")


async def test_expiring_a_checkout_delivers_it_lapsed() -> None:
    twin = PaymentsProviderTwinImpl()
    checkout = await twin.open_checkout(request())
    delivery = twin.verify_delivery(*twin.expire(checkout.id))
    assert (delivery.outcome, delivery.event_type) == (
        PaymentOutcome.EXPIRED,
        "checkout.session.expired",
    )


async def test_any_event_about_a_checkout_is_delivered_and_the_same_id_is_the_same_key() -> None:
    twin = PaymentsProviderTwinImpl()
    checkout = await twin.open_checkout(request())
    failed = twin.signed_event("checkout.session.async_payment_failed", checkout.id, "evt_9")
    again = twin.signed_event("checkout.session.async_payment_failed", checkout.id, "evt_9")
    first, second = twin.verify_delivery(*failed), twin.verify_delivery(*again)
    assert first.outcome is PaymentOutcome.FAILED and first.key == second.key
    with pytest.raises(KeyError):
        twin.complete("twin_cs_never_opened")


async def test_the_twin_signs_with_its_secret_as_the_provider_does() -> None:
    """Its header is Stripe's scheme under the secret it was made with: the
    shared check passes it under that secret, and refuses it under another."""
    twin = PaymentsProviderTwinImpl(webhook_secret="whsec_local")
    checkout = await twin.open_checkout(request())
    body, signature = twin.complete(checkout.id)
    assert SIGNATURE_HEADER == "Stripe-Signature" and signature.startswith("t=")
    assert verified(body, signature, "whsec_local").checkout_id == checkout.id
    with pytest.raises(DeliveryRefused):
        verified(body, signature, TWIN_WEBHOOK_SECRET)
    with pytest.raises(DeliveryRefused):
        twin.verify_delivery(body, sign(body, "not-whsec_local"))
    default = PaymentsProviderTwinImpl()
    opened = await default.open_checkout(request())
    assert verified(*default.complete(opened.id), TWIN_WEBHOOK_SECRET).checkout_id == opened.id
