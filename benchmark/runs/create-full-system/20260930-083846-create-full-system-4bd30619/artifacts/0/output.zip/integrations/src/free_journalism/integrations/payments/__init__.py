"""The payments provider: the hosted service that takes a reader's money.
Free Journalism sends the reader's browser to the provider's own page with
an amount, a currency, and whether it is once or monthly; no card number
reaches the platform. The provider's word on what was paid comes back as a
signed delivery, never on the browser's (ADR 0083).

One interface, a real client (`stripe.py`), a deterministic twin
(`twin.py`), and the absent provider (`absent.py`) of a process that takes
no money, such as the worker.

A checkout carries the support's id as its reference and the desk's org id,
and every delivery about it names both again, so the worker applies it
under the org it names. A call a request makes carries the request's
`deadline` (ADR 0069), and ends by then, `ProviderUnavailable`, as when the
provider does not answer."""

from abc import ABC, abstractmethod
from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


class _Frozen(BaseModel):
    model_config = ConfigDict(frozen=True)


class Cadence(StrEnum):
    """How often a support is charged: once, or every month until it ends."""

    ONE_TIME = "one_time"
    MONTHLY = "monthly"


class CheckoutRequest(_Frozen):
    """A checkout to open. `reference` is the support's id, which the
    provider keeps and hands back on every delivery about the checkout, and
    `org_id` the desk it is for. Amounts are in the currency's minor units
    (cents); `currency` is its ISO 4217 code in lower case. `application_fee`
    is the platform's fee out of `amount`, apart from the processor's."""

    reference: UUID
    org_id: UUID
    amount: int = Field(gt=0)
    currency: str = Field(pattern=r"^[a-z]{3}$")
    cadence: Cadence
    application_fee: int = Field(ge=0)
    success_url: str
    cancel_url: str


class Checkout(_Frozen):
    """An opened checkout: the provider's id for it, and where the reader's
    browser goes to pay."""

    id: str
    url: str


class PaymentOutcome(StrEnum):
    """What a delivery says became of a checkout."""

    PAID = "paid"
    """A one-time checkout is paid."""
    ACTIVE = "active"
    """A monthly checkout is paid, and its subscription runs."""
    FAILED = "failed"
    """The payment failed after the reader left the page."""
    EXPIRED = "expired"
    """The checkout lapsed unpaid."""


class PaymentDelivery(_Frozen):
    """One event the provider delivered to the webhook route, once its
    signature checked out. `key` is the delivery's key, the same for every
    copy of the event. `org_id` and `reference` are the desk and the support
    the checkout was opened for, read from its metadata, and None when the
    event carries none that parses. `outcome` is None for an event the
    product does not act on."""

    key: UUID
    event_id: str
    event_type: str
    created: datetime
    org_id: UUID | None = None
    reference: UUID | None = None
    checkout_id: str | None = None
    outcome: PaymentOutcome | None = None


class PaymentsProviderInterface(ABC):
    @property
    @abstractmethod
    def configured(self) -> bool:
        """False when this process cannot open a checkout through it."""
        ...

    @abstractmethod
    async def open_checkout(
        self, request: CheckoutRequest, *, deadline: datetime | None = None
    ) -> Checkout:
        """Opens a checkout on the provider's hosted page: a one-time payment,
        or a monthly subscription. The reader comes back to `success_url` or
        `cancel_url`, which say nothing of what was paid; the delivery does.
        ProviderRefused when the provider refuses what it was handed."""
        ...

    @abstractmethod
    def verify_delivery(self, payload: bytes, signature: str) -> PaymentDelivery:
        """The event a webhook delivery carries, once the signature over its
        body and its timestamp checks out under the endpoint's secret;
        `DeliveryRefused` otherwise, and `ProviderUnavailable` when this
        process holds no secret. It makes no call."""
        ...

    @abstractmethod
    def describe(self) -> str: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...
