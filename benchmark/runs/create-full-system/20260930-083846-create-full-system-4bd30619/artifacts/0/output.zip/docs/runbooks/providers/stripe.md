# Stripe: the payments provider

Readers support journalists through Stripe Checkout, once or monthly.
The portal sends the reader to Stripe's hosted page; no card number
reaches Free Journalism. Stripe's signed delivery, not the reader's
browser, says what was paid, and the maintenance worker records it
([ADR 0083](../../adr/0083-payments-are-stripes.md)). This page says what
lives where, what is set by hand once, and what to do when it breaks.

## The rule

**Stripe's word is final on money.** A support is marked paid only from a
delivery to `/webhooks/payments` whose signature checked out, never from
the page the reader comes back to. The key is a restricted key of the
platform's Stripe account, with only the permission a checkout needs, and
each environment holds one of its own mode.

The platform's fee is not charged yet. Stripe takes an application fee
only on a charge made for a connected account, and the desks' Stripe
Connect accounts come with their onboarding, which is not built. Until
then a support is a charge on the platform's own account, whole.

## Environments

| Free Journalism environment | Stripe mode | Key name | Webhook endpoint |
|------------------|-------------|----------|------------------|
| `local` | none (the twin), or test | `free-journalism-local` | `stripe listen` forwards to `http://localhost:8000/webhooks/payments` |
| `staging` | test | `free-journalism-staging` | `https://api.staging.free-journalism.example/webhooks/payments` |
| `production` | live | `free-journalism-production` | `https://api.free-journalism.example/webhooks/payments` |

A test-mode key opens checkouts that take Stripe's test cards and move no
money. The API's start line says which mode its key is.

## First-time setup, once per Stripe mode

1. **Find the account.** In the Stripe dashboard, open the platform's
   account, and pick the mode: test for staging, live for production.
   Live mode needs the account activated (the business details, the bank
   account payouts go to).
2. **Make the key.** Under Developers, API keys, create a restricted key
   `free-journalism-<env>` with Checkout Sessions set to Write and
   nothing else. Keep it in a password manager. Never use the account's
   standard secret key.
3. **Add the webhook endpoint** (below).
4. **Write both secrets** into the environment (below), and roll the API.

## The webhook

Stripe delivers its events to `https://<api host>/webhooks/payments`.
The API checks the `Stripe-Signature` header (an HMAC over the timestamp
and the body, inside a five-minute window) before anything is queued. A
checked delivery goes onto the `webhooks` queue as provider `payments`,
keyed by Stripe's event id, so a redelivery is the same delivery, and the
maintenance worker applies it to the desk's support rows.

1. In the Stripe dashboard, in the environment's mode, open Developers,
   Webhooks, and add an endpoint at the environment's URL (the table
   above).
2. Subscribe it to `checkout.session.completed`,
   `checkout.session.async_payment_succeeded`,
   `checkout.session.async_payment_failed`, and
   `checkout.session.expired`. The API accepts any other event and the
   worker leaves it be, so subscribing to more costs deliveries only.
3. Copy the endpoint's signing secret (`whsec_...`), and write it into
   the environment (below). The API reads it as
   `FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET`.

Until the secret is set, every delivery is refused with `503`, and
Stripe retries it for up to three days. A delivery whose signature does
not check out is refused with `400 webhook_signature_invalid`.

## The secrets of a deployed environment

The first deploy makes two secrets in the environment's account, each
holding `off`, which the API reads as not set:

| Secret | Setting | Read by |
|--------|---------|---------|
| `free_journalism/<env>/stripe_api_key` | `FREE_JOURNALISM_STRIPE_API_KEY` | the API |
| `free_journalism/<env>/stripe_webhook_secret` | `FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET` | the API |

The environment sets `FREE_JOURNALISM_PAYMENTS_PROVIDER=stripe` on the
API. Write each value under your own sign-in, then roll the API so its
tasks start with it:

```bash
unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
aws sso login --profile free-journalism-staging
read -rs VALUE
aws secretsmanager put-secret-value --profile free-journalism-staging --region us-west-2 \
  --secret-id free_journalism/staging/stripe_api_key --secret-string "$VALUE"   # or stripe_webhook_secret
unset VALUE
aws ecs update-service --profile free-journalism-staging --region us-west-2 \
  --cluster free-journalism-staging --service api --force-new-deployment
```

Production's everyday profile only reads. Writing there takes
`free-journalism-prod-power`, and only for a change a person authorized.

**Check.** The API's start line in `/free_journalism/<env>/api` names
`payments provider: Stripe (https://api.stripe.com, test mode)` in
staging and `live mode` in production. Then, in staging, support a
journalist from the portal with Stripe's test card `4242 4242 4242 4242`,
and see the delivery succeed on the endpoint's page in the dashboard.

## Local development

The local stack runs the twin (`FREE_JOURNALISM_PAYMENTS_PROVIDER=twin`
in `.env`): a checkout answers a `https://checkout.twin.test/<id>` page
that goes nowhere, and a test drives the rest with the twin's `complete`
and `expire`, which answer a delivery signed as Stripe signs one. The
tests and CI run the twin too, and need no key.

To run a checkout through Stripe itself, use a test-mode key of your
own and the Stripe CLI, which forwards the account's test deliveries to
the laptop and prints the signing secret they carry:

```bash
stripe listen --forward-to http://localhost:8000/webhooks/payments   # prints whsec_...
read -rs FREE_JOURNALISM_STRIPE_API_KEY && export FREE_JOURNALISM_STRIPE_API_KEY
read -rs FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET && export FREE_JOURNALISM_STRIPE_WEBHOOK_SECRET
FREE_JOURNALISM_PAYMENTS_PROVIDER=stripe make up
```

A key is never committed, and a live-mode key never reaches a laptop.

## Rotation

1. Roll the key on its page under Developers, API keys, with an
   expiry for the old one long enough to deploy.
2. Write the new key, and roll the API.
3. Check the start line; the old key expires on its own.

The webhook secret rolls from the endpoint's page, with an expiry for
the old one: while both live, Stripe signs each delivery with both, and
the API takes either. Write the new secret, roll the API, and let the
old one expire.

## When it breaks

| What you see | Why | Where to look |
|--------------|-----|---------------|
| Every checkout answers `503`, and the start line says `payments provider: none (FREE_JOURNALISM_STRIPE_API_KEY is not set)` | The key is `off` | Write it, and roll the API |
| Every checkout answers `503`: `Stripe refused FREE_JOURNALISM_STRIPE_API_KEY (401)` | The key is revoked, expired, or of another account | Make a key, and write it |
| Every checkout answers `503`: `Stripe refused FREE_JOURNALISM_STRIPE_API_KEY (403)` | The restricted key lacks Checkout Sessions: Write | The key's permissions |
| A checkout answers `400 provider_refused` | Stripe refused the amount or the currency, named in the API's log line | `/free_journalism/<env>/api` |
| Deliveries fail with `503` in the Stripe dashboard | `free_journalism/<env>/stripe_webhook_secret` is `off` | Write it, and roll the API |
| Deliveries fail with `400` | The secret is another endpoint's, or the other mode's | Copy it again from this endpoint's page |
| A reader paid and the support stays unpaid | The endpoint is not subscribed to the event, or the worker is down | The endpoint's events, `/free_journalism/<env>/maintenance`, and the queue's dead-letter twin |
| The API stops at start: `FREE_JOURNALISM_PAYMENTS_PROVIDER=twin is refused` | The twin is set in a deployed environment | The environment's Terraform root |

## When an environment is torn down

`scripts/cloud_nuke.sh` does not touch Stripe. The checkout sessions,
payments, and subscriptions a staging run made stay in test mode,
harmless. Keep the endpoint for the next staging, or delete it from the
dashboard if the environment is not coming back, and revoke the key.
