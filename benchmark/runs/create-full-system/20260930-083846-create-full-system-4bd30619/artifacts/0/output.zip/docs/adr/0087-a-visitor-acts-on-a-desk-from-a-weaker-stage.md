# ADR 0087: A visitor acts on a desk from a weaker stage

**Status**: accepted (2026-09-30)

## Context

[ADR 0082](0082-free-journalism-on-the-core.md) puts a follow, a support,
and a report's delivery in the journalist's desk, the org, and says a
reader is never a member of that desk and a source is no identity at all.
The core authorizes a tenant operation through a `TenantContext`, which
only a membership gives. So the three loops of the first release each
need a person who holds no membership in a desk to write one row into it:

- a reader follows a journalist, or opens a checkout to support them;
- a source, with no account, sends a report to one or more journalists,
  and later reads and answers the thread about it.

A new role on the core's ladder, a "visitor" member minted into every
desk a reader touches, would make every reader a user of every desk they
follow, which ADR 0082 refuses, and would widen the role table every
permission test holds.

## Decision

**A reader acts on a desk from the identity stage.** A follow and the
opening of a support are manager operations that take `IdentityContext`
first, the stage the reader's own session proves (`Identity` at the
edge), and the desk's `org_id` beside it. The row names the reader's
`identity_id`, set by the manager from the stage and never taken from the
request, and lands under the desk's `org_id`: the query's predicate and
the table's `tenant_fence` both hold it to that desk. The reader reads
their own rows across desks by identity, a read of the system scope on
the tenantless list, as the core reads a person's memberships
(`read_memberships_by_identity`); never by reading a desk.

**A source acts on a desk from the request stage.** Sending a report,
reading its thread, and answering in it are operations that take
`RequestContext`, since nobody is known. What proves a source's right to
a thread is the follow-up secret their device made: the delivery keeps
its SHA-256 digest, the source presents the secret, and the manager
compares the digests in constant time. A delivery sent with no digest
has no thread a source can reach.

**The desk's own operations stay on the tenant stage.** Listing
followers, supports, and the inbox, opening a delivery, moving its
state, and replying take `TenantContext`, `READ` or `WRITE`, as every
tenant operation does.

**A row a visitor's write lands names no desk user.** The outbox row of
such a write carries the desk's org and `EMPTY_UUID` as its actor
(`visitor_row`), the core's marker for no principal, so the event a
journalist's inbox is pushed carries no one's id, and a source's route
leaves nothing that names them.

**What a visitor sends is idempotent by its own id.** A source holds no
credential, so no idempotency marker can be kept for them. The report and
each message of its thread carry an id the source's device minted, and
the route is a `PUT` of that id: a retry writes nothing new. A follow is
a `PUT` of the reader's follow of one journalist, one per reader and
journalist. A support is a `POST` under the gateway's `Idem`, which the
reader's session carries.

**The report is kept once, in the object store, under the system scope.**
The ciphertext is written to the `sealed-reports` bucket under
`EMPTY_UUID`, the scope no org owns, keyed by the report's id. Each
recipient desk gets a delivery row that names the report and holds its
own wrapped key. The platform never holds a key that opens either.

## Consequences

A reader who is signed into a desk of their own acts on another desk
without joining it, and the second fence still holds every row they
write to the desk it names.

A source's reach is the secret on their device. A leaked secret reads
and answers that one thread and nothing else; a lost one ends the thread
for them.

A report sent to several desks is several writes, one per desk, since
one transaction names one tenant. A send that failed part-way is sent
again with the same ids by the source's device, and the desks it reached
already answer the rows they hold.

A journalist's inbox is pushed an event about a delivery or a message
that names no actor. Anyone reading a desk's stream sees that a visitor
wrote, never who.
