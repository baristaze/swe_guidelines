import { useMemo } from "react";
import { useFollowers } from "../../queries/community";
import { useJournalists } from "../../queries/journalists";
import { followRows, journalistNames } from "./followsModel";

/** The desk's followers: which journalist is followed, and since when. A
 * push of `community.follow.*` refreshes the list on every open screen. */
export function useFollowsVm() {
  const follows = useFollowers();
  const journalists = useJournalists();

  const names = useMemo(() => journalistNames(journalists.data ?? []), [journalists.data]);
  const rows = useMemo(() => followRows(follows.data ?? [], names), [follows.data, names]);

  return {
    loading: follows.isPending,
    loadError: follows.error ?? journalists.error,
    rows,
  };
}
