import { useInfiniteQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useEffect } from "react";
import type { DeliveryPageView, DeliveryState, DeliveryView, UpdateDeliveryRequest } from "@free_journalism/client";
import { api } from "../app/api";
import { keys } from "./keys";

/** A page size, not a ceiling: the list follows the cursor to the end. */
const INBOX_PAGE_SIZE = 200;

/** Which deliveries the inbox lists: only in `state`, and only tagged `tag`,
 * when either is given. */
export interface InboxFilter {
  state: DeliveryState | null;
  tag: string | null;
}

/** The query string of one page of the inbox under a filter. */
export function inboxPath(filter: InboxFilter, limit: number, cursor: string | null): string {
  const params = new URLSearchParams({ limit: String(limit) });
  if (filter.state) params.set("state", filter.state);
  if (filter.tag) params.set("tag", filter.tag);
  if (cursor) params.set("cursor", cursor);
  return `/v1/inbox?${params.toString()}`;
}

/** Every delivery of the desk's inbox under the filter, page after page,
 * oldest first. The pages loaded so far are returned as they arrive. A
 * delivery is sealed: its view carries sizes, digests, and wrapped keys,
 * never a report's words. */
export function useInbox(filter: InboxFilter) {
  const query = useInfiniteQuery({
    queryKey: keys.deliveries.list(INBOX_PAGE_SIZE, filter.state, filter.tag),
    initialPageParam: null as string | null,
    getNextPageParam: (last: DeliveryPageView) => last.next_cursor,
    queryFn: ({ pageParam, signal }) => api.get<DeliveryPageView>(inboxPath(filter, INBOX_PAGE_SIZE, pageParam), { signal }),
  });
  const { hasNextPage, isFetchingNextPage, isFetchNextPageError, fetchNextPage } = query;
  // A page that failed is not asked for again on its own, as the member list's.
  const walking = hasNextPage && !isFetchNextPageError;
  useEffect(() => {
    if (walking && !isFetchingNextPage) void fetchNextPage();
  }, [walking, isFetchingNextPage, fetchNextPage]);
  return {
    ...query,
    data: query.data?.pages.flatMap((page) => page.items) as DeliveryView[] | undefined,
    isPending: query.isPending || walking,
  };
}

/** Moves a delivery's state or sets its tags; a field left out stays as it
 * is. The same change sent twice leaves the same delivery. */
export function useUpdateDelivery() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ deliveryId, body }: { deliveryId: string; body: UpdateDeliveryRequest }) =>
      api.patch<DeliveryView>(`/v1/inbox/${encodeURIComponent(deliveryId)}`, body),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: keys.deliveries.all }),
  });
}
