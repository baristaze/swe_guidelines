// Pure: what the inbox says. The desk's deliveries in, rows, filters, and
// refusals out. A delivery is sealed: the report and its thread open only
// with the journalist's own key on their device, and this release of the
// portal holds no such key, so nothing here reads, opens, or decrypts one.
// No React, no fetch.
import type { DeliveryState, DeliveryView, MeView } from "@free_journalism/client";
import { humanSize } from "../settings/storageModel";

/** Every state a journalist moves a delivery through, in the inbox's order. */
export const DELIVERY_STATES: readonly DeliveryState[] = ["new", "reviewing", "follow-up", "useful", "archived"];

/** The server's bounds on a delivery's tags (`reports.rules`). */
export const MAX_TAGS = 20;
export const MAX_TAG_LENGTH = 40;

const STATE_LABELS: Record<DeliveryState, string> = {
  new: "New",
  reviewing: "Reviewing",
  "follow-up": "Follow-up",
  useful: "Useful",
  archived: "Archived",
};

export interface DeliveryRow {
  id: string;
  state: DeliveryState;
  stateLabel: string;
  tags: string[];
  size: string;
  received: string;
  replyable: boolean;
}

/** "New", "Follow-up". */
export function stateLabel(state: DeliveryState): string {
  return STATE_LABELS[state];
}

/** A moment as the inbox shows it: the day and the minute, in UTC. */
export function formatWhen(iso: string): string {
  const at = new Date(iso);
  const utc = Number.isNaN(at.getTime()) ? iso : at.toISOString();
  return `${utc.slice(0, 10)} ${utc.slice(11, 16)} UTC`;
}

/** The rows in the order the server pages them, oldest first. */
export function deliveryRows(deliveries: DeliveryView[]): DeliveryRow[] {
  return deliveries.map((delivery) => ({
    id: delivery.id,
    state: delivery.state,
    stateLabel: stateLabel(delivery.state),
    tags: [...delivery.tags],
    size: humanSize(delivery.report_size),
    received: formatWhen(delivery.created_at),
    replyable: delivery.has_thread,
  }));
}

/** What the thread column says: whether the source can read a reply. */
export function threadLabel(replyable: boolean): string {
  return replyable ? "Can be replied to" : "No reply possible";
}

/** A tag filter as the server takes it: trimmed, and none when blank. */
export function tagFilter(text: string): string | null {
  const trimmed = text.trim();
  return trimmed === "" ? null : trimmed;
}

/** Tags as a journalist types them, comma-separated: each trimmed, blanks
 * dropped, each once in the order given. The server's bounds are checked
 * before anything is sent; an empty text clears the tags. */
export function parseTags(text: string): { tags: string[] } | { error: string } {
  const tags: string[] = [];
  for (const raw of text.split(",")) {
    const tag = raw.trim();
    if (tag === "") continue;
    if (tag.length > MAX_TAG_LENGTH) return { error: `Keep each tag to ${MAX_TAG_LENGTH} characters.` };
    if (!tags.includes(tag)) tags.push(tag);
  }
  if (tags.length > MAX_TAGS) return { error: `Keep to ${MAX_TAGS} tags.` };
  return { tags };
}

/** The tags as the edit field shows them. */
export function tagsText(tags: readonly string[]): string {
  return tags.join(", ");
}

/** A viewer reads the inbox; a member and above moves and tags deliveries. */
export function canTriage(me: MeView | undefined): boolean {
  return me?.permissions.includes("write") ?? false;
}

/** "1 delivery", "3 deliveries". */
export function deliveriesLine(count: number): string {
  return `${count} ${count === 1 ? "delivery" : "deliveries"}`;
}
