import type { JournalistView, MeView } from "@free_journalism/client";
import { describe, expect, it } from "vitest";
import { canAddJournalists, checkDisplayName, journalistRows, journalistsLine } from "./journalistsModel";

const journalist = (id: string, name: string): JournalistView => ({
  id,
  display_name: name,
  public_key: null,
  created_at: "2026-09-30T10:00:00Z",
  created_by: "u1",
  updated_at: "2026-09-30T10:00:00Z",
  updated_by: "u1",
});

const meWith = (permissions: MeView["permissions"]): MeView => ({
  app: "portal",
  role: "member",
  permissions,
  user: { id: "u1", email: "ada@example.test", display_name: "Ada", created_at: "2026-09-01T00:00:00Z" },
  org: { id: "o1", name: "Ada's desk", slug: "ada", kind: "personal", created_at: "2026-09-01T00:00:00Z", deleted_at: null },
});

describe("journalists model", () => {
  it("lists the journalists in the server's order, by the day each was added", () => {
    expect(journalistRows([journalist("j1", "Ada Reporter"), journalist("j2", "Bo")])).toEqual([
      { id: "j1", name: "Ada Reporter", added: "2026-09-30" },
      { id: "j2", name: "Bo", added: "2026-09-30" },
    ]);
  });

  it("lets a member add journalists and a viewer only read them", () => {
    expect(canAddJournalists(meWith(["read", "write"]))).toBe(true);
    expect(canAddJournalists(meWith(["read"]))).toBe(false);
    expect(canAddJournalists(undefined)).toBe(false);
  });

  it("refuses an empty or an overlong display name before it is sent", () => {
    expect(checkDisplayName("  ")).not.toBeNull();
    expect(checkDisplayName("x".repeat(201))).not.toBeNull();
    expect(checkDisplayName(" Ada Reporter ")).toBeNull();
  });

  it("says the count in the singular and the plural", () => {
    expect(journalistsLine(1)).toBe("1 journalist");
    expect(journalistsLine(3)).toBe("3 journalists");
  });
});
