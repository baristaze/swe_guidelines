// Pure: what the followers screen says. The desk's follows and its
// journalists in, rows out. A follow names the journalist and when; who
// follows stays the reader's, so no row says it. No React, no fetch.
import type { FollowView, JournalistView } from "@free_journalism/client";
import { formatDay } from "../journalists/journalistsModel";

/** What a row says of a journalist the desk's list does not hold (yet). */
export const UNKNOWN_JOURNALIST = "A journalist of the desk";

export interface FollowRow {
  id: string;
  journalist: string;
  since: string;
}

/** Each journalist's name by id, for the rows that name one. */
export function journalistNames(journalists: JournalistView[]): ReadonlyMap<string, string> {
  return new Map(journalists.map((journalist) => [journalist.id, journalist.display_name]));
}

/** The rows in the order the server pages them, oldest first. */
export function followRows(follows: FollowView[], names: ReadonlyMap<string, string>): FollowRow[] {
  return follows.map((follow) => ({
    id: follow.id,
    journalist: names.get(follow.journalist_id) ?? UNKNOWN_JOURNALIST,
    since: formatDay(follow.created_at),
  }));
}

/** "1 follower", "3 followers". */
export function followersLine(count: number): string {
  return `${count} ${count === 1 ? "follower" : "followers"}`;
}
