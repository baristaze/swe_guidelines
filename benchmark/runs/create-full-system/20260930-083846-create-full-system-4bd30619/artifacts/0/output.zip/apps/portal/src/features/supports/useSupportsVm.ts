import { useMemo } from "react";
import { useJournalists } from "../../queries/journalists";
import { useSupporters } from "../../queries/support";
import { journalistNames } from "../follows/followsModel";
import { supportRows } from "./supportsModel";

/** The desk's supports: what was given to which journalist, how often, and
 * where each stands. A push of `support.support.*` refreshes the list on
 * every open screen, a status the payment provider moved included. */
export function useSupportsVm() {
  const supports = useSupporters();
  const journalists = useJournalists();

  const names = useMemo(() => journalistNames(journalists.data ?? []), [journalists.data]);
  const rows = useMemo(() => supportRows(supports.data ?? [], names), [supports.data, names]);

  return {
    loading: supports.isPending,
    loadError: supports.error ?? journalists.error,
    rows,
  };
}
