import { useInfiniteQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import type { FollowPageView, FollowView } from "@free_journalism/client";
import { api } from "../app/api";
import { keys } from "./keys";

/** A page size, not a ceiling: the list follows the cursor to the end. */
const FOLLOWERS_PAGE_SIZE = 200;

/** Every follow of the desk's journalists, page after page, oldest first.
 * The pages loaded so far are returned as they arrive. A follow names the
 * journalist and when, never the reader. */
export function useFollowers() {
  const query = useInfiniteQuery({
    queryKey: keys.follows.list(FOLLOWERS_PAGE_SIZE),
    initialPageParam: null as string | null,
    getNextPageParam: (last: FollowPageView) => last.next_cursor,
    queryFn: ({ pageParam, signal }) => {
      const cursor = pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : "";
      return api.get<FollowPageView>(`/v1/followers?limit=${FOLLOWERS_PAGE_SIZE}${cursor}`, { signal });
    },
  });
  const { hasNextPage, isFetchingNextPage, isFetchNextPageError, fetchNextPage } = query;
  // A page that failed is not asked for again on its own, as the member list's.
  const walking = hasNextPage && !isFetchNextPageError;
  useEffect(() => {
    if (walking && !isFetchingNextPage) void fetchNextPage();
  }, [walking, isFetchingNextPage, fetchNextPage]);
  return {
    ...query,
    data: query.data?.pages.flatMap((page) => page.items) as FollowView[] | undefined,
    isPending: query.isPending || walking,
  };
}
