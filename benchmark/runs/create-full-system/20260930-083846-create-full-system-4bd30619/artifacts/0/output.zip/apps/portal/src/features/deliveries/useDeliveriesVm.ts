import { useMemo, useState } from "react";
import type { DeliveryState } from "@free_journalism/client";
import { errorMessage } from "../../app/errorMessage";
import { useInbox, useUpdateDelivery } from "../../queries/reports";
import { useMe } from "../../queries/tenancy";
import { useNoticesStore } from "../../store/notices";
import { canTriage, deliveryRows, parseTags, tagFilter, tagsText, type DeliveryRow } from "./deliveriesModel";

/** The desk's inbox under a state and a tag filter, and the controls a
 * member moves a delivery's state and edits its tags with. A push of
 * `reports.delivery.*` or `reports.message.*` refreshes the list on every
 * open screen. Nothing here opens a report: it is sealed to the journalist's
 * own key, which the portal does not hold. */
export function useDeliveriesVm() {
  const me = useMe();
  const [state, setState] = useState<DeliveryState | null>(null);
  const [tagDraft, setTagDraft] = useState("");
  const [tag, setTag] = useState<string | null>(null);
  const inbox = useInbox({ state, tag });
  const update = useUpdateDelivery();
  const notify = useNoticesStore((s) => s.notify);
  const [editing, setEditing] = useState<string | null>(null);
  const [tagsDraft, setTagsDraft] = useState("");
  const [error, setError] = useState<string | null>(null);

  const rows = useMemo(() => deliveryRows(inbox.data ?? []), [inbox.data]);

  const applyTag = () => setTag(tagFilter(tagDraft));
  const clearTag = () => {
    setTagDraft("");
    setTag(null);
  };

  const move = async (row: DeliveryRow, next: DeliveryState) => {
    if (next === row.state) return;
    try {
      await update.mutateAsync({ deliveryId: row.id, body: { state: next } });
    } catch (caught) {
      notify(errorMessage(caught, "The delivery was not moved."));
    }
  };

  const startEditing = (row: DeliveryRow) => {
    setError(null);
    setEditing(row.id);
    setTagsDraft(tagsText(row.tags));
  };

  const cancelEditing = () => {
    setError(null);
    setEditing(null);
  };

  const saveTags = async () => {
    if (editing === null) return;
    setError(null);
    const parsed = parseTags(tagsDraft);
    if ("error" in parsed) {
      setError(parsed.error);
      return;
    }
    try {
      await update.mutateAsync({ deliveryId: editing, body: { tags: parsed.tags } });
      setEditing(null);
    } catch (caught) {
      notify(errorMessage(caught, "The tags were not saved."));
    }
  };

  return {
    loading: inbox.isPending,
    loadError: inbox.error,
    rows,
    mayTriage: canTriage(me.data),
    state,
    setState,
    tagDraft,
    setTagDraft,
    tag,
    applyTag,
    clearTag,
    move,
    editing,
    tagsDraft,
    setTagsDraft,
    startEditing,
    cancelEditing,
    saveTags,
    error,
    saving: update.isPending,
  };
}
