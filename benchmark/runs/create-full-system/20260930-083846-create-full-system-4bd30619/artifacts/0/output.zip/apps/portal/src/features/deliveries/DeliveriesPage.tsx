import type { ReactNode } from "react";
import { AppNav } from "../../app/AppNav";
import { Banner, Button, Caret, Card, ErrorText, Menu, MenuItemRadio, Muted, Page, Pill, Table, TextField } from "../../design/kit";
import { tokens } from "../../design/tokens";
import { DELIVERY_STATES, deliveriesLine, stateLabel, threadLabel, type DeliveryRow } from "./deliveriesModel";
import { useDeliveriesVm } from "./useDeliveriesVm";

type Vm = ReturnType<typeof useDeliveriesVm>;

const row = { display: "flex", flexWrap: "wrap", gap: tokens.space.sm, alignItems: "end" } as const;

/** The state filter: every state, or one. */
function StateFilter({ vm }: { vm: Vm }) {
  const current = vm.state === null ? "All states" : stateLabel(vm.state);
  return (
    <Menu
      label="Show deliveries in"
      triggerLabel={`Showing ${current}. Change`}
      minWidth={160}
      trigger={
        <>
          <span>{current}</span>
          <Caret />
        </>
      }
    >
      <MenuItemRadio checked={vm.state === null} onSelect={() => vm.setState(null)}>
        All states
      </MenuItemRadio>
      {DELIVERY_STATES.map((state) => (
        <MenuItemRadio key={state} checked={vm.state === state} onSelect={() => vm.setState(state)}>
          {stateLabel(state)}
        </MenuItemRadio>
      ))}
    </Menu>
  );
}

/** A delivery's state: a menu of the states for a member, the word for a viewer. */
function StateControl({ vm, delivery }: { vm: Vm; delivery: DeliveryRow }) {
  if (!vm.mayTriage) return <span data-state={delivery.state}>{delivery.stateLabel}</span>;
  return (
    <Menu
      label="Move the delivery to"
      triggerLabel={`State: ${delivery.stateLabel}. Change`}
      triggerClassName="free-journalism-menu-trigger free-journalism-role-trigger"
      minWidth={160}
      disabled={vm.saving}
      trigger={
        <>
          <span data-state={delivery.state}>{delivery.stateLabel}</span>
          <Caret />
        </>
      }
    >
      {DELIVERY_STATES.map((state) => (
        <MenuItemRadio key={state} checked={state === delivery.state} onSelect={() => void vm.move(delivery, state)}>
          {stateLabel(state)}
        </MenuItemRadio>
      ))}
    </Menu>
  );
}

/** A delivery's tags, and for a member the field they are edited in. */
function TagsControl({ vm, delivery }: { vm: Vm; delivery: DeliveryRow }) {
  if (vm.editing === delivery.id) {
    return (
      <form
        onSubmit={(event) => {
          event.preventDefault();
          void vm.saveTags();
        }}
        style={row}
      >
        <TextField label="Tags, comma-separated" value={vm.tagsDraft} onChange={vm.setTagsDraft} />
        <Button type="submit" disabled={vm.saving}>
          {vm.saving ? "Saving…" : "Save"}
        </Button>
        <Button tone="plain" onClick={vm.cancelEditing}>
          Cancel
        </Button>
        {vm.error ? <ErrorText>{vm.error}</ErrorText> : null}
      </form>
    );
  }
  const pills: ReactNode =
    delivery.tags.length === 0 ? <Muted>None</Muted> : delivery.tags.map((tag) => <Pill key={tag}>{tag}</Pill>);
  return (
    <span style={{ display: "inline-flex", flexWrap: "wrap", gap: tokens.space.xs, alignItems: "center" }}>
      {pills}
      {vm.mayTriage ? (
        <Button tone="plain" onClick={() => vm.startEditing(delivery)} disabled={vm.saving || vm.editing !== null}>
          Edit tags
        </Button>
      ) : null}
    </span>
  );
}

export function DeliveriesPage() {
  const vm = useDeliveriesVm();
  return (
    <Page title="Inbox" nav={<AppNav />}>
      {vm.loadError ? <Banner>{vm.loadError.message}</Banner> : null}
      <Card title="Reports sent to the desk" id="inbox">
        <Muted>
          A report and its thread are sealed on the source&apos;s device. Each is opened with the journalist&apos;s own key,
          on the journalist&apos;s own device; this portal holds no journalist key and opens nothing. Here the desk moves a
          delivery through its states and tags it.
        </Muted>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            vm.applyTag();
          }}
          style={{ ...row, marginTop: tokens.space.md, marginBottom: tokens.space.md }}
        >
          <StateFilter vm={vm} />
          <TextField label="Tag" value={vm.tagDraft} onChange={vm.setTagDraft} />
          <Button type="submit">Filter</Button>
          {vm.tag !== null ? (
            <Button tone="plain" onClick={vm.clearTag}>
              Any tag
            </Button>
          ) : null}
        </form>
        {vm.loading ? (
          <Muted>Loading</Muted>
        ) : vm.rows.length === 0 ? (
          <Muted>
            {vm.state === null && vm.tag === null ? "No report has reached this desk yet." : "No delivery matches the filter."}
          </Muted>
        ) : (
          <>
            <Muted>{deliveriesLine(vm.rows.length)}</Muted>
            <Table
              headers={["State", "Tags", "Size", "Received", "Thread"]}
              rows={vm.rows.map((delivery) => [
                <StateControl vm={vm} delivery={delivery} />,
                <TagsControl vm={vm} delivery={delivery} />,
                delivery.size,
                delivery.received,
                threadLabel(delivery.replyable),
              ])}
            />
          </>
        )}
      </Card>
    </Page>
  );
}
