import type { FollowView, JournalistView } from "@free_journalism/client";
import { describe, expect, it } from "vitest";
import { followersLine, followRows, journalistNames, UNKNOWN_JOURNALIST } from "./followsModel";

const journalist = (id: string, name: string): JournalistView => ({
  id,
  display_name: name,
  public_key: null,
  created_at: "2026-09-30T10:00:00Z",
  created_by: "u1",
  updated_at: "2026-09-30T10:00:00Z",
  updated_by: "u1",
});

const follow = (id: string, journalistId: string, at: string): FollowView => ({
  id,
  journalist_id: journalistId,
  created_at: at,
});

describe("follows model", () => {
  it("names the journalist followed and the day, in the server's order", () => {
    const names = journalistNames([journalist("j1", "Ada Reporter"), journalist("j2", "Bo")]);
    expect(
      followRows([follow("f1", "j2", "2026-09-29T08:00:00Z"), follow("f2", "j1", "2026-09-30T09:30:00Z")], names),
    ).toEqual([
      { id: "f1", journalist: "Bo", since: "2026-09-29" },
      { id: "f2", journalist: "Ada Reporter", since: "2026-09-30" },
    ]);
  });

  it("says nothing of who follows: a row holds the journalist and the day alone", () => {
    const [row] = followRows([follow("f1", "j1", "2026-09-30T09:30:00Z")], journalistNames([]));
    expect(Object.keys(row!).sort()).toEqual(["id", "journalist", "since"]);
  });

  it("reads a journalist the list does not hold yet as one of the desk", () => {
    expect(followRows([follow("f1", "j9", "2026-09-30T09:30:00Z")], journalistNames([]))[0]?.journalist).toBe(
      UNKNOWN_JOURNALIST,
    );
  });

  it("says the count in the singular and the plural", () => {
    expect(followersLine(1)).toBe("1 follower");
    expect(followersLine(4)).toBe("4 followers");
  });
});
