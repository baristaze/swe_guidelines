import type { SupportView } from "@free_journalism/client";
import { describe, expect, it } from "vitest";
import { UNKNOWN_JOURNALIST } from "../follows/followsModel";
import { cadenceLabel, formatAmount, minorDigits, statusTone, supportRows, supportsLine } from "./supportsModel";

const support = (id: string, amount: number, currency: string, extra: Partial<SupportView> = {}): SupportView => ({
  id,
  journalist_id: "j1",
  amount,
  currency,
  cadence: "one_time",
  status: "paid",
  created_at: "2026-09-30T10:00:00Z",
  updated_at: "2026-09-30T10:05:00Z",
  version: 2,
  ...extra,
});

describe("supports model", () => {
  it("reads an amount in its currency's minor units", () => {
    expect(minorDigits("eur")).toBe(2);
    expect(minorDigits("jpy")).toBe(0);
    expect(formatAmount(1500, "eur")).toBe("€15.00");
    expect(formatAmount(1999, "usd")).toBe("$19.99");
    expect(formatAmount(1500, "jpy")).toBe("¥1,500");
  });

  it("shows a currency the runtime does not know beside the major amount", () => {
    expect(formatAmount(1234, "zz1")).toBe("12.34 ZZ1");
  });

  it("names the journalist, the amount, the cadence, the status, and the day, in the server's order", () => {
    const names = new Map([["j1", "Ada Reporter"]]);
    expect(
      supportRows([support("s1", 500, "eur"), support("s2", 1000, "usd", { cadence: "monthly", status: "active" })], names),
    ).toEqual([
      { id: "s1", journalist: "Ada Reporter", amount: "€5.00", cadence: "Once", status: "paid", since: "2026-09-30" },
      { id: "s2", journalist: "Ada Reporter", amount: "$10.00", cadence: "Monthly", status: "active", since: "2026-09-30" },
    ]);
  });

  it("says nothing of who gave, and reads an unknown journalist as one of the desk", () => {
    const [row] = supportRows([support("s1", 500, "eur", { journalist_id: "j9" })], new Map());
    expect(row?.journalist).toBe(UNKNOWN_JOURNALIST);
    expect(Object.keys(row!).sort()).toEqual(["amount", "cadence", "id", "journalist", "since", "status"]);
  });

  it("labels each cadence and tones each status", () => {
    expect(cadenceLabel("one_time")).toBe("Once");
    expect(cadenceLabel("monthly")).toBe("Monthly");
    expect(statusTone("active")).toBe("accent");
    expect(statusTone("paid")).toBe("accent");
    expect(statusTone("failed")).toBe("danger");
    expect(statusTone("expired")).toBe("danger");
    expect(statusTone("pending")).toBe("plain");
    expect(statusTone("open")).toBe("plain");
  });

  it("says the count in the singular and the plural", () => {
    expect(supportsLine(1)).toBe("1 support");
    expect(supportsLine(2)).toBe("2 supports");
  });
});
