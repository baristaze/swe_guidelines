import { AppNav } from "../../app/AppNav";
import { Banner, Card, Muted, Page, Table } from "../../design/kit";
import { followersLine } from "./followsModel";
import { useFollowsVm } from "./useFollowsVm";

export function FollowsPage() {
  const vm = useFollowsVm();
  return (
    <Page title="Followers" nav={<AppNav />}>
      {vm.loadError ? <Banner>{vm.loadError.message}</Banner> : null}
      <Card title="Who follows the desk's journalists" id="followers">
        <Muted>The desk sees which journalist is followed and since when, never by whom.</Muted>
        {vm.loading ? (
          <Muted>Loading</Muted>
        ) : vm.rows.length === 0 ? (
          <Muted>No reader follows a journalist of this desk yet.</Muted>
        ) : (
          <>
            <Muted>{followersLine(vm.rows.length)}</Muted>
            <Table headers={["Journalist", "Since"]} rows={vm.rows.map((row) => [row.journalist, row.since])} />
          </>
        )}
      </Card>
    </Page>
  );
}
