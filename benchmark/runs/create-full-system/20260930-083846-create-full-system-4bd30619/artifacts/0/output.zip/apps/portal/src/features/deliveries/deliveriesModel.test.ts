import type { DeliveryView, MeView } from "@free_journalism/client";
import { describe, expect, it } from "vitest";
import {
  canTriage,
  DELIVERY_STATES,
  deliveriesLine,
  deliveryRows,
  formatWhen,
  MAX_TAGS,
  parseTags,
  stateLabel,
  tagFilter,
  tagsText,
  threadLabel,
} from "./deliveriesModel";

const delivery = (id: string, extra: Partial<DeliveryView> = {}): DeliveryView => ({
  id,
  report_id: "r1",
  journalist_id: "j1",
  wrapped_key: "d3JhcHBlZA==",
  report_digest: "a".repeat(64),
  report_size: 2048,
  source_public_key: null,
  has_thread: false,
  state: "new",
  tags: [],
  created_at: "2026-09-30T10:15:42Z",
  updated_at: "2026-09-30T10:15:42Z",
  ...extra,
});

const meWith = (permissions: MeView["permissions"]): MeView => ({
  app: "portal",
  role: "member",
  permissions,
  user: { id: "u1", email: "ada@example.test", display_name: "Ada", created_at: "2026-09-01T00:00:00Z" },
  org: { id: "o1", name: "Ada's desk", slug: "ada", kind: "personal", created_at: "2026-09-01T00:00:00Z", deleted_at: null },
});

describe("deliveries model", () => {
  it("shows the state, the tags, the size, the time received, and whether a reply reaches the source", () => {
    expect(
      deliveryRows([
        delivery("d1"),
        delivery("d2", { state: "follow-up", tags: ["water", "council"], has_thread: true, report_size: 3 * 1024 * 1024 }),
      ]),
    ).toEqual([
      { id: "d1", state: "new", stateLabel: "New", tags: [], size: "2.0 KB", received: "2026-09-30 10:15 UTC", replyable: false },
      {
        id: "d2",
        state: "follow-up",
        stateLabel: "Follow-up",
        tags: ["water", "council"],
        size: "3.0 MB",
        received: "2026-09-30 10:15 UTC",
        replyable: true,
      },
    ]);
  });

  it("carries nothing sealed into a row: no key, no digest, no report", () => {
    const [row] = deliveryRows([delivery("d1", { source_public_key: "c291cmNl" })]);
    expect(Object.keys(row!).sort()).toEqual(["id", "received", "replyable", "size", "state", "stateLabel", "tags"]);
  });

  it("offers every state the server knows, in the inbox's order, each with its label", () => {
    expect(DELIVERY_STATES).toEqual(["new", "reviewing", "follow-up", "useful", "archived"]);
    expect(DELIVERY_STATES.map(stateLabel)).toEqual(["New", "Reviewing", "Follow-up", "Useful", "Archived"]);
  });

  it("reads tags as typed: trimmed, blanks dropped, each once, an empty text clearing them", () => {
    expect(parseTags(" water , council,,water ")).toEqual({ tags: ["water", "council"] });
    expect(parseTags("   ")).toEqual({ tags: [] });
    expect(tagsText(["water", "council"])).toBe("water, council");
  });

  it("refuses a tag past the length, or more tags than the server keeps, before anything is sent", () => {
    expect(parseTags("x".repeat(41))).toHaveProperty("error");
    expect(parseTags("x".repeat(40))).toEqual({ tags: ["x".repeat(40)] });
    const many = Array.from({ length: MAX_TAGS + 1 }, (_, index) => `t${index}`).join(",");
    expect(parseTags(many)).toHaveProperty("error");
  });

  it("filters by a trimmed tag, and by none when blank", () => {
    expect(tagFilter("  water ")).toBe("water");
    expect(tagFilter("   ")).toBeNull();
  });

  it("lets a member triage the inbox and a viewer only read it", () => {
    expect(canTriage(meWith(["read", "write"]))).toBe(true);
    expect(canTriage(meWith(["read"]))).toBe(false);
    expect(canTriage(undefined)).toBe(false);
  });

  it("says the time in UTC to the minute, the thread in words, and the count in the singular and the plural", () => {
    expect(formatWhen("2026-09-30T23:59:59Z")).toBe("2026-09-30 23:59 UTC");
    expect(formatWhen("2026-10-01T01:30:00+02:00")).toBe("2026-09-30 23:30 UTC");
    expect(threadLabel(true)).toBe("Can be replied to");
    expect(threadLabel(false)).toBe("No reply possible");
    expect(deliveriesLine(1)).toBe("1 delivery");
    expect(deliveriesLine(5)).toBe("5 deliveries");
  });
});
