// Pure: what the supporters screen says. The desk's supports and its
// journalists in, rows out. A support names the journalist, what was given,
// how often, and where it stands; who gave stays the reader's. No React, no
// fetch.
import type { SupportCadence, SupportStatus, SupportView } from "@free_journalism/client";
import { formatDay } from "../journalists/journalistsModel";
import { UNKNOWN_JOURNALIST } from "../follows/followsModel";

export interface SupportRow {
  id: string;
  journalist: string;
  amount: string;
  cadence: string;
  status: SupportStatus;
  since: string;
}

const CADENCES: Record<SupportCadence, string> = {
  one_time: "Once",
  monthly: "Monthly",
};

/** How many minor units the currency has: 2 for the euro's cents, 0 for
 * the yen. A code the runtime does not know is read as having two. */
export function minorDigits(currency: string): number {
  try {
    return new Intl.NumberFormat("en", { style: "currency", currency }).resolvedOptions().maximumFractionDigits ?? 2;
  } catch {
    return 2;
  }
}

/** An amount given in the currency's minor units, as a person reads it:
 * 1500 eur is "€15.00", 1500 jpy is "¥1,500". A code the runtime does not
 * know is shown beside the major amount. */
export function formatAmount(amount: number, currency: string, locale = "en"): string {
  const digits = minorDigits(currency);
  const major = amount / 10 ** digits;
  try {
    return new Intl.NumberFormat(locale, { style: "currency", currency: currency.toUpperCase() }).format(major);
  } catch {
    return `${major.toFixed(digits)} ${currency.toUpperCase()}`;
  }
}

/** "Once", "Monthly". */
export function cadenceLabel(cadence: SupportCadence): string {
  return CADENCES[cadence];
}

/** The rows in the order the server pages them, oldest first. */
export function supportRows(supports: SupportView[], names: ReadonlyMap<string, string>, locale = "en"): SupportRow[] {
  return supports.map((support) => ({
    id: support.id,
    journalist: names.get(support.journalist_id) ?? UNKNOWN_JOURNALIST,
    amount: formatAmount(support.amount, support.currency, locale),
    cadence: cadenceLabel(support.cadence),
    status: support.status,
    since: formatDay(support.created_at),
  }));
}

/** Whether the status is money that came in or keeps coming in, or one
 * that went nowhere; the pill's tone. */
export function statusTone(status: SupportStatus): "accent" | "danger" | "plain" {
  if (status === "paid" || status === "active") return "accent";
  if (status === "failed" || status === "expired") return "danger";
  return "plain";
}

/** "1 support", "3 supports". */
export function supportsLine(count: number): string {
  return `${count} ${count === 1 ? "support" : "supports"}`;
}
