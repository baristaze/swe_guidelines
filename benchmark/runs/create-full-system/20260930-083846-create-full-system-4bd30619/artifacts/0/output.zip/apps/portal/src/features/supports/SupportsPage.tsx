import { AppNav } from "../../app/AppNav";
import { Banner, Card, Muted, Page, Pill, Table } from "../../design/kit";
import { statusTone, supportsLine } from "./supportsModel";
import { useSupportsVm } from "./useSupportsVm";

export function SupportsPage() {
  const vm = useSupportsVm();
  return (
    <Page title="Supporters" nav={<AppNav />}>
      {vm.loadError ? <Banner>{vm.loadError.message}</Banner> : null}
      <Card title="What readers give the desk's journalists" id="supporters">
        <Muted>The desk sees what was given, how often, and where it stands, never by whom.</Muted>
        {vm.loading ? (
          <Muted>Loading</Muted>
        ) : vm.rows.length === 0 ? (
          <Muted>No reader supports a journalist of this desk yet.</Muted>
        ) : (
          <>
            <Muted>{supportsLine(vm.rows.length)}</Muted>
            <Table
              headers={["Journalist", "Amount", "Cadence", "Status", "Since"]}
              rows={vm.rows.map((row) => [
                row.journalist,
                row.amount,
                row.cadence,
                <Pill tone={statusTone(row.status)}>
                  {row.status}
                </Pill>,
                row.since,
              ])}
            />
          </>
        )}
      </Card>
    </Page>
  );
}
