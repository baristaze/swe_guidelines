import { useInfiniteQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import type { SupportPageView, SupportView } from "@free_journalism/client";
import { api } from "../app/api";
import { keys } from "./keys";

/** A page size, not a ceiling: the list follows the cursor to the end. */
const SUPPORTERS_PAGE_SIZE = 200;

/** Every support of the desk's journalists, page after page, oldest first.
 * The pages loaded so far are returned as they arrive. A support names the
 * journalist, what was given, and where it stands, never the reader. */
export function useSupporters() {
  const query = useInfiniteQuery({
    queryKey: keys.supports.list(SUPPORTERS_PAGE_SIZE),
    initialPageParam: null as string | null,
    getNextPageParam: (last: SupportPageView) => last.next_cursor,
    queryFn: ({ pageParam, signal }) => {
      const cursor = pageParam ? `&cursor=${encodeURIComponent(pageParam)}` : "";
      return api.get<SupportPageView>(`/v1/supporters?limit=${SUPPORTERS_PAGE_SIZE}${cursor}`, { signal });
    },
  });
  const { hasNextPage, isFetchingNextPage, isFetchNextPageError, fetchNextPage } = query;
  // A page that failed is not asked for again on its own, as the member list's.
  const walking = hasNextPage && !isFetchNextPageError;
  useEffect(() => {
    if (walking && !isFetchingNextPage) void fetchNextPage();
  }, [walking, isFetchingNextPage, fetchNextPage]);
  return {
    ...query,
    data: query.data?.pages.flatMap((page) => page.items) as SupportView[] | undefined,
    isPending: query.isPending || walking,
  };
}
