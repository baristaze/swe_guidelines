# Handoff

Run of `arch-scaffold-new free_journalism --codeowners acme --first
journalists Journalist display_name:str` over `target/product-spec.md`
(the Independent Journalism Platform), guideline `0.45.0`.

## Done

- Name `free_journalism`, given in the arguments.
- Copied the scaffold with `new.py` (935 files, pinned at v0.45.0). The
  base was not recorded, since the plugin is not a clean checkout, so the
  repository has no commit yet; `arch-upgrade-scaffold` grafts the base on
  its first move. `make setup` and `make check` were green on the copy.
- Docker runs. `.env` copied from `.env.example`; every port knob was
  free, so no value in `.env` changed.
- ADRs:
  - 0082: the product on the core. A desk is an org, a reader is an
    identity, a source is neither. The platform never decrypts a report.
    Lists the first namespaces.
  - 0083: Stripe (Checkout, Connect Express, the platform fee as the
    application fee), `integrations/payments/`, with a twin.
  - 0084: Postmark (chosen over Resend), `integrations/email/`, with a
    twin; sends go through the work queue.
  - 0085: Twilio, `integrations/sms/`, with a twin; only to a verified
    number that opted in.
  - 0086: the malware scanner, `integrations/scanning/`, with a twin.
    Files the platform can read are scanned whole; a report's attachments
    are checked by digest on the journalist's client. The real provider
    is chosen when the real client is written, against the conditions
    the ADR states.
- The README opening, the llms.txt summary, and `.github/CODEOWNERS`
  (`@acme` on every rule).
- The `journalists` namespace and its `Journalist` entity (`core` role,
  `org` scope, `Trackable`, no version, no unique key besides the id, no
  manager-owned field):
  - the OM type, the table, and the migration `core/202609301545_journalists`
    with its `tenant_fence` policy;
  - the Postgres and memory storage, the manager (create, get, list,
    update, purge_tenant), and the roots;
  - the worker's per-tenant purge;
  - the API routes (`/v1/journalists`, `/v1/journalists/{id}`);
  - the regenerated clients;
  - the portal screen `/journalists`, linked from Home;
  - the contract, unit, integration, API, and portal tests.
- Gates, first run, all green: `make infra-up`, `make migrate`,
  `make openapi` (once, before the screen), `make check`,
  `make migrate-check`, `make test-integration`.

## Decided

Each decision is in the ADRs above. The entity's choices are in ADR 0082:
not `SoftDeletable`, since a profile goes with its desk, and no version.

## Left

- Nothing is committed. The first commit is the person's to make.
- The namespaces 0082 lists, in order: `community`, `support`, `reports`,
  `notifications`, `safety`. Each integration lands with the namespace
  that needs it (0083 to 0086).
- The public directory of journalists across desks, and the link from a
  journalist to the person who writes as them, both come with
  verification (ADR 0082).
- The placeholder GitHub repository `free-journalism-org/free_journalism`
  in `deployment/cloud/environments.json` and in the site's test is the
  person's to set.


---

# Session 2: the Initial MVP (2026-09-30)

Asked: build the MVP's three loops in the guideline's shape (follow and
support; a source sends a tip, encrypted on the device per recipient; a
journalist works the inbox and replies), each with an end-to-end
integration test, until `make check` and `make test-integration` pass.
Gate budget: one run plus at most three reruns. During the build only
targeted tools run (ruff, pyright, pytest on named files); those are not
counted as gate runs.

## Plan

1. ADR 0087 (written): a reader acts on a desk from the identity stage, a
   source from the request stage; visitor outbox rows carry `EMPTY_UUID`
   as actor; a source's writes are `PUT`s of device-minted ids; the
   ciphertext is kept once in a `sealed-reports` bucket under `EMPTY_UUID`.
2. Payments integration (done, by a sub-agent): `integrations/payments/`
   with Stripe (SDK `stripe==15.6.1`), twin, absent; `POST /webhooks/payments`
   queues on `Queues.WEBHOOKS` as provider `payments`. Settings, env,
   terraform (API only), runbook `docs/runbooks/providers/stripe.md`.
3. `journalists`: `public_key` on `Journalist`, and a public read of a
   profile (`GET /v1/desks/{org_id}/journalists/{id}`, no credential).
4. `community` namespace, entity `Follow` (core, org, append-only, unique
   per desk+journalist+identity).
5. `support` namespace, entity `Support` (core, org, Trackable, versioned;
   status is the manager's). Checkout opened synchronously in the request
   (ADR 0083: a checkout answers 503 when Stripe is down). The payment
   delivery is applied by a `payments` delivery provider in the maintenance
   worker (the core's `DeliveryProviderInterface`), a compare-and-set on
   the support's version.
6. `reports` namespace, entities `Delivery` (core, org, Trackable, state)
   and `Message` (core, org, append-only thread).
7. Python client: `free_journalism.client.sealing` (X25519 + HKDF-SHA256 +
   AES-256-GCM) and methods for the loop routes.
8. `make openapi`; portal screens for followers, supports, inbox.
9. Integration tests driving each loop end to end over Postgres.
10. READMEs, llms.txt, then the gates.

## Decided (session 2)

- No new work kind: nothing in the three loops is deferred work. The
  checkout is synchronous (ADR 0083) and the provider's deliveries go
  through the core's delivery consumer, which is how the worker README
  says a provider is added. `arch-scaffold-worker` was therefore not run.
- Out of the MVP, left for later: unfollow, journalist updates to
  followers, cancel/refund, Stripe Connect onboarding and payouts,
  notifications, safety (verification, abuse, rate limits past the
  gateway's, retention), the directory, internal notes, investigation
  links, the purge of a sealed report once its last delivery is purged.

## Progress (session 2)

- [x] ADR 0087
- [x] payments integration (+ worker settings test entries)
- [x] core: `visitor_row` in `om/outbox/types/row.py`; `visitor` rate budget
  (`FREE_JOURNALISM_VISITOR_RATE_*`) for no-credential routes
- [x] journalists: `public_key` (migration 202609301700), public profile
  `GET /v1/desks/{org_id}/journalists/{id}`
- [x] community: `Follow` (migration 202609301710), `PUT
  /v1/desks/{org}/journalists/{id}/follow`, `GET /v1/follows`, `GET
  /v1/followers`; tests. Weaker-stage ops are listed in
  `om/tests/unit/test_storage_exceptions.py` (REQUEST_/IDENTITY_TRANSITIONS)
  with docstrings opening "Platform-internal", as the core's convention is.
- [x] support (sub-agent): `Support` (migration 202609301720), checkout at
  Stripe in the request, `PaymentDeliveriesImpl` in the maintenance worker
  (`payments.py`, registered in `build_consumer`), settings
  `FREE_JOURNALISM_PLATFORM_FEE_BASIS_POINTS`, `FREE_JOURNALISM_SUPPORT_RETURN_URL`.
- [x] reports (sub-agent): `Delivery`, `Message` (migrations 202609301730/1731),
  bucket `sealed-reports` (Makefile, terraform), source routes under
  `/v1/reports`, the desk's `/v1/inbox`; every open of a report is an audit
  entry (so a viewer, who cannot write the audit, cannot open a report).
- [x] `IntegrationsOverImpl` now takes both providers (arch-check CON-06).
- [x] OM-02 `tenantless` option in pyproject for the reader/source types.
- [x] community README; om/README, API README, llms.txt entries.
- [x] `make openapi`; portal screens `/followers`, `/supporters`, `/inbox`
  (list, filter, state and tags; no decryption in the browser yet).
- [x] Python client: `free_journalism.client.sealing` (X25519 + HKDF-SHA256
  + AES-256-GCM) and the loop methods.
- [x] Loop tests (integration, over compose Postgres, API in-process, the
  worker's delivery consumer beside it, the payments twin):
  `services/api/tests/test_loop_follow_and_support_integration.py`,
  `test_loop_send_a_report_integration.py`,
  `test_loop_inbox_and_reply_integration.py`, helper `loop_support.py`.
- [x] Gates, run 1 of at most 4, all green: `make migrate`, `make check`
  (ruff, format, pyright, arch-check 106 rules clean, 2345 unit tests,
  portal/client/site lint, typecheck, tests), `make migrate-check` (every
  role in sync), `make test-integration` (358 passed, the six loop cases
  among them).

## Decided (session 2, beyond ADR 0087)

- Weaker-stage operations follow the core's own convention: each is named
  in `om/tests/unit/test_storage_exceptions.py` and its docstring opens
  "Platform-internal"; the reader's cross-desk reads are on the CTX-12
  tenantless list with "Cross-tenant" docstrings.
- A source's retry resends the same sealed bytes under the same report id;
  sealed afresh under that id it is refused as a conflict.
- A source's reply key and follow-up digest come together or not at all.
- Viewers list and read deliveries but cannot open a report, since every
  open is an audit entry and a viewer cannot write one.
- The Python client does not retry a source's `PUT`s on its own; they are
  safe to repeat by id, but widening `may_retry` to PUT changes other calls.
- Checkout fee: `application_fee` is computed (5% default) and carried on
  the checkout request; Stripe takes it only on a charge to a connected
  account, so the Stripe impl sends it once Connect lands.

## Left (after session 2)

- Nothing is committed; the first commit is the person's to make.
- Out of the MVP by the brief: unfollow, journalist updates to followers,
  notifications (0084, 0085), safety (verification, abuse, blocks,
  retention), the directory, internal notes, investigation links,
  cancel/refund, Stripe Connect onboarding and payouts (0083), the
  scanner (0086), and the portal's decryption of reports and threads (the
  journalist's client today is the Python client's `sealing`).
- The sealed object in `sealed-reports` is not removed when its last
  delivery is purged.
- The Stripe impl is proven against recorded wire shapes only; no live
  account or key exists (`docs/runbooks/providers/stripe.md`).
