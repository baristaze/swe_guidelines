-- Deliveries: one sealed report as one journalist's desk, the org, received
-- it (ADR 0082). The ciphertext is kept once in the object store; the row
-- holds the journalist's wrapped copy of the report's key, the digest and
-- size of the ciphertext, and what a source who wants replies sent: the
-- public key a reply is sealed to and the digest of their follow-up secret.
-- The state and the tags are the journalist's.
--
-- The table opens with its mixin header in house-style order: the id, the
-- tenant, the provenance. Its policy is the core role's `tenant_fence` on
-- `org_id`, forced on the table's owner too, with the system login's clause
-- for the sweep. The grants come from the role's first migration, by default
-- privilege.

CREATE TABLE core.deliveries (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid NOT NULL,
    report_id uuid NOT NULL,
    journalist_id uuid NOT NULL,
    wrapped_key text NOT NULL,
    report_digest text NOT NULL,
    report_size integer NOT NULL,
    source_public_key text NULL,
    follow_up_digest text NULL,
    state text NOT NULL,
    tags jsonb NOT NULL,
    CONSTRAINT pk_deliveries PRIMARY KEY (id)
);
CREATE INDEX ix_deliveries_org_id_id ON core.deliveries (org_id, id);
CREATE INDEX ix_deliveries_org_id_state_id ON core.deliveries (org_id, state, id);

ALTER TABLE core.deliveries ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.deliveries FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON core.deliveries
    USING (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    )
    WITH CHECK (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    );
