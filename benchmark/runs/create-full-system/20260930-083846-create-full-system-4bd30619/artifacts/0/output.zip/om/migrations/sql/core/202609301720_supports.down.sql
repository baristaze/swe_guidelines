-- Takes the supports table back out: its policy, then the table with its
-- indexes.

DROP POLICY tenant_fence ON core.supports;
DROP TABLE core.supports;
