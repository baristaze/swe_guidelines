-- Takes the public key back off the journalists table.

ALTER TABLE core.journalists DROP COLUMN public_key;
