-- Follows: a reader follows a journalist of a desk, the org (ADR 0082). The
-- row is the desk's and names the reader's identity, never a user of the
-- desk; one per reader and journalist.
--
-- The table opens with its mixin header in house-style order: the id, the
-- tenant, the time. Its policy is the core role's `tenant_fence` on
-- `org_id`, forced on the table's owner too, with the system login's clause
-- for the sweep and for a reader's read across desks by identity (ADR 0087).
-- The grants come from the role's first migration, by default privilege.

CREATE TABLE core.follows (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    created_at timestamptz NOT NULL,
    journalist_id uuid NOT NULL,
    identity_id uuid NOT NULL,
    CONSTRAINT pk_follows PRIMARY KEY (id)
);
CREATE INDEX ix_follows_org_id_id ON core.follows (org_id, id);
CREATE UNIQUE INDEX uq_follows_reader ON core.follows (org_id, journalist_id, identity_id);
CREATE INDEX ix_follows_identity_id_id ON core.follows (identity_id, id);

ALTER TABLE core.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.follows FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON core.follows
    USING (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    )
    WITH CHECK (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    );
