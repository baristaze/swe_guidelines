-- Takes the deliveries table back out: its policy, then the table with its
-- indexes.

DROP POLICY tenant_fence ON core.deliveries;
DROP TABLE core.deliveries;
