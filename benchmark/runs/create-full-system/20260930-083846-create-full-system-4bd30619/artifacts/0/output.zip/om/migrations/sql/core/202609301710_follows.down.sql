-- Takes the follows table back out: its policy, then the table with its
-- indexes.

DROP POLICY tenant_fence ON core.follows;
DROP TABLE core.follows;
