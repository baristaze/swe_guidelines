-- A journalist's public key: the public half of the X25519 pair their own
-- device made, which a source's device wraps a report's key to (ADR 0082).
-- Null until the journalist sets one; a profile with no key takes no report.

ALTER TABLE core.journalists ADD COLUMN public_key text;
