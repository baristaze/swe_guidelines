-- Supports: a reader's support of a journalist of a desk, the org, once or
-- monthly (ADR 0082, ADR 0083). The row is the desk's and names the reader's
-- identity, never a user of the desk; its status is what the payment
-- provider delivered, written by compare-and-set on its version.
--
-- The table opens with its mixin header in house-style order: the id, the
-- tenant, the provenance. Its policy is the core role's `tenant_fence` on
-- `org_id`, forced on the table's owner too, with the system login's clause
-- for the sweep and for a reader's read across desks by identity (ADR 0087).
-- The grants come from the role's first migration, by default privilege.

CREATE TABLE core.supports (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    created_at timestamptz NOT NULL,
    updated_at timestamptz NOT NULL,
    created_by uuid NOT NULL,
    updated_by uuid NOT NULL,
    version integer NOT NULL,
    journalist_id uuid NOT NULL,
    identity_id uuid NOT NULL,
    amount integer NOT NULL,
    currency text NOT NULL,
    cadence text NOT NULL,
    status text NOT NULL,
    checkout_id text NULL,
    checkout_url text NULL,
    CONSTRAINT pk_supports PRIMARY KEY (id)
);
CREATE INDEX ix_supports_org_id_id ON core.supports (org_id, id);
CREATE INDEX ix_supports_identity_id_id ON core.supports (identity_id, id);

ALTER TABLE core.supports ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.supports FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_fence ON core.supports
    USING (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    )
    WITH CHECK (
        org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
        OR (
            current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
            AND current_user = 'free_journalism_system'
        )
    );
