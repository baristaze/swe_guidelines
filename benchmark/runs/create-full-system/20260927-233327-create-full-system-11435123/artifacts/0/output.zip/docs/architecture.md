# Architecture, as built

This page describes the system as it is. How we build is the guideline, pinned in
[`specs/architecture.md`](../specs/architecture.md); why this system decided what it did is in [`adr/`](adr/).

## Shape

- One object model distribution, `om/` (`acme.om`): the entities, the managers, and their storage, split into
  namespaces: `tenancy`, `events`, `audit`, `outbox`, `idempotency`, and the product's own, starting with
  `journalists` ([ADR 0003](adr/0003-product-mapping.md)).
- `infra/` (`acme.infra`): cache, buckets, topics, queues, secrets, each an interface with a local and a cloud impl,
  and the process's observability.
- `integrations/` (`acme.integrations`): the external providers, each an interface with a real client and a twin
  ([ADR 0005](adr/0005-external-providers-and-their-twins.md)).
- One API process, `services/api/`, and one worker, `workers/maintenance/`; one browser app, `apps/portal/`.
- `clients/python/`, the typed client generated from the API's OpenAPI document, and `ops/`, the operator's tool.

## Data

Three database roles, one schema each: `core` (tenancy, the outbox, the idempotency marker, the product's records),
`activity` (events, audit), and `queue` (the work queue). Every table declares its role and its tenancy scope;
every tenant table carries a row-level security policy created in the migration that creates it. Three logins reach
the database (`acme_migration`, `acme_runtime`, `acme_system`), none a superuser.

Reports are encrypted on the sender's device; the platform stores ciphertext and per-recipient wrapped keys only
([ADR 0004](adr/0004-end-to-end-encrypted-reports.md)).

## Decisions

| ADR | Decision |
|-----|----------|
| [0001](adr/0001-root-package.md) | the root package is `acme` |
| [0002](adr/0002-technology-choices.md) | the stack as adopted, its substitutions, and versions held back |
| [0003](adr/0003-product-mapping.md) | a desk is the tenant; readers, patrons, and sources are identities |
| [0004](adr/0004-end-to-end-encrypted-reports.md) | reports are end-to-end encrypted; scanning by hash on the recipient |
| [0005](adr/0005-external-providers-and-their-twins.md) | every external provider behind an interface with a twin |
| [0006](adr/0006-identity-scoped-tenancy-rows.md) | the identity's copy of each membership; `tenant_id` on identity tables |
| [0007](adr/0007-work-item-key-unique-per-tenant.md) | the work item's key is unique per tenant; arch-check ASY-16 excepted |
| [0008](adr/0008-journalist-profile-entity.md) | the journalist profile: trackable, soft-deletable, unversioned, org scope |
