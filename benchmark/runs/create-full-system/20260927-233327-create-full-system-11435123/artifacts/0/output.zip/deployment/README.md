# How the platform runs

## Processes

| Process | What it is | Where it runs |
|---------|------------|---------------|
| `api` | the one API process: the gateway, every router, the realtime socket, the operator plane | ECS service behind the load balancer at `api.<base domain>`; on the host locally |
| `maintenance` | the worker whose work is the maintenance sweep: relays the outbox, purges what is past retention | ECS service with no public surface; on the host locally |
| `portal` | the browser app, a static bundle | S3 behind CloudFront at `app.<base domain>`; Vite's dev server locally |

Each process logs to its own log group (`/acme/<env>/<process>`), serves `/healthz` (what every health check reads)
and `/metrics` (read by the collector beside it, never by the public edge), and reports errors to the tracker.

## Locally

`deployment/local/docker-compose.yml` runs every dependency in a container: Postgres (with the three logins every
environment uses), Valkey, the object store, and the queue. The application runs on the host through
`scripts/dev.sh`. The optional `devx` profile adds one browser per backing service, Jaeger for traces, GlitchTip for
errors, and Prometheus with Grafana as the metrics view, whose dashboard has the same panels as the cloud's.
`deployment/local/docker-compose.full.yml` runs the application in containers too, for the case that asks for it.

## In the cloud

Two environments, each in an AWS account of its own: **staging** at `staging.<domain>`, and **production** at
`<domain>`. `deployment/cloud/environments.json` names each account, its region, its public names, and the profiles a
person holds for it.

- **Bootstrap roots** (`terraform/bootstrap/{staging,prod}`) hold what must exist before the pipeline: the state and
  artifacts buckets, the image registry, the pipeline's roles and their trust, the investigator role, the budget,
  and the DNS zones. The administrator applies them, once, through `scripts/cloud_create.sh`.
- **Environment roots** (`terraform/environments/{staging,prod}`) hold everything else, and the pipeline applies them
  on every deploy. The database migrates as a one-off task on the new image, inside the apply, before the rollout.

## The pipeline

- A merge to `main` deploys staging, with no approval.
- A release fast-forwards `release` to the last commit staging deployed; that plans production, waits for a person's
  approval on the plan, and applies it. Production never rebuilds: it promotes the images and the bundle staging
  built, replicated into its own account and checked against the digests recorded at build time.
- A revert is the rollback; the fast rollback returns production to the previous release only.

## Watching it

Each environment has one dashboard (`acme-<env>`) and a small set of alarms to one topic (`acme-<env>-alarms`), to
which the owner's address subscribes: the edge's error ratio and latency, unhealthy targets, a process below its
desired count, the database's processor and free storage, and the outbox's lag.

## Two switches and a budget

- `autoscaling_enabled` (off by default) turns on every process's autoscaling in one pull request.
- `destroyable` (off by default) lets the nuke script empty the buckets and skip the final snapshot outside
  production; production's database always keeps its final snapshot and its deletion protection until a released
  change lifts it.
- Every account carries a monthly budget, alerting at half, nine-tenths, and all of it, and at a forecast past it.
