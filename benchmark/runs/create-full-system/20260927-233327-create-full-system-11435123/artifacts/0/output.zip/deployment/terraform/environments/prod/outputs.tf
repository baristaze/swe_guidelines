output "api_url" {
  value = module.load_balancer.url
}

output "portal_url" {
  value = module.portal.url
}

output "portal_bucket" {
  value = module.portal.bucket
}

output "portal_distribution_id" {
  value = module.portal.distribution_id
}

output "cluster_name" {
  value = module.cluster.cluster_name
}

output "api_service_name" {
  value = module.api.service_name
}

output "worker_service_name" {
  value = module.worker.service_name
}

output "migration_task_definition" {
  value = module.migration.task_definition_family
}

output "grant_operator_task_definition" {
  description = "The grant-operator one-off task definition's family, acme-<env>-grant-operator, which grant-operator.yml runs."
  value       = module.grant_operator.task_definition_family
}

output "grant_operator_container" {
  value = module.grant_operator.container_name
}

output "oneoff_subnet_ids" {
  value = module.network.private_subnet_ids
}

output "oneoff_security_group_ids" {
  value = [module.cluster.tasks_security_group_id]
}

output "token_secret_names" {
  value = module.secrets.token_secret_names
}

output "alarm_topic_arn" {
  value = module.observability.alarm_topic_arn
}

output "alarm_names" {
  value = module.observability.alarm_names
}

output "dashboard_name" {
  value = module.observability.dashboard_name
}

output "log_groups" {
  value = [module.api.log_group, module.worker.log_group, module.migration.log_group, module.grant_operator.log_group]
}

output "data_buckets" {
  value = module.buckets.bucket_names
}

output "database_identifier" {
  value = module.database.identifier
}

output "autoscaling_enabled" {
  value = var.autoscaling_enabled
}
