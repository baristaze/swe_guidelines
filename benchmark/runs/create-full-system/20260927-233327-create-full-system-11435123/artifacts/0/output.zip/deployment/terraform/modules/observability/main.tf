# The operator's view of one environment: the alarm topic acme-<env>-alarms
# with its email subscription, the default alarm set, and the dashboard
# acme-<env>, whose panel titles are panels.json, the same list the local
# metrics view carries (a test holds the two equal).
#
# Custom metrics come from the collector beside each task: namespace Acme,
# dimensions environment and service (the process) plus a metric's own bounded
# labels (route, status, subsystem, outcome).

variable "name" {
  description = "acme-<env>."
  type        = string
}

variable "environment" {
  type = string
}

variable "region" {
  type = string
}

variable "alarm_email" {
  description = "The address subscribed to the alarm topic. Empty subscribes nobody (the topic stays)."
  type        = string
}

variable "metrics_namespace" {
  type    = string
  default = "Acme"
}

variable "cluster_name" {
  type = string
}

variable "api_service_name" {
  type = string
}

variable "worker_service_name" {
  type = string
}

variable "worker_process" {
  description = "The process whose sweep sets the outbox and queue gauges."
  type        = string
  default     = "maintenance"
}

variable "alb_arn_suffix" {
  type = string
}

variable "target_group_arn_suffix" {
  type = string
}

variable "db_identifier" {
  type = string
}

variable "cache_replication_group_id" {
  type = string
}

variable "queue_names" {
  description = "The queues and their dead-letter queues."
  type        = list(string)
}

variable "metric_names" {
  description = "The gauges the worker's sweep sets, as the processes name them."
  type = object({
    outbox_lag       = string
    queue_oldest_age = string
    work_failed      = string
    records_parked   = string
    requests         = string
    request_seconds  = string
    outcomes         = string
  })
  default = {
    outbox_lag       = "acme_outbox_lag_seconds"
    queue_oldest_age = "acme_queue_oldest_age_seconds"
    work_failed      = "acme_work_failed"
    records_parked   = "acme_records_parked"
    requests         = "acme_http_requests_total"
    request_seconds  = "acme_http_request_seconds"
    outcomes         = "acme_outcomes_total"
  }
}

variable "thresholds" {
  description = "The numbers are the system's; the set and the topic are the shape."
  nullable    = false
  type = object({
    alb_5xx_ratio            = number
    alb_p95_seconds          = number
    db_cpu_percent           = number
    db_free_storage_bytes    = number
    outbox_lag_seconds       = number
    queue_oldest_age_seconds = number
    work_failed              = number
    records_parked           = number
  })
  default = {
    alb_5xx_ratio            = 0.01
    alb_p95_seconds          = 1
    db_cpu_percent           = 80
    db_free_storage_bytes    = 2147483648
    outbox_lag_seconds       = 60
    queue_oldest_age_seconds = 300
    work_failed              = 0
    records_parked           = 0
  }
}

locals {
  panels = jsondecode(file("${path.module}/panels.json"))
  ns     = var.metrics_namespace
  env    = var.environment

  gauge_dims = {
    environment = var.environment
    service     = var.worker_process
  }

  alb_dims = {
    LoadBalancer = var.alb_arn_suffix
  }

  tg_dims = {
    LoadBalancer = var.alb_arn_suffix
    TargetGroup  = var.target_group_arn_suffix
  }
}

# ---------------------------------------------------------------------------
# The topic.
# ---------------------------------------------------------------------------

resource "aws_sns_topic" "alarms" {
  name              = "${var.name}-alarms"
  kms_master_key_id = "alias/aws/sns"
}

resource "aws_sns_topic_subscription" "email" {
  count     = var.alarm_email == "" ? 0 : 1
  topic_arn = aws_sns_topic.alarms.arn
  protocol  = "email"
  endpoint  = var.alarm_email
}

# ---------------------------------------------------------------------------
# The edge: error ratio, latency, unhealthy targets.
# ---------------------------------------------------------------------------

resource "aws_cloudwatch_metric_alarm" "alb_5xx_ratio" {
  alarm_name          = "${var.name}-alb-5xx-ratio"
  alarm_description   = "Share of responses at the load balancer that are 5xx."
  comparison_operator = "GreaterThanThreshold"
  threshold           = var.thresholds.alb_5xx_ratio
  evaluation_periods  = 5
  datapoints_to_alarm = 3
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]

  metric_query {
    id          = "ratio"
    expression  = "IF(requests > 0, (FILL(target5xx, 0) + FILL(elb5xx, 0)) / requests, 0)"
    label       = "5xx ratio"
    return_data = true
  }

  metric_query {
    id = "target5xx"
    metric {
      namespace   = "AWS/ApplicationELB"
      metric_name = "HTTPCode_Target_5XX_Count"
      dimensions  = local.alb_dims
      period      = 60
      stat        = "Sum"
    }
  }

  metric_query {
    id = "elb5xx"
    metric {
      namespace   = "AWS/ApplicationELB"
      metric_name = "HTTPCode_ELB_5XX_Count"
      dimensions  = local.alb_dims
      period      = 60
      stat        = "Sum"
    }
  }

  metric_query {
    id = "requests"
    metric {
      namespace   = "AWS/ApplicationELB"
      metric_name = "RequestCount"
      dimensions  = local.alb_dims
      period      = 60
      stat        = "Sum"
    }
  }
}

resource "aws_cloudwatch_metric_alarm" "alb_unhealthy_targets" {
  alarm_name          = "${var.name}-alb-unhealthy-targets"
  alarm_description   = "A target of the API's target group fails /healthz."
  namespace           = "AWS/ApplicationELB"
  metric_name         = "UnHealthyHostCount"
  dimensions          = local.tg_dims
  statistic           = "Maximum"
  period              = 60
  evaluation_periods  = 3
  comparison_operator = "GreaterThanThreshold"
  threshold           = 0
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "alb_p95_latency" {
  alarm_name          = "${var.name}-alb-p95-latency"
  alarm_description   = "p95 of the targets' response time at the load balancer, in seconds."
  namespace           = "AWS/ApplicationELB"
  metric_name         = "TargetResponseTime"
  dimensions          = local.alb_dims
  extended_statistic  = "p95"
  period              = 60
  evaluation_periods  = 5
  datapoints_to_alarm = 3
  comparison_operator = "GreaterThanThreshold"
  threshold           = var.thresholds.alb_p95_seconds
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
}

# ---------------------------------------------------------------------------
# The processes: running below desired, for the API and the worker.
# ---------------------------------------------------------------------------

resource "aws_cloudwatch_metric_alarm" "running_below_desired" {
  for_each = {
    api    = var.api_service_name
    worker = var.worker_service_name
  }

  alarm_name          = "${each.value}-running-below-desired"
  alarm_description   = "${each.value} runs fewer tasks than it desires."
  comparison_operator = "GreaterThanThreshold"
  threshold           = 0
  evaluation_periods  = 5
  datapoints_to_alarm = 5
  treat_missing_data  = "missing"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]

  metric_query {
    id          = "missing"
    expression  = "desired - running"
    label       = "tasks missing"
    return_data = true
  }

  metric_query {
    id = "desired"
    metric {
      namespace   = "ECS/ContainerInsights"
      metric_name = "DesiredTaskCount"
      dimensions  = { ClusterName = var.cluster_name, ServiceName = each.value }
      period      = 60
      stat        = "Average"
    }
  }

  metric_query {
    id = "running"
    metric {
      namespace   = "ECS/ContainerInsights"
      metric_name = "RunningTaskCount"
      dimensions  = { ClusterName = var.cluster_name, ServiceName = each.value }
      period      = 60
      stat        = "Average"
    }
  }
}

# ---------------------------------------------------------------------------
# The database: processor and free storage.
# ---------------------------------------------------------------------------

resource "aws_cloudwatch_metric_alarm" "db_cpu" {
  alarm_name          = "${var.name}-db-cpu"
  alarm_description   = "The database's processor."
  namespace           = "AWS/RDS"
  metric_name         = "CPUUtilization"
  dimensions          = { DBInstanceIdentifier = var.db_identifier }
  statistic           = "Average"
  period              = 60
  evaluation_periods  = 10
  datapoints_to_alarm = 8
  comparison_operator = "GreaterThanThreshold"
  threshold           = var.thresholds.db_cpu_percent
  treat_missing_data  = "missing"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
}

resource "aws_cloudwatch_metric_alarm" "db_free_storage" {
  alarm_name          = "${var.name}-db-free-storage"
  alarm_description   = "The database's free storage, in bytes (storage also grows on its own up to its maximum)."
  namespace           = "AWS/RDS"
  metric_name         = "FreeStorageSpace"
  dimensions          = { DBInstanceIdentifier = var.db_identifier }
  statistic           = "Minimum"
  period              = 300
  evaluation_periods  = 2
  comparison_operator = "LessThanThreshold"
  threshold           = var.thresholds.db_free_storage_bytes
  treat_missing_data  = "missing"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
}

# ---------------------------------------------------------------------------
# The queue and the outbox: the gauges the worker's sweep sets.
# ---------------------------------------------------------------------------

resource "aws_cloudwatch_metric_alarm" "gauge" {
  for_each = {
    outbox-lag = {
      metric      = var.metric_names.outbox_lag
      threshold   = var.thresholds.outbox_lag_seconds
      description = "The outbox's lag, in seconds, from the gauge the sweep sets."
    }
    queue-oldest-age = {
      metric      = var.metric_names.queue_oldest_age
      threshold   = var.thresholds.queue_oldest_age_seconds
      description = "The oldest waiting work item's age, in seconds."
    }
    work-failed = {
      metric      = var.metric_names.work_failed
      threshold   = var.thresholds.work_failed
      description = "Failed work items."
    }
    records-parked = {
      metric      = var.metric_names.records_parked
      threshold   = var.thresholds.records_parked
      description = "Parked records."
    }
  }

  alarm_name          = "${var.name}-${each.key}"
  alarm_description   = each.value.description
  namespace           = local.ns
  metric_name         = each.value.metric
  dimensions          = local.gauge_dims
  statistic           = "Maximum"
  period              = 60
  evaluation_periods  = 5
  datapoints_to_alarm = 3
  comparison_operator = "GreaterThanThreshold"
  threshold           = each.value.threshold
  treat_missing_data  = "notBreaching"
  alarm_actions       = [aws_sns_topic.alarms.arn]
  ok_actions          = [aws_sns_topic.alarms.arn]
}

# ---------------------------------------------------------------------------
# The dashboard: one widget per title in panels.json, in that order.
# ---------------------------------------------------------------------------

locals {
  search_by = {
    route  = "{${local.ns},environment,route,service}"
    status = "{${local.ns},environment,service,status}"
    base   = "{${local.ns},environment,service}"
    outcom = "{${local.ns},environment,outcome,service,subsystem}"
  }

  outcomes_widget = { for s in ["cache", "queue", "rate_limit", "idempotency", "worker"] : s => {
    view    = "timeSeries"
    stacked = true
    metrics = [[{
      id         = "e1"
      expression = "SEARCH('${local.search_by.outcom} MetricName=\"${var.metric_names.outcomes}\" environment=\"${local.env}\" subsystem=\"${s}\"', 'Sum', 60)"
      label      = ""
    }]]
  } }

  widget_properties = {
    "Processes up" = {
      view = "timeSeries"
      metrics = [
        ["ECS/ContainerInsights", "RunningTaskCount", "ClusterName", var.cluster_name, "ServiceName", var.api_service_name],
        ["ECS/ContainerInsights", "RunningTaskCount", "ClusterName", var.cluster_name, "ServiceName", var.worker_service_name],
        ["ECS/ContainerInsights", "DesiredTaskCount", "ClusterName", var.cluster_name, "ServiceName", var.api_service_name],
        ["ECS/ContainerInsights", "DesiredTaskCount", "ClusterName", var.cluster_name, "ServiceName", var.worker_service_name],
      ]
      stat = "Average"
    }
    "Requests per second by route" = {
      view = "timeSeries"
      metrics = [[{
        id         = "e1"
        expression = "SEARCH('${local.search_by.route} MetricName=\"${var.metric_names.requests}\" environment=\"${local.env}\"', 'Sum', 60) / 60"
        label      = ""
      }]]
    }
    "Responses per second by status" = {
      view    = "timeSeries"
      stacked = true
      metrics = [[{
        id         = "e1"
        expression = "SEARCH('${local.search_by.status} MetricName=\"${var.metric_names.requests}\" environment=\"${local.env}\"', 'Sum', 60) / 60"
        label      = ""
      }]]
    }
    "p95 latency by route" = {
      view = "timeSeries"
      metrics = [[{
        id         = "e1"
        expression = "SEARCH('${local.search_by.route} MetricName=\"${var.metric_names.request_seconds}\" environment=\"${local.env}\"', 'p95', 60)"
        label      = ""
      }]]
    }
    "Cache outcomes"       = local.outcomes_widget["cache"]
    "Queue outcomes"       = local.outcomes_widget["queue"]
    "Rate limit outcomes"  = local.outcomes_widget["rate_limit"]
    "Idempotency outcomes" = local.outcomes_widget["idempotency"]
    "Worker outcomes"      = local.outcomes_widget["worker"]
    "Outbox lag" = {
      view = "timeSeries"
      metrics = [[{
        id         = "e1"
        expression = "SEARCH('${local.search_by.base} MetricName=\"${var.metric_names.outbox_lag}\" environment=\"${local.env}\"', 'Maximum', 60)"
        label      = ""
      }]]
    }
    "Database" = {
      view = "timeSeries"
      metrics = [
        ["AWS/RDS", "CPUUtilization", "DBInstanceIdentifier", var.db_identifier],
        ["AWS/RDS", "DatabaseConnections", "DBInstanceIdentifier", var.db_identifier],
        ["AWS/RDS", "FreeStorageSpace", "DBInstanceIdentifier", var.db_identifier, { yAxis = "right" }],
      ]
      stat = "Average"
    }
    "Cache" = {
      view = "timeSeries"
      metrics = [
        [{ id = "cpu", expression = "SEARCH('{AWS/ElastiCache,CacheClusterId} MetricName=\"EngineCPUUtilization\" \"${var.cache_replication_group_id}\"', 'Average', 60)", label = "" }],
        [{ id = "conn", expression = "SEARCH('{AWS/ElastiCache,CacheClusterId} MetricName=\"CurrConnections\" \"${var.cache_replication_group_id}\"', 'Average', 60)", label = "" }],
        [{ id = "hit", expression = "SEARCH('{AWS/ElastiCache,CacheClusterId} MetricName=\"CacheHitRate\" \"${var.cache_replication_group_id}\"', 'Average', 60)", label = "" }],
      ]
    }
    "Queue" = {
      view = "timeSeries"
      metrics = concat(
        [for q in var.queue_names : ["AWS/SQS", "ApproximateAgeOfOldestMessage", "QueueName", q]],
        [for q in var.queue_names : ["AWS/SQS", "ApproximateNumberOfMessagesVisible", "QueueName", q, { yAxis = "right" }]],
        [
          [{ id = "age", expression = "SEARCH('${local.search_by.base} MetricName=\"${var.metric_names.queue_oldest_age}\" environment=\"${local.env}\"', 'Maximum', 60)", label = "" }],
          [{ id = "failed", expression = "SEARCH('${local.search_by.base} MetricName=\"${var.metric_names.work_failed}\" environment=\"${local.env}\"', 'Maximum', 60)", label = "", yAxis = "right" }],
          [{ id = "parked", expression = "SEARCH('${local.search_by.base} MetricName=\"${var.metric_names.records_parked}\" environment=\"${local.env}\"', 'Maximum', 60)", label = "", yAxis = "right" }],
        ],
      )
      stat = "Maximum"
    }
  }

  widgets = [for i, title in local.panels : {
    type       = "metric"
    x          = (i % 2) * 12
    y          = floor(i / 2) * 6
    width      = 12
    height     = 6
    properties = merge(local.widget_properties[title], { title = title, region = var.region, period = 60 })
  }]
}

resource "aws_cloudwatch_dashboard" "this" {
  dashboard_name = var.name
  dashboard_body = jsonencode({ widgets = local.widgets })

  lifecycle {
    precondition {
      condition     = toset(local.panels) == toset(keys(local.widget_properties)) && length(local.panels) == length(keys(local.widget_properties))
      error_message = "Every title in panels.json has one widget, and every widget a title."
    }
  }
}

output "alarm_topic_arn" {
  value = aws_sns_topic.alarms.arn
}

output "dashboard_name" {
  value = aws_cloudwatch_dashboard.this.dashboard_name
}

output "panel_titles" {
  value = local.panels
}

output "alarm_names" {
  value = concat(
    [
      aws_cloudwatch_metric_alarm.alb_5xx_ratio.alarm_name,
      aws_cloudwatch_metric_alarm.alb_unhealthy_targets.alarm_name,
      aws_cloudwatch_metric_alarm.alb_p95_latency.alarm_name,
      aws_cloudwatch_metric_alarm.db_cpu.alarm_name,
      aws_cloudwatch_metric_alarm.db_free_storage.alarm_name,
    ],
    [for a in aws_cloudwatch_metric_alarm.running_below_desired : a.alarm_name],
    [for a in aws_cloudwatch_metric_alarm.gauge : a.alarm_name],
  )
}
