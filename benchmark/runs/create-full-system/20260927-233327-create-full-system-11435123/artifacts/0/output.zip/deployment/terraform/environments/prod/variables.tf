# Every environment root declares the same variables; what differs between two
# environments is a value in its terraform.tfvars, or an input the pipeline
# passes (the images, the release, the alarm address).

variable "environment" {
  description = "staging or production: the key into deployment/cloud/environments.json."
  type        = string

  validation {
    condition     = contains(["staging", "production"], var.environment)
    error_message = "environment is staging or production."
  }
}

# ----- What the pipeline passes on each deploy -----

variable "release" {
  description = "The commit being deployed (ACME_RELEASE)."
  type        = string
}

variable "api_image" {
  description = "The API image by digest: <registry>/acme-api@sha256:..."
  type        = string
}

variable "worker_image" {
  description = "The maintenance worker's image by digest: <registry>/acme-maintenance@sha256:..."
  type        = string
}

variable "alarm_email" {
  description = "The address the alarm topic mails (the environment's ALARM_EMAIL variable)."
  type        = string
  default     = ""
}

# ----- The switches -----

variable "autoscaling_enabled" {
  description = "The one flip that scales the whole environment. Off by default: an unattended scale-out is a bill nobody approved."
  type        = bool
  default     = false
}

variable "destroyable" {
  description = "force_destroy on the buckets and, outside production, skip_final_snapshot on the database. Set by scripts/cloud_nuke.sh's apply only."
  type        = bool
  default     = false
}

variable "database_deletion_protection" {
  description = "The database's deletion protection; true in production, lifted only by a merged and released change."
  type        = bool
  default     = true
}

variable "waf_enabled" {
  description = "The managed web firewall's common rule sets in front of the load balancer and the portal's distribution."
  type        = bool
  default     = false
}

# ----- Network -----

variable "vpc_cidr" {
  type    = string
  default = "10.40.0.0/16"
}

variable "egress" {
  description = "The named egress choice of the private subnets."
  type        = string
  default     = "nat_gateway"
}

variable "nat_gateway_count" {
  type    = number
  default = 1
}

# ----- Database -----

variable "database_engine_version" {
  description = "Postgres major version (RDS resolves the minor)."
  type        = string
  default     = "18"
}

variable "database_parameter_group_family" {
  type    = string
  default = "postgres18"
}

variable "database_instance_class" {
  type    = string
  default = "db.t4g.micro"
}

variable "database_allocated_storage" {
  type    = number
  default = 20
}

variable "database_max_allocated_storage" {
  type    = number
  default = 100
}

variable "database_multi_az" {
  type    = bool
  default = false
}

variable "database_backup_retention_days" {
  description = "The point-in-time recovery window the environment declares."
  type        = number
  default     = 7
}

variable "database_password_version" {
  description = "Bump to rotate every generated database password; the services roll."
  type        = number
  default     = 1
}

variable "database_pool_size" {
  type    = number
  default = 10
}

variable "database_pool_checkout_timeout" {
  type    = number
  default = 5
}

variable "database_statement_timeout" {
  type    = number
  default = 10
}

# ----- Cache -----

variable "cache_engine_version" {
  type    = string
  default = "8.1"
}

variable "cache_node_type" {
  type    = string
  default = "cache.t4g.micro"
}

variable "cache_num_nodes" {
  type    = number
  default = 1
}

variable "cache_timeout_ms" {
  type    = number
  default = 250
}

# ----- Queue and calls -----

variable "queue_max_receives" {
  type    = number
  default = 5
}

variable "call_timeout_seconds" {
  type    = number
  default = 5
}

# ----- Secrets -----

variable "totp_key_version" {
  description = "Bump to rotate the API's TOTP encryption key."
  type        = number
  default     = 1
}

variable "internal_signing_key_version" {
  description = "Bump to rotate the API's internal signing key (ACME_API_INTERNAL_SIGNING_KEY)."
  type        = number
  default     = 1
}

variable "everyday_permission_set" {
  description = "The identity center's everyday permission set, whose role reads the operator-token secrets."
  type        = string
  default     = "Everyday"
}

# ----- Processes -----

variable "api_cpu" {
  type    = number
  default = 512
}

variable "api_memory" {
  type    = number
  default = 1024
}

variable "api_desired_count" {
  type    = number
  default = 1
}

variable "api_scaling" {
  description = "The API's lever, declared on: the root switch decides."
  type = object({
    enabled    = bool
    max        = number
    target_cpu = number
  })
  default = { enabled = true, max = 4, target_cpu = 60 }
}

variable "worker_cpu" {
  type    = number
  default = 256
}

variable "worker_memory" {
  type    = number
  default = 512
}

variable "worker_desired_count" {
  type    = number
  default = 1
}

variable "worker_scaling" {
  description = "The worker's lever, declared on: the root switch decides."
  type = object({
    enabled    = bool
    max        = number
    target_cpu = number
  })
  default = { enabled = true, max = 4, target_cpu = 60 }
}

variable "worker_capacity" {
  type    = number
  default = 8
}

variable "worker_poll_interval_seconds" {
  type    = number
  default = 1
}

variable "worker_lease_seconds" {
  type    = number
  default = 60
}

variable "worker_sweep_interval_seconds" {
  type    = number
  default = 30
}

variable "log_level" {
  type    = string
  default = "INFO"
}

variable "log_retention_days" {
  type    = number
  default = 30
}

variable "collector_image" {
  description = "The OpenTelemetry collector beside each task, at a pinned tag."
  type        = string
  default     = "public.ecr.aws/aws-observability/aws-otel-collector:v0.50.0"
}

# ----- The outside providers (non-secret values; the keys are secrets filled by a person) -----

variable "workos_client_id" {
  type    = string
  default = ""
}

variable "email_from" {
  type    = string
  default = ""
}

variable "twilio_account_sid" {
  type    = string
  default = ""
}

variable "sms_from" {
  type    = string
  default = ""
}

variable "integrations_timeout_seconds" {
  type    = number
  default = 10
}

variable "error_tracker_origin" {
  description = "The error tracker's ingest origin, admitted by the portal's connect-src."
  type        = string
  default     = ""
}

# ----- Alarms -----

variable "alarm_thresholds" {
  description = "The alarm numbers; null keeps the module's defaults."
  type = object({
    alb_5xx_ratio            = number
    alb_p95_seconds          = number
    db_cpu_percent           = number
    db_free_storage_bytes    = number
    outbox_lag_seconds       = number
    queue_oldest_age_seconds = number
    work_failed              = number
    records_parked           = number
  })
  default = null
}
