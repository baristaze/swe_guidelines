# Architecture specification

This system follows the Software Design and Architecture Guidelines, pinned at release **v0.37.0**:
<https://github.com/baristaze/swe_guidelines/blob/v0.37.0/architecture.md>.

The same tag is what `make arch-check` runs (`git+https://github.com/baristaze/swe_guidelines@v0.37.0`), so the
rules the checker decides and the document the reviews read are one release. Moving the pin is a pull request that
changes this file and the `Makefile` together.

What is implemented, as built: [`docs/architecture.md`](../docs/architecture.md).

## Substitutions

Recorded in [ADR 0002](../docs/adr/0002-technology-choices.md), with the rules each substitute must still satisfy.

| Named technology | Substitute | ADR |
|------------------|------------|-----|
| object store (local image) | SeaweedFS | [0002](../docs/adr/0002-technology-choices.md) |
| queue (local image) | ElasticMQ | [0002](../docs/adr/0002-technology-choices.md) |
| metrics view (devx) | Prometheus and Grafana | [0002](../docs/adr/0002-technology-choices.md) |

## Deviations

| Rule | Deviation | ADR |
|------|-----------|-----|
| arch-check ASY-16 (a unique index on `idempotency_key` alone) | `queue.work_items` is unique on `(org_id, idempotency_key)`, as The Work Queue prescribes; the checker rule is excepted for that table | [0007](../docs/adr/0007-work-item-key-unique-per-tenant.md) |
