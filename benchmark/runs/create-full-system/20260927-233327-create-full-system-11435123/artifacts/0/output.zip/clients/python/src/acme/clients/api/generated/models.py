"""Generated from the OpenAPI document by clients/python/generate.py. Do not edit."""

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict



class AddApiKeyRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_in: int | None = None
    name: str
    role: Role


class AddJournalistRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    display_name: str


class AddMemberRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    display_name: str
    email: str
    password: str | None = None
    role: Role


class AddOperatorTokenRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_in: int | None = None
    permission: OperatorPermission


class AddOrgRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    slug: str


class AdminEventView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    actor_id: UUID
    app_type: AppType
    app_version: str
    kind: str
    request_id: UUID
    seq: int
    target_id: UUID


class AdminMemberView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    identity_id: UUID
    name: str
    role: Role
    user_id: UUID


class AdminOrgView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    deleted_at: datetime | None = None
    id: UUID
    name: str
    slug: str


class ApiKeyView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    expires_at: datetime
    id: UUID
    name: str
    revoked_at: datetime | None = None
    role: Role

AppType = Literal["portal", "admin", "cli", "api", "worker", "ops", "bootstrap"]


class ConfirmTotpRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    totp_code: str


class ErrorBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    code: str
    message: str
    request_id: str


class ErrorResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")

    error: ErrorBody


class EventView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    actor_id: UUID
    kind: str
    seq: int
    target_id: UUID
    version: int | None = None


class ExchangeRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    org_id: UUID


class ExternalSignInRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    code: str | None = None
    redirect_uri: str | None = None
    token: str | None = None


class IssuedApiKeyView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    id: UUID
    name: str
    role: Role
    token: str | None = None


class IssuedOperatorTokenView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    id: UUID
    permission: OperatorPermission
    token: str | None = None


class IssuedSessionView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    token: str


class IssuedSignInView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    memberships: list[MembershipChoiceView]
    token: str


class JournalistView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    display_name: str
    id: UUID
    updated_at: datetime


class MemberView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    role: Role
    user_id: UUID


class MembershipChoiceView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    org_id: UUID
    org_name: str
    org_slug: str
    role: Role


class MembershipView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    role: Role
    user_id: UUID

OperatorPermission = Literal["read", "write", "enrol"]


class OperatorView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    email: str
    identity_id: UUID
    operator_role: OperatorPermission
    permissions: list[OperatorPermission]


class OrgView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    slug: str


class RealtimeTicketView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    ticket: str | None = None

Role = Literal["owner", "admin", "member", "viewer", "service"]


class SignInRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    email: str
    password: str
    totp_code: str | None = None


class SignUpRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    display_name: str
    email: str
    org_name: str
    org_slug: str
    password: str


class SizeView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    events_last_day: int
    tenants: int
    users: int


class TotpEnrolmentView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    otpauth_uri: str


class UpdateJournalistRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    display_name: str | None = None


class UpdateMemberRoleRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    role: Role


class UpdateUserRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str | None = None


class UserView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
