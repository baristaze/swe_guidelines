"""Each twin: the same shapes as its provider, deterministic, naming its provenance, and refused outside local."""

import pytest

from acme.integrations.email import OutboundEmail
from acme.integrations.email.twin import EmailTwinImpl
from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.identity.twin import IdentityProviderTwinImpl
from acme.integrations.impl.configured import build_integrations
from acme.integrations.malware import Verdict
from acme.integrations.malware.twin import EICAR_SHA256, EMPTY_SHA256, MalwareScannerTwinImpl
from acme.integrations.payments import SupportMode
from acme.integrations.payments.twin import PaymentsTwinImpl
from acme.integrations.settings import IntegrationsSettings
from acme.integrations.sms import OutboundSms
from acme.integrations.sms.twin import SmsTwinImpl


@pytest.mark.parametrize(
    "build",
    [
        lambda: IdentityProviderTwinImpl("staging", "s"),
        lambda: PaymentsTwinImpl("production", "s"),
        lambda: EmailTwinImpl("staging"),
        lambda: SmsTwinImpl("production"),
        lambda: MalwareScannerTwinImpl("staging"),
    ],
)
def test_a_twin_refuses_outside_local(build) -> None:  # type: ignore[no-untyped-def]
    with pytest.raises(IntegrationRefused):
        build()


def test_the_configured_root_refuses_a_twin_in_a_cloud_environment() -> None:
    with pytest.raises(IntegrationRefused):
        build_integrations(IntegrationsSettings(environment="production"))


async def test_identity_twin_round_trips_a_code_and_a_token() -> None:
    twin = IdentityProviderTwinImpl("local", "twin-signing-secret-of-32-bytes-or-more")
    url = twin.authorization_url("https://app.example/cb", "st", "google")
    assert url.startswith("https://app.example/cb?code=twin%3Agoogle%3A")
    found = await twin.exchange_code("twin:google:jo@acme.example", "https://app.example/cb")
    assert (found.subject, found.provenance) == ("twin|jo@acme.example", "twin")
    with pytest.raises(IntegrationRefused):
        await twin.verify_token(
            IdentityProviderTwinImpl("local", "another-signing-secret-of-32-bytes-or-more").issue_token(
                "x@acme.example", "x"
            )
        )


async def test_payments_twin_is_deterministic_and_signs_its_deliveries() -> None:
    twin = PaymentsTwinImpl("local", "secret")
    args = {
        "connected_account_id": "acct_twin",
        "amount_minor": 500,
        "currency": "eur",
        "mode": SupportMode.MONTHLY,
        "platform_fee_minor": 25,
        "success_url": "https://app.example/ok",
        "cancel_url": "https://app.example/no",
        "reference": "r",
        "idempotency_key": "same",
    }
    first = await twin.create_checkout(**args)  # type: ignore[arg-type]
    again = await twin.create_checkout(**args)  # type: ignore[arg-type]
    assert first == again and first.provenance == "twin"
    payload, header = twin.synthetic_delivery("checkout.session.completed", {"session": first.session_id})
    assert twin.verify_webhook(payload, header).type == "checkout.session.completed"
    with pytest.raises(IntegrationRefused):
        twin.verify_webhook(payload + b" ", header)


async def test_email_and_sms_twins_keep_one_message_per_key() -> None:
    email = EmailTwinImpl("local")
    message = OutboundEmail(to="r@acme.example", subject="s", text="t", tag="follow", idempotency_key="k")
    assert (await email.send(message)) == (await email.send(message))
    assert len(email.sent) == 1
    sms = SmsTwinImpl("local")
    text = OutboundSms(to="+15550000000", body="b", idempotency_key="k")
    assert (await sms.send(text)).provenance == "twin"
    assert len(sms.sent) == 1


async def test_scanner_twin_knows_eicar() -> None:
    twin = MalwareScannerTwinImpl("local")
    assert (await twin.lookup(EICAR_SHA256)).verdict == Verdict.MALICIOUS
    assert (await twin.lookup(EMPTY_SHA256)).verdict == Verdict.CLEAN
    assert (await twin.lookup("a" * 64)).verdict == Verdict.UNKNOWN
    with pytest.raises(IntegrationRefused):
        await twin.lookup("not-a-hash")
