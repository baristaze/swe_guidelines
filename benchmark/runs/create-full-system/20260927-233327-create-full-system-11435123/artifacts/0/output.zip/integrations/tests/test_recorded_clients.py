"""Each real client against recorded provider responses: the request it sends and the shape it reads back."""

import json
import time
from pathlib import Path

import httpx
import jwt
import pytest
from cryptography.hazmat.primitives.asymmetric import rsa

from acme.integrations.email import OutboundEmail
from acme.integrations.email.postmark import EmailPostmarkImpl
from acme.integrations.email.resend import EmailResendImpl
from acme.integrations.exceptions import IntegrationRefused, IntegrationUnavailable
from acme.integrations.identity.workos import IdentityProviderWorkOSImpl
from acme.integrations.malware import Verdict
from acme.integrations.malware.virustotal import MalwareScannerVirusTotalImpl
from acme.integrations.payments import SupportMode, sign
from acme.integrations.payments.stripe import PaymentsStripeImpl
from acme.integrations.sms import OutboundSms
from acme.integrations.sms.twilio import SmsTwilioImpl

FIXTURES = Path(__file__).parent / "fixtures"
EICAR = "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f"


def recorded(name: str, seen: list[httpx.Request], status: int = 200) -> httpx.MockTransport:
    body = (FIXTURES / name).read_text()

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(status, text=body, headers={"content-type": "application/json"})

    return httpx.MockTransport(handler)


async def test_stripe_checkout_sends_a_destination_charge_with_the_platform_fee() -> None:
    seen: list[httpx.Request] = []
    stripe = PaymentsStripeImpl(
        "sk_test", "whsec", "https://api.stripe.com", 5.0, recorded("stripe_checkout_session.json", seen)
    )
    await stripe.start()
    checkout = await stripe.create_checkout(
        connected_account_id="acct_1TestJournalist01",
        amount_minor=1000,
        currency="eur",
        mode=SupportMode.ONE_TIME,
        platform_fee_minor=50,
        success_url="https://app.example/ok",
        cancel_url="https://app.example/cancel",
        reference="support-0192",
        idempotency_key="key-1",
    )
    await stripe.close()
    assert checkout.session_id == "cs_test_a1B2c3D4e5F6" and checkout.provenance == "stripe"
    sent = seen[0]
    assert sent.url.path == "/v1/checkout/sessions" and sent.headers["Idempotency-Key"] == "key-1"
    form = dict(httpx.QueryParams(sent.content.decode()))
    assert form["payment_intent_data[application_fee_amount]"] == "50"
    assert form["payment_intent_data[transfer_data][destination]"] == "acct_1TestJournalist01"


async def test_stripe_connected_account_and_refund() -> None:
    seen: list[httpx.Request] = []
    stripe = PaymentsStripeImpl(
        "sk_test", "whsec", "https://api.stripe.com", 5.0, recorded("stripe_account.json", seen)
    )
    await stripe.start()
    account = await stripe.create_connected_account(email="j@acme.example", country="DE", idempotency_key="k")
    await stripe.close()
    assert account.account_id == "acct_1TestJournalist01"
    stripe = PaymentsStripeImpl("sk_test", "whsec", "https://api.stripe.com", 5.0, recorded("stripe_refund.json", seen))
    await stripe.start()
    refund = await stripe.refund(payment_intent_id="pi_3TestIntent0001", amount_minor=500, idempotency_key="r")
    await stripe.close()
    assert (refund.refund_id, refund.status) == ("re_3TestRefund0001", "succeeded")


def test_stripe_webhook_signature_and_replay_window() -> None:
    stripe = PaymentsStripeImpl("sk_test", "whsec_test", "https://api.stripe.com", 5.0)
    payload = json.dumps({"id": "evt_1", "type": "checkout.session.completed", "data": {"object": {}}}).encode()
    delivery = stripe.verify_webhook(payload, sign(payload, "whsec_test", int(time.time())))
    assert delivery.delivery_id == "evt_1"
    with pytest.raises(IntegrationRefused):
        stripe.verify_webhook(payload, sign(payload, "another", int(time.time())))
    with pytest.raises(IntegrationRefused):
        stripe.verify_webhook(payload, sign(payload, "whsec_test", int(time.time()) - 3600))


async def test_postmark_and_resend_send_one_message() -> None:
    seen: list[httpx.Request] = []
    message = OutboundEmail(
        to="reader@acme.example", subject="Update", text="Hi", tag="journalist_update", idempotency_key="k1"
    )
    postmark = EmailPostmarkImpl("pm-token", "desk@acme.example", 5.0, transport=recorded("postmark_email.json", seen))
    await postmark.start()
    assert (await postmark.send(message)).message_id == "b7bc2f4a-e38e-4336-af7d-e6c392c2f817"
    await postmark.close()
    assert seen[0].headers["X-Postmark-Server-Token"] == "pm-token"
    resend = EmailResendImpl("re-key", "desk@acme.example", 5.0, transport=recorded("resend_email.json", seen))
    await resend.start()
    assert (await resend.send(message)).message_id == "49a3999c-0ce1-4ea6-ab68-afcd6dc2e794"
    await resend.close()
    assert seen[1].headers["Idempotency-Key"] == "k1"


async def test_twilio_sends_through_the_account() -> None:
    seen: list[httpx.Request] = []
    twilio = SmsTwilioImpl("AC123", "token", "+15017122661", 5.0, transport=recorded("twilio_message.json", seen))
    await twilio.start()
    delivery = await twilio.send(OutboundSms(to="+15558675310", body="A source replied", idempotency_key="k"))
    await twilio.close()
    assert delivery.message_id.startswith("SM")
    assert seen[0].url.path == "/2010-04-01/Accounts/AC123/Messages.json"


async def test_virustotal_reads_a_verdict_and_an_unknown_file() -> None:
    seen: list[httpx.Request] = []
    scanner = MalwareScannerVirusTotalImpl("vt-key", 5.0, transport=recorded("virustotal_file.json", seen))
    await scanner.start()
    result = await scanner.lookup(EICAR)
    await scanner.close()
    assert result.verdict == Verdict.MALICIOUS and result.engines_flagged == 62
    missing = MalwareScannerVirusTotalImpl("vt-key", 5.0, transport=recorded("virustotal_file.json", seen, status=404))
    await missing.start()
    assert (await missing.lookup(EICAR)).verdict == Verdict.UNKNOWN
    await missing.close()


async def test_a_provider_outage_is_unavailable() -> None:
    scanner = MalwareScannerVirusTotalImpl("vt-key", 5.0, transport=recorded("virustotal_file.json", [], status=503))
    await scanner.start()
    with pytest.raises(IntegrationUnavailable):
        await scanner.lookup(EICAR)
    await scanner.close()


async def test_workos_verifies_a_token_against_its_published_keys() -> None:
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    jwk = json.loads(jwt.algorithms.RSAAlgorithm.to_jwk(key.public_key()))
    jwk["kid"] = "key-1"
    now = int(time.time())
    token = jwt.encode(
        {
            "iss": "https://api.workos.com/user_management/client_1",
            "sub": "user_01",
            "email": "j@acme.example",
            "exp": now + 60,
        },
        key,
        algorithm="RS256",
        headers={"kid": "key-1"},
    )

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/sso/jwks/client_1":
            return httpx.Response(200, json={"keys": [jwk]})
        return httpx.Response(
            200, json={"user": {"email": "j@acme.example", "first_name": "Jo"}, "access_token": token}
        )

    workos = IdentityProviderWorkOSImpl("client_1", "sk", "https://api.workos.com", 5.0, httpx.MockTransport(handler))
    await workos.start()
    found = await workos.exchange_code("code-1", "https://app.example/callback")
    await workos.close()
    assert (found.subject, found.email, found.display_name, found.provenance) == (
        "user_01",
        "j@acme.example",
        "Jo",
        "workos",
    )
    assert "provider=authkit" in workos.authorization_url("https://app.example/cb", "state-1")
