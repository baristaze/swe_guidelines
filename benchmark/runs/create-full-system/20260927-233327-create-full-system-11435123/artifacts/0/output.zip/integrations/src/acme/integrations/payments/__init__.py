"""The payment processor: checkout for one-time and monthly support, connected accounts and payouts for
journalists, refunds, and signed webhook deliveries. The platform fee is a field of each checkout, set by its caller.
"""

import hashlib
import hmac
import time
from abc import ABC, abstractmethod
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict

from acme.integrations.exceptions import IntegrationRefused

SIGNATURE_TOLERANCE_SECONDS = 300


class SupportMode(StrEnum):
    ONE_TIME = "payment"
    MONTHLY = "subscription"


class Checkout(BaseModel):
    model_config = ConfigDict(frozen=True)

    session_id: str
    url: str
    provenance: str


class ConnectedAccount(BaseModel):
    model_config = ConfigDict(frozen=True)

    account_id: str
    provenance: str


class Refund(BaseModel):
    model_config = ConfigDict(frozen=True)

    refund_id: str
    status: str
    provenance: str


class WebhookDelivery(BaseModel):
    model_config = ConfigDict(frozen=True)

    delivery_id: str  # the provider's event id: the key a UUID v5 derives the idempotency key from
    type: str
    data: dict[str, Any]


class PaymentsInterface(ABC):
    @abstractmethod
    async def create_checkout(
        self,
        *,
        connected_account_id: str,
        amount_minor: int,
        currency: str,
        mode: SupportMode,
        platform_fee_minor: int,
        success_url: str,
        cancel_url: str,
        reference: str,
        idempotency_key: str,
    ) -> Checkout: ...

    @abstractmethod
    async def create_connected_account(self, *, email: str, country: str, idempotency_key: str) -> ConnectedAccount: ...

    @abstractmethod
    async def onboarding_link(self, account_id: str, refresh_url: str, return_url: str) -> str: ...

    @abstractmethod
    async def refund(self, *, payment_intent_id: str, amount_minor: int | None, idempotency_key: str) -> Refund: ...

    @abstractmethod
    def verify_webhook(self, payload: bytes, signature_header: str) -> WebhookDelivery:
        """Checks the provider's signature over the body and a timestamp inside the replay window."""
        ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...


def sign(payload: bytes, secret: str, timestamp: int) -> str:
    """The Stripe signature scheme: HMAC-SHA256 over `<timestamp>.<body>`, sent as `t=<ts>,v1=<hex>`."""
    mac = hmac.new(secret.encode(), f"{timestamp}.".encode() + payload, hashlib.sha256).hexdigest()
    return f"t={timestamp},v1={mac}"


def verify_signature(payload: bytes, header: str, secret: str, now: float | None = None) -> None:
    parts = dict(item.split("=", 1) for item in header.split(",") if "=" in item)
    try:
        timestamp = int(parts["t"])
    except (KeyError, ValueError) as exc:
        raise IntegrationRefused("the delivery carries no timestamp") from exc
    if abs((now or time.time()) - timestamp) > SIGNATURE_TOLERANCE_SECONDS:
        raise IntegrationRefused("the delivery is outside the replay window")
    expected = sign(payload, secret, timestamp).split("v1=", 1)[1]
    if not hmac.compare_digest(expected, parts.get("v1", "")):
        raise IntegrationRefused("the delivery's signature does not match")
