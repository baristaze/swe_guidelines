#!/usr/bin/env bash
# Destroys one cloud environment of the platform, as its account's
# administrator: the hands of the ops-cloud-deployment-nuke skill.
#
#   scripts/cloud_nuke.sh <staging|production> [--confirm production] [--dry-run]
#
# Production is refused unless `--confirm production` is typed, the root's
# database_deletion_protection reads false on release, and the applied state no
# longer protects the database (a released change lifted it; this script never
# sets that variable). It applies from the environment's exact deployed commit
# (release for production; for staging, the commit of staging's last successful
# deploy, from its deployment record, never the tip of main) in a clean worktree
# of its own: the destroyable switch, the data buckets emptied, the environment
# root destroyed, the GitHub environments and their variables removed, the
# investigate profile and the env file removed. It prints what remains.
#
# --dry-run prints every command it would run and runs none.
set -euo pipefail

usage() {
  sed -n '2,17p' "$0" | sed 's/^# \{0,1\}//'
  exit "${1:-2}"
}

ENV_NAME=""
CONFIRM=""
DRY_RUN=0

while [ $# -gt 0 ]; do
  case "$1" in
    staging | production) ENV_NAME="$1" ;;
    --confirm) CONFIRM="${2:?--confirm needs a value}"; shift ;;
    --dry-run) DRY_RUN=1 ;;
    -h | --help) usage 0 ;;
    local) echo "local has no administrator; this script acts on a cloud environment only" >&2; exit 2 ;;
    *) echo "unknown argument: $1" >&2; usage 2 ;;
  esac
  shift
done
[ -n "$ENV_NAME" ] || usage 2

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAYOUT="${REPO_ROOT}/deployment/cloud/environments.json"
PRODUCT="$(jq -r '.product' "$LAYOUT")"
ROOT_PACKAGE="acme"
REGION="$(jq -r '.region' "$LAYOUT")"
ACCOUNT_ID="$(jq -r --arg e "$ENV_NAME" '.environments[$e].account_id' "$LAYOUT")"
ADMIN_PROFILE="$(jq -r --arg e "$ENV_NAME" '.environments[$e].admin_profile' "$LAYOUT")"
if [ "$ENV_NAME" = "production" ]; then DIR="prod"; else DIR="$ENV_NAME"; fi
ROOT_REL="deployment/terraform/environments/${DIR}"
STATE_BUCKET="${PRODUCT}-state-${ACCOUNT_ID}"
NAME="${PRODUCT}-${ENV_NAME}"
CLUSTER="${NAME}"
INVESTIGATE_PROFILE="${PRODUCT}-${ENV_NAME}-investigate"
ENV_FILE="${HOME}/.config/${ROOT_PACKAGE}/ops/${ENV_NAME}.env"
RECORD_TASK="acme-release"

say() { printf '\n== %s\n' "$*"; }

show() {
  local out="+" a
  for a in "$@"; do out+=" $(printf '%q' "$a")"; done
  printf '%s\n' "$out"
}

run() {
  show "$@"
  if [ "$DRY_RUN" -eq 0 ]; then "$@"; fi
}

capture() {
  local placeholder="$1"
  shift
  show "$@" >&2
  if [ "$DRY_RUN" -eq 0 ]; then "$@"; else printf '%s\n' "$placeholder"; fi
}

need() {
  command -v "$1" > /dev/null 2>&1 || { echo "missing tool: $1" >&2; exit 1; }
}

check_account() {
  local account arn
  account="$(capture "$ACCOUNT_ID" aws sts get-caller-identity --query Account --output text)"
  arn="$(capture "arn:aws:sts::${ACCOUNT_ID}:assumed-role/AWSReservedSSO_Admin/dry-run" aws sts get-caller-identity --query Arn --output text)"
  if [ "$account" != "$ACCOUNT_ID" ]; then
    echo "profile ${ADMIN_PROFILE} answers account ${account}; ${ENV_NAME} is ${ACCOUNT_ID}. Refusing." >&2
    exit 1
  fi
  case "$arn" in
    *assumed-role/${PRODUCT}-investigate-* | *assumed-role/${PRODUCT}-deploy-* | *assumed-role/${PRODUCT}-plan-*)
      echo "profile ${ADMIN_PROFILE} resolves to ${arn}, not the administrator. Refusing." >&2
      exit 1
      ;;
  esac
  echo "account ${account} (${arn})"
}

# ---------------------------------------------------------------------------
# 0. The credential.
# ---------------------------------------------------------------------------

unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN AWS_DEFAULT_PROFILE AWS_PROFILE
export AWS_PROFILE="$ADMIN_PROFILE"
export AWS_REGION="$REGION" AWS_DEFAULT_REGION="$REGION"

for tool in aws terraform jq gh git; do need "$tool"; done

say "Destroying ${ENV_NAME}: account ${ACCOUNT_ID}, profile ${ADMIN_PROFILE}$([ "$DRY_RUN" -eq 1 ] && echo ' (dry run)')"
check_account
REPO="$(capture "OWNER/free-journalism" gh repo view --json nameWithOwner --jq .nameWithOwner)"

# ---------------------------------------------------------------------------
# 1. Production's preconditions, and the exact deployed commit.
# ---------------------------------------------------------------------------

run git -C "$REPO_ROOT" fetch --no-tags origin main release

if [ "$ENV_NAME" = "production" ]; then
  if [ "$CONFIRM" != "production" ]; then
    echo "production is destroyed only with the confirmation typed by a person; it is missing" >&2
    exit 1
  fi
  tfvars="$(capture 'database_deletion_protection = false' git -C "$REPO_ROOT" show "origin/release:${ROOT_REL}/terraform.tfvars")"
  if ! grep -Eq '^[[:space:]]*database_deletion_protection[[:space:]]*=[[:space:]]*false' <<< "$tfvars"; then
    echo "database_deletion_protection is not false on release; a merged and released change lifts it first. Refusing." >&2
    exit 1
  fi
  SHA="$(capture "<release sha>" git -C "$REPO_ROOT" rev-parse origin/release)"
  echo "applies from origin/release at ${SHA}"
else
  SHA=""
  for row in $(capture "0:<staging sha>" gh api "repos/${REPO}/deployments?environment=staging&task=${RECORD_TASK}&per_page=50" --jq '.[] | "\(.id):\(.sha)"'); do
    id="${row%%:*}"
    state="$(capture success gh api "repos/${REPO}/deployments/${id}/statuses?per_page=1" --jq '.[0].state // ""')"
    if [ "$state" = "success" ]; then
      SHA="${row#*:}"
      break
    fi
  done
  if [ -z "$SHA" ]; then
    echo "no successful staging deployment is recorded; nothing to apply from. Refusing." >&2
    exit 1
  fi
  echo "applies from staging's last successful deploy at ${SHA}"
fi

# ---------------------------------------------------------------------------
# 2. A clean worktree of that commit.
# ---------------------------------------------------------------------------

WORKTREE="$(mktemp -d "${TMPDIR:-/tmp}/${NAME}-nuke.XXXXXX")"
rmdir "$WORKTREE"
cleanup() {
  if [ "$DRY_RUN" -eq 0 ] && [ -d "$WORKTREE" ]; then
    git -C "$REPO_ROOT" worktree remove --force "$WORKTREE" > /dev/null 2>&1 || true
  fi
}
trap cleanup EXIT

run git -C "$REPO_ROOT" worktree add --detach "$WORKTREE" "$SHA"
dirty="$(capture "" git -C "$WORKTREE" status --porcelain)"
if [ -n "$dirty" ]; then
  echo "the worktree at ${WORKTREE} is not clean; refusing" >&2
  exit 1
fi
ROOT_DIR="${WORKTREE}/${ROOT_REL}"

run terraform -chdir="$ROOT_DIR" init -input=false -reconfigure -backend-config="bucket=${STATE_BUCKET}"

# The applied state must no longer protect the database.
if [ "$ENV_NAME" = "production" ]; then
  protected="$(capture false bash -c "terraform -chdir='${ROOT_DIR}' show -json | jq -r '[.values.root_module.child_modules[]?.resources[]? | select(.address == \"module.database.aws_db_instance.this\") | .values.deletion_protection][0] // false'")"
  if [ "$protected" != "false" ]; then
    echo "the applied state still protects ${NAME}'s database; the released change has not been applied. Refusing." >&2
    exit 1
  fi
fi

# The images the environment runs, so the apply changes nothing but the switch.
image_of() {
  local service="$1" container="$2" td
  td="$(capture "<task definition>" aws ecs describe-services --cluster "$CLUSTER" --services "$service" --query 'services[0].taskDefinition' --output text)"
  capture "<image of ${service}>" aws ecs describe-task-definition --task-definition "$td" \
    --query "taskDefinition.containerDefinitions[?name=='${container}'].image | [0]" --output text
}
API_IMAGE="$(image_of "${NAME}-api" api)"
WORKER_IMAGE="$(image_of "${NAME}-maintenance" maintenance)"

tf_vars=(
  -var "release=${SHA}"
  -var "api_image=${API_IMAGE}"
  -var "worker_image=${WORKER_IMAGE}"
  -var "destroyable=true"
)

# ---------------------------------------------------------------------------
# 3. The destroyable switch: force_destroy on the buckets and, outside
#    production, skip_final_snapshot. Production always leaves its final snapshot.
# ---------------------------------------------------------------------------

say "The destroyable switch"
check_account
run terraform -chdir="$ROOT_DIR" apply -input=false "${tf_vars[@]}"

# ---------------------------------------------------------------------------
# 4. Empty every data bucket of the environment, versions included; never the state bucket.
# ---------------------------------------------------------------------------

say "Emptying ${NAME}-* buckets"
empty_bucket() {
  local bucket="$1" batch
  run aws s3 rm "s3://${bucket}" --recursive --only-show-errors
  while :; do
    batch="$(capture '{"Objects": []}' aws s3api list-object-versions --bucket "$bucket" --max-items 500 --output json \
      --query '{Objects: [Versions[].{Key: Key, VersionId: VersionId}, DeleteMarkers[].{Key: Key, VersionId: VersionId}][] | [?Key != null]}')"
    if [ "$(jq '.Objects | length' <<< "$batch")" -eq 0 ]; then break; fi
    run aws s3api delete-objects --bucket "$bucket" --delete "$(jq -c '. + {Quiet: true}' <<< "$batch")"
  done
}
for bucket in $(capture "${NAME}-report-attachments ${NAME}-profile-media ${NAME}-portal" \
  aws s3api list-buckets --query "Buckets[?starts_with(Name, '${NAME}-')].Name" --output text); do
  case "$bucket" in
    "$STATE_BUCKET") continue ;;
  esac
  empty_bucket "$bucket"
done

# ---------------------------------------------------------------------------
# 5. Destroy the environment root.
# ---------------------------------------------------------------------------

say "terraform destroy ${ROOT_REL}"
check_account
run terraform -chdir="$ROOT_DIR" destroy -input=false "${tf_vars[@]}"

# ---------------------------------------------------------------------------
# 6. The GitHub environments, the investigate profile, the env file.
# ---------------------------------------------------------------------------

say "GitHub environments and local credentials"
if [ "$ENV_NAME" = "production" ]; then
  gh_envs=(production-plan production release)
else
  gh_envs=(staging)
fi
for env in "${gh_envs[@]}"; do
  run gh api -X DELETE "repos/${REPO}/environments/${env}"
done

config="${HOME}/.aws/config"
echo "+ remove [profile ${INVESTIGATE_PROFILE}] from ${config}"
if [ "$DRY_RUN" -eq 0 ] && [ -f "$config" ]; then
  awk -v section="[profile ${INVESTIGATE_PROFILE}]" '
    /^\[/ { skip = ($0 == section) }
    !skip { print }
  ' "$config" > "${config}.tmp" && mv "${config}.tmp" "$config"
  chmod 0600 "$config"
fi
run rm -f "$ENV_FILE"

# ---------------------------------------------------------------------------
# 7. What remains.
# ---------------------------------------------------------------------------

say "What remains"
if [ "$ENV_NAME" = "production" ]; then
  echo "- The final snapshot ${NAME}-final and the automated backups:"
  run aws rds describe-db-snapshots --db-snapshot-identifier "${NAME}-final" --query 'DBSnapshots[0].[DBSnapshotIdentifier,Status]' --output text
fi
cat <<EOF
- The bootstrap root (deployment/terraform/bootstrap/${DIR}), which serves the
  environment's next life: the zones the domain delegates to, the state bucket
  ${STATE_BUCKET} with the prefix environments/${DIR}/ empty, the artifacts
  bucket, the registry and its images (${PRODUCT}-api, ${PRODUCT}-maintenance),
  the roles (${PRODUCT}-investigate-${ENV_NAME} and the pipeline roles), the
  boundary, the trail, and the budget.
EOF
if [ "$ENV_NAME" = "staging" ]; then
  echo "- Production's copies of what staging built, in production's account."
fi
