#!/usr/bin/env bash
# Creates one cloud environment of the platform in its own account, as that
# account's administrator: the hands of the ops-cloud-deployment-create skill.
#
#   scripts/cloud_create.sh <staging|production> [--dry-run]
#       [--owner-email <address>] [--alarm-email <address>] [--app-id <id>]
#       [--reviewer <github login>]
#
# Inputs (flags or environment): OWNER_EMAIL, ALARM_EMAIL, APP_ID (the id of
# the repository host's app release.yml pushes with), REVIEWER (production's
# required reviewer, production only), and DNS_API_TOKEN, the domain's DNS host
# token, from the environment only, so it never lands in shell history (the
# run's one credential outside the account; scoped to the domain's zone and held
# only for the run). DNS_HOST names the host whose API writes the delegation
# (cloudflare is implemented; any other prints the records as a manual step).
#
# Order across accounts: staging, then production, then staging again, which
# finds production's artifacts bucket and turns replication on.
#
# --dry-run prints every command it would run and runs none. The script is
# safe to repeat; a repeat is also how an account is reproduced.
set -euo pipefail

usage() {
  sed -n '2,20p' "$0" | sed 's/^# \{0,1\}//'
  exit "${1:-2}"
}

# ---------------------------------------------------------------------------
# Arguments
# ---------------------------------------------------------------------------

ENV_NAME=""
DRY_RUN=0
OWNER_EMAIL="${OWNER_EMAIL:-}"
ALARM_EMAIL="${ALARM_EMAIL:-}"
APP_ID="${APP_ID:-}"
REVIEWER="${REVIEWER:-}"
DNS_HOST="${DNS_HOST:-cloudflare}"

while [ $# -gt 0 ]; do
  case "$1" in
    staging | production) ENV_NAME="$1" ;;
    --dry-run) DRY_RUN=1 ;;
    --owner-email) OWNER_EMAIL="${2:?--owner-email needs a value}"; shift ;;
    --alarm-email) ALARM_EMAIL="${2:?--alarm-email needs a value}"; shift ;;
    --app-id) APP_ID="${2:?--app-id needs a value}"; shift ;;
    --reviewer) REVIEWER="${2:?--reviewer needs a value}"; shift ;;
    -h | --help) usage 0 ;;
    local) echo "local has no administrator; this script acts on a cloud environment only" >&2; exit 2 ;;
    *) echo "unknown argument: $1" >&2; usage 2 ;;
  esac
  shift
done
[ -n "$ENV_NAME" ] || usage 2

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAYOUT="${REPO_ROOT}/deployment/cloud/environments.json"
PRODUCT="$(jq -r '.product' "$LAYOUT")"
ROOT_PACKAGE="acme"
PREFIX_UPPER="ACME"
REGION="$(jq -r '.region' "$LAYOUT")"
DOMAIN="$(jq -r '.domain' "$LAYOUT")"
ACCOUNT_ID="$(jq -r --arg e "$ENV_NAME" '.environments[$e].account_id' "$LAYOUT")"
ADMIN_PROFILE="$(jq -r --arg e "$ENV_NAME" '.environments[$e].admin_profile' "$LAYOUT")"
SSO_PROFILE="$(jq -r --arg e "$ENV_NAME" '.environments[$e].sso_profile' "$LAYOUT")"
BASE_DOMAIN="$(jq -r --arg e "$ENV_NAME" '.environments[$e].base_domain' "$LAYOUT")"
BRANCH="$(jq -r --arg e "$ENV_NAME" '.environments[$e].branch' "$LAYOUT")"
mapfile -t PUBLIC_NAMES < <(jq -r --arg e "$ENV_NAME" '.environments[$e].public_names[]' "$LAYOUT")
PRODUCTION_ACCOUNT_ID="$(jq -r '.environments.production.account_id' "$LAYOUT")"

if [ "$ENV_NAME" = "production" ]; then DIR="prod"; else DIR="$ENV_NAME"; fi
BOOTSTRAP_DIR="${REPO_ROOT}/deployment/terraform/bootstrap/${DIR}"
STATE_BUCKET="${PRODUCT}-state-${ACCOUNT_ID}"
INVESTIGATE_PROFILE="${PRODUCT}-${ENV_NAME}-investigate"
ENV_FILE="${HOME}/.config/${ROOT_PACKAGE}/ops/${ENV_NAME}.env"

# ---------------------------------------------------------------------------
# Helpers: every command is printed before it runs; a dry run runs none.
# ---------------------------------------------------------------------------

say() { printf '\n== %s\n' "$*"; }

show() {
  local out="+" a
  for a in "$@"; do out+=" $(printf '%q' "$a")"; done
  printf '%s\n' "$out"
}

run() {
  show "$@"
  if [ "$DRY_RUN" -eq 0 ]; then "$@"; fi
}

# capture <placeholder> <command...>: prints the command, echoes its output (or
# the placeholder in a dry run).
capture() {
  local placeholder="$1"
  shift
  show "$@" >&2
  if [ "$DRY_RUN" -eq 0 ]; then "$@"; else printf '%s\n' "$placeholder"; fi
}

need() {
  command -v "$1" > /dev/null 2>&1 || { echo "missing tool: $1" >&2; exit 1; }
}

# Refuses unless the administrator profile answers this environment's account.
# Asked before every apply.
check_account() {
  local account arn
  account="$(capture "$ACCOUNT_ID" aws sts get-caller-identity --query Account --output text)"
  arn="$(capture "arn:aws:sts::${ACCOUNT_ID}:assumed-role/AWSReservedSSO_Admin/dry-run" aws sts get-caller-identity --query Arn --output text)"
  if [ "$account" != "$ACCOUNT_ID" ]; then
    echo "profile ${ADMIN_PROFILE} answers account ${account}; ${ENV_NAME} is ${ACCOUNT_ID}. Refusing." >&2
    exit 1
  fi
  case "$arn" in
    *assumed-role/${PRODUCT}-investigate-* | *assumed-role/${PRODUCT}-deploy-* | *assumed-role/${PRODUCT}-plan-*)
      echo "profile ${ADMIN_PROFILE} resolves to ${arn}, not the administrator. Refusing." >&2
      exit 1
      ;;
  esac
  echo "account ${account} (${arn})"
}

# ---------------------------------------------------------------------------
# 0. The credential: keys exported in the shell outrank a profile, so clear them.
# ---------------------------------------------------------------------------

unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN AWS_SECURITY_TOKEN AWS_DEFAULT_PROFILE AWS_PROFILE
export AWS_PROFILE="$ADMIN_PROFILE"
export AWS_REGION="$REGION" AWS_DEFAULT_REGION="$REGION"

for tool in aws terraform jq gh curl git; do need "$tool"; done

say "Environment ${ENV_NAME}: account ${ACCOUNT_ID}, region ${REGION}, profile ${ADMIN_PROFILE}$([ "$DRY_RUN" -eq 1 ] && echo ' (dry run)')"
check_account
run gh auth status

missing=()
[ -n "$OWNER_EMAIL" ] || missing+=("OWNER_EMAIL (--owner-email)")
[ -n "$ALARM_EMAIL" ] || missing+=("ALARM_EMAIL (--alarm-email)")
[ -n "$APP_ID" ] || missing+=("APP_ID (--app-id)")
if [ "$ENV_NAME" = "production" ] && [ -z "$REVIEWER" ]; then missing+=("REVIEWER (--reviewer)"); fi
if [ "$DRY_RUN" -eq 0 ] && [ -z "${DNS_API_TOKEN:-}" ]; then missing+=("DNS_API_TOKEN (environment only)"); fi
if [ "${#missing[@]}" -gt 0 ]; then
  printf 'missing input: %s\n' "${missing[@]}" >&2
  exit 1
fi

REPO="$(capture "OWNER/free-journalism" gh repo view --json nameWithOwner --jq .nameWithOwner)"
REPO_ID="$(capture "000000000" gh api "repos/${REPO}" --jq .id)"
REPO_OWNER_ID="$(capture "000000000" gh api "repos/${REPO}" --jq .owner.id)"

# ---------------------------------------------------------------------------
# 1. The bootstrap root, with local state first, then moved into its bucket.
# ---------------------------------------------------------------------------

say "Bootstrap root deployment/terraform/bootstrap/${DIR}"

tf_vars=(
  -var "github_repository=${REPO}"
  -var "github_repository_id=${REPO_ID}"
  -var "github_repository_owner_id=${REPO_OWNER_ID}"
  -var "owner_email=${OWNER_EMAIL}"
)

if [ "$ENV_NAME" = "staging" ]; then
  # Replication into production needs production's artifacts bucket. From this
  # account it answers 403 when it exists and 404 when it does not.
  replicate=false
  probe="$(capture "404" bash -c "aws s3api head-bucket --bucket '${PRODUCT}-artifacts-${PRODUCTION_ACCOUNT_ID}' 2>&1 || true")"
  if [ -z "$probe" ] || printf '%s' "$probe" | grep -q -E '403|Forbidden'; then
    replicate=true
  fi
  echo "production's artifacts bucket $([ "$replicate" = true ] && echo exists: replication on || echo 'does not exist yet: replication off')"
  tf_vars+=(-var "replicate_to_production=${replicate}")
fi

state_exists="$(capture "no" bash -c "aws s3api head-bucket --bucket '${STATE_BUCKET}' > /dev/null 2>&1 && echo yes || echo no")"

if [ "$state_exists" = "yes" ]; then
  run terraform -chdir="$BOOTSTRAP_DIR" init -input=false -reconfigure -backend-config="bucket=${STATE_BUCKET}"
  check_account
  run terraform -chdir="$BOOTSTRAP_DIR" apply -input=false "${tf_vars[@]}"
else
  override="${BOOTSTRAP_DIR}/backend_override.tf"
  echo "+ write ${override}: terraform { backend \"local\" {} }"
  if [ "$DRY_RUN" -eq 0 ]; then
    printf 'terraform {\n  backend "local" {}\n}\n' > "$override"
  fi
  run terraform -chdir="$BOOTSTRAP_DIR" init -input=false -reconfigure
  check_account
  run terraform -chdir="$BOOTSTRAP_DIR" apply -input=false "${tf_vars[@]}"
  run rm -f "$override"
  run terraform -chdir="$BOOTSTRAP_DIR" init -input=false -migrate-state -force-copy -backend-config="bucket=${STATE_BUCKET}"
  run rm -f "${BOOTSTRAP_DIR}/terraform.tfstate" "${BOOTSTRAP_DIR}/terraform.tfstate.backup"
fi

outputs="$(capture '{}' terraform -chdir="$BOOTSTRAP_DIR" output -json)"
out() { jq -r "$1 // \"<${2:-unknown}>\"" <<< "$outputs"; }
ARTIFACTS_BUCKET="$(out '.artifacts_bucket.value' artifacts-bucket)"
ECR_REGISTRY="$(out '.ecr_registry.value' registry)"
DEPLOY_ROLE_ARN="$(out '.pipeline_role_arns.value.deploy' deploy-role-arn)"
BUILD_ROLE_ARN="$(out '.pipeline_role_arns.value.build' build-role-arn)"
PLAN_ROLE_ARN="$(out '.pipeline_role_arns.value.plan' plan-role-arn)"
INVESTIGATE_ROLE_ARN="$(out '.investigate_role_arn.value' investigate-role-arn)"

# ---------------------------------------------------------------------------
# 2. The delegation: each public name's NS records at the domain's DNS host.
# ---------------------------------------------------------------------------

say "Delegation of ${PUBLIC_NAMES[*]} at ${DNS_HOST}"

cloudflare() {
  local method="$1" path="$2" body="${3:-}"
  show curl -fsS -X "$method" "https://api.cloudflare.com/client/v4${path}" -H "Authorization: Bearer \$DNS_API_TOKEN" ${body:+--data "$body"} >&2
  if [ "$DRY_RUN" -eq 1 ]; then echo '{"result": []}'; return 0; fi
  curl -fsS -X "$method" "https://api.cloudflare.com/client/v4${path}" \
    -H "Authorization: Bearer ${DNS_API_TOKEN}" -H "Content-Type: application/json" ${body:+--data "$body"}
}

for name in "${PUBLIC_NAMES[@]}"; do
  mapfile -t servers < <(jq -r --arg n "$name" '.zone_name_servers.value[$n][]? // empty' <<< "$outputs")
  if [ "${#servers[@]}" -eq 0 ]; then servers=("<name servers of ${name}>"); fi
  if [ "$DNS_HOST" = "cloudflare" ]; then
    zone_id="$(cloudflare GET "/zones?name=${DOMAIN}" | jq -r '.result[0].id // "<zone id>"')"
    # Remove stale NS records for the name, then write one per name server.
    for record in $(cloudflare GET "/zones/${zone_id}/dns_records?type=NS&name=${name}" | jq -r '.result[].id'); do
      cloudflare DELETE "/zones/${zone_id}/dns_records/${record}" > /dev/null
    done
    for server in "${servers[@]}"; do
      cloudflare POST "/zones/${zone_id}/dns_records" \
        "$(jq -cn --arg n "$name" --arg s "$server" '{type: "NS", name: $n, content: $s, ttl: 3600}')" > /dev/null
    done
  else
    echo "MANUAL: at ${DNS_HOST}, in the zone ${DOMAIN}, write NS records for ${name}: ${servers[*]}"
  fi
done
unset DNS_API_TOKEN

# ---------------------------------------------------------------------------
# 3. The pipeline roles' trust reads the repository host's customized subject.
# ---------------------------------------------------------------------------

say "OIDC subject template of ${REPO}"
run gh api -X PUT "repos/${REPO}/actions/oidc/customization/sub" \
  -F use_default=false \
  -f 'include_claim_keys[]=repository_owner_id' \
  -f 'include_claim_keys[]=repository_id' \
  -f 'include_claim_keys[]=environment' \
  -f 'include_claim_keys[]=ref'

# ---------------------------------------------------------------------------
# 4. The investigate profile, chained from the identity center sign-in.
# ---------------------------------------------------------------------------

say "Profile ${INVESTIGATE_PROFILE} in ~/.aws/config"
run aws configure set --profile "$INVESTIGATE_PROFILE" role_arn "$INVESTIGATE_ROLE_ARN"
run aws configure set --profile "$INVESTIGATE_PROFILE" source_profile "$SSO_PROFILE"
run aws configure set --profile "$INVESTIGATE_PROFILE" region "$REGION"
run aws configure set --profile "$INVESTIGATE_PROFILE" duration_seconds 3600

# ---------------------------------------------------------------------------
# 5. The owner-only env file: the API's URL and empty token and tracker lines.
# ---------------------------------------------------------------------------

say "Env file ${ENV_FILE}"
echo "+ mkdir -m 0700 -p $(dirname "$ENV_FILE"); write ${ENV_FILE} (0600) when absent"
if [ "$DRY_RUN" -eq 0 ]; then
  mkdir -p "$(dirname "$ENV_FILE")"
  chmod 0700 "$(dirname "$ENV_FILE")"
  if [ ! -f "$ENV_FILE" ]; then
    (
      umask 077
      cat > "$ENV_FILE" <<EOF
${PREFIX_UPPER}_API_URL=https://api.${BASE_DOMAIN}
${PREFIX_UPPER}_OPERATOR_TOKEN=
${PREFIX_UPPER}_PROVISIONER_TOKEN=
${PREFIX_UPPER}_ERROR_TRACKER_URL=
${PREFIX_UPPER}_ERROR_TRACKER_TOKEN=
EOF
    )
  fi
  chmod 0600 "$ENV_FILE"
fi
echo "Fill by hand, once the environment's project exists in the error tracker:"
echo "  ${PREFIX_UPPER}_ERROR_TRACKER_URL=<the tracker's base URL>"
echo "  ${PREFIX_UPPER}_ERROR_TRACKER_TOKEN=<a read token of that project>"

# ---------------------------------------------------------------------------
# 6. The branch rulesets, when absent.
# ---------------------------------------------------------------------------

say "Rulesets of ${REPO}"
existing="$(capture '' gh api "repos/${REPO}/rulesets" --jq '.[].name')"

if ! grep -qx main <<< "$existing"; then
  main_ruleset="$(jq -n '{
    name: "main", target: "branch", enforcement: "active",
    conditions: {ref_name: {include: ["refs/heads/main"], exclude: []}},
    rules: [
      {type: "deletion"},
      {type: "non_fast_forward"},
      {type: "pull_request", parameters: {
        required_approving_review_count: 1, require_code_owner_review: true,
        dismiss_stale_reviews_on_push: true, require_last_push_approval: false,
        required_review_thread_resolution: false}},
      {type: "required_status_checks", parameters: {
        strict_required_status_checks_policy: true,
        required_status_checks: [
          {context: "check"}, {context: "integration"},
          {context: "terraform (deployment/terraform/bootstrap/staging)"},
          {context: "terraform (deployment/terraform/bootstrap/prod)"},
          {context: "terraform (deployment/terraform/environments/staging)"},
          {context: "terraform (deployment/terraform/environments/prod)"},
          {context: "image (api)"}, {context: "image (maintenance)"}]}}
    ]}')"
  show gh api -X POST "repos/${REPO}/rulesets" --input - "<<< main ruleset"
  if [ "$DRY_RUN" -eq 0 ]; then gh api -X POST "repos/${REPO}/rulesets" --input - <<< "$main_ruleset" > /dev/null; fi
fi

if ! grep -qx release <<< "$existing"; then
  release_ruleset="$(jq -n --argjson app "${APP_ID:-0}" '{
    name: "release", target: "branch", enforcement: "active",
    conditions: {ref_name: {include: ["refs/heads/release"], exclude: []}},
    rules: [{type: "deletion"}, {type: "non_fast_forward"}, {type: "update"}, {type: "creation"}],
    bypass_actors: [{actor_id: $app, actor_type: "Integration", bypass_mode: "always"}]}')"
  show gh api -X POST "repos/${REPO}/rulesets" --input - "<<< release ruleset (bypass: app ${APP_ID})"
  if [ "$DRY_RUN" -eq 0 ]; then gh api -X POST "repos/${REPO}/rulesets" --input - <<< "$release_ruleset" > /dev/null; fi
fi

# ---------------------------------------------------------------------------
# 7. The GitHub environments, their branch policies, and their variables.
# ---------------------------------------------------------------------------

make_environment() {
  local name="$1" branch="$2" reviewer_id="${3:-}" body
  if [ -n "$reviewer_id" ]; then
    body="$(jq -n --argjson r "$reviewer_id" '{reviewers: [{type: "User", id: $r}], deployment_branch_policy: {protected_branches: false, custom_branch_policies: true}}')"
  else
    body='{"deployment_branch_policy": {"protected_branches": false, "custom_branch_policies": true}}'
  fi
  show gh api -X PUT "repos/${REPO}/environments/${name}" --input - "<<< ${body}"
  if [ "$DRY_RUN" -eq 0 ]; then gh api -X PUT "repos/${REPO}/environments/${name}" --input - <<< "$body" > /dev/null; fi
  if ! capture "" gh api "repos/${REPO}/environments/${name}/deployment-branch-policies" --jq '.branch_policies[].name' | grep -qx "$branch"; then
    run gh api -X POST "repos/${REPO}/environments/${name}/deployment-branch-policies" -f "name=${branch}" -f type=branch
  fi
}

set_vars() {
  local env="$1"
  shift
  local pair
  for pair in "$@"; do
    run gh variable set "${pair%%=*}" --repo "$REPO" --env "$env" --body "${pair#*=}"
  done
}

common_vars=(
  "AWS_REGION=${REGION}"
  "TF_STATE_BUCKET=${STATE_BUCKET}"
  "ARTIFACTS_BUCKET=${ARTIFACTS_BUCKET}"
  "ECR_REGISTRY=${ECR_REGISTRY}"
  "API_DOMAIN=api.${BASE_DOMAIN}"
  "APP_DOMAIN=app.${BASE_DOMAIN}"
  "ADMIN_DOMAIN=admin.${BASE_DOMAIN}"
  "ALARM_EMAIL=${ALARM_EMAIL}"
)

say "GitHub environments"
if [ "$ENV_NAME" = "staging" ]; then
  make_environment staging "$BRANCH"
  set_vars staging "${common_vars[@]}" "AWS_ROLE_ARN=${DEPLOY_ROLE_ARN}" "BUILD_ROLE_ARN=${BUILD_ROLE_ARN}"
else
  reviewer_id="$(capture "1" gh api "users/${REVIEWER}" --jq .id)"
  make_environment production-plan "$BRANCH"
  make_environment production "$BRANCH" "$reviewer_id"
  make_environment release main
  set_vars production-plan "${common_vars[@]}" "AWS_ROLE_ARN=${PLAN_ROLE_ARN}"
  set_vars production "${common_vars[@]}" "AWS_ROLE_ARN=${DEPLOY_ROLE_ARN}"
  set_vars release "RELEASE_APP_ID=${APP_ID}"
fi

# ---------------------------------------------------------------------------
# 8. The first deploy goes through the pipeline; this script applies no environment root.
# ---------------------------------------------------------------------------

say "First deploy"
if [ "$ENV_NAME" = "staging" ]; then
  run gh workflow run deploy-staging.yml --repo "$REPO" --ref main
  echo "Watch it: gh run list --repo ${REPO} --workflow deploy-staging.yml --limit 1"
else
  cat <<EOF
Production's first deploy is its first release, which waits for a commit staging
built after replication was on:
  1. Run scripts/cloud_create.sh staging again: it finds production's artifacts
     bucket and turns replication on.
  2. Merge a change to main; staging deploys it (replicated into production).
  3. Dispatch release.yml on main; it fast-forwards release and starts deploy-production.yml.
EOF
fi

# ---------------------------------------------------------------------------
# 9. What a person does by hand.
# ---------------------------------------------------------------------------

say "Manual steps"
cat <<EOF
- The repository host's app release.yml pushes with (id ${APP_ID}): made by hand
  with contents write on ${REPO}, installed there, and its private key stored in
  the release environment:
    gh secret set RELEASE_APP_PRIVATE_KEY --repo ${REPO} --env release < <app private key>.pem
- The provider keys, created empty by the environment root's first apply; put
  each value under ${ADMIN_PROFILE} (the services start once they are filled):
    ${PRODUCT}-${ENV_NAME}-error-tracking-dsn, ${PRODUCT}-${ENV_NAME}-workos-api-key,
    ${PRODUCT}-${ENV_NAME}-stripe-secret-key, ${PRODUCT}-${ENV_NAME}-stripe-webhook-secret,
    ${PRODUCT}-${ENV_NAME}-postmark-server-token, ${PRODUCT}-${ENV_NAME}-twilio-auth-token,
    ${PRODUCT}-${ENV_NAME}-virustotal-api-key
    e.g. aws secretsmanager put-secret-value --profile ${ADMIN_PROFILE} --secret-id <name> --secret-string file://<file>
- The two error-tracker lines of ${ENV_FILE}.
- The first operator: sign up at https://app.${BASE_DOMAIN}, then dispatch
  grant-operator.yml on ${BRANCH} (email, permission=write); the operator enrols the
  second factor at the console's first sign-in and runs, in their own terminal:
    uv run ${ROOT_PACKAGE}-ops token --env ${ENV_NAME} --identity operator
- The smoke test follows the smoke identity's grant: sign it up, dispatch
  grant-operator.yml on ${BRANCH} with permission=read and mint_token=smoke, and set
  the SMOKE_EMAIL variable of the ${ENV_NAME} environment; the next deploy runs it.
  It never passes before that grant.
- Put ${ADMIN_PROFILE} away; every later skill runs under ${INVESTIGATE_PROFILE}:
    aws sso login --profile ${SSO_PROFILE}
    aws sts get-caller-identity --profile ${INVESTIGATE_PROFILE}
EOF
