#!/usr/bin/env bash
# Starts every application process on the host, against the local stack; `stop` stops them.
# A code change is a restart. Logs go to .run/<process>.log, pids to .run/<process>.pid.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p .run

# One line per process: name, then the command that runs it. Each scaffold appends its own.
PROCESSES=(
  "api|uv run acme-api serve"
  "maintenance|uv run acme-maintenance serve"
  "portal|pnpm --filter @acme/portal dev"
)

# The portal reads its settings from /config.json at start, as a deploy writes it next to the bundle.
write_portal_config() {
  mkdir -p apps/portal/public
  printf '{"apiOrigin":"%s","requestTimeoutMs":15000,"errorTrackingDsn":"%s","environment":"%s"}\n' \
    "${ACME_API_PUBLIC_URL:-http://localhost:8000}" "${ACME_PORTAL_ERROR_TRACKING_DSN:-}" "${ACME_ENVIRONMENT:-local}" \
    >apps/portal/public/config.json
}

start() {
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
  write_portal_config
  for entry in "${PROCESSES[@]}"; do
    name="${entry%%|*}"
    command="${entry#*|}"
    if [ -f ".run/${name}.pid" ] && kill -0 "$(cat ".run/${name}.pid")" 2>/dev/null; then
      echo "${name}: already running"
      continue
    fi
    nohup bash -c "exec ${command}" >".run/${name}.log" 2>&1 &
    echo $! >".run/${name}.pid"
    echo "${name}: started (log .run/${name}.log)"
  done
}

stop() {
  for entry in "${PROCESSES[@]}"; do
    name="${entry%%|*}"
    if [ -f ".run/${name}.pid" ]; then
      kill "$(cat ".run/${name}.pid")" 2>/dev/null || true
      rm -f ".run/${name}.pid"
      echo "${name}: stopped"
    fi
  done
}

case "${1:-start}" in
  start) start ;;
  stop) stop ;;
  restart) stop; start ;;
  *) echo "usage: scripts/dev.sh start|stop|restart" >&2; exit 2 ;;
esac
