#!/usr/bin/env bash
# Prints every local URL a developer opens, with the ports read from .env.
set -euo pipefail
cd "$(dirname "$0")/.."
set -a
# shellcheck disable=SC1091
source .env
set +a
api="http://localhost:${ACME_API_PORT:-8000}"
cat <<URLS
API                 ${api}
API docs            ${api}/docs
Portal              http://localhost:${ACME_PORTAL_PORT:-5173}
pgweb (Postgres)    http://localhost:${ACME_LOCAL_PGWEB_PORT}
Valkey Admin        http://localhost:${ACME_LOCAL_VALKEY_ADMIN_PORT}
Object store        http://localhost:${ACME_LOCAL_S3_CONSOLE_PORT}
Queue console       http://localhost:${ACME_LOCAL_SQS_CONSOLE_PORT}
Jaeger (traces)     http://localhost:${ACME_LOCAL_JAEGER_PORT}
GlitchTip (errors)  http://localhost:${ACME_LOCAL_GLITCHTIP_PORT}
Prometheus          http://localhost:${ACME_LOCAL_PROMETHEUS_PORT}
Grafana (metrics)   http://localhost:${ACME_LOCAL_GRAFANA_PORT}
Seeded sign-in      ${ACME_SEED_OWNER_EMAIL} / ${ACME_SEED_OWNER_PASSWORD} (local only)
URLS
