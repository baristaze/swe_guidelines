"""Waits until a local dashboard answers, so the step after `make devx-up` finds it ready."""

import os
import sys
import time
import urllib.request

TARGETS = {
    "glitchtip": lambda: f"http://localhost:{os.environ.get('ACME_LOCAL_GLITCHTIP_PORT', '58000')}/_health/",
    "api": lambda: f"http://localhost:{os.environ.get('ACME_API_PORT', '8000')}/healthz",
}


def main() -> int:
    url = TARGETS[sys.argv[1]]()
    deadline = time.monotonic() + float(sys.argv[2] if len(sys.argv) > 2 else 180)
    while time.monotonic() < deadline:
        try:
            with urllib.request.urlopen(url, timeout=3) as response:  # noqa: S310 - a local URL
                if response.status < 500:
                    print(f"{sys.argv[1]} answers at {url}")
                    return 0
        except OSError:
            pass
        time.sleep(2)
    print(f"{sys.argv[1]} did not answer at {url}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())
