"""The second fence, read from the migrated database: every table's policy matches its declared scope, the three
logins are what they claim, the schema matches the ORM, and a data migration lifts FORCE for itself and counts."""

import uuid
from pathlib import Path

import psycopg
import pytest
from local_stack import local_settings
from psycopg import sql

from acme.om.storage.migrate import check_sql_role, schema_diff
from acme.om.storage.roles import TABLE_ROLES, TABLE_SCOPES, DatabaseRole, TenancyScope
from acme.om.storage.settings import StorageSettings

pytestmark = pytest.mark.integration

EMPTY = "00000000-0000-0000-0000-000000000000"
SYSTEM_CLAUSE = f"current_setting('app.org_id'::text, true) = '{EMPTY}'::text"


def connect(url: str) -> psycopg.Connection:
    return psycopg.connect(url, autocommit=True)


def test_every_table_carries_the_policy_its_scope_declares() -> None:
    settings = local_settings()
    with connect(settings.database_migration_url) as conn:
        for table, (scope, column) in TABLE_SCOPES.items():
            schema = TABLE_ROLES[table].value
            row = conn.execute(
                "SELECT c.relrowsecurity, c.relforcerowsecurity FROM pg_class c "
                "JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = %s AND c.relname = %s",
                (schema, table),
            ).fetchone()
            assert row is not None, f"{schema}.{table} is not migrated"
            policies = conn.execute(
                "SELECT policyname, cmd, qual, with_check FROM pg_policies WHERE schemaname = %s AND tablename = %s",
                (schema, table),
            ).fetchall()
            if scope == TenancyScope.SYSTEM:
                assert row == (False, False) and not policies, f"{schema}.{table} is a system table"
                continue
            assert row == (True, True), f"{schema}.{table} must ENABLE and FORCE row level security"
            assert len(policies) == 1, f"{schema}.{table} carries one policy"
            _, cmd, qual, check = policies[0]
            assert cmd == "ALL" and qual == check
            key = "org_id" if scope in (TenancyScope.ORG, TenancyScope.BOTH) else column
            setting = "app.identity_id" if scope == TenancyScope.IDENTITY else "app.org_id"
            assert f"{key} = (NULLIF(current_setting('{setting}'::text, true), ''::text))::uuid" in qual
            assert SYSTEM_CLAUSE in qual and "CURRENT_USER = 'acme_system'::name" in qual


@pytest.mark.parametrize("which", ["database_url", "database_system_url", "database_migration_url"])
def test_no_login_is_a_superuser_or_bypasses_the_fence(which: str) -> None:
    with connect(getattr(local_settings(), which)) as conn:
        row = conn.execute("SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = current_user").fetchone()
        assert row == (False, False)


def test_the_runtime_login_owns_no_table() -> None:
    with connect(local_settings().database_url) as conn:
        owned = conn.execute(
            "SELECT count(*) FROM pg_tables WHERE tableowner = current_user AND schemaname = ANY(%s)",
            ([r.value for r in DatabaseRole],),
        ).fetchone()
        assert owned == (0,)


def test_the_runtime_login_naming_the_system_scope_reads_nothing() -> None:
    settings = local_settings()
    with connect(settings.database_system_url) as system:
        system.execute("BEGIN")
        system.execute("SELECT set_config('app.org_id', %s, true)", (EMPTY,))
        seen_by_system = system.execute("SELECT count(*) FROM core.users").fetchone()
        system.execute("COMMIT")
    with connect(settings.database_url) as runtime:
        runtime.execute("BEGIN")
        runtime.execute("SELECT set_config('app.org_id', %s, true)", (EMPTY,))
        assert runtime.execute("SELECT count(*) FROM core.users").fetchone() == (0,)
        assert runtime.execute("SELECT count(*) FROM core.sessions").fetchone() == (0,)
        runtime.execute("COMMIT")
    assert seen_by_system is not None


def test_a_transaction_that_names_no_tenant_reads_nothing() -> None:
    with connect(local_settings().database_url) as runtime:
        assert runtime.execute("SELECT count(*) FROM core.outbox").fetchone() == (0,)


@pytest.mark.parametrize(
    "role",
    [r for r in DatabaseRole if (Path(__file__).resolve().parents[2] / "migrations" / "versions" / r.value).is_dir()],
)
def test_the_orm_matches_the_migrated_schema(role: DatabaseRole) -> None:
    local_settings()
    assert schema_diff(role) == []


BACKFILL = """
ALTER TABLE core.backfill_fixture NO FORCE ROW LEVEL SECURITY;
DO $$
DECLARE expected bigint; touched bigint;
BEGIN
  SELECT count(*) INTO expected FROM core.backfill_fixture WHERE NOT flag;
  UPDATE core.backfill_fixture SET flag = true WHERE NOT flag;
  GET DIAGNOSTICS touched = ROW_COUNT;
  IF touched <> expected THEN
    RAISE EXCEPTION 'backfill touched % rows, expected %', touched, expected;
  END IF;
END $$;
ALTER TABLE core.backfill_fixture FORCE ROW LEVEL SECURITY;
"""


def test_a_backfill_lifts_force_for_itself_and_touches_every_tenant() -> None:
    settings = StorageSettings()
    local_settings()
    tenants = [str(uuid.uuid4()), str(uuid.uuid4())]
    with connect(settings.database_migration_url) as owner:
        owner.execute("DROP TABLE IF EXISTS core.backfill_fixture")
        owner.execute(
            "CREATE TABLE core.backfill_fixture "
            "(id uuid PRIMARY KEY, org_id uuid NOT NULL, flag boolean NOT NULL DEFAULT false)"
        )
        expression = (
            "org_id = NULLIF(current_setting('app.org_id', true), '')::uuid "
            f"OR (current_setting('app.org_id', true) = '{EMPTY}' AND current_user = 'acme_system')"
        )
        owner.execute(
            sql.SQL("CREATE POLICY tenant_fence ON core.backfill_fixture FOR ALL USING ({e}) WITH CHECK ({e})").format(
                e=sql.SQL(expression)  # type: ignore[arg-type]
            )
        )
        owner.execute("ALTER TABLE core.backfill_fixture ENABLE ROW LEVEL SECURITY")
        owner.execute("ALTER TABLE core.backfill_fixture FORCE ROW LEVEL SECURITY")
        owner.execute("GRANT SELECT, INSERT, UPDATE, DELETE ON core.backfill_fixture TO acme_runtime, acme_system")
    try:
        with connect(settings.database_url) as runtime:
            for tenant in tenants:
                for _ in range(2):
                    runtime.execute("BEGIN")
                    runtime.execute("SELECT set_config('app.org_id', %s, true)", (tenant,))
                    runtime.execute(
                        "INSERT INTO core.backfill_fixture (id, org_id) VALUES (%s, %s)", (str(uuid.uuid4()), tenant)
                    )
                    runtime.execute("COMMIT")
        check_sql_role("core", BACKFILL, "backfill")
        with psycopg.connect(settings.database_migration_url) as owner:  # one transaction, never split on `;`
            owner.execute(BACKFILL)
            owner.commit()
        with connect(settings.database_url) as runtime:
            for tenant in tenants:
                runtime.execute("BEGIN")
                runtime.execute("SELECT set_config('app.org_id', %s, true)", (tenant,))
                flags = runtime.execute("SELECT flag FROM core.backfill_fixture").fetchall()
                runtime.execute("COMMIT")
                assert flags == [(True,), (True,)], f"tenant {tenant} was not backfilled"
    finally:
        with connect(settings.database_migration_url) as owner:
            owner.execute("DROP TABLE IF EXISTS core.backfill_fixture")
