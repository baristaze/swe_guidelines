"""The tenancy nouns: orgs, identities, users, memberships, credentials, and the operator allowlist."""

from datetime import datetime
from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from acme.om.base import Created, Identifiable, Named, Platform, SoftDeletable, Trackable
from acme.om.opcontext import CredentialKind, IdentityContext, OpContext, OperatorPermission, Role


class Org(Identifiable, Named, Trackable, SoftDeletable):
    """A tenant. For this product, a journalist's desk: the journalist and anyone they work with."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("slug", "provisioned_by")
    slug: str
    provisioned_by: UUID | None = None  # the operator identity that provisioned it (a traffic run's), else None


class Identity(Identifiable, Trackable):
    """A person across tenants. The email is a name to sign in with, stored beside its digest."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = (
        "email",
        "email_digest",
        "password_hash",
        "totp_secret",
        "totp_confirmed_at",
        "totp_last_step",
        "issuer",
        "subject",
    )
    email: str
    email_digest: str
    display_name: str
    password_hash: str | None = None
    totp_secret: str | None = None  # encrypted under the TOTP encryption key; never the plain secret
    totp_confirmed_at: datetime | None = None
    totp_last_step: int | None = None  # the last time step accepted, so a code is used once
    issuer: str | None = None  # the external identity provider, with the subject it names the person by
    subject: str | None = None


class User(Identifiable, Named, Trackable):
    """A person inside one tenant; `name` is how the tenant sees them."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("identity_id",)
    identity_id: UUID


class Membership(Identifiable, Trackable):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("user_id", "role")
    user_id: UUID
    role: Role


class SessionKind(StrEnum):
    LOGIN = "login"  # the sign-in credential: names a person and no tenant
    TENANT = "tenant"  # a tenant session, exchanged from a sign-in
    OPERATOR = "operator"  # an operator token, one permission, one hour at most


class Session(Identifiable, Created):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = (
        "created_at",
        "identity_id",
        "kind",
        "tenant_id",
        "user_id",
        "permission",
        "digest",
        "second_factor",
        "last_seen_at",
        "expires_at",
        "ended_at",
    )
    identity_id: UUID
    kind: SessionKind
    tenant_id: UUID  # a tenant session's org; EMPTY_UUID for a sign-in or an operator token
    user_id: UUID | None = None
    permission: OperatorPermission | None = None
    digest: str
    second_factor: bool = False  # a sign-in that verified a TOTP code
    last_seen_at: datetime
    expires_at: datetime
    ended_at: datetime | None = None


class ApiKey(Identifiable, Named, Created):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("digest", "role", "issued_by", "expires_at", "revoked_at")
    issued_by: UUID  # the issuer's user id; the key's effective role never exceeds the issuer's current one
    digest: str
    role: Role
    expires_at: datetime
    revoked_at: datetime | None = None


class SocketTicket(Identifiable, Created):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()
    identity_id: UUID
    tenant_id: UUID  # the org the ticket's socket serves; the table is scoped to the identity
    user_id: UUID
    credential_kind: CredentialKind
    credential_id: UUID
    digest: str
    expires_at: datetime
    redeemed_at: datetime | None = None


class OperatorEntry(Identifiable, Trackable):
    """An identity on the operator allowlist; `write` implies `read`."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("identity_id", "permission", "disabled_at")
    identity_id: UUID
    permission: OperatorPermission
    disabled_at: datetime | None = None


class IdentityMembership(Identifiable, Created):
    """The identity's own copy of one membership, read under the identity stage across tenants."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()
    tenant_id: UUID  # the org of the membership; the table is scoped to the identity
    user_id: UUID
    role: Role


class SignInThrottle(Platform):
    failures: int
    retry_at: datetime


class ApiKeyInsert(StrEnum):
    INSERTED = "inserted"
    ID_EXISTS = "id_exists"
    NO_MEMBERSHIP = "no_membership"  # the issuer's membership ended before the key could land


class MembershipChoice(Platform):
    org_id: UUID
    org_name: str
    org_slug: str
    user_id: UUID
    role: Role


class Member(Platform):
    user_id: UUID
    identity_id: UUID
    name: str
    role: Role


class IssuedCredential(Platform):
    """A secret shown once; only its digest is stored."""

    credential_id: UUID
    token: str
    expires_at: datetime


class IssuedApiKey(Platform):
    api_key: ApiKey
    token: str


class SignedIn(Platform):
    identity: IdentityContext
    credential: IssuedCredential
    memberships: tuple[MembershipChoice, ...]


class SocketGrant(Platform):
    ctx: OpContext
    expires_at: datetime  # the socket closes at this instant, whatever the client does


class TotpEnrolment(Platform):
    secret: str  # base32, shown once to the operator's authenticator
    uri: str


class TenancySize(Platform):
    tenants: int
    users: int


class PlatformSize(Platform):
    tenants: int
    users: int
    events_last_day: int


class MarkerGuard(Platform):
    """The attempt an idempotency marker holds; a rerun's re-mint writes only while it still holds."""

    marker_id: UUID
    attempt_token: UUID
