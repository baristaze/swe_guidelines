"""The storage contract cases over the memory root."""

from collections.abc import Awaitable, Callable

import pytest

from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.storage.root import StorageInterface
from contracts.registry import ALL_CASES


@pytest.fixture
def storage() -> StorageInterface:
    return StorageMemoryImpl()


@pytest.mark.parametrize("case", ALL_CASES, ids=lambda c: c.__name__.removeprefix("case_"))
async def test_contract(case: Callable[[StorageInterface], Awaitable[None]], storage: StorageInterface) -> None:
    await case(storage)
