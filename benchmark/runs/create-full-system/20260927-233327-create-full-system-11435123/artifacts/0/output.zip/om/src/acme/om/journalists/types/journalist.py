"""The journalist profile: the name a desk's readers see, and in time its bio, coverage, and verification."""

from typing import ClassVar

from acme.om.base import Identifiable, SoftDeletable, Trackable


class Journalist(Identifiable, Trackable, SoftDeletable):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    display_name: str  # the name readers see; a personal field, so it never rides an event or an outbox row
