"""The work manager over the memory root: enqueue, the relayed enqueue, the claim's context, and the transitions."""

from datetime import timedelta

import pytest
from conftest import rctx
from flows import tenant_ctx

from acme.infra.topics import TopicPayload, Topics
from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.opcontext import Role
from acme.om.root import Managers
from acme.om.work.types.work_item import WorkItem, WorkKind, WorkStatus
from contracts import factories as f


def fresh(lane: str = "default", key=None) -> WorkItem:  # type: ignore[no-untyped-def]
    now = utcnow()
    return WorkItem(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=new_id(),  # the manager stamps the actor over what the caller sent
        updated_by=new_id(),
        kind=WorkKind.NOOP,
        target_id=new_id(),
        idempotency_key=key or new_id(),
        request_id=new_id(),
        lane=lane,
        status=WorkStatus.DONE,  # the manager owns the status
        available_at=now,
    )


async def test_enqueue_publishes_once_and_a_retry_publishes_nothing(managers: Managers, infra) -> None:  # type: ignore[no-untyped-def]
    wakes: list[TopicPayload] = []

    async def listen(p: TopicPayload) -> None:
        wakes.append(p)

    infra.get_topics().subscribe(Topics.WORK_AVAILABLE, "test", listen)
    ctx, _ = await tenant_ctx(managers)
    it = fresh()
    queued = await managers.work.enqueue(ctx, it)
    assert queued.status == WorkStatus.QUEUED and queued.created_by == ctx.user_id
    assert queued.created_at == it.created_at
    again = await managers.work.enqueue(ctx, it)
    assert again == queued and len(wakes) == 1
    by_key = await managers.work.enqueue(ctx, fresh(key=it.idempotency_key))
    assert by_key.id == it.id


async def test_the_relayed_enqueue_takes_the_rows_provenance(managers: Managers, storage) -> None:  # type: ignore[no-untyped-def]
    t = await f.tenant(storage)
    row = f.row(t.org_id, "work.noop").model_copy(
        update={"actor_id": t.user.id, "traceparent": "00-" + "a" * 32 + "-" + "b" * 16 + "-01"}
    )
    item = await managers.work.enqueue_relayed(t.org_id, row)
    assert (item.id, item.idempotency_key, item.created_by, item.request_id) == (
        row.id,
        row.id,
        t.user.id,
        row.request_id,
    )
    assert item.traceparent == row.traceparent
    assert (await managers.work.enqueue_relayed(t.org_id, row)) == item


async def test_a_relayed_work_row_is_done_once_its_item_is_queued(managers: Managers, storage, infra) -> None:  # type: ignore[no-untyped-def]
    t = await f.tenant(storage)
    row = f.row(t.org_id, "work.noop")
    await storage.get_tenancy_storage().write_user(t.org_id, t.user, (row,))
    infra.get_topics().accepting = False  # the wake-up is refused; the row is done all the same
    assert await managers.relay.relay(t.org_id, row)
    assert await managers.relay.relay(t.org_id, row)
    assert (await storage.get_outbox_storage().read_row(t.org_id, row.id)).done_at is not None
    assert (await storage.get_work_storage().read_item(t.org_id, row.id)) is not None


async def test_claim_returns_the_enqueuers_context_naming_the_cause(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    it = await managers.work.enqueue(ctx, fresh(lane="claims"))
    claimed = await managers.work.claim(rctx(), "claims", (WorkKind.NOOP,), "w1", timedelta(minutes=1))
    assert claimed is not None
    work_ctx, item = claimed
    assert work_ctx.user_id == ctx.user_id and work_ctx.security.role == Role.SERVICE
    assert work_ctx.caused_by_request_id == it.request_id and item.claim_token is not None


async def test_an_item_from_the_platform_runs_under_the_service_context(managers: Managers, storage) -> None:  # type: ignore[no-untyped-def]
    t = await f.tenant(storage)
    await managers.work.enqueue_relayed(
        t.org_id, f.row(t.org_id, "work.noop").model_copy(update={"actor_id": EMPTY_UUID})
    )
    claimed = await managers.work.claim(rctx(), "default", (WorkKind.NOOP,), "w1", timedelta(minutes=1))
    assert claimed is not None and claimed[0].user_id == EMPTY_UUID


async def test_an_item_whose_tenant_is_gone_is_failed_and_never_handed_out(managers: Managers, storage) -> None:  # type: ignore[no-untyped-def]
    orphan_org = new_id()
    row = f.row(orphan_org, "work.noop")
    await managers.work.enqueue_relayed(orphan_org, row)
    assert await managers.work.claim(rctx(), "default", (WorkKind.NOOP,), "w1", timedelta(minutes=1)) is None
    assert (await storage.get_work_storage().read_item(orphan_org, row.id)).status == WorkStatus.FAILED


async def test_every_write_after_the_enqueue_is_signed_by_the_platform(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    await managers.work.enqueue(ctx, fresh(lane="signs"))
    claimed = await managers.work.claim(rctx(), "signs", (WorkKind.NOOP,), "w1", timedelta(minutes=1))
    assert claimed is not None
    work_ctx, item = claimed
    renewed = await managers.work.extend_lease(work_ctx, item, timedelta(minutes=2))
    done = await managers.work.complete(work_ctx, renewed)
    assert done.status == WorkStatus.DONE and done.updated_by == EMPTY_UUID


async def test_a_stale_holder_is_refused(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    await managers.work.enqueue(ctx, fresh(lane="stale"))
    claimed = await managers.work.claim(rctx(), "stale", (WorkKind.NOOP,), "w1", timedelta(minutes=1))
    assert claimed is not None
    work_ctx, item = claimed
    await managers.work.release(work_ctx, item, "shutting down")
    with pytest.raises(Conflict):
        await managers.work.complete(work_ctx, item)


async def test_failure_requeues_then_dead_letters_with_an_audit_entry(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    await managers.work.enqueue(ctx, fresh(lane="fails").model_copy(update={"max_attempts": 1}))
    claimed = await managers.work.claim(rctx(), "fails", (WorkKind.NOOP,), "w1", timedelta(minutes=1))
    assert claimed is not None
    failed = await managers.work.fail(claimed[0], claimed[1], "boom")
    assert failed.status == WorkStatus.FAILED
    trail = await managers.audit.get_audit_entries(ctx, 0, 10)
    assert [e.kind for e in trail] == ["work.dead_letter"]


async def test_defer_hands_back_later_and_purge_takes_old_finished_items(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    await managers.work.enqueue(ctx, fresh(lane="defer"))
    claimed = await managers.work.claim(rctx(), "defer", (WorkKind.NOOP,), "w1", timedelta(minutes=1))
    assert claimed is not None
    deferred = await managers.work.defer(claimed[0], claimed[1], timedelta(hours=1))
    assert deferred.status == WorkStatus.QUEUED and deferred.available_at > utcnow()
    assert await managers.work.claim(rctx(), "defer", (WorkKind.NOOP,), "w1", timedelta(minutes=1)) is None
    assert await managers.work.purge_items(rctx()) == 0
