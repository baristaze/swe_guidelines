"""The guard every integration suite takes: it runs only against the local compose stack."""

from urllib.parse import urlparse

import pytest

from acme.om.storage.settings import StorageSettings

LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "postgres"}


def local_settings() -> StorageSettings:
    """Every database URL the settings resolve (shared, per role, from the environment, .env, or a default)."""
    settings = StorageSettings()
    remote = [u for u in settings.all_urls() if urlparse(u).hostname not in LOCAL_HOSTS]
    if remote:
        pytest.exit("an integration run refuses a database URL that is not a local address", returncode=2)
    return settings
