"""Imports every table module, so the metadata the migration check compares is whole."""

import importlib

TABLE_MODULES = (
    "acme.om.tenancy.storage.tables.tenancy",
    "acme.om.outbox.storage.tables.outbox",
    "acme.om.idempotency.storage.tables.idempotency_markers",
    "acme.om.events.storage.tables.events",
    "acme.om.audit.storage.tables.audit_entries",
    "acme.om.work.storage.tables.work_items",
    "acme.om.journalists.storage.tables.journalists",
)


def import_all_tables() -> None:
    for module in TABLE_MODULES:
        importlib.import_module(module)
