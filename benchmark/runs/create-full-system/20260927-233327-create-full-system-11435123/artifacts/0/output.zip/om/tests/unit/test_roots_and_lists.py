"""Every root is built whole at construction, and every manager method on the request stage is named here."""

import dataclasses
import inspect
from pathlib import Path

from conftest import manager_options

from acme.infra.cache import CacheScope
from acme.infra.impl.local import InfraLocalImpl
from acme.om.opcontext import Permission, RequestContext, Role
from acme.om.root import Managers, build_managers
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.storage.impl.postgres import StoragePostgresImpl
from acme.om.storage.root import StorageInterface
from acme.om.storage.settings import StorageSettings
from acme.om.tenancy import rules

# Every manager method that takes the request stage instead of a later one. A new one is a decision.
REQUEST_STAGE = {
    "TenancyManagerImpl.sign_up",
    "TenancyManagerImpl.sign_in",
    "TenancyManagerImpl.sign_in_external",
    "TenancyManagerImpl.authenticate",
    "TenancyManagerImpl.authenticate_internal",
    "TenancyManagerImpl.authenticate_login",
    "TenancyManagerImpl.redeem_socket_ticket",
    "TenancyManagerImpl.bootstrap",
    "TenancyManagerImpl.ensure_identity",
    "TenancyManagerImpl.grant_operator",
    "TenancyManagerImpl.disable_operator",
    "TenancyManagerImpl.grant_operator_token",
    "TenancyManagerImpl.service_contexts",
    "TenancyManagerImpl.purge_socket_tickets",
    "TenancyManagerImpl.purge_sessions",
    "OutboxRelayImpl.relay_pending",
    "OutboxRelayImpl.purge_done",
    "OutboxRelayImpl.read_lag",
    "IdempotencyManagerImpl.purge_markers",
    "TenancyManagerImpl.claim_context",
    "WorkManagerImpl.claim",
    "WorkManagerImpl.purge_items",
    "WorkManagerImpl.read_gauges",
    "WorkManagerImpl.maintenance_contexts",
}

STORAGE_GETTERS = [n for n, _ in inspect.getmembers(StorageInterface) if n.startswith("get_")]


def test_the_memory_root_builds_every_storage_at_construction() -> None:
    root = StorageMemoryImpl()
    built = {name: getattr(root, name)() for name in STORAGE_GETTERS}
    assert all(built.values())
    assert all(getattr(root, name)() is built[name] for name in STORAGE_GETTERS)  # built once, never on first use


def test_the_postgres_root_builds_every_storage_at_construction() -> None:
    root = StoragePostgresImpl(StorageSettings(_env_file=None))  # type: ignore[call-arg]  # opens nothing yet
    built = {name: getattr(root, name)() for name in STORAGE_GETTERS}
    assert all(built.values())
    assert all(getattr(root, name)() is built[name] for name in STORAGE_GETTERS)


def test_the_infra_root_builds_every_capability(tmp_path: Path) -> None:
    root = InfraLocalImpl(tmp_path)
    caches = {scope: root.get_cache(scope) for scope in CacheScope}
    assert all(root.get_cache(scope) is caches[scope] for scope in CacheScope)
    for getter in (root.get_buckets, root.get_topics, root.get_queues, root.get_secrets):
        assert getter() is getter()


def test_build_managers_fills_every_field_once(tmp_path: Path) -> None:
    managers = build_managers(StorageMemoryImpl(), InfraLocalImpl(tmp_path), manager_options())
    for field in dataclasses.fields(Managers):
        assert getattr(managers, field.name) is not None


def test_the_journalists_namespace_is_wired(tmp_path: Path) -> None:
    storage = StorageMemoryImpl()
    assert storage.get_journalist_storage() is storage.get_journalist_storage()
    managers = build_managers(storage, InfraLocalImpl(tmp_path), manager_options())
    assert managers.journalists is not None


def test_the_request_stage_list_is_exact(tmp_path: Path) -> None:
    managers = build_managers(StorageMemoryImpl(), InfraLocalImpl(tmp_path), manager_options())
    found = set()
    for field in dataclasses.fields(Managers):
        impl = getattr(managers, field.name)
        for name, method in inspect.getmembers(type(impl), inspect.iscoroutinefunction):
            params = list(inspect.signature(method).parameters.values())
            if len(params) > 1 and params[1].annotation in (RequestContext, "RequestContext"):
                found.add(f"{type(impl).__name__}.{name}")
    assert found == REQUEST_STAGE


def test_each_role_holds_the_permissions_of_the_next() -> None:
    for higher, lower in zip(rules.PERSON_ROLES, rules.PERSON_ROLES[1:], strict=False):
        assert rules.ROLE_PERMISSIONS[lower] <= rules.ROLE_PERMISSIONS[higher]
    assert rules.ROLE_PERMISSIONS[Role.OWNER] == frozenset(Permission)
    assert rules.lower_role(Role.OWNER, Role.VIEWER) == Role.VIEWER
    assert rules.lower_role(Role.MEMBER, Role.ADMIN) == Role.MEMBER


def test_the_sign_in_delay_doubles_to_a_cap() -> None:
    assert [rules.sign_in_delay_seconds(n, 1.0, 5.0) for n in range(5)] == [0.0, 1.0, 2.0, 4.0, 5.0]


def test_every_storage_setting_is_in_env_example() -> None:
    env = Path(__file__).resolve().parents[3] / ".env.example"
    documented = {
        line.split("=", 1)[0] for line in env.read_text().splitlines() if "=" in line and not line.startswith("#")
    }
    missing = {f"ACME_{name.upper()}" for name in StorageSettings.model_fields} - documented
    assert not missing, f"undocumented storage settings: {sorted(missing)}"
