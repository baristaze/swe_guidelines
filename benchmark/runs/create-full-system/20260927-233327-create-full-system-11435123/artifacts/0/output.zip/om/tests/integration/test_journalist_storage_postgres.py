"""The journalists storage contract over Postgres, as the runtime login, under the table's policy."""

from collections.abc import Awaitable, Callable

import pytest

from acme.om.storage.impl.postgres import StoragePostgresImpl
from acme.om.storage.root import StorageInterface
from contracts.journalist_storage import CASES

pytestmark = pytest.mark.integration


@pytest.mark.parametrize("case", CASES, ids=lambda c: c.__name__.removeprefix("case_"))
async def test_contract(case: Callable[[StorageInterface], Awaitable[None]], pg_storage: StoragePostgresImpl) -> None:
    await case(pg_storage)
