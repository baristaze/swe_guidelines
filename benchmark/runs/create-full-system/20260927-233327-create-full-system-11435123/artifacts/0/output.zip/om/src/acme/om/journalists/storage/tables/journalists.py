"""The desk's journalist profiles, in the core role, fenced by the tenant."""

from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, IdentifiableMixin, SoftDeletableMixin, TrackableMixin


class Journalists(IdentifiableMixin, TrackableMixin, SoftDeletableMixin, Base):
    __tablename__ = "journalists"

    display_name: Mapped[str]
