"""The journalists manager: the swimlane of the profiles a desk presents to its readers."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.journalists.types.journalist import Journalist
from acme.om.opcontext import OpContext


class JournalistsManagerInterface(ABC):
    @abstractmethod
    async def get_journalists(self, ctx: OpContext, limit: int) -> list[Journalist]: ...

    @abstractmethod
    async def get_journalist(self, ctx: OpContext, journalist_id: UUID) -> Journalist:
        """Raises NotFound for an id the tenant does not hold, or a deleted profile."""
        ...

    @abstractmethod
    async def create_journalist(self, ctx: OpContext, journalist: Journalist) -> Journalist:
        """A rerun under the same id returns the profile as stored."""
        ...

    @abstractmethod
    async def update_journalist(self, ctx: OpContext, journalist: Journalist) -> Journalist:
        """Copies onto the stored row: who made it, and whether it is deleted, stay as stored."""
        ...

    @abstractmethod
    async def delete_journalist(self, ctx: OpContext, journalist_id: UUID) -> None:
        """A soft delete; the row stays readable by id to the storage, and leaves every list."""
        ...
