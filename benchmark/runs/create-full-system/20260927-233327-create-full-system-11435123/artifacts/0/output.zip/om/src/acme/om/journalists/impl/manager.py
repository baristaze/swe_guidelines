"""The journalists manager impl: authorize, verify, copy, write with the outbox row, relay at once."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.base import PROVENANCE_FIELDS, utcnow
from acme.om.exceptions import Conflict, NotFound
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.journalists.storage import JournalistsStorageInterface
from acme.om.journalists.types.journalist import Journalist
from acme.om.opcontext import OpContext, Permission
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, outbox_row


@dataclass(frozen=True)
class JournalistsOptions:
    page_size: int  # the most one list answers


class JournalistsManagerImpl(JournalistsManagerInterface):
    def __init__(
        self, storage: JournalistsStorageInterface, relay: OutboxRelayInterface, options: JournalistsOptions
    ) -> None:
        self._storage = storage
        self._relay = relay
        self._options = options

    async def get_journalists(self, ctx: OpContext, limit: int) -> list[Journalist]:
        ctx.require(Permission.READ)
        return await self._storage.read_journalists(ctx.org_id, max(1, min(limit, self._options.page_size)))

    async def get_journalist(self, ctx: OpContext, journalist_id: UUID) -> Journalist:
        ctx.require(Permission.READ)
        found = await self._storage.read_journalist(ctx.org_id, journalist_id)
        if found is None or found.deleted_at is not None:
            raise NotFound("no such journalist")
        return found

    async def create_journalist(self, ctx: OpContext, journalist: Journalist) -> Journalist:
        ctx.require(Permission.WRITE)
        copy = journalist.model_copy(
            update={
                "created_by": ctx.user_id,
                "updated_by": ctx.user_id,
                "deleted_at": None,
                "deleted_by": None,
            }
        )
        rows = (outbox_row(ctx, "journalists.journalist.created", copy.id, {}),)
        if not await self._storage.create_journalist(ctx.org_id, copy, rows):
            stored = await self._storage.read_journalist(ctx.org_id, copy.id)
            if stored is None:
                raise Conflict("that journalist id is taken")
            return stored
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def update_journalist(self, ctx: OpContext, journalist: Journalist) -> Journalist:
        ctx.require(Permission.WRITE)
        current = await self.get_journalist(ctx, journalist.id)
        copy = Journalist.model_validate(
            {
                **current.model_dump(),
                **journalist.model_dump(exclude=set(PROVENANCE_FIELDS) | set(Journalist.MANAGER_OWNED_FIELDS)),
                "updated_at": utcnow(),
                "updated_by": ctx.user_id,
            }
        )
        rows = (outbox_row(ctx, "journalists.journalist.updated", copy.id, {}),)
        await self._storage.write_journalist(ctx.org_id, copy, rows)
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def delete_journalist(self, ctx: OpContext, journalist_id: UUID) -> None:
        ctx.require(Permission.WRITE)
        current = await self.get_journalist(ctx, journalist_id)
        now = utcnow()
        copy = current.model_copy(
            update={"deleted_at": now, "deleted_by": ctx.user_id, "updated_at": now, "updated_by": ctx.user_id}
        )
        rows = (outbox_row(ctx, "journalists.journalist.deleted", copy.id, {}),)
        await self._storage.write_journalist(ctx.org_id, copy, rows)
        await self._relay_all(ctx.org_id, rows)

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; the write has committed, a failure is the sweep's
