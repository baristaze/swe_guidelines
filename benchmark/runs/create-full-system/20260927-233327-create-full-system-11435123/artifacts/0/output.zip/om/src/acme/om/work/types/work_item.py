"""The work item: durable background work as a row, carrying the producer's key and recording its own claim."""

from datetime import datetime
from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from pydantic import Field

from acme.om.base import FrozenMapping, Identifiable, Platform, Trackable


class WorkKind(StrEnum):
    NOOP = "NOOP"  # the maintenance worker's placeholder kind; its handler does nothing, idempotently


class WorkStatus(StrEnum):
    QUEUED = "queued"
    CLAIMED = "claimed"
    DONE = "done"
    FAILED = "failed"


class WorkItem(Identifiable, Trackable):
    """`created_by` is the person who asked for the work; `updated_by` is the machinery that ran it (EMPTY_UUID)."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = (
        "status",
        "available_at",
        "claimed_by",
        "claim_token",
        "lease_expires_at",
        "attempts",
        "last_error",
    )

    kind: WorkKind  # what to do
    target_id: UUID  # the record it advances
    idempotency_key: UUID  # unique per tenant
    request_id: UUID  # the request that caused the work
    traceparent: str | None = None  # the trace context of that request, for a link
    payload: FrozenMapping = Field(default_factory=dict, validate_default=True)
    lane: str = "default"  # routing: "default", "region:<id>", ...
    status: WorkStatus = WorkStatus.QUEUED
    available_at: datetime  # not before
    claimed_by: str | None = None  # the worker's name, for an operator; never a fence
    claim_token: UUID | None = None  # the fence every write to the row conditions on
    lease_expires_at: datetime | None = None
    attempts: int = 0
    max_attempts: int = 3
    last_error: str | None = None


class NoopPayload(Platform):
    """The NOOP kind carries nothing."""


WORK_PAYLOADS: dict[WorkKind, type[Platform]] = {
    WorkKind.NOOP: NoopPayload,
}


class WorkGauges(Platform):
    oldest_waiting_at: datetime | None
    failed: int
