"""The tenancy manager over the memory root: every transition, and one refusal per rule it states."""

from datetime import timedelta

import pytest
from conftest import rctx
from flows import operator_ctx, signed_up, tenant_ctx

from acme.infra.topics import SESSION_REVOKED, EntityChangedPayload, TopicPayload, Topics
from acme.om.base import new_id
from acme.om.exceptions import (
    Conflict,
    NotAuthenticated,
    NotAuthorized,
    NotFound,
    SecondFactorRequired,
    TooManyRequests,
    ValidationFailed,
)
from acme.om.opcontext import CredentialKind, OperatorPermission, Permission, Role
from acme.om.root import Managers
from acme.om.tenancy import rules
from acme.om.tenancy.impl.credentials import TotpCipher
from acme.om.tenancy.types import MarkerGuard


async def test_sign_up_answers_as_a_sign_in(managers: Managers) -> None:
    signed = await signed_up(managers)
    assert signed.identity.credential_kind == CredentialKind.PASSWORD
    assert [c.role for c in signed.memberships] == [Role.OWNER]


async def test_sign_up_refuses_a_held_email_and_a_held_slug(managers: Managers) -> None:
    await signed_up(managers)
    with pytest.raises(Conflict):
        await signed_up(managers, slug="other")
    with pytest.raises(Conflict):
        await signed_up(managers, email="other@acme.example")


async def test_a_closed_sign_up_answers_not_found(storage, infra) -> None:  # type: ignore[no-untyped-def]
    from dataclasses import replace

    from conftest import manager_options

    from acme.om.root import build_managers

    options = manager_options()
    closed = build_managers(storage, infra, replace(options, tenancy=replace(options.tenancy, signup_enabled=False)))
    with pytest.raises(NotFound):
        await signed_up(closed)


async def test_sign_in_delays_an_email_after_a_failure(managers: Managers) -> None:
    await signed_up(managers)
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.sign_in(rctx(), "owner@acme.example", "wrong", None)
    with pytest.raises(TooManyRequests):
        await managers.tenancy.sign_in(rctx(), "owner@acme.example", "pswd_1234", None)


async def test_an_unknown_email_is_delayed_like_a_known_one(managers: Managers) -> None:
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.sign_in(rctx(), "nobody@acme.example", "x", None)
    with pytest.raises(TooManyRequests):
        await managers.tenancy.sign_in(rctx(), "nobody@acme.example", "x", None)


async def test_exchange_authenticate_and_switch(managers: Managers) -> None:
    ctx, session = await tenant_ctx(managers)
    assert ctx.security.role == Role.OWNER and ctx.has(Permission.MANAGE_MEMBERS)
    login = await managers.tenancy.authenticate_login(rctx(), session.token)
    assert login.credential_kind == CredentialKind.TENANT_SESSION
    await managers.tenancy.exchange(login, ctx.org_id)  # a switch presented with a session ends it
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.authenticate(rctx(), session.token)


async def test_exchange_refuses_an_org_without_a_membership(managers: Managers) -> None:
    signed = await signed_up(managers)
    login = await managers.tenancy.authenticate_login(rctx(), signed.credential.token)
    with pytest.raises(NotFound):
        await managers.tenancy.exchange(login, new_id())


async def test_sign_out_ends_the_credential_and_announces_it(managers: Managers, infra) -> None:  # type: ignore[no-untyped-def]
    heard: list[TopicPayload] = []

    async def listen(p: TopicPayload) -> None:
        heard.append(p)

    infra.get_topics().subscribe(Topics.ENTITY_CHANGED, "test", listen)
    _, session = await tenant_ctx(managers)
    login = await managers.tenancy.authenticate_login(rctx(), session.token)
    await managers.tenancy.sign_out(login)
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.authenticate(rctx(), session.token)
    revoked = [p for p in heard if isinstance(p, EntityChangedPayload) and p.kind == SESSION_REVOKED]
    assert [p.target_id for p in revoked] == [session.credential_id]


async def test_an_api_key_is_capped_at_its_issuers_current_role(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    issued = await managers.tenancy.create_api_key(owner, new_id(), "ci", Role.ADMIN, timedelta(days=1), None)
    key_ctx = await managers.tenancy.authenticate(rctx(), issued.token)
    assert key_ctx.security.role == Role.ADMIN
    with pytest.raises(NotAuthorized):  # a key never carries the service role
        await managers.tenancy.create_api_key(owner, new_id(), "x", Role.SERVICE, timedelta(days=1), None)
    with pytest.raises(ValidationFailed):  # expires_in is capped
        await managers.tenancy.create_api_key(owner, new_id(), "x", Role.VIEWER, timedelta(days=3650), None)


async def test_a_key_above_the_issuer_is_refused(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    issued = await managers.tenancy.create_api_key(owner, new_id(), "ci", Role.ADMIN, timedelta(days=1), None)
    admin_ctx = await managers.tenancy.authenticate(rctx(), issued.token)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.create_api_key(admin_ctx, new_id(), "up", Role.OWNER, timedelta(days=1), None)


async def test_a_rerun_re_mints_the_secret_under_the_marker(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    outcome = await managers.idempotency.begin(owner, "key-1", "digest")
    marker = outcome.marker
    assert marker.attempt_token is not None
    guard = MarkerGuard(marker_id=marker.id, attempt_token=marker.attempt_token)
    first = await managers.tenancy.create_api_key(owner, marker.target_id, "ci", Role.MEMBER, timedelta(days=1), guard)
    rerun = await managers.tenancy.create_api_key(owner, marker.target_id, "ci", Role.MEMBER, timedelta(days=1), guard)
    assert rerun.api_key.id == first.api_key.id and rerun.token != first.token
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.authenticate(rctx(), first.token)
    assert (await managers.tenancy.authenticate(rctx(), rerun.token)).credential_id == first.api_key.id


async def test_removing_a_member_revokes_their_keys(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    org_id = owner.org_id
    octx = await operator_ctx(managers, OperatorPermission.WRITE)
    added = await managers.tenancy.add_member(
        octx, org_id, new_id(), "admin@acme.example", "Admin", Role.ADMIN, "pswd_admin"
    )
    signed = await managers.tenancy.sign_in(rctx(), "admin@acme.example", "pswd_admin", None)
    login = await managers.tenancy.authenticate_login(rctx(), signed.credential.token)
    admin_ctx = await managers.tenancy.authenticate(rctx(), (await managers.tenancy.exchange(login, org_id)).token)
    key = await managers.tenancy.create_api_key(admin_ctx, new_id(), "k", Role.MEMBER, timedelta(days=1), None)
    await managers.tenancy.remove_member(owner, added.user_id)
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.authenticate(rctx(), key.token)


async def test_a_viewer_cannot_manage_members(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    key = await managers.tenancy.create_api_key(owner, new_id(), "v", Role.VIEWER, timedelta(days=1), None)
    viewer = await managers.tenancy.authenticate(rctx(), key.token)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.update_member_role(viewer, owner.user_id, Role.VIEWER)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.remove_member(viewer, owner.user_id)


async def test_socket_ticket_redeems_once_and_rechecks(managers: Managers) -> None:
    ctx, session = await tenant_ctx(managers)
    ticket = await managers.tenancy.issue_socket_ticket(ctx)
    grant = await managers.tenancy.redeem_socket_ticket(rctx(), ticket.token)
    assert grant.ctx.org_id == ctx.org_id
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.redeem_socket_ticket(rctx(), ticket.token)
    await managers.tenancy.recheck_session(grant.ctx)
    login = await managers.tenancy.authenticate_login(rctx(), session.token)
    await managers.tenancy.sign_out(login)
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.recheck_session(grant.ctx)


async def test_the_operator_plane_refuses_a_tenant_session(managers: Managers) -> None:
    _, session = await tenant_ctx(managers)
    login = await managers.tenancy.authenticate_login(rctx(), session.token)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.admit_operator(login)


async def test_a_password_alone_admits_only_enrolment(managers: Managers) -> None:
    await managers.tenancy.ensure_identity(rctx(), "op@acme.example", "pswd_operator", "Operator")
    await managers.tenancy.grant_operator(rctx(), "op@acme.example", OperatorPermission.READ)
    signed = await managers.tenancy.sign_in(rctx(), "op@acme.example", "pswd_operator", None)
    octx = await managers.tenancy.admit_operator(signed.identity)
    assert octx.permissions == (OperatorPermission.ENROL,)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.get_orgs(octx, 10)


async def test_totp_enrolment_then_a_second_factor_admits(managers: Managers) -> None:
    await managers.tenancy.ensure_identity(rctx(), "op@acme.example", "pswd_operator", "Operator")
    await managers.tenancy.grant_operator(rctx(), "op@acme.example", OperatorPermission.READ)
    signed = await managers.tenancy.sign_in(rctx(), "op@acme.example", "pswd_operator", None)
    enrolling = await managers.tenancy.admit_operator(signed.identity)
    await managers.tenancy.enrol_totp(enrolling)
    identity = await managers_storage_identity(managers, enrolling.identity_id)
    secret = TotpCipher(managers_totp_key(managers)).decrypt(identity.totp_secret or "")
    assert secret is not None
    import time

    code = rules.totp_code(secret, rules.totp_step(time.time()))
    await managers.tenancy.confirm_totp(enrolling, code)
    # A password alone no longer admits once a factor is enrolled.
    with pytest.raises(SecondFactorRequired):
        await managers.tenancy.admit_operator(
            (await managers.tenancy.sign_in(rctx(), "op@acme.example", "pswd_operator", None)).identity
        )
    # A code already used is refused, even inside its time step.
    with pytest.raises(NotAuthenticated):
        await managers.tenancy.sign_in(rctx(), "op@acme.example", "pswd_operator", code)


def managers_totp_key(m: Managers) -> str:
    return m.tenancy._options.totp_encryption_key  # type: ignore[attr-defined]


async def managers_storage_identity(m: Managers, identity_id):  # type: ignore[no-untyped-def]
    found = await m.tenancy._storage.read_identity(identity_id)  # type: ignore[attr-defined]
    assert found is not None
    return found


async def test_a_read_operator_cannot_provision(managers: Managers) -> None:
    octx = await operator_ctx(managers, OperatorPermission.READ)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.create_org(octx, new_id(), "Desk", "prov-desk")
    assert (await managers.tenancy.get_size(octx)).tenants == 0


async def test_a_token_never_mints_a_token(managers: Managers) -> None:
    octx = await operator_ctx(managers, OperatorPermission.WRITE)
    with pytest.raises(NotAuthorized):
        await managers.tenancy.issue_operator_token(octx, OperatorPermission.READ, None)


async def test_a_write_operator_provisions_a_tenant(managers: Managers) -> None:
    octx = await operator_ctx(managers, OperatorPermission.WRITE)
    org_id = new_id()
    org = await managers.tenancy.create_org(octx, org_id, "Traffic Desk", "traffic-desk")
    assert (await managers.tenancy.create_org(octx, org_id, "Traffic Desk", "traffic-desk")) == org  # a retry
    member = await managers.tenancy.add_member(octx, org_id, new_id(), "p@acme.example", "P", Role.MEMBER, "pswd_p")
    assert [m.user_id for m in await managers.tenancy.get_members_for_operator(octx, org_id, 10)] == [member.user_id]
    await managers.tenancy.delete_org(octx, org_id)
    assert (await managers.tenancy.get_org_for_operator(octx, org_id)).deleted_at is not None


async def test_service_contexts_page_live_tenants(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    contexts = await managers.tenancy.service_contexts(rctx(), None, 10)
    assert [c.org_id for c in contexts] == [owner.org_id]
    assert contexts[0].security.role == Role.SERVICE
