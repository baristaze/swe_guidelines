"""Flows the manager tests share: a signed-up tenant's context, and an admitted operator's."""

from conftest import rctx

from acme.om.base import new_id
from acme.om.opcontext import OpContext, OperatorContext, OperatorPermission
from acme.om.root import Managers
from acme.om.tenancy.types import IssuedCredential, SignedIn


async def signed_up(m: Managers, email: str = "owner@acme.example", slug: str = "desk") -> SignedIn:
    return await m.tenancy.sign_up(rctx(), email, "pswd_1234", "Owner", "Desk", slug)


async def tenant_ctx(
    m: Managers, email: str = "owner@acme.example", slug: str = "desk"
) -> tuple[OpContext, IssuedCredential]:
    signed = await signed_up(m, email, slug)
    login = await m.tenancy.authenticate_login(rctx(), signed.credential.token)
    session = await m.tenancy.exchange(login, signed.memberships[0].org_id)
    return await m.tenancy.authenticate(rctx(), session.token), session


async def operator_ctx(m: Managers, permission: OperatorPermission) -> OperatorContext:
    email = f"op-{new_id().hex[:8]}@acme.example"
    await m.tenancy.ensure_identity(rctx(), email, "pswd_operator", "Operator")
    await m.tenancy.grant_operator(rctx(), email, permission)
    token = await m.tenancy.grant_operator_token(rctx(), email, None)
    return await m.tenancy.admit_operator(await m.tenancy.authenticate_login(rctx(), token.token))
