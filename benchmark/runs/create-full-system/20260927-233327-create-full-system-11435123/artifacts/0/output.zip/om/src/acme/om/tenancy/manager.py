"""The tenancy manager: the transitions that produce every stage, and the operations on tenants and credentials."""

from abc import ABC, abstractmethod
from datetime import timedelta
from uuid import UUID

from acme.om.opcontext import IdentityContext, OpContext, OperatorContext, OperatorPermission, RequestContext, Role
from acme.om.tenancy.types import (
    ApiKey,
    IssuedApiKey,
    IssuedCredential,
    MarkerGuard,
    Member,
    Membership,
    MembershipChoice,
    OperatorEntry,
    Org,
    PlatformSize,
    SignedIn,
    SocketGrant,
    TotpEnrolment,
    User,
)


class TenancyManagerInterface(ABC):
    # --- the request stage: transitions and bookkeeping with no principal

    @abstractmethod
    async def sign_up(
        self, rctx: RequestContext, email: str, password: str, display_name: str, org_name: str, org_slug: str
    ) -> SignedIn: ...

    @abstractmethod
    async def sign_in(self, rctx: RequestContext, email: str, password: str, totp_code: str | None) -> SignedIn: ...

    @abstractmethod
    async def sign_in_external(
        self, rctx: RequestContext, issuer: str, subject: str, email: str, display_name: str
    ) -> SignedIn:
        """The external identity provider's sign-in: finds or creates the identity keyed on issuer and subject."""
        ...

    @abstractmethod
    async def authenticate(self, rctx: RequestContext, bearer: str) -> OpContext: ...

    @abstractmethod
    async def authenticate_internal(
        self, rctx: RequestContext, org_id: UUID, user_id: UUID, credential_id: UUID
    ) -> OpContext:
        """Rebuilds the context a peer service's verified internal credential names; the role is read here."""
        ...

    @abstractmethod
    async def authenticate_login(self, rctx: RequestContext, bearer: str) -> IdentityContext: ...

    @abstractmethod
    async def redeem_socket_ticket(self, rctx: RequestContext, ticket: str) -> SocketGrant: ...

    @abstractmethod
    async def bootstrap(
        self, rctx: RequestContext, org_name: str, org_slug: str, owner_email: str, owner_password: str, owner_name: str
    ) -> OpContext:
        """Seeds a first org and its owner, idempotently; answers the owner's context."""
        ...

    @abstractmethod
    async def ensure_identity(self, rctx: RequestContext, email: str, password: str, display_name: str) -> UUID:
        """Seeds an identity with no tenant, idempotently, for an operator the seed or the grant job names."""
        ...

    @abstractmethod
    async def grant_operator(
        self, rctx: RequestContext, email: str, permission: OperatorPermission
    ) -> OperatorEntry: ...

    @abstractmethod
    async def disable_operator(self, rctx: RequestContext, email: str) -> OperatorEntry: ...

    @abstractmethod
    async def grant_operator_token(
        self, rctx: RequestContext, email: str, expires_in: timedelta | None
    ) -> IssuedCredential: ...

    @abstractmethod
    async def service_contexts(self, rctx: RequestContext, after: UUID | None, limit: int) -> list[OpContext]:
        """One service context per live tenant, a page at a time, for a sweep that acts inside tenants."""
        ...

    @abstractmethod
    async def claim_context(
        self, rctx: RequestContext, org_id: UUID, user_id: UUID, caused_by_request_id: UUID
    ) -> OpContext:
        """The context a claimed work item runs under: the enqueuer under the service role, or the tenant's service
        context; NotFound when the tenant is gone."""
        ...

    @abstractmethod
    async def purge_socket_tickets(self, rctx: RequestContext) -> int: ...

    @abstractmethod
    async def purge_sessions(self, rctx: RequestContext) -> int: ...

    # --- the identity stage

    @abstractmethod
    async def get_memberships(self, ictx: IdentityContext, limit: int) -> list[MembershipChoice]: ...

    @abstractmethod
    async def exchange(self, ictx: IdentityContext, org_id: UUID) -> IssuedCredential: ...

    @abstractmethod
    async def sign_out(self, ictx: IdentityContext) -> None: ...

    @abstractmethod
    async def admit_operator(self, ictx: IdentityContext) -> OperatorContext: ...

    # --- tenant operations

    @abstractmethod
    async def issue_socket_ticket(self, ctx: OpContext) -> IssuedCredential: ...

    @abstractmethod
    async def recheck_session(self, ctx: OpContext) -> None:
        """Raises NotAuthenticated once the session or the membership behind ctx has ended or its role moved."""
        ...

    @abstractmethod
    async def get_org(self, ctx: OpContext) -> Org: ...

    @abstractmethod
    async def get_members(self, ctx: OpContext, limit: int) -> list[Member]: ...

    @abstractmethod
    async def get_user(self, ctx: OpContext, user_id: UUID) -> User: ...

    @abstractmethod
    async def update_user(self, ctx: OpContext, user: User) -> User: ...

    @abstractmethod
    async def update_member_role(self, ctx: OpContext, user_id: UUID, role: Role) -> Membership: ...

    @abstractmethod
    async def remove_member(self, ctx: OpContext, user_id: UUID) -> None: ...

    @abstractmethod
    async def create_api_key(
        self, ctx: OpContext, key_id: UUID, name: str, role: Role, expires_in: timedelta, guard: MarkerGuard | None
    ) -> IssuedApiKey: ...

    @abstractmethod
    async def get_api_keys(self, ctx: OpContext, limit: int) -> list[ApiKey]: ...

    @abstractmethod
    async def revoke_api_key(self, ctx: OpContext, key_id: UUID) -> None: ...

    @abstractmethod
    async def revoke_session(self, ctx: OpContext, session_id: UUID) -> None: ...

    # --- the operator plane: the tenant is a parameter, never a context

    @abstractmethod
    async def get_operator(self, octx: OperatorContext) -> OperatorEntry: ...

    @abstractmethod
    async def get_size(self, octx: OperatorContext) -> PlatformSize: ...

    @abstractmethod
    async def get_orgs(self, octx: OperatorContext, limit: int) -> list[Org]: ...

    @abstractmethod
    async def get_org_for_operator(self, octx: OperatorContext, org_id: UUID) -> Org: ...

    @abstractmethod
    async def get_members_for_operator(self, octx: OperatorContext, org_id: UUID, limit: int) -> list[Member]: ...

    @abstractmethod
    async def create_org(self, octx: OperatorContext, org_id: UUID, name: str, slug: str) -> Org: ...

    @abstractmethod
    async def add_member(
        self,
        octx: OperatorContext,
        org_id: UUID,
        user_id: UUID,
        email: str,
        display_name: str,
        role: Role,
        password: str | None,
    ) -> Member: ...

    @abstractmethod
    async def delete_org(self, octx: OperatorContext, org_id: UUID) -> None: ...

    @abstractmethod
    async def enrol_totp(self, octx: OperatorContext) -> TotpEnrolment: ...

    @abstractmethod
    async def confirm_totp(self, octx: OperatorContext, totp_code: str) -> None: ...

    @abstractmethod
    async def issue_operator_token(
        self, octx: OperatorContext, permission: OperatorPermission, expires_in: timedelta | None
    ) -> IssuedCredential: ...
