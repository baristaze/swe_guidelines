"""The storage root in memory: the twin of the Postgres root, for unit tests and the fast gate."""

from acme.om.audit.storage import AuditStorageInterface
from acme.om.audit.storage.impl.memory import AuditStorageMemoryImpl
from acme.om.events.storage import EventsStorageInterface
from acme.om.events.storage.impl.memory import EventsStorageMemoryImpl
from acme.om.idempotency.storage import IdempotencyStorageInterface
from acme.om.idempotency.storage.impl.memory import IdempotencyStorageMemoryImpl
from acme.om.journalists.storage import JournalistsStorageInterface
from acme.om.journalists.storage.impl.memory import JournalistsStorageMemoryImpl
from acme.om.outbox.storage import OutboxStorageInterface
from acme.om.outbox.storage.impl.memory import OutboxStorageMemoryImpl
from acme.om.storage.impl.memory_base import MemoryOutboxLedger
from acme.om.storage.root import StorageInterface
from acme.om.tenancy.storage import TenancyStorageInterface
from acme.om.tenancy.storage.impl.memory import TenancyStorageMemoryImpl
from acme.om.work.storage import WorkStorageInterface
from acme.om.work.storage.impl.memory import WorkStorageMemoryImpl


class StorageMemoryImpl(StorageInterface):
    def __init__(self) -> None:
        ledger = MemoryOutboxLedger()
        self._idempotency: IdempotencyStorageInterface = IdempotencyStorageMemoryImpl(ledger)
        self._tenancy: TenancyStorageInterface = TenancyStorageMemoryImpl(ledger, self._idempotency)
        self._events: EventsStorageInterface = EventsStorageMemoryImpl(ledger)
        self._audit: AuditStorageInterface = AuditStorageMemoryImpl(ledger)
        self._outbox: OutboxStorageInterface = OutboxStorageMemoryImpl(ledger)
        self._work: WorkStorageInterface = WorkStorageMemoryImpl(ledger)
        self._journalists: JournalistsStorageInterface = JournalistsStorageMemoryImpl(ledger)

    def get_tenancy_storage(self) -> TenancyStorageInterface:
        return self._tenancy

    def get_events_storage(self) -> EventsStorageInterface:
        return self._events

    def get_audit_storage(self) -> AuditStorageInterface:
        return self._audit

    def get_outbox_storage(self) -> OutboxStorageInterface:
        return self._outbox

    def get_idempotency_storage(self) -> IdempotencyStorageInterface:
        return self._idempotency

    def get_work_storage(self) -> WorkStorageInterface:
        return self._work

    def get_journalist_storage(self) -> JournalistsStorageInterface:
        return self._journalists

    def describe(self) -> str:
        return "storage: in-process memory"

    async def healthcheck(self) -> bool:
        return True

    async def close(self) -> None:
        return None
