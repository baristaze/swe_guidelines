"""The relay: a failure never answers the write as failed, a refused publish stays pending, a rerun leaves one event."""

from uuid import UUID

from conftest import rctx
from flows import tenant_ctx

from acme.infra.topics import TopicPayload, Topics
from acme.infra.topics.memory import TopicsMemoryImpl
from acme.om.events.manager import EventsManagerInterface
from acme.om.outbox.types import OutboxRow
from acme.om.root import Managers
from contracts import factories as f


async def landed_row(managers: Managers, storage) -> OutboxRow:  # type: ignore[no-untyped-def]
    t = await f.tenant(storage)
    row = f.row(t.org_id, "tenancy.user.updated", t.user.id)
    await storage.get_tenancy_storage().write_user(t.org_id, t.user, (row,))
    return row


async def test_a_relayed_row_appends_one_event_and_publishes(managers: Managers, storage, infra) -> None:  # type: ignore[no-untyped-def]
    heard: list[TopicPayload] = []

    async def listen(p: TopicPayload) -> None:
        heard.append(p)

    infra.get_topics().subscribe(Topics.ENTITY_CHANGED, "test", listen)
    row = await landed_row(managers, storage)
    assert await managers.relay.relay(row.org_id, row)
    assert (await storage.get_outbox_storage().read_row(row.org_id, row.id)).done_at is not None
    assert len(heard) == 1
    assert (await storage.get_events_storage().read_head(row.org_id)) == 1


async def test_a_refused_publish_leaves_the_row_pending(managers: Managers, storage, infra) -> None:  # type: ignore[no-untyped-def]
    topics = infra.get_topics()
    assert isinstance(topics, TopicsMemoryImpl)
    topics.accepting = False
    row = await landed_row(managers, storage)
    assert not await managers.relay.relay(row.org_id, row)
    assert (await storage.get_outbox_storage().read_row(row.org_id, row.id)).done_at is None
    topics.accepting = True
    assert await managers.relay.relay_pending(rctx(), 100) >= 1
    assert (await storage.get_outbox_storage().read_row(row.org_id, row.id)).done_at is not None
    assert (await storage.get_events_storage().read_head(row.org_id)) == 1  # the rerun left one event


class FailingEvents(EventsManagerInterface):
    async def append_relayed(self, org_id: UUID, row: OutboxRow):  # type: ignore[no-untyped-def]
        raise RuntimeError("activity is down")

    async def get_events(self, ctx, after_seq, limit):  # type: ignore[no-untyped-def]
        return []

    async def get_head(self, ctx):  # type: ignore[no-untyped-def]
        return 0

    async def count_events_for_operator(self, octx, since):  # type: ignore[no-untyped-def]
        return 0

    async def get_events_for_operator(self, octx, org_id, after_seq, limit):  # type: ignore[no-untyped-def]
        return []


async def test_a_failed_append_never_raises_and_leaves_the_row(storage, infra) -> None:  # type: ignore[no-untyped-def]
    from conftest import manager_options

    from acme.om.outbox.impl.manager import OutboxRelayImpl

    relay = OutboxRelayImpl(
        storage.get_outbox_storage(),
        FailingEvents(),
        infra.get_topics(),
        manager_options().outbox,
        lambda: None,  # type: ignore[arg-type,return-value]
    )
    t = await f.tenant(storage)
    row = f.row(t.org_id)
    await storage.get_tenancy_storage().write_user(t.org_id, t.user, (row,))
    assert not await relay.relay(row.org_id, row)
    assert (await storage.get_outbox_storage().read_row(row.org_id, row.id)).done_at is None


async def test_a_manager_write_answers_even_when_its_relay_fails(managers: Managers, storage, infra) -> None:  # type: ignore[no-untyped-def]
    topics = infra.get_topics()
    topics.accepting = False
    ctx, _ = await tenant_ctx(managers)
    user = await managers.tenancy.get_user(ctx, ctx.user_id)
    renamed = await managers.tenancy.update_user(ctx, user.model_copy(update={"name": "Renamed"}))
    assert renamed.name == "Renamed"
    assert await storage.get_outbox_storage().read_pending(100)


async def test_the_lag_reads_the_oldest_pending_row(managers: Managers, storage, infra) -> None:  # type: ignore[no-untyped-def]
    infra.get_topics().accepting = False
    await landed_row(managers, storage)
    assert (await managers.relay.read_lag(rctx())).total_seconds() >= 0
