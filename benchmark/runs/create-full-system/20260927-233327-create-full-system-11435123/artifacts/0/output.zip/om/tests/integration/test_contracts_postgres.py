"""The storage contract cases over Postgres, as the runtime and system logins, under the database policies."""

from collections.abc import Awaitable, Callable

import pytest

from acme.om.storage.impl.postgres import StoragePostgresImpl
from acme.om.storage.root import StorageInterface
from contracts.registry import ALL_CASES

pytestmark = pytest.mark.integration


@pytest.mark.parametrize("case", ALL_CASES, ids=lambda c: c.__name__.removeprefix("case_"))
async def test_contract(case: Callable[[StorageInterface], Awaitable[None]], pg_storage: StoragePostgresImpl) -> None:
    await case(pg_storage)
