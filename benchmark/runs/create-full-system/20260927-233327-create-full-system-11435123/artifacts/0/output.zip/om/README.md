# The Free Journalism object model

These are the nouns of the platform and how they relate. Everything else in the system, the services, the apps,
the tables, is built on them.

## Who is who

- A **person** is an **identity**: one per human, across the whole platform, with the address they sign in with.
  A person signs in with a password or through a hosted sign-in (an email code, or a Google, Apple, GitHub, or
  Microsoft account).
- A **desk** is where a journalist works: the journalist and anyone they bring in later. A desk is the platform's
  tenant: what belongs to one desk is never visible to another.
- A person inside a desk is a **user** of that desk, and their **membership** gives them a **role**: the **owner**
  (the journalist who opened the desk), an **admin**, a **member**, or a **viewer**. Each role can do everything the
  next one can, and more. One person can belong to several desks, and works in one at a time.
- A **reader** follows journalists and may support them; a **patron** supports one with money; a **source** sends a
  journalist information. These are things a person does, not roles in a desk, and a source may send information
  without ever having an identity at all.

## What a desk holds

- The desk's **journalist profiles**: the name readers see, and in time the bio, coverage areas, topics, links,
  and the verification badge. Most desks present one; a small team may present several.
- Its members and their **credentials**: the **sessions** of people signed in to it, and **keys** for programs that
  act for a member, which never carry a role above the member who issued them.
- Its **events**: a numbered record of every change, one per change, which is what keeps every open screen current.
- Its **audit trail**: who did what, when, from which app, including every time someone on the desk opens a
  sensitive report.

## The platform's own

- **Operators** run the platform. They are people on the operator **allowlist**, who read or also write across
  desks, always with a second factor, and whose every look inside a desk is recorded.
- An **operator token** is a short-lived credential an operator mints for a program (the traffic generator, the
  smoke test, a support agent), carrying one permission and lasting an hour at most.

## Where to read more

Each group of nouns has its own page, one level down:

- [Tenancy](src/acme/om/tenancy/README.md): desks, people, users, memberships, roles, sessions, keys, the operator
  allowlist.
- [Events](src/acme/om/events/README.md): the numbered record of changes behind every live update.
- [Audit](src/acme/om/audit/README.md): who did what, when, and from where.
- [Outbox](src/acme/om/outbox/README.md): the note every change leaves, so nothing it sets off is ever lost.
- [Idempotency](src/acme/om/idempotency/README.md): why doing the same request twice creates one thing.
- [Work](src/acme/om/work/README.md): the background work the platform owes, and how it is done exactly once.
- [Journalists](src/acme/om/journalists/README.md): the profiles a desk presents to its readers.
