"""The journalists manager over the memory root: every operation, its authorization, and the copy it writes."""

from datetime import timedelta

import pytest
from conftest import rctx
from flows import tenant_ctx

from acme.om.base import new_id, utcnow
from acme.om.exceptions import NotAuthorized, NotFound
from acme.om.journalists.types.journalist import Journalist
from acme.om.opcontext import OpContext, Role
from acme.om.root import Managers


def fresh(display_name: str = "Reporter") -> Journalist:
    now = utcnow()
    stranger = new_id()
    return Journalist(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=stranger,  # the manager stamps the actor over what the caller sent
        updated_by=stranger,
        display_name=display_name,
    )


async def viewer_of(managers: Managers, owner: OpContext) -> OpContext:
    key = await managers.tenancy.create_api_key(owner, new_id(), "viewer", Role.VIEWER, timedelta(days=1), None)
    return await managers.tenancy.authenticate(rctx(), key.token)


async def test_create_stamps_the_actor_and_announces_the_change(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    sent = fresh()
    made = await managers.journalists.create_journalist(ctx, sent)
    assert made.created_by == made.updated_by == ctx.user_id
    assert (made.created_at, made.updated_at, made.display_name) == (sent.created_at, sent.updated_at, "Reporter")
    events = await managers.events.get_events(ctx, 0, 100)
    change = next(e for e in events if e.kind == "journalists.journalist.created")
    assert change.target_id == made.id and change.actor_id == ctx.user_id


async def test_a_rerun_of_create_returns_the_row_as_stored(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    sent = fresh()
    made = await managers.journalists.create_journalist(ctx, sent)
    again = await managers.journalists.create_journalist(ctx, sent.model_copy(update={"display_name": "Other"}))
    assert again == made
    kinds = [e.kind for e in await managers.events.get_events(ctx, 0, 100)]
    assert kinds.count("journalists.journalist.created") == 1


async def test_list_and_get(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    a = await managers.journalists.create_journalist(ctx, fresh("A"))
    b = await managers.journalists.create_journalist(ctx, fresh("B"))
    assert await managers.journalists.get_journalists(ctx, 10) == [a, b]
    assert await managers.journalists.get_journalists(ctx, 1) == [a]
    assert await managers.journalists.get_journalist(ctx, b.id) == b
    with pytest.raises(NotFound):
        await managers.journalists.get_journalist(ctx, new_id())


async def test_another_tenant_sees_nothing(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    other, _ = await tenant_ctx(managers, "other@acme.example", "other-desk")
    made = await managers.journalists.create_journalist(ctx, fresh())
    assert await managers.journalists.get_journalists(other, 10) == []
    with pytest.raises(NotFound):
        await managers.journalists.get_journalist(other, made.id)
    with pytest.raises(NotFound):
        await managers.journalists.update_journalist(other, made.model_copy(update={"display_name": "X"}))
    with pytest.raises(NotFound):
        await managers.journalists.delete_journalist(other, made.id)
    assert await managers.journalists.get_journalist(ctx, made.id) == made


async def test_update_keeps_provenance_and_deletion_as_stored(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    made = await managers.journalists.create_journalist(ctx, fresh())
    sent = made.model_copy(
        update={
            "display_name": "Renamed",
            "created_by": new_id(),
            "created_at": utcnow() - timedelta(days=30),
            "deleted_at": utcnow(),
            "deleted_by": new_id(),
        }
    )
    updated = await managers.journalists.update_journalist(ctx, sent)
    assert updated.display_name == "Renamed"
    assert (updated.created_by, updated.created_at) == (made.created_by, made.created_at)
    assert (updated.deleted_at, updated.deleted_by) == (None, None)
    assert updated.updated_by == ctx.user_id and updated.updated_at >= made.updated_at
    assert await managers.journalists.get_journalist(ctx, made.id) == updated


def test_the_manager_owns_no_field() -> None:
    # Every field of the profile is the caller's to write; the update test above covers provenance.
    assert Journalist.MANAGER_OWNED_FIELDS == ()


async def test_delete_hides_the_profile_and_a_second_delete_is_not_found(managers: Managers) -> None:
    ctx, _ = await tenant_ctx(managers)
    made = await managers.journalists.create_journalist(ctx, fresh())
    await managers.journalists.delete_journalist(ctx, made.id)
    assert await managers.journalists.get_journalists(ctx, 10) == []
    with pytest.raises(NotFound):
        await managers.journalists.get_journalist(ctx, made.id)
    with pytest.raises(NotFound):
        await managers.journalists.delete_journalist(ctx, made.id)
    with pytest.raises(NotFound):
        await managers.journalists.update_journalist(ctx, made)
    kinds = [e.kind for e in await managers.events.get_events(ctx, 0, 100)]
    assert "journalists.journalist.deleted" in kinds


async def test_a_viewer_reads_and_never_writes(managers: Managers) -> None:
    owner, _ = await tenant_ctx(managers)
    made = await managers.journalists.create_journalist(owner, fresh())
    viewer = await viewer_of(managers, owner)
    assert await managers.journalists.get_journalists(viewer, 10) == [made]
    with pytest.raises(NotAuthorized):
        await managers.journalists.create_journalist(viewer, fresh())
    with pytest.raises(NotAuthorized):
        await managers.journalists.update_journalist(viewer, made.model_copy(update={"display_name": "X"}))
    with pytest.raises(NotAuthorized):
        await managers.journalists.delete_journalist(viewer, made.id)
