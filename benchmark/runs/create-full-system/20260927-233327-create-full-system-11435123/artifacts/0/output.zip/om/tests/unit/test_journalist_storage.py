"""The journalists storage contract over the memory root."""

from collections.abc import Awaitable, Callable

import pytest

from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.storage.root import StorageInterface
from contracts.journalist_storage import CASES


@pytest.mark.parametrize("case", CASES, ids=lambda c: c.__name__.removeprefix("case_"))
async def test_contract(case: Callable[[StorageInterface], Awaitable[None]]) -> None:
    await case(StorageMemoryImpl())
