"""Shared fixtures of the OM suites: the memory root, the local infra root, and the managers built over them."""

from collections.abc import AsyncIterator
from datetime import timedelta
from pathlib import Path

import pytest
from cryptography.fernet import Fernet

from acme.infra.impl.local import InfraLocalImpl
from acme.om.audit.impl.manager import AuditOptions
from acme.om.base import new_id
from acme.om.events.impl.manager import EventsOptions
from acme.om.idempotency.impl.manager import IdempotencyOptions
from acme.om.journalists.impl.manager import JournalistsOptions
from acme.om.opcontext import AppContext, AppType, RequestContext
from acme.om.outbox.impl.manager import OutboxOptions
from acme.om.root import ManagerOptions, Managers, build_managers
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.tenancy.impl.manager import TenancyOptions
from acme.om.work.impl.manager import WorkOptions


def manager_options() -> ManagerOptions:
    return ManagerOptions(
        tenancy=TenancyOptions(
            signup_enabled=True,
            session_idle=timedelta(hours=12),
            session_absolute=timedelta(days=7),
            login_ttl=timedelta(minutes=15),
            socket_ticket_ttl=timedelta(seconds=30),
            api_key_max_expiry=timedelta(days=365),
            operator_token_max=timedelta(hours=1),
            touch_interval=timedelta(minutes=1),
            sign_in_delay_base=timedelta(seconds=1),
            sign_in_delay_cap=timedelta(minutes=15),
            page_size=100,
            purge_batch=500,
            totp_encryption_key=Fernet.generate_key().decode(),
            totp_issuer="Free Journalism",
        ),
        events=EventsOptions(page_size=100),
        audit=AuditOptions(page_size=100),
        outbox=OutboxOptions(retention=timedelta(days=14), purge_batch=500),
        idempotency=IdempotencyOptions(lease=timedelta(seconds=30), retention=timedelta(days=1), purge_batch=500),
        work=WorkOptions(
            item_retention=timedelta(days=7),
            retry_base=timedelta(seconds=5),
            retry_cap=timedelta(minutes=10),
            purge_batch=500,
            sweep_batch=100,
        ),
        journalists=JournalistsOptions(page_size=100),
    )


def rctx() -> RequestContext:
    return RequestContext(request_id=new_id(), app=AppContext(type=AppType.API, version="api@test"))


@pytest.fixture
def storage() -> StorageMemoryImpl:
    return StorageMemoryImpl()


@pytest.fixture
async def infra(tmp_path: Path) -> AsyncIterator[InfraLocalImpl]:
    root = InfraLocalImpl(tmp_path)
    await root.start()
    yield root
    await root.close()


@pytest.fixture
def managers(storage: StorageMemoryImpl, infra: InfraLocalImpl) -> Managers:
    return build_managers(storage, infra, manager_options())
