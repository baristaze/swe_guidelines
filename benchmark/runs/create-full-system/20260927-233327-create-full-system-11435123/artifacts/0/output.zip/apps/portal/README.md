# The portal

`@acme/portal`: the browser app a journalist and their desk work in. React and TypeScript on
Vite, built to a static bundle served by CloudFront (`deployment/terraform/modules/static_site`).
It calls one API (`services/api`) and holds one realtime socket.

## Conventions

- **Config at load time.** `src/config.ts` reads `/config.json` once, before the first render:
  `apiOrigin`, `requestTimeoutMs` (15 s when absent), `errorTrackingDsn` (empty means no error
  tracking), `environment`. `scripts/dev.sh` writes `public/config.json` from `.env`, and each
  deploy writes its own next to the bundle. No `import.meta.env` value changes between
  environments.
- **Contract.** `openapi.json` is a copy of `services/api/openapi.json`. `pnpm run generate`
  turns it into `src/api/schema.d.ts`, which nobody edits by hand. `make openapi` refreshes both.
  Feature code imports types from the facade `src/api/types.ts`, never from the schema; a lint
  rule enforces this.
- **One transport.** `src/api/client.ts` is the only code that calls `fetch`, and a lint rule
  enforces that too. It adds the API origin, the timeout, the bearer, and
  `x-app-type`/`x-app-version`. It parses the error envelope into `ApiError` with the request id.
  A 401 clears the session. Each create gets an `Idempotency-Key`, minted once and resent on each
  retry. It also owns the one retry (`src/api/retry.ts`): only a timeout, a dropped connection, or
  a 502/503/504 is retried, and only for a call that is safe to repeat. The retry is bounded, with
  backoff and jitter. TanStack Query's own retry is off.
- **Session.** `src/store/session.ts` holds one bearer and the current desk. It keeps them in
  memory and in `sessionStorage`, never in `localStorage`. Sign-in shows the membership choice,
  then exchanges it for a desk session and drops the sign-in bearer. Switching desks means a
  second exchange. Then `dropTenantState` clears the query cache and the tenant stores, and the
  signed-in tree remounts under the new session (keyed by desk and epoch). The socket reopens with
  it.
- **State.** Server state lives in TanStack Query. Keys come from `src/queries/keys.ts`, with the
  entity name first. There is one hooks module per domain. A mutation writes its answer into the
  cached pages (`src/queries/placement.ts`) and does not re-read them. Client state lives in
  Zustand (`src/store/`).
- **Realtime.** `src/realtime/RealtimeProvider.tsx` opens the one socket with a ticket and pings
  every `ping_interval_seconds` from `deployment/realtime-timeouts.json`. It reconnects with
  backoff. After more than one failed cycle it shows a banner and polls the event log every
  30 s. `src/realtime/router.ts` routes every frame into the cache, never into a component. A hint
  triggers a read of the one entity it names, which is then placed or removed. A burst triggers a
  re-read of the collection instead. A gap in `seq` (from an event, `hello`, or `pong`) triggers a
  replay from `GET /v1/events?after_seq=`. `src/realtime/envelopes.ts` mirrors the service's
  `envelopes.py` by hand.
- **Screens.** Each screen under `src/features/<screen>/` has three parts: a view
  (`<Screen>Page.tsx`, rendering only), a view-model hook (`use<Screen>Vm.ts`), and a pure model
  (`<screen>Model.ts`) with its test. The screen never decides what the server decides, such as
  the password rule, the last owner, or who may do what. It shows the server's refusal instead.
- **Design.** Tokens live in `src/design/tokens.ts` and a small kit in `src/design/kit/`. The
  operator console imports both.
- **Errors.** `main.tsx` initializes Sentry only when a DSN is set. It reports from the React
  root's error callbacks and from each route's error element.

## Commands

| Command              | Does                                              |
|----------------------|---------------------------------------------------|
| `pnpm run dev`       | the dev server at http://localhost:5173           |
| `pnpm run generate`  | `openapi.json` into `src/api/schema.d.ts`         |
| `pnpm run lint`      | ESLint (the root rules and the portal's)          |
| `pnpm run typecheck` | `tsc --noEmit`                                    |
| `pnpm run test`      | Vitest, over the models, the transport, and the realtime router |
| `pnpm run build`     | the static bundle in `dist/`                      |
