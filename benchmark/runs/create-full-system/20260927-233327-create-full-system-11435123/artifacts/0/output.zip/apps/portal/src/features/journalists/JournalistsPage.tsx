import { Banner, Button, Card, cellStyle, Muted, Stack, Table, TextField } from "../../design/kit";
import { useJournalistsVm } from "./useJournalistsVm";

export function JournalistsPage() {
  const vm = useJournalistsVm();

  return (
    <Stack gap={24}>
      <Card title="Add a journalist">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            vm.add();
          }}
        >
          <Stack row>
            <TextField label="Display name" value={vm.newName} onChange={(e) => vm.setNewName(e.target.value)} />
            <Button variant="primary" type="submit" disabled={!vm.canAdd} style={{ alignSelf: "flex-end" }}>
              Add
            </Button>
          </Stack>
        </form>
      </Card>

      <Card title="Journalists" actions={<Muted>{vm.countText}</Muted>}>
        {vm.loading && <Muted>Loading journalists…</Muted>}
        {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
        {vm.rows.length > 0 && (
          <Table head={["Display name", "Added", "Updated", ""]}>
            {vm.rows.map((row) =>
              vm.editingId === row.id ? (
                <tr key={row.id}>
                  <td style={cellStyle} colSpan={3}>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        vm.saveEdit();
                      }}
                    >
                      <Stack row>
                        <TextField label="Display name" value={vm.draft} onChange={(e) => vm.setDraft(e.target.value)} autoFocus />
                        <Button variant="primary" type="submit" disabled={!vm.canSaveEdit} style={{ alignSelf: "flex-end" }}>
                          Save
                        </Button>
                        <Button onClick={vm.cancelEdit} style={{ alignSelf: "flex-end" }}>
                          Cancel
                        </Button>
                      </Stack>
                    </form>
                  </td>
                  <td style={cellStyle} />
                </tr>
              ) : (
                <tr key={row.id}>
                  <td style={cellStyle}>{row.displayName}</td>
                  <td style={cellStyle}>{row.added}</td>
                  <td style={cellStyle}>{row.updated}</td>
                  <td style={{ ...cellStyle, textAlign: "right" }}>
                    <Stack row style={{ justifyContent: "flex-end" }}>
                      <Button onClick={() => vm.startEdit(row.id, row.displayName)}>Edit</Button>
                      <Button variant="danger" disabled={vm.removing} onClick={() => vm.remove(row.id)}>
                        Delete
                      </Button>
                    </Stack>
                  </td>
                </tr>
              ),
            )}
          </Table>
        )}
      </Card>
    </Stack>
  );
}
