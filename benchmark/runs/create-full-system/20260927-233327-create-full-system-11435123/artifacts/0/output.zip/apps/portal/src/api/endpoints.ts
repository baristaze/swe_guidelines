// The API's routes as typed calls over the one transport. Configured once, before the first
// render, by main.tsx; nothing else constructs a transport.
import { createTransport, type Transport, type TransportOptions } from "./client";
import type {
  AddApiKeyRequest,
  AddJournalistRequest,
  ApiKeyView,
  EventView,
  IssuedApiKeyView,
  IssuedSessionView,
  IssuedSignInView,
  JournalistView,
  MemberView,
  MembershipChoiceView,
  OrgView,
  RealtimeTicketView,
  Role,
  SignInRequest,
  SignUpRequest,
  UpdateJournalistRequest,
  UpdateUserRequest,
  UserView,
} from "./types";

let transport: Transport | null = null;

export function configureApi(options: TransportOptions): void {
  transport = createTransport(options);
}

function t(): Transport {
  if (transport === null) throw new Error("the API client is used before configureApi");
  return transport;
}

const enc = encodeURIComponent;

export const api = {
  auth: {
    signUp: (body: SignUpRequest) => t().request<IssuedSignInView>("POST", "/auth/signup", { body, anonymous: true }),
    login: (body: SignInRequest) => t().request<IssuedSignInView>("POST", "/auth/login", { body, anonymous: true }),
    memberships: (limit?: number) => t().request<MembershipChoiceView[]>("GET", "/auth/memberships", { query: { limit } }),
    exchange: (orgId: string) => t().request<IssuedSessionView>("POST", "/auth/exchange", { body: { org_id: orgId } }),
    logout: () => t().request<void>("POST", "/auth/logout"),
  },
  org: {
    get: () => t().request<OrgView>("GET", "/org"),
  },
  me: {
    get: () => t().request<UserView>("GET", "/me"),
    update: (body: UpdateUserRequest) => t().request<UserView>("PATCH", "/me", { body }),
  },
  members: {
    list: (limit?: number) => t().request<MemberView[]>("GET", "/members", { query: { limit } }),
    updateRole: (userId: string, role: Role) => t().request<MemberView>("PATCH", `/members/${enc(userId)}`, { body: { role } }),
    remove: (userId: string) => t().request<void>("DELETE", `/members/${enc(userId)}`),
  },
  apiKeys: {
    list: (limit?: number) => t().request<ApiKeyView[]>("GET", "/api-keys", { query: { limit } }),
    create: (body: AddApiKeyRequest) => t().request<IssuedApiKeyView>("POST", "/api-keys", { body, creates: true }),
    revoke: (keyId: string) => t().request<void>("DELETE", `/api-keys/${enc(keyId)}`),
  },
  events: {
    list: (afterSeq: number, limit?: number) =>
      t().request<EventView[]>("GET", "/events", { query: { after_seq: afterSeq, limit } }),
  },
  realtime: {
    ticket: () => t().request<RealtimeTicketView>("POST", "/realtime/tickets", { creates: true }),
    socketUrl: (ticket: string) => t().socketUrl("/realtime/socket", { ticket }),
  },
  journalists: {
    list: (limit?: number) => t().request<JournalistView[]>("GET", "/journalists", { query: { limit } }),
    get: (id: string) => t().request<JournalistView>("GET", `/journalists/${enc(id)}`),
    create: (body: AddJournalistRequest) => t().request<JournalistView>("POST", "/journalists", { body, creates: true }),
    update: (id: string, body: UpdateJournalistRequest) =>
      t().request<JournalistView>("PATCH", `/journalists/${enc(id)}`, { body }),
    remove: (id: string) => t().request<void>("DELETE", `/journalists/${enc(id)}`),
  },
};

export type Api = typeof api;
