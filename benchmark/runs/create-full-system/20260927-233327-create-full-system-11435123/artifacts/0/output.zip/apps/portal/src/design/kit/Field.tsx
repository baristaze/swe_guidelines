import { useId, type InputHTMLAttributes, type SelectHTMLAttributes } from "react";
import { color, font, radius, space } from "../tokens";

const labelStyle = { display: "grid", gap: space.xs, fontFamily: font.ui, fontSize: font.size.sm, color: color.muted } as const;
const controlStyle = {
  fontFamily: font.ui,
  fontSize: font.size.md,
  padding: `${space.sm}px ${space.md}px`,
  border: `1px solid ${color.line}`,
  borderRadius: radius.sm,
  color: color.ink,
  background: color.surface,
} as const;

export function TextField({ label, ...rest }: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  const id = useId();
  return (
    <label htmlFor={id} style={labelStyle}>
      {label}
      <input id={id} {...rest} style={{ ...controlStyle, ...rest.style }} />
    </label>
  );
}

export function SelectField({
  label,
  options,
  ...rest
}: SelectHTMLAttributes<HTMLSelectElement> & { label: string; options: ReadonlyArray<{ value: string; label: string }> }) {
  const id = useId();
  return (
    <label htmlFor={id} style={labelStyle}>
      {label}
      <select id={id} {...rest} style={{ ...controlStyle, ...rest.style }}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
