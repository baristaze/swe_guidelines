// The facade: the only names feature code uses from the API's contract. Everything else in
// src/ imports from here (through src/api), never from the generated schema.
import type { components } from "./schema";

type Schemas = components["schemas"];

export type ErrorBody = Schemas["ErrorBody"];
export type ErrorResponse = Schemas["ErrorResponse"];
export type Role = Schemas["Role"];

export type SignInRequest = Schemas["SignInRequest"];
export type SignUpRequest = Schemas["SignUpRequest"];
export type IssuedSignInView = Schemas["IssuedSignInView"];
export type MembershipChoiceView = Schemas["MembershipChoiceView"];
export type IssuedSessionView = Schemas["IssuedSessionView"];

export type OrgView = Schemas["OrgView"];
export type UserView = Schemas["UserView"];
export type UpdateUserRequest = Schemas["UpdateUserRequest"];
export type MemberView = Schemas["MemberView"];
export type UpdateMemberRoleRequest = Schemas["UpdateMemberRoleRequest"];

export type ApiKeyView = Schemas["ApiKeyView"];
export type AddApiKeyRequest = Schemas["AddApiKeyRequest"];
export type IssuedApiKeyView = Schemas["IssuedApiKeyView"];

export type EventView = Schemas["EventView"];
export type RealtimeTicketView = Schemas["RealtimeTicketView"];

// The desk's journalist profiles.
export type JournalistView = Schemas["JournalistView"];
export type AddJournalistRequest = Schemas["AddJournalistRequest"];
export type UpdateJournalistRequest = Schemas["UpdateJournalistRequest"];
