// The journalists view-model: the desk's profiles, added, renamed, and removed. Every write puts
// its answer into the cache; hints from other tabs and people arrive through the realtime router.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { useAddJournalist, useJournalists, useRemoveJournalist, useUpdateJournalist } from "../../queries/journalists";
import { canSave, countText, journalistRows, toAddJournalistRequest, toUpdateJournalistRequest } from "./journalistsModel";

export function useJournalistsVm() {
  const journalists = useJournalists();
  const add = useAddJournalist();
  const update = useUpdateJournalist();
  const remove = useRemoveJournalist();
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState<{ id: string; draft: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const rows = journalistRows(journalists.data ?? []);
  const onError = (e: unknown) => setError(errorText(e));
  const editedRow = editing ? rows.find((r) => r.id === editing.id) : undefined;

  return {
    loading: journalists.isPending,
    loadError: journalists.error ? errorText(journalists.error) : null,
    rows,
    countText: countText(rows.length),
    error,

    newName,
    setNewName,
    canAdd: canSave(newName) && !add.isPending,
    add: () => {
      setError(null);
      add.mutate(toAddJournalistRequest(newName), { onSuccess: () => setNewName(""), onError });
    },

    editingId: editing?.id ?? null,
    draft: editing?.draft ?? "",
    startEdit: (id: string, current: string) => setEditing({ id, draft: current }),
    setDraft: (draft: string) => setEditing((e) => (e ? { ...e, draft } : e)),
    cancelEdit: () => setEditing(null),
    canSaveEdit: editing !== null && canSave(editing.draft, editedRow?.displayName) && !update.isPending,
    saveEdit: () => {
      if (!editing) return;
      setError(null);
      update.mutate({ id: editing.id, body: toUpdateJournalistRequest(editing.draft) }, { onSuccess: () => setEditing(null), onError });
    },

    remove: (id: string) => {
      setError(null);
      remove.mutate(id, { onError });
    },
    removing: remove.isPending,
  };
}
