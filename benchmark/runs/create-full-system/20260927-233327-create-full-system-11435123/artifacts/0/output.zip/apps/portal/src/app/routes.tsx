// The routes: everything sits behind the sign-in gate, inside the chrome.
import { createBrowserRouter, Navigate } from "react-router";
import { ApiKeysPage } from "../features/api_keys/ApiKeysPage";
import { HomePage } from "../features/home/HomePage";
import { JournalistsPage } from "../features/journalists/JournalistsPage";
import { RequireAuth } from "./RequireAuth";
import { RouteError } from "./RouteError";
import { Shell } from "./Shell";

export function createRouter() {
  return createBrowserRouter([
    {
      element: <RequireAuth />,
      errorElement: <RouteError />,
      children: [
        {
          element: <Shell />,
          errorElement: <RouteError />,
          children: [
            { index: true, element: <HomePage /> },
            { path: "journalists", element: <JournalistsPage /> },
            { path: "api-keys", element: <ApiKeysPage /> },
            { path: "*", element: <Navigate to="/" replace /> },
          ],
        },
      ],
    },
  ]);
}
