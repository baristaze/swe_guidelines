// The app's chrome: the navigation, the org chip, the degraded-mode banner, and the screen.
import { NavLink, Outlet } from "react-router";
import { Banner } from "../design/kit";
import { color, font, space } from "../design/tokens";
import { OrgChip } from "../features/org_chip/OrgChip";
import { useConnection } from "../store/connection";

const links = [
  { to: "/", label: "Desk", end: true },
  { to: "/journalists", label: "Journalists", end: false },
  { to: "/api-keys", label: "API keys", end: false },
];

function ConnectionBanner() {
  const status = useConnection((s) => s.status);
  if (status !== "degraded") return null;
  return <Banner tone="warn">Live updates are interrupted. The page refreshes every 30 seconds until the connection is back.</Banner>;
}

export function Shell() {
  return (
    <div style={{ minHeight: "100vh", background: color.paper, color: color.ink }}>
      <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: space.lg, padding: `${space.md}px ${space.xl}px`, borderBottom: `1px solid ${color.line}`, background: color.surface }}>
        <nav style={{ display: "flex", alignItems: "center", gap: space.lg, fontFamily: font.ui }}>
          <strong style={{ fontFamily: font.body, fontSize: font.size.lg }}>Free Journalism</strong>
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.end}
              style={({ isActive }) => ({ color: isActive ? color.accent : color.ink, textDecoration: "none", fontWeight: isActive ? 600 : 400 })}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <OrgChip />
      </header>
      <div style={{ maxWidth: 960, margin: "0 auto", padding: space.xl, display: "grid", gap: space.lg }}>
        <ConnectionBanner />
        <main>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
