// The journalists screen's pure rules: rows, the edit state, and the requests it sends.
import type { AddJournalistRequest, JournalistView, UpdateJournalistRequest } from "../../api";
import { formatDate } from "../api_keys/apiKeysModel";

export interface JournalistRow {
  id: string;
  displayName: string;
  added: string;
  updated: string;
}

export function journalistRows(journalists: readonly JournalistView[]): JournalistRow[] {
  return [...journalists]
    .sort((a, b) => a.display_name.localeCompare(b.display_name) || (a.id < b.id ? -1 : 1))
    .map((j) => ({ id: j.id, displayName: j.display_name, added: formatDate(j.created_at), updated: formatDate(j.updated_at) }));
}

export function canSave(draft: string, current?: string): boolean {
  const name = draft.trim();
  return name.length > 0 && name !== current;
}

export function toAddJournalistRequest(draft: string): AddJournalistRequest {
  return { display_name: draft.trim() };
}

/** A partial update: only the field that changed is sent. */
export function toUpdateJournalistRequest(draft: string): UpdateJournalistRequest {
  return { display_name: draft.trim() };
}

export function countText(count: number): string {
  return count === 0 ? "No journalists yet" : count === 1 ? "1 journalist" : `${count} journalists`;
}
