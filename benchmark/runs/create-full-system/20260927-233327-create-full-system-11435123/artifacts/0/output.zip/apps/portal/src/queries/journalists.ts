// The journalists domain: its queries, its mutations, and the cache writes a mutation and a
// realtime hint share.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, isApiError, type AddJournalistRequest, type JournalistView, type UpdateJournalistRequest } from "../api";
import { placeInLists, removeFromLists } from "./cache";
import { keys, PAGE_SIZE } from "./keys";
import { newerByUpdatedAt } from "./placement";

export const journalistsCache = {
  place(queryClient: QueryClient, view: JournalistView): void {
    const detailKey = keys.journalists.detail(view.id);
    const cached = queryClient.getQueryData<JournalistView>(detailKey);
    if (!cached || newerByUpdatedAt(view, cached)) queryClient.setQueryData(detailKey, view);
    placeInLists(queryClient, keys.journalists.lists(), view, newerByUpdatedAt);
  },
  remove(queryClient: QueryClient, id: string): void {
    queryClient.removeQueries({ queryKey: keys.journalists.detail(id), exact: true });
    removeFromLists<JournalistView>(queryClient, keys.journalists.lists(), id);
  },
  /** The authorized read of one journalist; null when it is gone or not visible. */
  async read(id: string): Promise<JournalistView | null> {
    try {
      return await api.journalists.get(id);
    } catch (error) {
      if (isApiError(error) && error.status === 404) return null;
      throw error;
    }
  },
};

export function useJournalists(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.journalists.list(limit), queryFn: () => api.journalists.list(limit) });
}

export function useAddJournalist() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: AddJournalistRequest) => api.journalists.create(body),
    onSuccess: (view) => journalistsCache.place(queryClient, view),
  });
}

export function useUpdateJournalist() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: UpdateJournalistRequest }) => api.journalists.update(id, body),
    onSuccess: (view) => journalistsCache.place(queryClient, view),
  });
}

export function useRemoveJournalist() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      try {
        await api.journalists.remove(id);
      } catch (error) {
        // A retried delete whose first attempt landed answers 404: the row is gone either way.
        if (!(isApiError(error) && error.status === 404)) throw error;
      }
      return id;
    },
    onSuccess: (id) => journalistsCache.remove(queryClient, id),
  });
}
