import { describe, expect, it } from "vitest";
import type { JournalistView } from "../../api";
import { canSave, countText, journalistRows, toAddJournalistRequest, toUpdateJournalistRequest } from "./journalistsModel";

const j = (id: string, display_name: string): JournalistView => ({
  id,
  display_name,
  created_at: "2026-05-01T10:00:00Z",
  updated_at: "2026-05-02T10:00:00Z",
});

describe("journalists model", () => {
  it("lists profiles by name", () => {
    expect(journalistRows([j("2", "Zora"), j("1", "Ada")])).toEqual([
      { id: "1", displayName: "Ada", added: "2026-05-01", updated: "2026-05-02" },
      { id: "2", displayName: "Zora", added: "2026-05-01", updated: "2026-05-02" },
    ]);
  });

  it("saves only a non-empty name that changed", () => {
    expect(canSave("  ")).toBe(false);
    expect(canSave("Ada", "Ada")).toBe(false);
    expect(canSave("Ada L.", "Ada")).toBe(true);
  });

  it("trims what it sends", () => {
    expect(toAddJournalistRequest(" Ada ")).toEqual({ display_name: "Ada" });
    expect(toUpdateJournalistRequest(" Ada ")).toEqual({ display_name: "Ada" });
  });

  it("counts", () => {
    expect(countText(0)).toBe("No journalists yet");
    expect(countText(2)).toBe("2 journalists");
  });
});
