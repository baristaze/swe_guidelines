// The query-key factory. The entity name is first in every key, so a write and a realtime hint
// find every cached collection of an entity with one prefix.

export const keys = {
  org: {
    all: ["org"] as const,
    current: () => ["org", "current"] as const,
  },
  me: {
    all: ["me"] as const,
    current: () => ["me", "current"] as const,
  },
  memberships: {
    all: ["memberships"] as const,
    list: (limit: number) => ["memberships", "list", { limit }] as const,
  },
  members: {
    all: ["members"] as const,
    lists: () => ["members", "list"] as const,
    list: (limit: number) => ["members", "list", { limit }] as const,
  },
  apiKeys: {
    all: ["apiKeys"] as const,
    lists: () => ["apiKeys", "list"] as const,
    list: (limit: number) => ["apiKeys", "list", { limit }] as const,
  },
  journalists: {
    all: ["journalists"] as const,
    lists: () => ["journalists", "list"] as const,
    list: (limit: number) => ["journalists", "list", { limit }] as const,
    details: () => ["journalists", "detail"] as const,
    detail: (id: string) => ["journalists", "detail", id] as const,
  },
};

/** The page size every list screen asks for; the server clamps it. */
export const PAGE_SIZE = 100;

/** The `limit` a list key was built with, so placement knows where a loaded page ends. */
export function limitOf(queryKey: readonly unknown[]): number | null {
  const params = queryKey[2];
  if (typeof params === "object" && params !== null && "limit" in params) {
    const limit = (params as { limit: unknown }).limit;
    return typeof limit === "number" ? limit : null;
  }
  return null;
}
