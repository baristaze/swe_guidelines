"""The realtime channel's service: the ticket, the head seq a socket opens and pongs with, and the recheck."""

from abc import ABC, abstractmethod

from acme.om.opcontext import OpContext
from acme.services.api.types.events import RealtimeTicketView


class RealtimeServiceInterface(ABC):
    @abstractmethod
    async def issue_ticket(self, ctx: OpContext) -> RealtimeTicketView: ...

    @abstractmethod
    async def get_head(self, ctx: OpContext) -> int: ...

    @abstractmethod
    async def recheck(self, ctx: OpContext) -> None: ...
