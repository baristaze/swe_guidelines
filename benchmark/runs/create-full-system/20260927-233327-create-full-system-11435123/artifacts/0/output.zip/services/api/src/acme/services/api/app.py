"""The app factory: the container (settings, then logging, error reporting, and tracing, then the roots), then the
middleware in fixed order (CORS, request id, deadline, admission, idempotency), the routers under /v1, and health."""

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from acme.infra.observability import OUTCOMES
from acme.services.api.container import VERSION, AppContainer
from acme.services.api.gateway import errors
from acme.services.api.gateway.idempotency import IdempotencyMiddleware
from acme.services.api.gateway.observability import AdmissionMiddleware, DeadlineMiddleware, RequestIdMiddleware
from acme.services.api.routers import all_routers, diagnostics


def operation_id(route: APIRoute) -> str:
    """A stable operation id per route, `<tag>_<function>`, which the generated clients name their calls by."""
    return f"{route.tags[0]}_{route.name}" if route.tags else route.name


def create_app(container: AppContainer | None = None) -> FastAPI:
    if container is None:
        container = AppContainer.from_environment()
    settings = container.settings
    local = container.infra_settings.environment == "local"

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        await container.start()
        try:
            yield
        finally:
            await container.close()

    app = FastAPI(
        title="Free Journalism API",
        version=VERSION,
        lifespan=lifespan,
        docs_url="/docs" if local else None,
        redoc_url="/redoc" if local else None,
        openapi_url="/openapi.json" if local else None,
        generate_unique_id_function=operation_id,
    )
    app.state.container = container
    errors.install(app)

    # Added innermost first: the request passes CORS, then the request id, the deadline, admission, idempotency.
    app.add_middleware(IdempotencyMiddleware)
    app.add_middleware(
        AdmissionMiddleware, max_reads=settings.max_in_flight_reads, max_writes=settings.max_in_flight_writes
    )
    app.add_middleware(DeadlineMiddleware, seconds=settings.request_deadline.total_seconds())
    app.add_middleware(RequestIdMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.allowed_origins),
        allow_methods=["GET", "POST", "PATCH", "DELETE"],
        allow_headers=[
            "authorization",
            "content-type",
            "idempotency-key",
            "x-request-id",
            "x-app-type",
            "x-app-version",
        ],
        expose_headers=["x-request-id", "idempotent-replayed", "retry-after"],
    )

    for router in all_routers(settings.namespaces):
        app.include_router(router, prefix="/v1")
    if local:
        app.include_router(diagnostics.router, prefix="/v1")

    @app.get("/healthz", include_in_schema=False)
    async def healthz() -> dict[str, str]:
        return {"status": "ok", "version": VERSION}

    @app.get("/readyz", include_in_schema=False)
    async def readyz() -> JSONResponse:
        try:
            async with asyncio.timeout(settings.readyz_timeout.total_seconds()):
                ready = await container.storage.healthcheck()
        except TimeoutError:
            ready = False
        OUTCOMES.labels("database", "readyz", "ok" if ready else "unavailable").inc()
        return JSONResponse({"ready": ready, "version": VERSION}, status_code=200 if ready else 503)

    @app.get("/metrics", include_in_schema=False)
    async def metrics() -> Response:
        return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

    return app
