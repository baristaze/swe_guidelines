"""The operator plane's service: the tenant is a parameter of every call, never a context."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.opcontext import OperatorContext
from acme.services.api.types.admin import (
    AddMemberRequest,
    AddOperatorTokenRequest,
    AddOrgRequest,
    AdminEventView,
    AdminMemberView,
    AdminOrgView,
    ConfirmTotpRequest,
    IssuedOperatorTokenView,
    OperatorView,
    SizeView,
    TotpEnrolmentView,
)


class AdminServiceInterface(ABC):
    @abstractmethod
    async def get_me(self, octx: OperatorContext) -> OperatorView: ...

    @abstractmethod
    async def get_size(self, octx: OperatorContext) -> SizeView: ...

    @abstractmethod
    async def get_orgs(self, octx: OperatorContext, limit: int) -> list[AdminOrgView]: ...

    @abstractmethod
    async def get_org(self, octx: OperatorContext, org_id: UUID) -> AdminOrgView: ...

    @abstractmethod
    async def get_members(self, octx: OperatorContext, org_id: UUID, limit: int) -> list[AdminMemberView]: ...

    @abstractmethod
    async def get_events(
        self, octx: OperatorContext, org_id: UUID, after_seq: int, limit: int
    ) -> list[AdminEventView]: ...

    @abstractmethod
    async def create_org(self, octx: OperatorContext, org_id: UUID, req: AddOrgRequest) -> AdminOrgView: ...

    @abstractmethod
    async def add_member(
        self, octx: OperatorContext, org_id: UUID, user_id: UUID, req: AddMemberRequest
    ) -> AdminMemberView: ...

    @abstractmethod
    async def delete_org(self, octx: OperatorContext, org_id: UUID) -> None: ...

    @abstractmethod
    async def enrol_totp(self, octx: OperatorContext) -> TotpEnrolmentView: ...

    @abstractmethod
    async def confirm_totp(self, octx: OperatorContext, req: ConfirmTotpRequest) -> None: ...

    @abstractmethod
    async def issue_token(self, octx: OperatorContext, req: AddOperatorTokenRequest) -> IssuedOperatorTokenView: ...
