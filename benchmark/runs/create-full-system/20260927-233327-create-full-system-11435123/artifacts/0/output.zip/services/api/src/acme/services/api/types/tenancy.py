"""The tenancy wire types: sign-up, sign-in, memberships, the exchange, API keys, members, the org."""

from datetime import datetime
from uuid import UUID

from pydantic import Field

from acme.om.opcontext import Role
from acme.services.api.types.common import RequestBody, View


class SignUpRequest(RequestBody):
    email: str = Field(min_length=3, max_length=320, pattern=r"^[^@\s]+@[^@\s]+$")
    password: str = Field(min_length=8, max_length=256)
    display_name: str = Field(min_length=1, max_length=120)
    org_name: str = Field(min_length=1, max_length=120)
    org_slug: str = Field(min_length=2, max_length=63, pattern=r"^[a-z0-9][a-z0-9-]*[a-z0-9]$")


class SignInRequest(RequestBody):
    email: str = Field(min_length=3, max_length=320)
    password: str = Field(min_length=1, max_length=256)
    totp_code: str | None = Field(default=None, pattern=r"^[0-9]{6}$")


class ExternalSignInRequest(RequestBody):
    """The identity provider's answer: the code its hosted page redirected back with, or its access token."""

    code: str | None = None
    redirect_uri: str | None = None
    token: str | None = None


class MembershipChoiceView(View):
    org_id: UUID
    org_name: str
    org_slug: str
    role: Role


class IssuedSignInView(View):
    """The identity-stage bearer, shown once, and the choice of desks it can enter."""

    token: str
    expires_at: datetime
    memberships: tuple[MembershipChoiceView, ...]


class ExchangeRequest(RequestBody):
    org_id: UUID


class IssuedSessionView(View):
    token: str
    expires_at: datetime


class OrgView(View):
    id: UUID
    name: str
    slug: str


class MemberView(View):
    user_id: UUID
    name: str
    role: Role


class MembershipView(View):
    user_id: UUID
    role: Role


class UpdateMemberRoleRequest(RequestBody):
    role: Role


class UserView(View):
    id: UUID
    name: str


class UpdateUserRequest(RequestBody):
    """A partial update: an absent field is unchanged."""

    name: str | None = Field(default=None, min_length=1, max_length=120)


class AddApiKeyRequest(RequestBody):
    name: str = Field(min_length=1, max_length=120)
    role: Role
    expires_in: int = Field(default=30 * 24 * 3600, gt=0, description="seconds; capped by the server")


class ApiKeyView(View):
    id: UUID
    name: str
    role: Role
    created_at: datetime
    expires_at: datetime
    revoked_at: datetime | None = None


class IssuedApiKeyView(View):
    """The key, shown once. A replay of the create answers the row with no token."""

    id: UUID
    name: str
    role: Role
    expires_at: datetime
    token: str | None = None
