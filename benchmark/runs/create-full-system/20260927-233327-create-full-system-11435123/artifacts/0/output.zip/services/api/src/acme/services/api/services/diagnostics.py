"""The local diagnostics: one operation that fails on purpose, for the telemetry round trip."""

from abc import ABC, abstractmethod

from acme.om.opcontext import RequestContext


class DiagnosticsServiceInterface(ABC):
    @abstractmethod
    async def fail_on_purpose(self, rctx: RequestContext) -> None:
        """Raises an unexpected failure, which the edge answers 500 and reports as an error event."""
        ...
