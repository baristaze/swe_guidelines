# The API process

The one API process of the platform: the gateway (credentials, the operator gate, rate limits, edge idempotency,
the error envelope, the request id), one router per hosted namespace under `/v1`, the operator plane under
`/v1/admin`, and the realtime socket at `/v1/realtime/socket`. Its OpenAPI document is `openapi.json`, emitted by
`make openapi` and committed.

The binary is its own operations CLI, `acme-api`: `serve`, `migrate` (the OM's migration runner), `bootstrap`
(`--seed` for the local development seed), `grant-operator` (the operator allowlist and operator tokens), and
`openapi`. Settings are `ACME_API_*` beside the shared `ACME_*` ones; `.env.example` documents each.

Locally only (the settings name the `local` environment), the process also serves the interactive docs at `/docs`
and `POST /v1/diagnostics/failure`, a route that fails on purpose so the telemetry round trip can read an error
event back by request id. No deployed process serves either.
