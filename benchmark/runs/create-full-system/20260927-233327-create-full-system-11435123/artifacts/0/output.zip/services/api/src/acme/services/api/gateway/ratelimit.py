"""Per-route rate limits over the shared cache, so every replica shares one budget. They fail open: fairness
between subjects, never a security boundary."""

import hashlib
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import timedelta
from typing import TYPE_CHECKING

from fastapi import Request

from acme.infra.cache import CacheScope
from acme.infra.observability import OUTCOMES
from acme.om.base import EMPTY_UUID
from acme.om.exceptions import TooManyRequests
from acme.om.opcontext import CredentialScope

if TYPE_CHECKING:
    from acme.services.api.settings import ApiSettings

SYSTEM_SCOPE = EMPTY_UUID


@dataclass(frozen=True)
class Limit:
    requests: int
    window: timedelta

    @classmethod
    def parse(cls, spec: str) -> Limit:
        count, _, seconds = spec.partition("/")
        return cls(requests=int(count), window=timedelta(seconds=int(seconds or 60)))


@dataclass(frozen=True)
class RateLimitOptions:
    """Built once at boot from settings and held on the container."""

    auth: Limit
    writes: Limit

    @classmethod
    def from_settings(cls, settings: ApiSettings) -> RateLimitOptions:
        return cls(auth=Limit.parse(settings.rate_limit_auth), writes=Limit.parse(settings.rate_limit_writes))


def credential_subject(scope: CredentialScope) -> str:
    """The subject of an authenticated route: the credential id, whatever the tenant."""
    return f"credential:{scope.credential_id}"


def address_subject(request: Request) -> str:
    """An unauthenticated route keys on the client address, kept only as a short-lived digest."""
    host = request.client.host if request.client else "unknown"
    return "address:" + hashlib.sha256(host.encode()).hexdigest()[:32]


async def enforce(request: Request, route: str, subject: str, limit: Limit) -> None:
    cache = request.app.state.container.infra.get_cache(CacheScope.RATE_LIMIT)
    count, remaining = await cache.increment(SYSTEM_SCOPE, f"{route}:{subject}", limit.window)
    if count > limit.requests:
        OUTCOMES.labels("rate_limit", route, "refused").inc()
        raise TooManyRequests("slow down", retry_after=max(1, int(remaining.total_seconds())))
    OUTCOMES.labels("rate_limit", route, "admitted").inc()


def limited_by_address(route: str) -> Callable[[Request], Awaitable[None]]:
    async def dependency(request: Request) -> None:
        await enforce(request, route, address_subject(request), request.app.state.container.rate_limits.auth)

    return dependency
