"""Every hosted namespace's router. The `namespaces` setting names the ones a process mounts; empty mounts all."""

from fastapi import APIRouter

from acme.services.api.realtime import socket, ticket
from acme.services.api.routers import admin, events, journalists, tenancy

HOSTED: dict[str, tuple[APIRouter, ...]] = {
    "tenancy": (tenancy.router, admin.router),
    "events": (events.router, ticket.router, socket.router),
    "journalists": (journalists.router,),
}


def all_routers(namespaces: tuple[str, ...] = ()) -> list[APIRouter]:
    unknown = set(namespaces) - set(HOSTED)
    if unknown:
        raise SystemExit(f"ACME_API_NAMESPACES names what this process does not host: {sorted(unknown)}")
    chosen = namespaces or tuple(HOSTED)
    return [router for name in chosen for router in HOSTED[name]]
