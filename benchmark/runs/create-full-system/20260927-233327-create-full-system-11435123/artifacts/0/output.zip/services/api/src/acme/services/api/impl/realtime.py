"""The in-process realtime service."""

from acme.om.events.manager import EventsManagerInterface
from acme.om.opcontext import OpContext
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.services.api.services.realtime import RealtimeServiceInterface
from acme.services.api.types.events import RealtimeTicketView


class RealtimeServiceImpl(RealtimeServiceInterface):
    def __init__(self, tenancy: TenancyManagerInterface, events: EventsManagerInterface) -> None:
        self._tenancy = tenancy
        self._events = events

    async def issue_ticket(self, ctx: OpContext) -> RealtimeTicketView:
        issued = await self._tenancy.issue_socket_ticket(ctx)
        return RealtimeTicketView(ticket=issued.token, expires_at=issued.expires_at)

    async def get_head(self, ctx: OpContext) -> int:
        return await self._events.get_head(ctx)

    async def recheck(self, ctx: OpContext) -> None:
        await self._tenancy.recheck_session(ctx)
