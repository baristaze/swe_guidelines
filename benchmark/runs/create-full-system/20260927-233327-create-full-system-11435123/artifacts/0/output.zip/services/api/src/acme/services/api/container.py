"""The app container: storage, then infra, then the integrations, then the managers, then the services root."""

import logging
import tempfile
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path

from acme.infra.impl.configured import InfraConfiguredImpl
from acme.infra.impl.local import InfraLocalImpl
from acme.infra.impl.settings import InfraSettings
from acme.infra.observability import configure_error_tracking, configure_logging, configure_tracing
from acme.infra.root import InfraInterface
from acme.integrations.impl.configured import build_integrations, build_twins
from acme.integrations.root import Integrations
from acme.integrations.settings import IntegrationsSettings
from acme.om.audit.impl.manager import AuditOptions
from acme.om.events.impl.manager import EventsOptions
from acme.om.idempotency.impl.manager import IdempotencyOptions
from acme.om.journalists.impl.manager import JournalistsOptions
from acme.om.outbox.impl.manager import OutboxOptions
from acme.om.root import ManagerOptions, Managers, build_managers
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.storage.impl.postgres import StoragePostgresImpl
from acme.om.storage.root import StorageInterface
from acme.om.storage.settings import StorageSettings
from acme.om.tenancy.impl.manager import TenancyOptions
from acme.om.work.impl.manager import WorkOptions
from acme.services.api.gateway.ratelimit import RateLimitOptions
from acme.services.api.impl import ServicesImpl
from acme.services.api.realtime.hub import SocketHub
from acme.services.api.services import ServicesInterface
from acme.services.api.settings import ApiSettings

logger = logging.getLogger(__name__)

VERSION = "0.1.0"
SERVICE = "acme-api"


def boot(infra_settings: InfraSettings) -> None:
    """Every process start: logging, error reporting, tracing. The trust store is the entry module's, before this."""
    configure_logging(SERVICE, infra_settings.environment, infra_settings.log_json, infra_settings.log_level)
    configure_error_tracking(
        infra_settings.error_tracking_dsn, SERVICE, infra_settings.release, infra_settings.environment
    )
    configure_tracing(infra_settings.otel_exporter_endpoint, SERVICE, infra_settings.environment)


def manager_options(settings: ApiSettings) -> ManagerOptions:
    return ManagerOptions(
        tenancy=TenancyOptions(
            signup_enabled=settings.signup_enabled,
            session_idle=settings.session_idle_lifetime,
            session_absolute=settings.session_absolute_lifetime,
            login_ttl=settings.login_lifetime,
            socket_ticket_ttl=settings.socket_ticket_lifetime,
            api_key_max_expiry=settings.api_key_max_expires_in,
            operator_token_max=settings.operator_token_max_expires_in,
            touch_interval=min(settings.session_idle_lifetime / 10, settings.session_recheck_interval),
            sign_in_delay_base=settings.signin_delay_base,
            sign_in_delay_cap=settings.signin_delay_cap,
            page_size=settings.page_size,
            purge_batch=settings.purge_batch,
            totp_encryption_key=settings.totp_encryption_key,
            totp_issuer="Free Journalism",
        ),
        events=EventsOptions(page_size=settings.page_size),
        audit=AuditOptions(page_size=settings.page_size),
        outbox=OutboxOptions(retention=settings.outbox_retention, purge_batch=settings.purge_batch),
        idempotency=IdempotencyOptions(
            lease=settings.idempotency_lease, retention=settings.idempotency_retention, purge_batch=settings.purge_batch
        ),
        work=WorkOptions(
            item_retention=settings.item_retention,
            retry_base=timedelta(seconds=5),
            retry_cap=timedelta(minutes=10),
            purge_batch=settings.purge_batch,
            sweep_batch=settings.page_size,
        ),
        journalists=JournalistsOptions(page_size=settings.page_size),
    )


@dataclass(frozen=True)
class AppContainer:
    settings: ApiSettings
    infra_settings: InfraSettings
    storage: StorageInterface
    infra: InfraInterface
    integrations: Integrations
    managers: Managers
    services: ServicesInterface
    hub: SocketHub
    rate_limits: RateLimitOptions

    @classmethod
    def from_environment(cls) -> AppContainer:
        """The deployed shape: settings from the environment, the process booted, the configured roots."""
        infra_settings = InfraSettings()
        boot(infra_settings)
        return cls.build(ApiSettings(), infra_settings)  # type: ignore[call-arg]  # credentials come from the env

    @classmethod
    def for_document(cls, settings: ApiSettings) -> AppContainer:
        """The roots in memory, only to emit the OpenAPI document; nothing is started."""
        root = Path(tempfile.gettempdir()) / "acme-openapi"
        return cls.for_tests(StorageMemoryImpl(), InfraLocalImpl(root), settings)

    @classmethod
    def build(cls, settings: ApiSettings, infra_settings: InfraSettings) -> AppContainer:
        storage = StoragePostgresImpl(StorageSettings())
        infra = InfraConfiguredImpl(infra_settings)
        integrations = build_integrations(IntegrationsSettings(environment=infra_settings.environment))
        return cls._wire(settings, infra_settings, storage, infra, integrations)

    @classmethod
    def for_tests(cls, storage: StorageInterface, infra: InfraInterface, settings: ApiSettings) -> AppContainer:
        """The same container over the memory storage root and the local infra root, every backend a twin."""
        infra_settings = InfraSettings(
            _env_file=None,  # type: ignore[call-arg]
            environment="local",
            service_name="acme-api",
            buckets_root=Path(".data/test-buckets"),
        )
        return cls._wire(settings, infra_settings, storage, infra, build_twins())

    @classmethod
    def _wire(
        cls,
        settings: ApiSettings,
        infra_settings: InfraSettings,
        storage: StorageInterface,
        infra: InfraInterface,
        integrations: Integrations,
    ) -> AppContainer:
        managers = build_managers(storage, infra, manager_options(settings))
        return cls(
            settings=settings,
            infra_settings=infra_settings,
            storage=storage,
            infra=infra,
            integrations=integrations,
            managers=managers,
            services=ServicesImpl(managers),
            hub=SocketHub(infra.get_topics()),
            rate_limits=RateLimitOptions.from_settings(settings),
        )

    def describe(self) -> list[str]:
        return [self.storage.describe(), *self.infra.describe(), *self.integrations.describe()]

    async def start(self) -> None:
        await self.infra.start()
        await self.integrations.start()
        self.hub.start()
        logger.info("backends: %s", "; ".join(self.describe()))

    async def close(self) -> None:
        self.hub.close()
        await self.integrations.close()
        await self.infra.close()
        await self.storage.close()
