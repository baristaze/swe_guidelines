"""The API binary is its own operations CLI: `serve`, `migrate`, `bootstrap`, `grant-operator`, `openapi`.

Commands log to standard error; standard output carries only what a command prints (a minted token, the document).
"""

import argparse
import asyncio
import json
import logging
import sys
from datetime import timedelta
from pathlib import Path
from urllib.parse import urlparse

from acme.infra.impl.settings import InfraSettings
from acme.infra.secrets.aws import write_process_secret
from acme.om.base import new_id
from acme.om.opcontext import AppContext, AppType, OperatorPermission, RequestContext
from acme.om.storage import migrate as om_migrate
from acme.om.storage.settings import StorageSettings
from acme.services.api.app import create_app
from acme.services.api.container import SERVICE, VERSION, AppContainer, boot
from acme.services.api.settings import ApiSettings

logger = logging.getLogger(__name__)

LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "postgres"}


def _local_database_only() -> None:
    """The seed and a printed token run only against a local database: every URL StorageSettings resolves."""
    remote = [u for u in StorageSettings().all_urls() if urlparse(u).hostname not in LOCAL_HOSTS]
    if remote:
        raise SystemExit("refused: a database URL is not a local address (the seed and printed tokens are local only)")


def _command_stage() -> RequestContext:
    """The request stage a command mints, once per command."""
    return RequestContext(request_id=new_id(), app=AppContext(type=AppType.BOOTSTRAP, version=f"api@{VERSION}"))


def serve() -> int:
    import uvicorn

    settings = ApiSettings()  # type: ignore[call-arg]
    uvicorn.run(
        create_app(),
        host=settings.host,
        port=settings.port,
        log_config=None,
        access_log=False,  # the edge logs each request itself, never a query string that could carry a ticket
        ws_ping_interval=None,
    )
    return 0


async def _with_container(work):  # type: ignore[no-untyped-def]
    container = AppContainer.build(ApiSettings(), InfraSettings())  # type: ignore[call-arg]
    await container.start()
    try:
        return await work(container)
    finally:
        await container.close()


def bootstrap(args: argparse.Namespace) -> int:
    if args.seed:
        _local_database_only()
        from acme.services.api.seed import SeedSettings

        seed = SeedSettings()
        org_name, org_slug, email, password, name = (
            seed.org_name,
            seed.org_slug,
            seed.owner_email,
            seed.owner_password,
            "Local Owner",
        )
    else:
        org_name, org_slug, email, password, name = args.org, args.slug, args.email, args.password, args.name
        seed = None

    async def work(container: AppContainer) -> int:
        tenancy = container.managers.tenancy
        ctx = await tenancy.bootstrap(_command_stage(), org_name, org_slug, email, password, name)
        logger.info("bootstrap: org %s ready, owner user %s", ctx.org_id, ctx.user_id)
        if seed is not None:
            for address, secret, permission in (
                (seed.operator_email, seed.operator_password, OperatorPermission.READ),
                (seed.provisioner_email, seed.provisioner_password, OperatorPermission.WRITE),
            ):
                await tenancy.ensure_identity(_command_stage(), address, secret, address.split("@")[0])
                await tenancy.grant_operator(_command_stage(), address, permission)
                logger.info("bootstrap: operator %s on a %s entry", address, permission.value)
        return 0

    return asyncio.run(_with_container(work))


def grant_operator(args: argparse.Namespace) -> int:
    infra = InfraSettings()
    if args.mint_token and not args.token_secret:
        _local_database_only()
    if args.expires_in is not None and args.expires_in > 3600:
        raise SystemExit("refused: an operator token expires within 3600 seconds")

    async def work(container: AppContainer) -> int:
        tenancy = container.managers.tenancy
        if args.disable:
            await tenancy.disable_operator(_command_stage(), args.email)
            logger.info("grant-operator: disabled %s", args.email)
            return 0
        if args.permission:
            await tenancy.grant_operator(_command_stage(), args.email, OperatorPermission(args.permission))
            logger.info("grant-operator: %s holds a %s entry", args.email, args.permission)
        if args.mint_token:
            expires = None if args.expires_in is None else timedelta(seconds=args.expires_in)
            issued = await tenancy.grant_operator_token(_command_stage(), args.email, expires)
            if args.token_secret:
                await write_process_secret(args.token_secret, issued.token, infra.aws_region)
                print(args.token_secret)
            else:
                print(issued.token)
        return 0

    return asyncio.run(_with_container(work))


def openapi(args: argparse.Namespace) -> int:
    settings = ApiSettings(
        _env_file=None,  # type: ignore[call-arg]
        totp_encryption_key="0" * 43 + "=",
        internal_signing_key="document-only",
    )
    app = create_app(AppContainer.for_document(settings))
    document = json.dumps(app.openapi(), indent=2, sort_keys=True) + "\n"
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(document)
        logger.info("openapi: wrote %s", args.out)
    else:
        sys.stdout.write(document)
    return 0


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="acme-api", description=f"{SERVICE} {VERSION}")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("serve", help="serve the API")
    mig = sub.add_parser("migrate", help="the OM's migration CLI: upgrade, check, roundtrip, ensure-logins")
    mig.add_argument("rest", nargs=argparse.REMAINDER)
    boot_cmd = sub.add_parser("bootstrap", help="seed a first org and its owner")
    boot_cmd.add_argument("--seed", action="store_true", help="the development org, owner, and local operators")
    for flag in ("--org", "--slug", "--email", "--password", "--name"):
        boot_cmd.add_argument(flag)
    grant = sub.add_parser("grant-operator", help="put an identity on the operator allowlist, or disable it")
    grant.add_argument("--email", required=True)
    grant.add_argument("--permission", choices=["read", "write"])
    grant.add_argument("--disable", action="store_true")
    grant.add_argument("--mint-token", action="store_true")
    grant.add_argument("--expires-in", type=int)
    grant.add_argument("--token-secret")
    doc = sub.add_parser("openapi", help="emit the OpenAPI document")
    doc.add_argument("--out")
    args = parser.parse_args(argv)

    logging.basicConfig(stream=sys.stderr, level=logging.INFO)
    if args.command == "serve":
        return serve()
    if args.command == "migrate":
        return om_migrate.main(args.rest)
    if args.command == "openapi":
        return openapi(args)
    boot(InfraSettings())
    if args.command == "bootstrap":
        if not args.seed and not all((args.org, args.slug, args.email, args.password, args.name)):
            parser.error("bootstrap takes --seed, or --org, --slug, --email, --password, and --name")
        return bootstrap(args)
    if not args.disable and not args.permission and not args.mint_token:
        parser.error("grant-operator takes --permission, --disable, or --mint-token")
    return grant_operator(args)
