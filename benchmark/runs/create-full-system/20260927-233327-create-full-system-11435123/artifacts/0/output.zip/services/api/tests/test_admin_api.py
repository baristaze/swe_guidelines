"""The operator plane: the gate, the second factor, the operator token, provisioning, and the support trail."""

import logging

import pytest
from api_harness import Api, bearer

from acme.om.opcontext import OperatorPermission
from acme.services.api.main import _command_stage


async def test_an_identity_off_the_allowlist_is_refused(api: Api) -> None:
    signed = await api.sign_up()
    assert (await api.client.get("/v1/admin/me", headers=bearer(signed["token"]))).status_code == 403


async def test_a_portal_session_is_refused_though_its_identity_is_allowlisted(api: Api) -> None:
    headers = await api.session()
    await api.container.managers.tenancy.grant_operator(_command_stage(), "owner@acme.example", OperatorPermission.READ)
    assert (await api.client.get("/v1/admin/me", headers=headers)).status_code == 403


async def test_an_unenrolled_operator_reaches_enrolment_alone(api: Api) -> None:
    headers, _ = await api.operator("new@acme.example", OperatorPermission.READ, enrol=False)
    refused = await api.client.get("/v1/admin/orgs", headers=headers)
    assert refused.status_code == 403 and refused.json()["error"]["code"] == "second_factor_not_enrolled"
    enrolled = await api.client.post("/v1/admin/me/totp", headers=headers)
    assert enrolled.status_code == 200 and enrolled.json()["otpauth_uri"].startswith("otpauth://totp/")


async def test_an_enrolled_operators_sign_in_without_a_code_is_refused(api: Api) -> None:
    await api.operator("op@acme.example", OperatorPermission.READ)
    signed = await api.client.post("/v1/auth/login", json={"email": "op@acme.example", "password": "pswd_operator"})
    refused = await api.client.get("/v1/admin/me", headers=bearer(signed.json()["token"]))
    assert refused.status_code == 401 and refused.json()["error"]["code"] == "second_factor_required"


async def test_a_wrong_code_and_a_reused_code_are_refused(api: Api) -> None:
    await api.operator("op@acme.example", OperatorPermission.READ)
    wrong = await api.client.post(
        "/v1/auth/login", json={"email": "op@acme.example", "password": "pswd_operator", "totp_code": "000000"}
    )
    assert wrong.status_code in (401, 429)


async def test_a_read_entry_is_refused_on_every_provisioning_route(api: Api) -> None:
    headers, _ = await api.operator("reader@acme.example", OperatorPermission.READ)
    assert (await api.client.get("/v1/admin/me", headers=headers)).json()["operator_role"] == "read"
    create = await api.client.post("/v1/admin/orgs", json={"name": "D", "slug": "dd"}, headers=headers)
    assert create.status_code == 403
    signed = await api.sign_up()
    org_id = signed["memberships"][0]["org_id"]
    member = await api.client.post(
        f"/v1/admin/orgs/{org_id}/members",
        json={"email": "m@acme.example", "display_name": "M", "role": "member"},
        headers=headers,
    )
    assert member.status_code == 403
    assert (await api.client.delete(f"/v1/admin/orgs/{org_id}", headers=headers)).status_code == 403


async def test_a_write_entry_provisions_and_deletes(api: Api) -> None:
    headers, _ = await api.operator("prov@acme.example", OperatorPermission.WRITE)
    created = await api.client.post(
        "/v1/admin/orgs", json={"name": "Traffic", "slug": "traffic-1"}, headers={**headers, "Idempotency-Key": "o-1"}
    )
    assert created.status_code == 201
    org_id = created.json()["id"]
    member = await api.client.post(
        f"/v1/admin/orgs/{org_id}/members",
        json={"email": "p1@acme.example", "display_name": "P1", "role": "member", "password": "pswd_p1_long"},
        headers={**headers, "Idempotency-Key": "m-1"},
    )
    assert member.status_code == 201
    assert (await api.client.get("/v1/admin/size", headers=headers)).json()["tenants"] == 0  # provisioned: left out
    assert (await api.client.delete(f"/v1/admin/orgs/{org_id}", headers=headers)).status_code == 204


async def test_a_read_of_a_tenants_rows_leaves_a_trail(api: Api, caplog: pytest.LogCaptureFixture) -> None:
    headers, _ = await api.operator("support@acme.example", OperatorPermission.READ)
    org_id = (await api.sign_up())["memberships"][0]["org_id"]
    with caplog.at_level(logging.INFO):
        assert (await api.client.get(f"/v1/admin/orgs/{org_id}/members", headers=headers)).status_code == 200
        assert (await api.client.get(f"/v1/admin/orgs/{org_id}/events", headers=headers)).status_code == 200
    trail = [r for r in caplog.records if getattr(r, "org_id", None) == org_id]
    assert trail and all(getattr(r, "operator_identity_id", None) for r in trail)


async def test_an_operator_token_is_admitted_with_its_one_permission(api: Api) -> None:
    headers, _ = await api.operator("minter@acme.example", OperatorPermission.WRITE)
    minted = await api.client.post(
        "/v1/admin/me/tokens", json={"permission": "read"}, headers={**headers, "Idempotency-Key": "t-1"}
    )
    assert minted.status_code == 201
    token = bearer(minted.json()["token"])
    assert (await api.client.get("/v1/admin/me", headers=token)).json()["permissions"] == ["read"]
    assert (await api.client.post("/v1/admin/orgs", json={"name": "D", "slug": "dx"}, headers=token)).status_code == 403
    again = await api.client.post("/v1/admin/me/tokens", json={"permission": "read"}, headers=token)
    assert again.status_code == 403  # a token never mints a token
    too_long = await api.client.post(
        "/v1/admin/me/tokens", json={"permission": "read", "expires_in": 7200}, headers=headers
    )
    assert too_long.status_code == 422


async def test_a_mint_wider_than_the_entry_is_refused(api: Api) -> None:
    headers, _ = await api.operator("narrow@acme.example", OperatorPermission.READ)
    refused = await api.client.post("/v1/admin/me/tokens", json={"permission": "write"}, headers=headers)
    assert refused.status_code == 403


async def test_a_token_from_the_grant_job_is_admitted(api: Api) -> None:
    tenancy = api.container.managers.tenancy
    await tenancy.ensure_identity(_command_stage(), "prov@acme.example", "pswd_prov_1", "Prov")
    await tenancy.grant_operator(_command_stage(), "prov@acme.example", OperatorPermission.WRITE)
    issued = await tenancy.grant_operator_token(_command_stage(), "prov@acme.example", None)
    me = await api.client.get("/v1/admin/me", headers=bearer(issued.token))
    assert me.status_code == 200 and me.json()["permissions"] == ["read", "write"]
