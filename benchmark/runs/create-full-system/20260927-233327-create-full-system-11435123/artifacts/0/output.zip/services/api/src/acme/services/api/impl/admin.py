"""The in-process operator plane: every call passes the tenant as a parameter to the tenancy manager."""

from datetime import timedelta
from uuid import UUID

from acme.om.events.manager import EventsManagerInterface
from acme.om.opcontext import OperatorContext, OperatorPermission
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.services.api.services.admin import AdminServiceInterface
from acme.services.api.types.admin import (
    AddMemberRequest,
    AddOperatorTokenRequest,
    AddOrgRequest,
    AdminEventView,
    AdminMemberView,
    AdminOrgView,
    ConfirmTotpRequest,
    IssuedOperatorTokenView,
    OperatorView,
    SizeView,
    TotpEnrolmentView,
)


class AdminServiceImpl(AdminServiceInterface):
    def __init__(self, tenancy: TenancyManagerInterface, events: EventsManagerInterface) -> None:
        self._tenancy = tenancy
        self._events = events

    async def get_me(self, octx: OperatorContext) -> OperatorView:
        entry = await self._tenancy.get_operator(octx)
        return OperatorView(
            identity_id=octx.identity_id, email=octx.email, operator_role=entry.permission, permissions=octx.permissions
        )

    async def get_size(self, octx: OperatorContext) -> SizeView:
        return SizeView.model_validate(await self._tenancy.get_size(octx))

    async def get_orgs(self, octx: OperatorContext, limit: int) -> list[AdminOrgView]:
        return [AdminOrgView.model_validate(o) for o in await self._tenancy.get_orgs(octx, limit)]

    async def get_org(self, octx: OperatorContext, org_id: UUID) -> AdminOrgView:
        return AdminOrgView.model_validate(await self._tenancy.get_org_for_operator(octx, org_id))

    async def get_members(self, octx: OperatorContext, org_id: UUID, limit: int) -> list[AdminMemberView]:
        members = await self._tenancy.get_members_for_operator(octx, org_id, limit)
        return [AdminMemberView.model_validate(m) for m in members]

    async def get_events(self, octx: OperatorContext, org_id: UUID, after_seq: int, limit: int) -> list[AdminEventView]:
        events = await self._events.get_events_for_operator(octx, org_id, after_seq, limit)
        return [
            AdminEventView(
                seq=e.seq,
                kind=e.kind,
                target_id=e.target_id,
                actor_id=e.actor_id,
                request_id=e.request_id,
                app_type=e.app.type,
                app_version=e.app.version,
            )
            for e in events
        ]

    async def create_org(self, octx: OperatorContext, org_id: UUID, req: AddOrgRequest) -> AdminOrgView:
        return AdminOrgView.model_validate(await self._tenancy.create_org(octx, org_id, req.name, req.slug))

    async def add_member(
        self, octx: OperatorContext, org_id: UUID, user_id: UUID, req: AddMemberRequest
    ) -> AdminMemberView:
        member = await self._tenancy.add_member(
            octx, org_id, user_id, req.email, req.display_name, req.role, req.password
        )
        return AdminMemberView.model_validate(member)

    async def delete_org(self, octx: OperatorContext, org_id: UUID) -> None:
        await self._tenancy.delete_org(octx, org_id)

    async def enrol_totp(self, octx: OperatorContext) -> TotpEnrolmentView:
        return TotpEnrolmentView(otpauth_uri=(await self._tenancy.enrol_totp(octx)).uri)

    async def confirm_totp(self, octx: OperatorContext, req: ConfirmTotpRequest) -> None:
        await self._tenancy.confirm_totp(octx, req.totp_code)

    async def issue_token(self, octx: OperatorContext, req: AddOperatorTokenRequest) -> IssuedOperatorTokenView:
        expires_in = None if req.expires_in is None else timedelta(seconds=req.expires_in)
        issued = await self._tenancy.issue_operator_token(octx, req.permission, expires_in)
        return IssuedOperatorTokenView(
            id=issued.credential_id,
            permission=OperatorPermission(req.permission),
            expires_at=issued.expires_at,
            token=issued.token,
        )
