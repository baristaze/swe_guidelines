"""The journalists wire types: the profile as the desk sees it, and the two requests that write it."""

from datetime import datetime
from typing import Self
from uuid import UUID

from pydantic import Field, model_validator

from acme.services.api.types.common import RequestBody, View


class JournalistView(View):
    id: UUID
    display_name: str
    created_at: datetime
    updated_at: datetime


class AddJournalistRequest(RequestBody):
    display_name: str = Field(min_length=1, max_length=120)


class UpdateJournalistRequest(RequestBody):
    """A partial update: an absent field stays as it is. The display name is never cleared, so a null is refused."""

    display_name: str | None = Field(default=None, min_length=1, max_length=120)

    @model_validator(mode="after")
    def _no_null_for_a_required_field(self) -> Self:
        if "display_name" in self.model_fields_set and self.display_name is None:
            raise ValueError("display_name cannot be cleared")
        return self
