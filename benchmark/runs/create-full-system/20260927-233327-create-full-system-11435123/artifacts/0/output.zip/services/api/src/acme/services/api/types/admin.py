"""The operator plane's wire types."""

from datetime import datetime
from uuid import UUID

from pydantic import Field

from acme.om.opcontext import AppType, OperatorPermission, Role
from acme.services.api.types.common import RequestBody, View


class OperatorView(View):
    identity_id: UUID
    email: str
    operator_role: OperatorPermission
    permissions: tuple[OperatorPermission, ...]


class SizeView(View):
    """Tenants, users, and rows written in the last day, leaving out the tenants a traffic run provisioned."""

    tenants: int
    users: int
    events_last_day: int


class AdminOrgView(View):
    id: UUID
    name: str
    slug: str
    created_at: datetime
    deleted_at: datetime | None = None


class AdminMemberView(View):
    user_id: UUID
    identity_id: UUID
    name: str
    role: Role


class AdminEventView(View):
    seq: int
    kind: str
    target_id: UUID
    actor_id: UUID
    request_id: UUID
    app_type: AppType
    app_version: str


class AddOrgRequest(RequestBody):
    name: str = Field(min_length=1, max_length=120)
    slug: str = Field(min_length=2, max_length=63, pattern=r"^[a-z0-9][a-z0-9-]*[a-z0-9]$")


class AddMemberRequest(RequestBody):
    email: str = Field(min_length=3, max_length=320, pattern=r"^[^@\s]+@[^@\s]+$")
    display_name: str = Field(min_length=1, max_length=120)
    role: Role
    password: str | None = Field(default=None, min_length=8, max_length=256)


class TotpEnrolmentView(View):
    otpauth_uri: str


class ConfirmTotpRequest(RequestBody):
    totp_code: str = Field(pattern=r"^[0-9]{6}$")


class AddOperatorTokenRequest(RequestBody):
    permission: OperatorPermission
    expires_in: int | None = Field(default=None, gt=0, le=3600, description="seconds; at most 3600")


class IssuedOperatorTokenView(View):
    """The token, shown once. A replay of the mint answers with no token."""

    id: UUID
    permission: OperatorPermission
    expires_at: datetime
    token: str | None = None
