"""The per-socket send buffer: two bounded lanes, control frames first, the oldest stream frame dropped when full."""

import asyncio
import logging
from collections import deque

from acme.infra.observability import OUTCOMES
from acme.services.api.realtime.envelopes import ControlFrame, EventFrame

logger = logging.getLogger(__name__)


class SendBuffer:
    def __init__(self, stream_size: int, control_size: int) -> None:
        self._stream: deque[EventFrame] = deque()
        self._control: deque[ControlFrame] = deque()
        self._stream_size = stream_size
        self._control_size = control_size
        self._ready = asyncio.Event()

    def push_control(self, frame: ControlFrame) -> None:
        if len(self._control) >= self._control_size:
            # The socket produces state faster than it can be written, which it should not.
            logger.warning("control lane overflow; dropped the oldest control frame")
            OUTCOMES.labels("realtime", "control", "overflow").inc()
            self._control.popleft()
        self._control.append(frame)
        self._ready.set()

    def push_stream(self, frame: EventFrame) -> None:
        if len(self._stream) >= self._stream_size:
            dropped = self._stream.popleft()
            logger.info("send buffer full; dropped stream frame seq=%s", dropped.seq)
            OUTCOMES.labels("realtime", "stream", "dropped").inc()
        self._stream.append(frame)
        self._ready.set()

    async def next(self) -> ControlFrame | EventFrame:
        while not self._control and not self._stream:
            self._ready.clear()
            await self._ready.wait()
        return self._control.popleft() if self._control else self._stream.popleft()

    def pending(self) -> int:
        return len(self._control) + len(self._stream)
