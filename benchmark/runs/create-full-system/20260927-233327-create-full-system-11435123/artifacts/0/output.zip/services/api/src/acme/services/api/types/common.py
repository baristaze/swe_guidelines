"""The two bases of every wire type, and the error envelope."""

from pydantic import BaseModel, ConfigDict


class View(BaseModel):
    """Anything returned: a frozen snapshot, read from attributes, tolerant of what it does not name."""

    model_config = ConfigDict(frozen=True, from_attributes=True)


class RequestBody(BaseModel):
    """Anything accepted: a misspelled key is refused at once."""

    model_config = ConfigDict(extra="forbid")


class ErrorBody(View):
    code: str
    message: str
    request_id: str


class ErrorResponse(View):
    error: ErrorBody
