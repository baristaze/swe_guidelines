"""The tenancy routes, through the whole edge: sign-up, sign-in, the exchange, sign-out, keys, and the refusals."""

import asyncio
from datetime import timedelta
from pathlib import Path

import httpx
from api_harness import Api, api_settings, bearer

from acme.infra.impl.local import InfraLocalImpl
from acme.om.opcontext import OperatorPermission
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.tenancy.impl.credentials import digest
from acme.services.api.app import create_app
from acme.services.api.container import AppContainer


async def started(tmp_path: Path, **overrides: object):  # type: ignore[no-untyped-def]
    container = AppContainer.for_tests(StorageMemoryImpl(), InfraLocalImpl(tmp_path), api_settings(**overrides))
    return create_app(container), container


async def test_sign_up_answers_as_a_sign_in_and_enters_through_the_exchange(api: Api) -> None:
    signed = await api.sign_up()
    assert [m["role"] for m in signed["memberships"]] == ["owner"]
    headers = await api.session("second@acme.example", "second")
    org = await api.client.get("/v1/org", headers=headers)
    assert org.status_code == 200 and org.json()["slug"] == "second"


async def test_a_second_sign_up_with_the_same_email_is_refused(api: Api) -> None:
    await api.sign_up()
    again = await api.client.post(
        "/v1/auth/signup",
        json={
            "email": "owner@acme.example",
            "password": "pswd_1234",
            "display_name": "O",
            "org_name": "D",
            "org_slug": "d2",
        },
    )
    assert again.status_code == 409 and again.json()["error"]["code"] == "conflict"


async def test_a_closed_sign_up_answers_not_found(tmp_path: Path) -> None:
    app, _ = await started(tmp_path, signup_enabled=False)
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client,
    ):
        response = await client.post(
            "/v1/auth/signup",
            json={
                "email": "a@acme.example",
                "password": "pswd_1234",
                "display_name": "A",
                "org_name": "D",
                "org_slug": "dd",
            },
        )
    assert response.status_code == 404


async def test_memberships_list_under_the_sign_in_and_under_a_session(api: Api) -> None:
    signed = await api.sign_up()
    under_login = await api.client.get("/v1/auth/memberships", headers=bearer(signed["token"]))
    assert [m["org_slug"] for m in under_login.json()] == ["desk"]
    exchanged = await api.client.post(
        "/v1/auth/exchange", json={"org_id": signed["memberships"][0]["org_id"]}, headers=bearer(signed["token"])
    )
    under_session = await api.client.get("/v1/auth/memberships", headers=bearer(exchanged.json()["token"]))
    assert under_session.json() == under_login.json()


async def test_a_switch_ends_the_presented_session(api: Api) -> None:
    headers = await api.session()
    org_id = (await api.client.get("/v1/org", headers=headers)).json()["id"]
    switched = await api.client.post("/v1/auth/exchange", json={"org_id": org_id}, headers=headers)
    assert switched.status_code == 200
    assert (await api.client.get("/v1/org", headers=headers)).status_code == 401
    assert (await api.client.get("/v1/org", headers=bearer(switched.json()["token"]))).status_code == 200


async def test_sign_out_ends_the_credential(api: Api) -> None:
    headers = await api.session()
    assert (await api.client.post("/v1/auth/logout", headers=headers)).status_code == 204
    refused = await api.client.get("/v1/org", headers=headers)
    assert refused.status_code == 401 and refused.json()["error"]["code"] == "not_authenticated"


async def test_a_failed_sign_in_delays_the_next_attempt_for_that_email(api: Api) -> None:
    await api.sign_up()
    wrong = await api.client.post("/v1/auth/login", json={"email": "owner@acme.example", "password": "wrong-one"})
    assert wrong.status_code == 401
    right = await api.client.post("/v1/auth/login", json={"email": "owner@acme.example", "password": "pswd_1234"})
    assert right.status_code == 429 and int(right.headers["retry-after"]) >= 1


async def test_a_session_idle_past_its_lifetime_is_refused(api: Api) -> None:
    headers = await api.session()
    token = headers["Authorization"].removeprefix("Bearer ")
    storage = api.container.storage.get_tenancy_storage()
    session = await storage.read_session_by_digest(digest(token))
    assert session is not None
    idle = api.container.settings.session_idle_lifetime
    await storage.touch_session(session.identity_id, session.id, session.last_seen_at - idle - timedelta(minutes=1))
    assert (await api.client.get("/v1/org", headers=headers)).status_code == 401


async def test_a_session_past_its_absolute_lifetime_is_refused_while_in_use(tmp_path: Path) -> None:
    app, _ = await started(tmp_path, session_absolute_lifetime=timedelta(milliseconds=300))
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client,
    ):
        api = Api(app=app, client=client, container=app.state.container)
        headers = await api.session()
        assert (await client.get("/v1/org", headers=headers)).status_code == 200
        await asyncio.sleep(0.4)
        assert (await client.get("/v1/org", headers=headers)).status_code == 401


async def test_api_keys_are_capped_at_the_issuers_role_and_follow_it(api: Api) -> None:
    owner = await api.session()
    issued = await api.client.post(
        "/v1/api-keys", json={"name": "ci", "role": "admin"}, headers={**owner, "Idempotency-Key": "k-1"}
    )
    assert issued.status_code == 201 and issued.json()["token"].startswith("fjk_")
    admin_key = bearer(issued.json()["token"])
    above = await api.client.post("/v1/api-keys", json={"name": "up", "role": "owner"}, headers=admin_key)
    assert above.status_code == 403
    # A key issued by a member who is then demoted answers at the member's new role.
    member_key = await api.client.post("/v1/api-keys", json={"name": "m", "role": "admin"}, headers=admin_key)
    assert member_key.status_code == 201
    me = (await api.client.get("/v1/me", headers=owner)).json()
    members = (await api.client.get("/v1/members", headers=owner)).json()
    assert [m["role"] for m in members] == ["owner"] and me["name"] == "Owner"


async def test_a_replayed_create_answers_the_stored_row_without_its_secret(api: Api) -> None:
    owner = await api.session()
    headers = {**owner, "Idempotency-Key": "same-key"}
    first = await api.client.post("/v1/api-keys", json={"name": "ci", "role": "member"}, headers=headers)
    again = await api.client.post("/v1/api-keys", json={"name": "ci", "role": "member"}, headers=headers)
    assert again.status_code == 201 and again.headers["idempotent-replayed"] == "true"
    assert again.json()["id"] == first.json()["id"] and "token" not in again.json()
    other = await api.client.post("/v1/api-keys", json={"name": "other", "role": "member"}, headers=headers)
    assert other.status_code == 422


async def test_a_removed_members_keys_are_refused(api: Api) -> None:
    owner = await api.session()
    octx_headers, _ = await api.operator("prov@acme.example", OperatorPermission.WRITE)
    org_id = (await api.client.get("/v1/org", headers=owner)).json()["id"]
    added = await api.client.post(
        f"/v1/admin/orgs/{org_id}/members",
        json={"email": "admin@acme.example", "display_name": "Admin", "role": "admin", "password": "pswd_admin_1"},
        headers={**octx_headers, "Idempotency-Key": "add-admin"},
    )
    assert added.status_code == 201, added.text
    signed = await api.client.post("/v1/auth/login", json={"email": "admin@acme.example", "password": "pswd_admin_1"})
    session = await api.client.post(
        "/v1/auth/exchange", json={"org_id": org_id}, headers=bearer(signed.json()["token"])
    )
    admin = bearer(session.json()["token"])
    key = await api.client.post("/v1/api-keys", json={"name": "k", "role": "member"}, headers=admin)
    demoted = await api.client.patch(f"/v1/members/{added.json()['user_id']}", json={"role": "viewer"}, headers=owner)
    assert demoted.status_code == 200
    as_viewer = await api.client.post(
        "/v1/api-keys", json={"name": "x", "role": "viewer"}, headers=bearer(key.json()["token"])
    )
    assert as_viewer.status_code == 403  # the key now answers at its issuer's new role
    removed = await api.client.delete(f"/v1/members/{added.json()['user_id']}", headers=owner)
    assert removed.status_code == 204
    assert (await api.client.get("/v1/org", headers=bearer(key.json()["token"]))).status_code == 401


async def test_the_sign_in_route_is_rate_limited(tmp_path: Path) -> None:
    app, _ = await started(tmp_path, rate_limit_auth="2/60")
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client,
    ):
        codes = [
            (await client.post("/v1/auth/login", json={"email": f"x{i}@acme.example", "password": "p"})).status_code
            for i in range(3)
        ]
    assert codes[-1] == 429


async def test_the_error_envelope_carries_the_request_id(api: Api) -> None:
    response = await api.client.get("/v1/org", headers={"Authorization": "Bearer nonsense"})
    body = response.json()["error"]
    assert response.status_code == 401 and body["request_id"] == response.headers["x-request-id"]


async def test_an_unknown_app_is_refused(api: Api) -> None:
    response = await api.client.get("/v1/org", headers={"x-app-type": "scraper"})
    assert response.status_code == 401


async def test_the_twin_identity_provider_signs_in(api: Api) -> None:
    response = await api.client.post("/v1/auth/external", json={"code": "twin:google:reader@acme.example"})
    assert response.status_code == 200 and response.json()["memberships"] == []
