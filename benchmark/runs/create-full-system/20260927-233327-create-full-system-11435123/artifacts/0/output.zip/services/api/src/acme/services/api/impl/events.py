"""The in-process event feed."""

from acme.om.events.manager import EventsManagerInterface
from acme.om.opcontext import OpContext
from acme.services.api.services.events import EventServiceInterface
from acme.services.api.types.events import EventView


class EventServiceImpl(EventServiceInterface):
    def __init__(self, events: EventsManagerInterface) -> None:
        self._events = events

    async def get_events(self, ctx: OpContext, after_seq: int, limit: int) -> list[EventView]:
        return [EventView.model_validate(e) for e in await self._events.get_events(ctx, after_seq, limit)]
