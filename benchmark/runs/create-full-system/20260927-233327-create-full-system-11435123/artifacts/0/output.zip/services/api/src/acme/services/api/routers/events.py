"""The replay a reconnecting client uses: every event after the last seq it saw."""

from fastapi import APIRouter, Query

from acme.services.api.deps import EventSvc
from acme.services.api.gateway.auth import Ctx
from acme.services.api.types.common import ErrorResponse
from acme.services.api.types.events import EventView

router = APIRouter(tags=["events"], responses={"default": {"model": ErrorResponse}})


@router.get("/events")
async def get_events(
    ctx: Ctx, events: EventSvc, after_seq: int = Query(default=0, ge=0), limit: int = Query(default=100, ge=1, le=500)
) -> list[EventView]:
    return await events.get_events(ctx, after_seq, limit)
