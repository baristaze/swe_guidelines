"""The in-process journalists service: build the entity, call one manager operation, project onto the view."""

from uuid import UUID

from acme.om.base import utcnow
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.journalists.types.journalist import Journalist
from acme.om.opcontext import OpContext
from acme.services.api.services.journalists import JournalistServiceInterface
from acme.services.api.types.journalists import AddJournalistRequest, JournalistView, UpdateJournalistRequest


class JournalistServiceImpl(JournalistServiceInterface):
    def __init__(self, journalists: JournalistsManagerInterface) -> None:
        self._journalists = journalists

    async def get_journalists(self, ctx: OpContext, limit: int) -> list[JournalistView]:
        return [JournalistView.model_validate(j) for j in await self._journalists.get_journalists(ctx, limit)]

    async def get_journalist(self, ctx: OpContext, journalist_id: UUID) -> JournalistView:
        return JournalistView.model_validate(await self._journalists.get_journalist(ctx, journalist_id))

    async def create_journalist(self, ctx: OpContext, journalist_id: UUID, req: AddJournalistRequest) -> JournalistView:
        now = utcnow()
        journalist = Journalist(
            id=journalist_id,  # minted by the Idempotency-Key dependency before the marker
            created_at=now,
            updated_at=now,
            created_by=ctx.user_id,
            updated_by=ctx.user_id,
            display_name=req.display_name,
        )
        return JournalistView.model_validate(await self._journalists.create_journalist(ctx, journalist))

    async def update_journalist(
        self, ctx: OpContext, journalist_id: UUID, req: UpdateJournalistRequest
    ) -> JournalistView:
        # A partial update: the stored entity, the request's set fields copied onto it, the whole handed on.
        current = await self._journalists.get_journalist(ctx, journalist_id)
        updated = Journalist.model_validate({**current.model_dump(), **req.model_dump(exclude_unset=True)})
        return JournalistView.model_validate(await self._journalists.update_journalist(ctx, updated))

    async def delete_journalist(self, ctx: OpContext, journalist_id: UUID) -> None:
        await self._journalists.delete_journalist(ctx, journalist_id)
