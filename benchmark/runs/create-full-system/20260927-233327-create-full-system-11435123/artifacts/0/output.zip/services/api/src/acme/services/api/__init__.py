"""The API process: the gateway, every router, the realtime channel, and the operator plane."""
