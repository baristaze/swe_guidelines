"""The development seed's settings, local only: the org, its owner, and the two local operator identities."""

from pydantic_settings import BaseSettings, SettingsConfigDict


class SeedSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ACME_SEED_", env_file=".env", extra="ignore", env_ignore_empty=True)

    org_name: str = "Local Desk"
    org_slug: str = "local-desk"
    owner_email: str = "owner@acme.example"
    owner_password: str = "pswd_1234"
    operator_email: str = "operator@acme.example"
    operator_password: str = "pswd_operator_1234"
    provisioner_email: str = "provisioner@acme.example"
    provisioner_password: str = "pswd_provisioner_1234"
