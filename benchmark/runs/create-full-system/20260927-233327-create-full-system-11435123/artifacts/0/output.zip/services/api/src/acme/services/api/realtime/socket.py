"""The socket: `/v1/realtime/socket?ticket=...`, opened with a ticket and bounded by the session behind it.

On open it is subscribed to its tenant's stream and sends `hello` with the head seq. Inbound: ping (answered by
pong with the head seq), subscribe and unsubscribe. It closes at the session's expiry whatever the client does, on
SESSION_REVOKED for its session, and on the periodic recheck when the session or the membership ended.
"""

import asyncio
import contextlib
import logging
from datetime import datetime

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
from pydantic import ValidationError

from acme.om.base import utcnow
from acme.om.exceptions import NotAuthenticated
from acme.om.opcontext import OpContext
from acme.services.api.deps import RealtimeSvc
from acme.services.api.gateway.auth import SocketCtx, container_of
from acme.services.api.realtime.envelopes import (
    INBOUND,
    TENANT_STREAM,
    ErrorFrame,
    Hello,
    Ping,
    Pong,
    Subscribe,
    Subscribed,
    Unsubscribed,
)
from acme.services.api.realtime.hub import SocketHandle
from acme.services.api.realtime.send_buffer import SendBuffer
from acme.services.api.services.realtime import RealtimeServiceInterface

logger = logging.getLogger(__name__)

router = APIRouter(tags=["realtime"])

CLOSE_NORMAL = 1000
CLOSE_POLICY = 1008  # the credential behind the socket ended


@router.websocket("/realtime/socket")
async def realtime_socket(websocket: WebSocket, grant: SocketCtx, realtime: RealtimeSvc) -> None:
    await Socket(websocket, grant.ctx, grant.expires_at, realtime).run()


class Socket:
    def __init__(
        self, websocket: WebSocket, ctx: OpContext, expires_at: datetime, realtime: RealtimeServiceInterface
    ) -> None:
        settings = container_of(websocket).settings
        self._ws = websocket
        self._ctx = ctx
        self._expires_at = expires_at
        self._realtime = realtime
        self._hub = container_of(websocket).hub
        self._buffer = SendBuffer(settings.socket_buffer_size, settings.socket_control_lane_size)
        self._recheck_every = settings.session_recheck_interval.total_seconds()
        self._closing: asyncio.Future[tuple[int, str]] = asyncio.get_running_loop().create_future()

    def _close(self, code: int, reason: str) -> None:
        if not self._closing.done():
            self._closing.set_result((code, reason))

    async def run(self) -> None:
        await self._ws.accept()
        handle = SocketHandle(
            self._ctx.org_id,
            self._ctx.credential_id,
            self._buffer.push_stream,
            lambda reason: self._close(CLOSE_POLICY, reason),
        )
        unregister = self._hub.register(handle)
        self._buffer.push_control(Hello(head_seq=await self._realtime.get_head(self._ctx)))
        tasks = [
            asyncio.create_task(self._drain()),
            asyncio.create_task(self._read()),
            asyncio.create_task(self._expire()),
            asyncio.create_task(self._recheck()),
        ]
        try:
            code, reason = await self._closing
        finally:
            unregister()
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
        with contextlib.suppress(RuntimeError, WebSocketDisconnect):
            await self._ws.close(code=code, reason=reason)

    async def _drain(self) -> None:
        try:
            while True:
                frame = await self._buffer.next()
                await self._ws.send_text(frame.model_dump_json())
        except WebSocketDisconnect, RuntimeError:
            self._close(CLOSE_NORMAL, "client gone")

    async def _read(self) -> None:
        try:
            while True:
                raw = await self._ws.receive_text()
                try:
                    message = INBOUND.validate_json(raw)
                except ValidationError:
                    self._buffer.push_control(ErrorFrame(code="bad_frame", message="unknown frame"))
                    continue
                if isinstance(message, Ping):
                    self._buffer.push_control(Pong(head_seq=await self._realtime.get_head(self._ctx)))
                elif message.scope != TENANT_STREAM:
                    self._buffer.push_control(ErrorFrame(code="unknown_scope", message="one stream per tenant"))
                elif isinstance(message, Subscribe):
                    self._buffer.push_control(Subscribed(scope=message.scope))
                else:
                    self._buffer.push_control(Unsubscribed(scope=message.scope))
        except WebSocketDisconnect, RuntimeError:
            self._close(CLOSE_NORMAL, "client gone")

    async def _expire(self) -> None:
        await asyncio.sleep(max(0.0, (self._expires_at - utcnow()).total_seconds()))
        self._close(CLOSE_POLICY, "session expired")

    async def _recheck(self) -> None:
        while True:
            await asyncio.sleep(self._recheck_every)
            try:
                await self._realtime.recheck(self._ctx)
            except NotAuthenticated:
                self._close(CLOSE_POLICY, "session ended")
                return
