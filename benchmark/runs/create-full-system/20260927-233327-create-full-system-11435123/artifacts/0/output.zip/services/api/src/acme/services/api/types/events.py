"""The event feed's wire type: the replay a reconnecting client asks for after the last seq it saw."""

from datetime import datetime
from uuid import UUID

from acme.services.api.types.common import View


class EventView(View):
    """A hint: the identity of a change, never a field of the entity. The entity is read through its route."""

    seq: int
    kind: str
    target_id: UUID
    actor_id: UUID
    version: int | None = None


class RealtimeTicketView(View):
    """A single-use, short-lived pass to open the live channel."""

    ticket: str | None = None
    expires_at: datetime
