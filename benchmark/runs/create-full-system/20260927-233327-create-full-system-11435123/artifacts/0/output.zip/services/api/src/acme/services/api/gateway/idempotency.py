"""Edge idempotency on every creating POST, over the durable marker.

The dependency `begin`s the marker before the route runs: a replay answers with the stored outcome, a live attempt
is a conflict, another request under the same key is refused, and a released or stale marker is taken over on its
own id. The middleware `finish`es the marker with the outcome, or releases it on a 5xx or a 429, which a retry can
change. The outcome stored for a create that issued a secret leaves the secret out.
"""

import hashlib
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Annotated
from uuid import UUID

from fastapi import Depends, Request
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from acme.infra.observability import OUTCOMES
from acme.om.base import new_id
from acme.om.exceptions import Conflict, ValidationFailed
from acme.om.idempotency.types import BeginOutcome, IdempotencyMarker, MarkerOutcome
from acme.om.opcontext import OpContext, OperatorContext
from acme.om.tenancy.types import MarkerGuard
from acme.services.api.gateway.admin import OperatorCtx
from acme.services.api.gateway.auth import Ctx, container_of
from acme.services.api.gateway.errors import IdempotentReplay
from acme.services.api.gateway.ratelimit import credential_subject, enforce

if TYPE_CHECKING:
    from acme.om.idempotency.manager import IdempotencyManagerInterface

HEADER = "idempotency-key"
STATE_KEY = "idempotency_attempt"


@dataclass(frozen=True)
class CreateKey:
    """What a creating route receives: the id its create uses, minted before the marker, and the marker's guard."""

    target_id: UUID
    guard: MarkerGuard | None


@dataclass(frozen=True)
class Attempt:
    ctx: OpContext | OperatorContext
    marker: IdempotencyMarker
    secret_fields: tuple[str, ...]


async def _digest(request: Request) -> str:
    body = await request.body()
    return hashlib.sha256(request.method.encode() + b" " + request.url.path.encode() + b"\n" + body).hexdigest()


def _resolve(
    request: Request, outcome: MarkerOutcome, ctx: OpContext | OperatorContext, secrets: tuple[str, ...]
) -> CreateKey:
    marker = outcome.marker
    OUTCOMES.labels("idempotency", "begin", outcome.outcome.value).inc()
    if outcome.outcome == BeginOutcome.REPLAY:
        raise IdempotentReplay(marker.status or 200, marker.body or "")
    if outcome.outcome == BeginOutcome.RUNNING:
        raise Conflict("a request under this Idempotency-Key is still running")
    if outcome.outcome == BeginOutcome.MISMATCH:
        raise ValidationFailed("this Idempotency-Key was used with another request")
    request.state.idempotency_attempt = Attempt(ctx=ctx, marker=marker, secret_fields=secrets)
    assert marker.attempt_token is not None
    return CreateKey(
        target_id=marker.target_id, guard=MarkerGuard(marker_id=marker.id, attempt_token=marker.attempt_token)
    )


def idempotent(secret_fields: tuple[str, ...] = ()) -> Callable[..., Awaitable[CreateKey]]:
    """The dependency of a tenant route that writes a durable row; it also takes the write rate limit."""

    async def dependency(request: Request, ctx: Ctx) -> CreateKey:
        container = container_of(request)
        await enforce(request, "writes", credential_subject(ctx), container.rate_limits.writes)
        key = request.headers.get(HEADER)
        if not key:
            return CreateKey(target_id=new_id(), guard=None)
        outcome = await container.managers.idempotency.begin(ctx, key[:200], await _digest(request))
        return _resolve(request, outcome, ctx, secret_fields)

    return dependency


def idempotent_operator(secret_fields: tuple[str, ...] = ()) -> Callable[..., Awaitable[CreateKey]]:
    """The operator plane's: its marker is keyed under the system scope with the operator's identity."""

    async def dependency(request: Request, octx: OperatorCtx) -> CreateKey:
        key = request.headers.get(HEADER)
        if not key:
            return CreateKey(target_id=new_id(), guard=None)
        container = container_of(request)
        outcome = await container.managers.idempotency.begin_for_operator(octx, key[:200], await _digest(request))
        return _resolve(request, outcome, octx, secret_fields)

    return dependency


Created = Annotated[CreateKey, Depends(idempotent())]
CreatedWithSecret = Annotated[CreateKey, Depends(idempotent(secret_fields=("token",)))]
OperatorCreated = Annotated[CreateKey, Depends(idempotent_operator())]
OperatorCreatedWithSecret = Annotated[CreateKey, Depends(idempotent_operator(secret_fields=("token",)))]


def _stored(body: bytes, secrets: tuple[str, ...]) -> str:
    if not secrets or not body:
        return body.decode()
    try:
        data = json.loads(body)
    except ValueError:
        return body.decode()
    if isinstance(data, dict):
        data = {k: v for k, v in data.items() if k not in secrets}
    return json.dumps(data)


async def _settle(manager: IdempotencyManagerInterface, attempt: Attempt, status: int, body: bytes) -> None:
    ctx = attempt.ctx
    release = status >= 500 or status == 429
    if isinstance(ctx, OperatorContext):
        if release:
            await manager.release_for_operator(ctx, attempt.marker)
        else:
            await manager.finish_for_operator(ctx, attempt.marker, status, _stored(body, attempt.secret_fields))
    elif release:
        await manager.release(ctx, attempt.marker)
    else:
        await manager.finish(ctx, attempt.marker, status, _stored(body, attempt.secret_fields))
    OUTCOMES.labels("idempotency", "settle", "released" if release else "finished").inc()


class IdempotencyMiddleware:
    """Finishes or releases the marker a creating route began, from the response the route produced."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("method") != "POST":
            await self.app(scope, receive, send)
            return
        response: dict[str, object] = {"status": 500, "body": b""}

        async def capture(message: Message) -> None:
            if message["type"] == "http.response.start":
                response["status"] = message["status"]
            elif message["type"] == "http.response.body":
                response["body"] = bytes(response["body"]) + message.get("body", b"")  # type: ignore[arg-type]
            await send(message)

        try:
            await self.app(scope, receive, capture)
        except BaseException:
            await self._finish(scope, 500, b"")
            raise
        await self._finish(scope, int(response["status"]), bytes(response["body"]))  # type: ignore[arg-type]

    async def _finish(self, scope: Scope, status: int, body: bytes) -> None:
        attempt = scope.get("state", {}).get(STATE_KEY)
        if isinstance(attempt, Attempt):
            await _settle(scope["app"].state.container.managers.idempotency, attempt, status, body)
