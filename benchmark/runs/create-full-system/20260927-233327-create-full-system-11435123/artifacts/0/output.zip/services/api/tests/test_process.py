"""The process: the container builds once, every setting is documented and deployed, the realtime timeouts agree
with the shared file, and the entry point installs the trust store before a cloud TLS context opens."""

import json
import re
import subprocess
import sys
from pathlib import Path

from api_harness import Api

from acme.services.api.settings import ApiSettings

ROOT = Path(__file__).resolve().parents[3]


async def test_the_managers_build_once_for_any_number_of_requests(api: Api) -> None:
    before = api.container.managers
    services = api.container.services
    for _ in range(5):
        await api.client.get("/healthz")
        await api.client.get("/v1/org")
    assert api.container.managers is before and api.container.services is services
    assert services.get_tenancy_service() is services.get_tenancy_service()
    for field in ("storage", "infra", "integrations", "managers", "services", "hub", "rate_limits"):
        assert getattr(api.container, field) is not None


def test_every_setting_is_in_env_example() -> None:
    lines = (ROOT / ".env.example").read_text().splitlines()
    documented = {line.split("=", 1)[0] for line in lines if "=" in line and not line.startswith("#")}
    missing = {f"ACME_API_{name.upper()}" for name in ApiSettings.model_fields} - documented
    assert not missing, f"undocumented API settings: {sorted(missing)}"


def test_every_environment_sets_each_setting_without_a_local_default() -> None:
    required = [f"ACME_API_{name.upper()}" for name, field in ApiSettings.model_fields.items() if field.is_required()]
    assert required
    for root in sorted((ROOT / "deployment/terraform/environments").iterdir()):
        text = "\n".join(p.read_text() for p in root.glob("*.tf"))
        text += "\n".join(p.read_text() for p in (ROOT / "deployment/terraform/modules").rglob("*.tf"))
        for name in required:
            assert re.search(rf"\b{name}\b", text), f"{root.name} neither sets nor wires {name}"


def test_the_ping_interval_sits_inside_the_idle_timeout() -> None:
    timeouts = json.loads((ROOT / "deployment/realtime-timeouts.json").read_text())
    assert 0 < timeouts["ping_interval_seconds"] * 2 <= timeouts["idle_timeout_seconds"]
    for env in ("staging", "prod"):
        main = (ROOT / f"deployment/terraform/environments/{env}/main.tf").read_text()
        assert "realtime-timeouts.json" in main, f"{env} does not read the load balancer's idle timeout from the file"


def test_the_entry_point_installs_the_trust_store_before_a_cloud_tls_context() -> None:
    replay = (
        "import sys; sys.argv = ['acme-api', '--help'];"
        "from acme.services.api import entry;"
        "import truststore, ssl;"
        "entry_main = entry.main\n"
        "try:\n    entry_main()\nexcept SystemExit:\n    pass\n"
        "import botocore.httpsession\n"
        "ctx = botocore.httpsession.create_urllib3_context(); ctx.load_default_certs()\n"
        "assert ssl.SSLContext.__module__.startswith('truststore'), ssl.SSLContext.__module__\n"
        "print('ok')"
    )
    result = subprocess.run([sys.executable, "-c", replay], capture_output=True, text=True, timeout=60, cwd=ROOT)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip().endswith("ok")
