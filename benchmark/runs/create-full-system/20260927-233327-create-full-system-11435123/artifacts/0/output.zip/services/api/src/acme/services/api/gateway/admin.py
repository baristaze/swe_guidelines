"""The operator gate: the identity stage, admitted by the tenancy manager onto the operator plane."""

from typing import Annotated

from fastapi import Depends, Request

from acme.om.opcontext import OperatorContext
from acme.services.api.gateway.auth import Identity, container_of


async def operator_context(request: Request, identity: Identity) -> OperatorContext:
    """Admission is the manager's: a sign-in with a verified second factor, or an operator token, and never a
    tenant session or an API key; an allowlisted identity with no confirmed factor reaches enrolment alone."""
    return await container_of(request).managers.tenancy.admit_operator(identity)


OperatorCtx = Annotated[OperatorContext, Depends(operator_context)]
