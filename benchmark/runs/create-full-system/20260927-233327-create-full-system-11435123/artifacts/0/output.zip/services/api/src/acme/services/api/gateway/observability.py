"""The edge's middleware: the request id, the server span, the request metrics, the deadline, and admission."""

import asyncio
import json
import logging
import time
import uuid
from typing import Any

from opentelemetry import trace
from opentelemetry.propagate import extract
from prometheus_client import Counter, Histogram
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from acme.infra.observability import OUTCOMES, request_id_var
from acme.om.base import new_id

REQUESTS = Counter("acme_http_requests_total", "Requests by route template and status", ["route", "status"])
LATENCY = Histogram("acme_http_request_seconds", "Request latency by route template", ["route"])
OUTSIDE_BUDGETS = frozenset({"/healthz", "/readyz", "/metrics"})
READS = frozenset({"GET", "HEAD"})

tracer = trace.get_tracer("acme.api")
logger = logging.getLogger(__name__)


def parse_request_id(value: str | None) -> uuid.UUID:
    """An inbound id is accepted only when it parses as a UUID; otherwise one is minted."""
    if value:
        try:
            return uuid.UUID(value)
        except ValueError:
            pass
    return new_id()


def _header(scope: Scope, name: bytes) -> str | None:
    for key, value in scope.get("headers", []):
        if key == name:
            return value.decode("latin-1")
    return None


def route_template(scope: Scope) -> str:
    """The matched route's template with the prefix it was mounted under (`/v1/members/{user_id}`), never an id."""
    template = getattr(scope.get("route"), "path", None)
    if not template:
        return "unmatched"
    path = scope.get("path", "")
    static = template.split("{", 1)[0]
    at = path.find(static) if static else -1
    return (path[:at] if at > 0 else "") + template


async def _envelope(send: Send, status: int, code: str, message: str, request_id: str) -> None:
    body = json.dumps({"error": {"code": code, "message": message, "request_id": request_id}}).encode()
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [(b"content-type", b"application/json"), (b"x-request-id", request_id.encode())],
        }
    )
    await send({"type": "http.response.body", "body": body})


class RequestIdMiddleware:
    """Stamps the request id on the scope, the log context, the span, and the response, over HTTP and websockets."""

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] not in ("http", "websocket"):
            await self.app(scope, receive, send)
            return
        request_id = str(parse_request_id(_header(scope, b"x-request-id")))
        scope.setdefault("state", {})["request_id"] = request_id
        token = request_id_var.set(request_id)
        carrier = {k.decode("latin-1"): v.decode("latin-1") for k, v in scope.get("headers", [])}
        started = time.perf_counter()
        status = {"code": 500}

        async def stamped(message: Message) -> None:
            if message["type"] == "http.response.start":
                status["code"] = message["status"]
                message.setdefault("headers", []).append((b"x-request-id", request_id.encode()))
            await send(message)

        name = f"{scope.get('method', 'WS')} {scope.get('path', '')}"
        try:
            with tracer.start_as_current_span(name, context=extract(carrier), kind=trace.SpanKind.SERVER) as span:
                span.set_attribute("acme.request_id", request_id)
                await self.app(scope, receive, stamped)
                span.set_attribute("http.route", route_template(scope))
                span.set_attribute("http.status_code", status["code"])
        finally:
            request_id_var.reset(token)
            if scope["type"] == "http" and scope.get("path") not in OUTSIDE_BUDGETS:
                route = route_template(scope)
                elapsed = time.perf_counter() - started
                REQUESTS.labels(route, str(status["code"])).inc()
                LATENCY.labels(route).observe(elapsed)
                # One line per request, by route template and never the query string, with the request id.
                logger.info("%s %s %s %.1fms", scope.get("method"), route, status["code"], elapsed * 1000)


class DeadlineMiddleware:
    """Bounds every request at the deadline from settings; a request past it answers unavailable."""

    def __init__(self, app: ASGIApp, seconds: float) -> None:
        self.app = app
        self.seconds = seconds

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        started = {"sent": False}

        async def tracked(message: Message) -> None:
            if message["type"] == "http.response.start":
                started["sent"] = True
            await send(message)

        try:
            async with asyncio.timeout(self.seconds):
                await self.app(scope, receive, tracked)
        except TimeoutError:
            if not started["sent"]:
                await _envelope(
                    send, 503, "unavailable", "the request passed its deadline", scope["state"]["request_id"]
                )


class AdmissionMiddleware:
    """The process defending itself: a read budget and a write budget, refusing at once past either (fails closed).
    Health, readiness, and metrics stay outside both budgets."""

    def __init__(self, app: ASGIApp, max_reads: int, max_writes: int) -> None:
        self.app = app
        self.limits = {"read": max_reads, "write": max_writes}
        self.in_flight: dict[str, int] = {"read": 0, "write": 0}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http" or scope.get("path") in OUTSIDE_BUDGETS:
            await self.app(scope, receive, send)
            return
        lane = "read" if scope.get("method") in READS else "write"
        if self.in_flight[lane] >= self.limits[lane]:
            OUTCOMES.labels("admission", lane, "refused").inc()
            await _envelope(
                send, 503, "unavailable", "the process is at its admission bound", scope["state"]["request_id"]
            )
            return
        self.in_flight[lane] += 1
        try:
            await self.app(scope, receive, send)
        finally:
            self.in_flight[lane] -= 1


def current_traceparent() -> str | None:
    """The trace context of the current span as a `traceparent` header, or None under the no-op tracer."""
    context = trace.get_current_span().get_span_context()
    if not context.is_valid:
        return None
    return f"00-{context.trace_id:032x}-{context.span_id:016x}-{int(context.trace_flags):02x}"


def current_trace_id() -> str | None:
    context = trace.get_current_span().get_span_context()
    return f"{context.trace_id:032x}" if context.is_valid else None


def header(scope: dict[str, Any], name: str) -> str | None:
    return _header(scope, name.lower().encode())
