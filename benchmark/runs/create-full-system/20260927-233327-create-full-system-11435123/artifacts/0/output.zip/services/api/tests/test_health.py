"""Liveness answers with no I/O; readiness awaits storage under a deadline of its own and answers negative on it."""

import asyncio
from datetime import timedelta
from pathlib import Path

import httpx
from api_harness import Api, api_settings

from acme.infra.impl.local import InfraLocalImpl
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.services.api.app import create_app
from acme.services.api.container import AppContainer


class SlowStorage(StorageMemoryImpl):
    async def healthcheck(self) -> bool:
        await asyncio.sleep(5)
        return True


async def test_healthz_answers_with_the_version(api: Api) -> None:
    response = await api.client.get("/healthz")
    assert response.status_code == 200 and response.json()["status"] == "ok"
    assert "x-request-id" in response.headers


async def test_readyz_is_ready_over_healthy_storage(api: Api) -> None:
    assert (await api.client.get("/readyz")).json()["ready"] is True


async def test_readyz_answers_negative_when_storage_passes_its_deadline(tmp_path: Path) -> None:
    settings = api_settings(readyz_timeout=timedelta(milliseconds=50))
    app = create_app(AppContainer.for_tests(SlowStorage(), InfraLocalImpl(tmp_path), settings))
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client,
    ):
        response = await client.get("/readyz")
    assert response.status_code == 503 and response.json()["ready"] is False


async def test_metrics_counts_requests_by_route_template(api: Api) -> None:
    await api.client.get("/v1/org")
    body = (await api.client.get("/metrics")).text
    assert 'acme_http_requests_total{route="/v1/org",status="401"}' in body


async def test_an_inbound_request_id_is_kept_only_when_it_is_a_uuid(api: Api) -> None:
    kept = "0199f2d1-8a8b-7c1e-9b5a-2f6f1c1e4a10"
    assert (await api.client.get("/healthz", headers={"x-request-id": kept})).headers["x-request-id"] == kept
    minted = (await api.client.get("/healthz", headers={"x-request-id": "drop table"})).headers["x-request-id"]
    assert minted != "drop table" and len(minted) == 36


async def test_the_docs_are_served_only_locally(api: Api, tmp_path: Path) -> None:
    assert (await api.client.get("/docs")).status_code == 200


async def test_an_unexpected_failure_answers_the_envelope_with_the_request_id(tmp_path: Path) -> None:
    container = AppContainer.for_tests(StorageMemoryImpl(), InfraLocalImpl(tmp_path), api_settings())
    app = create_app(container)
    if container.infra_settings.environment != "local":
        return  # the diagnostics route is mounted only locally
    transport = httpx.ASGITransport(app=app, raise_app_exceptions=False)
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(transport=transport, base_url="http://test") as client,
    ):
        response = await client.post("/v1/diagnostics/failure", headers={"x-request-id": "not-a-uuid"})
    assert response.status_code == 500
    body = response.json()["error"]
    assert body["code"] == "internal_error" and body["request_id"] == response.headers["x-request-id"]
