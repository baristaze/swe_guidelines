"""A route that fails on purpose, mounted only when the settings name the local environment, so the telemetry
round trip can read an error event back by request id. No deployed process serves it."""

from fastapi import APIRouter

from acme.services.api.deps import DiagnosticsSvc
from acme.services.api.gateway.auth import Rctx
from acme.services.api.types.common import ErrorResponse

router = APIRouter(tags=["diagnostics"], responses={"default": {"model": ErrorResponse}})


@router.post("/diagnostics/failure", include_in_schema=False)
async def fail_on_purpose(rctx: Rctx, diagnostics: DiagnosticsSvc) -> None:
    return await diagnostics.fail_on_purpose(rctx)
