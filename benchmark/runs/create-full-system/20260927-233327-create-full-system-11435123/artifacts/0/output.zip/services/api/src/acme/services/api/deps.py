"""The service each router calls, resolved from the one container the process built."""

from typing import Annotated

from fastapi import Depends
from starlette.requests import HTTPConnection

from acme.services.api.services.admin import AdminServiceInterface
from acme.services.api.services.diagnostics import DiagnosticsServiceInterface
from acme.services.api.services.events import EventServiceInterface
from acme.services.api.services.journalists import JournalistServiceInterface
from acme.services.api.services.realtime import RealtimeServiceInterface
from acme.services.api.services.tenancy import TenancyServiceInterface


def tenancy_service(connection: HTTPConnection) -> TenancyServiceInterface:
    return connection.app.state.container.services.get_tenancy_service()


def admin_service(connection: HTTPConnection) -> AdminServiceInterface:
    return connection.app.state.container.services.get_admin_service()


def event_service(connection: HTTPConnection) -> EventServiceInterface:
    return connection.app.state.container.services.get_event_service()


def journalist_service(connection: HTTPConnection) -> JournalistServiceInterface:
    return connection.app.state.container.services.get_journalist_service()


def realtime_service(connection: HTTPConnection) -> RealtimeServiceInterface:
    return connection.app.state.container.services.get_realtime_service()


def diagnostics_service(connection: HTTPConnection) -> DiagnosticsServiceInterface:
    return connection.app.state.container.services.get_diagnostics_service()


TenancySvc = Annotated[TenancyServiceInterface, Depends(tenancy_service)]
AdminSvc = Annotated[AdminServiceInterface, Depends(admin_service)]
EventSvc = Annotated[EventServiceInterface, Depends(event_service)]
JournalistSvc = Annotated[JournalistServiceInterface, Depends(journalist_service)]
RealtimeSvc = Annotated[RealtimeServiceInterface, Depends(realtime_service)]
DiagnosticsSvc = Annotated[DiagnosticsServiceInterface, Depends(diagnostics_service)]
