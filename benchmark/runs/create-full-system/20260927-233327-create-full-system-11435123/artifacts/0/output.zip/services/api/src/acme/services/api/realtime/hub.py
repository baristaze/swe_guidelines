"""The process's sockets, routed by tenant. One subscription to the bus per process; every replica receives each
publish and filters by tenant. SESSION_REVOKED closes the sockets of that session and is never forwarded."""

import logging
from collections.abc import Callable
from uuid import UUID

from acme.infra.topics import SESSION_REVOKED, EntityChangedPayload, TopicPayload, Topics, TopicsInterface
from acme.services.api.realtime.envelopes import EventFrame

logger = logging.getLogger(__name__)


class SocketHandle:
    """What the hub needs of an open socket: its tenant, its credential, a stream push, and a close."""

    def __init__(
        self, org_id: UUID, credential_id: UUID, push: Callable[[EventFrame], None], close: Callable[[str], None]
    ) -> None:
        self.org_id = org_id
        self.credential_id = credential_id
        self.push = push
        self.close = close


class SocketHub:
    def __init__(self, topics: TopicsInterface) -> None:
        self._topics = topics
        self._sockets: dict[UUID, set[SocketHandle]] = {}
        self._unsubscribe: Callable[[], None] | None = None

    def start(self) -> None:
        self._unsubscribe = self._topics.subscribe(Topics.ENTITY_CHANGED, "realtime-hub", self._on_change)

    def close(self) -> None:
        if self._unsubscribe is not None:
            self._unsubscribe()
            self._unsubscribe = None

    def register(self, handle: SocketHandle) -> Callable[[], None]:
        self._sockets.setdefault(handle.org_id, set()).add(handle)

        def unregister() -> None:
            self._sockets.get(handle.org_id, set()).discard(handle)

        return unregister

    def open_sockets(self) -> int:
        return sum(len(s) for s in self._sockets.values())

    async def _on_change(self, payload: TopicPayload) -> None:
        if not isinstance(payload, EntityChangedPayload):
            return
        sockets = list(self._sockets.get(payload.org_id, ()))
        if payload.kind == SESSION_REVOKED:
            for handle in sockets:
                if handle.credential_id == payload.target_id:
                    handle.close("session revoked")
            return
        if payload.seq is None:
            return
        frame = EventFrame(
            seq=payload.seq,
            kind=payload.kind,
            target_id=payload.target_id,
            actor_id=payload.actor_id,
            version=payload.version,
        )
        for handle in sockets:
            handle.push(frame)
