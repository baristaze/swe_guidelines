"""The console script's first module: it installs the OS trust store before anything else is imported, then runs
the command line. Injecting the store after a library bound `ssl.SSLContext` would recurse at the first TLS context."""

import sys


def main() -> int:
    from acme.infra import trust

    trust.install()
    from acme.services.api import main as commands

    return commands.main(sys.argv[1:])


if __name__ == "__main__":
    sys.exit(main())
