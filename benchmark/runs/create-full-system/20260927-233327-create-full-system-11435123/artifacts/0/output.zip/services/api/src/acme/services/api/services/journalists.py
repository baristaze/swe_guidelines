"""The journalists service: the desk's journalist profiles."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.opcontext import OpContext
from acme.services.api.types.journalists import AddJournalistRequest, JournalistView, UpdateJournalistRequest


class JournalistServiceInterface(ABC):
    @abstractmethod
    async def get_journalists(self, ctx: OpContext, limit: int) -> list[JournalistView]: ...

    @abstractmethod
    async def get_journalist(self, ctx: OpContext, journalist_id: UUID) -> JournalistView: ...

    @abstractmethod
    async def create_journalist(
        self, ctx: OpContext, journalist_id: UUID, req: AddJournalistRequest
    ) -> JournalistView: ...

    @abstractmethod
    async def update_journalist(
        self, ctx: OpContext, journalist_id: UUID, req: UpdateJournalistRequest
    ) -> JournalistView: ...

    @abstractmethod
    async def delete_journalist(self, ctx: OpContext, journalist_id: UUID) -> None: ...
