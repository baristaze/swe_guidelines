"""The harness of the API suites: the app over the memory roots, every backend a twin."""

import time
from dataclasses import dataclass
from typing import Any

import httpx
from cryptography.fernet import Fernet
from fastapi import FastAPI

from acme.om.opcontext import OperatorPermission
from acme.om.tenancy import rules
from acme.om.tenancy.impl.credentials import TotpCipher
from acme.services.api.container import AppContainer
from acme.services.api.main import _command_stage
from acme.services.api.settings import ApiSettings


def api_settings(**overrides: Any) -> ApiSettings:
    values: dict[str, Any] = {
        "_env_file": None,
        "totp_encryption_key": Fernet.generate_key().decode(),
        "internal_signing_key": "test-internal-signing-key",
        "rate_limit_auth": "1000/60",
        "rate_limit_writes": "1000/60",
        **overrides,
    }
    return ApiSettings(**values)


@dataclass
class Api:
    app: FastAPI
    client: httpx.AsyncClient
    container: AppContainer

    async def sign_up(self, email: str = "owner@acme.example", slug: str = "desk") -> dict[str, Any]:
        response = await self.client.post(
            "/v1/auth/signup",
            json={
                "email": email,
                "password": "pswd_1234",
                "display_name": "Owner",
                "org_name": "Desk",
                "org_slug": slug,
            },
        )
        assert response.status_code == 200, response.text
        return response.json()

    async def session(self, email: str = "owner@acme.example", slug: str = "desk") -> dict[str, str]:
        """Signs up, exchanges the sign-in for a tenant session, and answers the headers that carry it."""
        signed = await self.sign_up(email, slug)
        exchanged = await self.client.post(
            "/v1/auth/exchange",
            json={"org_id": signed["memberships"][0]["org_id"]},
            headers=bearer(signed["token"]),
        )
        assert exchanged.status_code == 200, exchanged.text
        return bearer(exchanged.json()["token"])

    async def operator(
        self, email: str, permission: OperatorPermission, *, enrol: bool = True
    ) -> tuple[dict[str, str], str]:
        """An allowlisted operator who signed in with a verified second factor; answers the headers and the email."""
        tenancy = self.container.managers.tenancy
        await tenancy.ensure_identity(_command_stage(), email, "pswd_operator", "Operator")
        await tenancy.grant_operator(_command_stage(), email, permission)
        signed = await self.client.post("/v1/auth/login", json={"email": email, "password": "pswd_operator"})
        headers = bearer(signed.json()["token"])
        if not enrol:
            return headers, email
        await self.client.post("/v1/admin/me/totp", headers=headers)
        code = await self.totp_code(email)
        confirmed = await self.client.post("/v1/admin/me/totp/confirm", json={"totp_code": code}, headers=headers)
        assert confirmed.status_code == 204, confirmed.text
        code = await self.totp_code(email, fresh=True)  # the confirmation spent this step; the next step answers
        signed = await self.client.post(
            "/v1/auth/login", json={"email": email, "password": "pswd_operator", "totp_code": code}
        )
        assert signed.status_code == 200, signed.text
        return bearer(signed.json()["token"]), email

    async def totp_code(self, email: str, *, fresh: bool = False) -> str:
        """The code the operator's authenticator would show; `fresh` moves past the step a code was used in."""
        from acme.om.tenancy.impl.credentials import email_digest

        storage = self.container.storage.get_tenancy_storage()
        identity = await storage.read_identity_by_email_digest(email_digest(email))
        assert identity is not None and identity.totp_secret is not None
        secret = TotpCipher(self.container.settings.totp_encryption_key).decrypt(identity.totp_secret)
        assert secret is not None
        step = rules.totp_step(time.time())
        if fresh and identity.totp_last_step is not None and step <= identity.totp_last_step:
            step = identity.totp_last_step + 1  # within the one step of drift the check allows
        return rules.totp_code(secret, step)


def bearer(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}
