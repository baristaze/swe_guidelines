"""The in-process diagnostics service."""

from acme.om.opcontext import RequestContext
from acme.services.api.services.diagnostics import DiagnosticsServiceInterface


class DiagnosticsServiceImpl(DiagnosticsServiceInterface):
    async def fail_on_purpose(self, rctx: RequestContext) -> None:
        raise RuntimeError(f"a deliberate failure for request {rctx.request_id}")
