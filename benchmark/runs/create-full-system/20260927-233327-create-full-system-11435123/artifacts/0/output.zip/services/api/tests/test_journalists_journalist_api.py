"""The journalists routes, through the whole edge: create with a key, list, read, rename, delete, and refusals."""

from api_harness import Api, bearer


async def add(api: Api, headers: dict[str, str], name: str = "Reporter", key: str = "j-1") -> dict:  # type: ignore[type-arg]
    response = await api.client.post(
        "/v1/journalists", json={"display_name": name}, headers={**headers, "Idempotency-Key": key}
    )
    assert response.status_code == 201, response.text
    return response.json()


async def test_create_list_read_rename_delete(api: Api) -> None:
    owner = await api.session()
    made = await add(api, owner)
    assert made["display_name"] == "Reporter" and set(made) == {"id", "display_name", "created_at", "updated_at"}
    listed = await api.client.get("/v1/journalists", headers=owner)
    assert [j["id"] for j in listed.json()] == [made["id"]]
    read = await api.client.get(f"/v1/journalists/{made['id']}", headers=owner)
    assert read.status_code == 200 and read.json() == made
    renamed = await api.client.patch(f"/v1/journalists/{made['id']}", json={"display_name": "Renamed"}, headers=owner)
    assert renamed.status_code == 200 and renamed.json()["display_name"] == "Renamed"
    unchanged = await api.client.patch(f"/v1/journalists/{made['id']}", json={}, headers=owner)
    assert unchanged.json()["display_name"] == "Renamed"
    deleted = await api.client.delete(f"/v1/journalists/{made['id']}", headers=owner)
    assert deleted.status_code == 204
    assert (await api.client.get(f"/v1/journalists/{made['id']}", headers=owner)).status_code == 404
    assert (await api.client.get("/v1/journalists", headers=owner)).json() == []


async def test_the_post_takes_an_idempotency_key_and_a_replay_creates_one(api: Api) -> None:
    owner = await api.session()
    first = await add(api, owner, key="same")
    again = await api.client.post(
        "/v1/journalists", json={"display_name": "Reporter"}, headers={**owner, "Idempotency-Key": "same"}
    )
    assert again.status_code == 201 and again.json()["id"] == first["id"]
    assert len((await api.client.get("/v1/journalists", headers=owner)).json()) == 1
    missing = await api.client.post("/v1/journalists", json={"display_name": "No key"}, headers=owner)
    assert missing.status_code == 201  # a key is optional: without one, a retry may create a second profile


async def test_a_null_display_name_and_an_unknown_field_are_refused(api: Api) -> None:
    owner = await api.session()
    made = await add(api, owner)
    cleared = await api.client.patch(f"/v1/journalists/{made['id']}", json={"display_name": None}, headers=owner)
    assert cleared.status_code == 422
    unknown = await api.client.patch(f"/v1/journalists/{made['id']}", json={"created_by": made["id"]}, headers=owner)
    assert unknown.status_code == 422
    empty = await api.client.post(
        "/v1/journalists", json={"display_name": ""}, headers={**owner, "Idempotency-Key": "empty"}
    )
    assert empty.status_code == 422


async def test_another_desk_sees_none_of_it(api: Api) -> None:
    owner = await api.session()
    made = await add(api, owner)
    other = await api.session("other@acme.example", "other")
    assert (await api.client.get("/v1/journalists", headers=other)).json() == []
    assert (await api.client.get(f"/v1/journalists/{made['id']}", headers=other)).status_code == 404
    patched = await api.client.patch(f"/v1/journalists/{made['id']}", json={"display_name": "X"}, headers=other)
    assert patched.status_code == 404
    assert (await api.client.delete(f"/v1/journalists/{made['id']}", headers=other)).status_code == 404


async def test_a_viewer_key_reads_and_is_refused_a_write(api: Api) -> None:
    owner = await api.session()
    made = await add(api, owner)
    issued = await api.client.post(
        "/v1/api-keys", json={"name": "v", "role": "viewer"}, headers={**owner, "Idempotency-Key": "k-v"}
    )
    viewer = bearer(issued.json()["token"])
    assert (await api.client.get("/v1/journalists", headers=viewer)).status_code == 200
    refused = await api.client.post(
        "/v1/journalists", json={"display_name": "X"}, headers={**viewer, "Idempotency-Key": "v-1"}
    )
    assert refused.status_code == 403
    assert (await api.client.delete(f"/v1/journalists/{made['id']}", headers=viewer)).status_code == 403


async def test_a_change_is_numbered_in_the_events_with_ids_only(api: Api) -> None:
    owner = await api.session()
    made = await add(api, owner, name="Secret Name")
    events = (await api.client.get("/v1/events", headers=owner)).json()
    change = next(e for e in events if e["kind"] == "journalists.journalist.created")
    assert change["target_id"] == made["id"] and "Secret Name" not in str(events)
