"""The realtime channel: one socket per app, hints only, bounded by its session, replayed from the event record."""
