"""The network-layer root: one getter per service this process hosts."""

from abc import ABC, abstractmethod

from acme.services.api.services.admin import AdminServiceInterface
from acme.services.api.services.diagnostics import DiagnosticsServiceInterface
from acme.services.api.services.events import EventServiceInterface
from acme.services.api.services.journalists import JournalistServiceInterface
from acme.services.api.services.realtime import RealtimeServiceInterface
from acme.services.api.services.tenancy import TenancyServiceInterface


class ServicesInterface(ABC):
    @abstractmethod
    def get_tenancy_service(self) -> TenancyServiceInterface: ...

    @abstractmethod
    def get_admin_service(self) -> AdminServiceInterface: ...

    @abstractmethod
    def get_event_service(self) -> EventServiceInterface: ...

    @abstractmethod
    def get_journalist_service(self) -> JournalistServiceInterface: ...

    @abstractmethod
    def get_realtime_service(self) -> RealtimeServiceInterface: ...

    @abstractmethod
    def get_diagnostics_service(self) -> DiagnosticsServiceInterface: ...
