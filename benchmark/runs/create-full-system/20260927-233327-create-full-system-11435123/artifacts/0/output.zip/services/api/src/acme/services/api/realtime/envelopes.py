"""The typed frames of the socket, discriminated by `type`. The portal's envelopes.ts mirrors them by hand.

Control frames report the socket itself (hello, pong, subscribed, unsubscribed, error); the one stream frame,
`event`, is a hint: the identity of a change, never a field of the entity.
"""

from typing import Annotated, Literal
from uuid import UUID

from pydantic import Field, TypeAdapter

from acme.services.api.types.common import RequestBody, View


class Hello(View):
    type: Literal["hello"] = "hello"
    head_seq: int


class Pong(View):
    type: Literal["pong"] = "pong"
    head_seq: int


class Subscribed(View):
    type: Literal["subscribed"] = "subscribed"
    scope: str


class Unsubscribed(View):
    type: Literal["unsubscribed"] = "unsubscribed"
    scope: str


class ErrorFrame(View):
    type: Literal["error"] = "error"
    code: str
    message: str


class EventFrame(View):
    type: Literal["event"] = "event"
    seq: int
    kind: str
    target_id: UUID
    actor_id: UUID
    version: int | None = None


ControlFrame = Hello | Pong | Subscribed | Unsubscribed | ErrorFrame


class Ping(RequestBody):
    type: Literal["ping"]


class Subscribe(RequestBody):
    """Names a visibility scope; only meaningful when the product keeps more than one stream. Never a kind."""

    type: Literal["subscribe"]
    scope: str


class Unsubscribe(RequestBody):
    type: Literal["unsubscribe"]
    scope: str


Inbound = Annotated[Ping | Subscribe | Unsubscribe, Field(discriminator="type")]
INBOUND: TypeAdapter[Ping | Subscribe | Unsubscribe] = TypeAdapter(Inbound)

TENANT_STREAM = "tenant"  # the default and only stream: a socket is subscribed to it when it opens
