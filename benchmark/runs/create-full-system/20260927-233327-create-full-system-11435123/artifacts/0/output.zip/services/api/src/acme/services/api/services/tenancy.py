"""The tenancy service: sign-up, sign-in, the exchange, sign-out, members, and API keys, on the wire."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.integrations.identity import ExternalIdentity
from acme.om.opcontext import IdentityContext, OpContext, RequestContext
from acme.om.tenancy.types import MarkerGuard
from acme.services.api.types.tenancy import (
    AddApiKeyRequest,
    ApiKeyView,
    ExchangeRequest,
    IssuedApiKeyView,
    IssuedSessionView,
    IssuedSignInView,
    MembershipChoiceView,
    MembershipView,
    MemberView,
    OrgView,
    SignInRequest,
    SignUpRequest,
    UpdateMemberRoleRequest,
    UpdateUserRequest,
    UserView,
)


class TenancyServiceInterface(ABC):
    @abstractmethod
    async def sign_up(self, rctx: RequestContext, req: SignUpRequest) -> IssuedSignInView: ...

    @abstractmethod
    async def sign_in(self, rctx: RequestContext, req: SignInRequest) -> IssuedSignInView: ...

    @abstractmethod
    async def sign_in_external(self, rctx: RequestContext, identity: ExternalIdentity) -> IssuedSignInView: ...

    @abstractmethod
    async def get_memberships(self, ictx: IdentityContext, limit: int) -> list[MembershipChoiceView]: ...

    @abstractmethod
    async def exchange(self, ictx: IdentityContext, req: ExchangeRequest) -> IssuedSessionView: ...

    @abstractmethod
    async def sign_out(self, ictx: IdentityContext) -> None: ...

    @abstractmethod
    async def get_org(self, ctx: OpContext) -> OrgView: ...

    @abstractmethod
    async def get_members(self, ctx: OpContext, limit: int) -> list[MemberView]: ...

    @abstractmethod
    async def update_member_role(
        self, ctx: OpContext, user_id: UUID, req: UpdateMemberRoleRequest
    ) -> MembershipView: ...

    @abstractmethod
    async def remove_member(self, ctx: OpContext, user_id: UUID) -> None: ...

    @abstractmethod
    async def get_me(self, ctx: OpContext) -> UserView: ...

    @abstractmethod
    async def update_me(self, ctx: OpContext, req: UpdateUserRequest) -> UserView: ...

    @abstractmethod
    async def create_api_key(
        self, ctx: OpContext, key_id: UUID, guard: MarkerGuard | None, req: AddApiKeyRequest
    ) -> IssuedApiKeyView: ...

    @abstractmethod
    async def get_api_keys(self, ctx: OpContext, limit: int) -> list[ApiKeyView]: ...

    @abstractmethod
    async def revoke_api_key(self, ctx: OpContext, key_id: UUID) -> None: ...
