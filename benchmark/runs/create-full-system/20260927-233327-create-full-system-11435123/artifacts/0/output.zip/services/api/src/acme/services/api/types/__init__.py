"""The wire types, one module per namespace: views and requests, hand-written, never derived from the OM."""
