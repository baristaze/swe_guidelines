"""The journalists routes: the desk's journalist profiles."""

from uuid import UUID

from fastapi import APIRouter, Query, status

from acme.services.api.deps import JournalistSvc
from acme.services.api.gateway.auth import Ctx
from acme.services.api.gateway.idempotency import Created
from acme.services.api.types.common import ErrorResponse
from acme.services.api.types.journalists import AddJournalistRequest, JournalistView, UpdateJournalistRequest

router = APIRouter(tags=["journalists"], responses={"default": {"model": ErrorResponse}})


@router.get("/journalists")
async def get_journalists(
    ctx: Ctx, journalists: JournalistSvc, limit: int = Query(default=50, ge=1, le=500)
) -> list[JournalistView]:
    return await journalists.get_journalists(ctx, limit)


@router.get("/journalists/{journalist_id}")
async def get_journalist(ctx: Ctx, journalist_id: UUID, journalists: JournalistSvc) -> JournalistView:
    return await journalists.get_journalist(ctx, journalist_id)


@router.post("/journalists", status_code=status.HTTP_201_CREATED)
async def create_journalist(
    ctx: Ctx, created: Created, body: AddJournalistRequest, journalists: JournalistSvc
) -> JournalistView:
    return await journalists.create_journalist(ctx, created.target_id, body)


@router.patch("/journalists/{journalist_id}")
async def update_journalist(
    ctx: Ctx, journalist_id: UUID, body: UpdateJournalistRequest, journalists: JournalistSvc
) -> JournalistView:
    return await journalists.update_journalist(ctx, journalist_id, body)


@router.delete("/journalists/{journalist_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_journalist(ctx: Ctx, journalist_id: UUID, journalists: JournalistSvc) -> None:
    return await journalists.delete_journalist(ctx, journalist_id)
