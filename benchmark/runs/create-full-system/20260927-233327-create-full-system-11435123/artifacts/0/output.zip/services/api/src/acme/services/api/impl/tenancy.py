"""The in-process tenancy service: builds the arguments, calls one manager operation, projects the view."""

from datetime import timedelta
from uuid import UUID

from acme.integrations.identity import ExternalIdentity
from acme.om.opcontext import IdentityContext, OpContext, RequestContext
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.om.tenancy.types import MarkerGuard, SignedIn
from acme.services.api.services.tenancy import TenancyServiceInterface
from acme.services.api.types.tenancy import (
    AddApiKeyRequest,
    ApiKeyView,
    ExchangeRequest,
    IssuedApiKeyView,
    IssuedSessionView,
    IssuedSignInView,
    MembershipChoiceView,
    MembershipView,
    MemberView,
    OrgView,
    SignInRequest,
    SignUpRequest,
    UpdateMemberRoleRequest,
    UpdateUserRequest,
    UserView,
)


def _signed_in(signed: SignedIn) -> IssuedSignInView:
    return IssuedSignInView(
        token=signed.credential.token,
        expires_at=signed.credential.expires_at,
        memberships=tuple(MembershipChoiceView.model_validate(m) for m in signed.memberships),
    )


class TenancyServiceImpl(TenancyServiceInterface):
    def __init__(self, tenancy: TenancyManagerInterface) -> None:
        self._tenancy = tenancy

    async def sign_up(self, rctx: RequestContext, req: SignUpRequest) -> IssuedSignInView:
        signed = await self._tenancy.sign_up(
            rctx, req.email, req.password, req.display_name, req.org_name, req.org_slug
        )
        return _signed_in(signed)

    async def sign_in(self, rctx: RequestContext, req: SignInRequest) -> IssuedSignInView:
        return _signed_in(await self._tenancy.sign_in(rctx, req.email, req.password, req.totp_code))

    async def sign_in_external(self, rctx: RequestContext, identity: ExternalIdentity) -> IssuedSignInView:
        signed = await self._tenancy.sign_in_external(
            rctx, identity.issuer, identity.subject, identity.email, identity.display_name
        )
        return _signed_in(signed)

    async def get_memberships(self, ictx: IdentityContext, limit: int) -> list[MembershipChoiceView]:
        return [MembershipChoiceView.model_validate(m) for m in await self._tenancy.get_memberships(ictx, limit)]

    async def exchange(self, ictx: IdentityContext, req: ExchangeRequest) -> IssuedSessionView:
        issued = await self._tenancy.exchange(ictx, req.org_id)
        return IssuedSessionView(token=issued.token, expires_at=issued.expires_at)

    async def sign_out(self, ictx: IdentityContext) -> None:
        await self._tenancy.sign_out(ictx)

    async def get_org(self, ctx: OpContext) -> OrgView:
        return OrgView.model_validate(await self._tenancy.get_org(ctx))

    async def get_members(self, ctx: OpContext, limit: int) -> list[MemberView]:
        return [MemberView.model_validate(m) for m in await self._tenancy.get_members(ctx, limit)]

    async def update_member_role(self, ctx: OpContext, user_id: UUID, req: UpdateMemberRoleRequest) -> MembershipView:
        return MembershipView.model_validate(await self._tenancy.update_member_role(ctx, user_id, req.role))

    async def remove_member(self, ctx: OpContext, user_id: UUID) -> None:
        await self._tenancy.remove_member(ctx, user_id)

    async def get_me(self, ctx: OpContext) -> UserView:
        return UserView.model_validate(await self._tenancy.get_user(ctx, ctx.user_id))

    async def update_me(self, ctx: OpContext, req: UpdateUserRequest) -> UserView:
        # A partial update: the stored entity, the request's set fields copied onto it, the whole handed on.
        current = await self._tenancy.get_user(ctx, ctx.user_id)
        changes = req.model_dump(exclude_unset=True)
        updated = type(current).model_validate({**current.model_dump(), **changes})
        return UserView.model_validate(await self._tenancy.update_user(ctx, updated))

    async def create_api_key(
        self, ctx: OpContext, key_id: UUID, guard: MarkerGuard | None, req: AddApiKeyRequest
    ) -> IssuedApiKeyView:
        issued = await self._tenancy.create_api_key(
            ctx, key_id, req.name, req.role, timedelta(seconds=req.expires_in), guard
        )
        key = issued.api_key
        return IssuedApiKeyView(id=key.id, name=key.name, role=key.role, expires_at=key.expires_at, token=issued.token)

    async def get_api_keys(self, ctx: OpContext, limit: int) -> list[ApiKeyView]:
        return [ApiKeyView.model_validate(k) for k in await self._tenancy.get_api_keys(ctx, limit)]

    async def revoke_api_key(self, ctx: OpContext, key_id: UUID) -> None:
        await self._tenancy.revoke_api_key(ctx, key_id)
