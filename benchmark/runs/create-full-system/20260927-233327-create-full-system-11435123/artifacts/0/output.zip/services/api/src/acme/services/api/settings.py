"""The API process's own settings. The database settings are the OM's StorageSettings, the backends InfraSettings."""

from datetime import timedelta

from pydantic_settings import BaseSettings, SettingsConfigDict


class ApiSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ACME_API_", env_file=".env", extra="ignore", env_ignore_empty=True)

    host: str = "0.0.0.0"  # noqa: S104 - the container's interface; the host process binds what the start script says
    port: int = 8000
    public_url: str = "http://localhost:8000"
    namespaces: tuple[str, ...] = ()  # the routers this process mounts; empty mounts every hosted one
    allowed_origins: tuple[str, ...] = ()  # the browser apps' origins; empty refuses every cross-origin request

    # process credentials, injected at start from the secret store; no default, a fixed local value in .env.example
    totp_encryption_key: str
    internal_signing_key: str

    request_deadline: timedelta = timedelta(seconds=15)
    readyz_timeout: timedelta = timedelta(seconds=2)  # shorter than the interval anything polls /readyz on
    max_in_flight_reads: int = 256
    max_in_flight_writes: int = 64

    signup_enabled: bool = True
    signin_delay_base: timedelta = timedelta(seconds=1)
    signin_delay_cap: timedelta = timedelta(minutes=15)
    session_idle_lifetime: timedelta = timedelta(hours=24)
    session_absolute_lifetime: timedelta = timedelta(days=7)
    login_lifetime: timedelta = timedelta(minutes=15)
    api_key_max_expires_in: timedelta = timedelta(days=365)
    operator_token_max_expires_in: timedelta = timedelta(seconds=3600)
    socket_ticket_lifetime: timedelta = timedelta(seconds=30)
    page_size: int = 100
    purge_batch: int = 500

    idempotency_lease: timedelta = timedelta(seconds=30)
    idempotency_retention: timedelta = timedelta(days=1)
    outbox_retention: timedelta = timedelta(days=14)
    item_retention: timedelta = timedelta(days=7)  # done and failed work items; the worker reads the same setting

    rate_limit_auth: str = "20/60"  # sign-up, sign-in, exchange: per client address, per window in seconds
    rate_limit_writes: str = "600/60"  # creating routes: per credential

    session_recheck_interval: timedelta = timedelta(minutes=5)
    socket_buffer_size: int = 256  # the stream lane
    socket_control_lane_size: int = 16
