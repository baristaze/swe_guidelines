"""The event feed: the replay a reconnecting client asks for."""

from abc import ABC, abstractmethod

from acme.om.opcontext import OpContext
from acme.services.api.types.events import EventView


class EventServiceInterface(ABC):
    @abstractmethod
    async def get_events(self, ctx: OpContext, after_seq: int, limit: int) -> list[EventView]: ...
