"""The ticket route: a single-use, short-lived pass to open the socket, minted by an authenticated request."""

from fastapi import APIRouter, Depends, status

from acme.services.api.deps import RealtimeSvc
from acme.services.api.gateway.auth import Ctx
from acme.services.api.gateway.idempotency import CreateKey, idempotent
from acme.services.api.types.common import ErrorResponse
from acme.services.api.types.events import RealtimeTicketView

router = APIRouter(tags=["realtime"], responses={"default": {"model": ErrorResponse}})

TicketCreated = Depends(idempotent(secret_fields=("ticket",)))


@router.post("/realtime/tickets", status_code=status.HTTP_201_CREATED)
async def issue_ticket(ctx: Ctx, realtime: RealtimeSvc, created: CreateKey = TicketCreated) -> RealtimeTicketView:
    return await realtime.issue_ticket(ctx)
