"""The socket: hello with the head seq, a write in its tenant reaching it unasked, pong with the head seq, hints only,
and a close at the session's expiry, on SESSION_REVOKED, and on the recheck when the revocation was dropped."""

import json
import time
from datetime import timedelta
from pathlib import Path
from typing import Any

import pytest
from api_harness import api_settings
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

from acme.infra.impl.local import InfraLocalImpl
from acme.infra.topics.memory import TopicsMemoryImpl
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.tenancy.impl.credentials import digest
from acme.services.api.app import create_app
from acme.services.api.container import AppContainer

SIGNUP = {
    "email": "owner@acme.example",
    "password": "pswd_1234",
    "display_name": "O",
    "org_name": "D",
    "org_slug": "desk",
}


def client_for(tmp_path: Path, **overrides: Any) -> TestClient:
    container = AppContainer.for_tests(StorageMemoryImpl(), InfraLocalImpl(tmp_path), api_settings(**overrides))
    return TestClient(create_app(container))


def session(client: TestClient) -> dict[str, str]:
    signed = client.post("/v1/auth/signup", json=SIGNUP).json()
    token = client.post(
        "/v1/auth/exchange",
        json={"org_id": signed["memberships"][0]["org_id"]},
        headers={"Authorization": f"Bearer {signed['token']}"},
    ).json()["token"]
    return {"Authorization": f"Bearer {token}"}


def ticket(client: TestClient, headers: dict[str, str]) -> str:
    response = client.post("/v1/realtime/tickets", headers=headers)
    assert response.status_code == 201, response.text
    return response.json()["ticket"]


def keep_pinging(ws: Any) -> None:
    while True:
        ws.send_text(json.dumps({"type": "ping"}))
        ws.receive_json()


def test_hello_then_an_unasked_write_then_pong(tmp_path: Path) -> None:
    with client_for(tmp_path) as client:
        headers = session(client)
        with client.websocket_connect(f"/v1/realtime/socket?ticket={ticket(client, headers)}") as ws:
            hello = ws.receive_json()
            assert hello == {"type": "hello", "head_seq": hello["head_seq"]}
            renamed = client.patch("/v1/me", json={"name": "Renamed"}, headers=headers)
            assert renamed.status_code == 200
            frame = ws.receive_json()
            assert frame["type"] == "event" and frame["kind"] == "tenancy.user.updated"
            assert set(frame) == {"type", "seq", "kind", "target_id", "actor_id", "version"}  # a hint, no field
            ws.send_text(json.dumps({"type": "ping"}))
            assert ws.receive_json() == {"type": "pong", "head_seq": frame["seq"]}


def test_a_ticket_opens_one_socket_only(tmp_path: Path) -> None:
    with client_for(tmp_path) as client:
        headers = session(client)
        once = ticket(client, headers)
        with client.websocket_connect(f"/v1/realtime/socket?ticket={once}") as ws:
            ws.receive_json()
        with pytest.raises(WebSocketDisconnect), client.websocket_connect(f"/v1/realtime/socket?ticket={once}") as ws:
            ws.receive_json()


def test_sign_out_closes_the_socket_by_session_revoked(tmp_path: Path) -> None:
    with client_for(tmp_path) as client:
        headers = session(client)
        with client.websocket_connect(f"/v1/realtime/socket?ticket={ticket(client, headers)}") as ws:
            ws.receive_json()
            assert client.post("/v1/auth/logout", headers=headers).status_code == 204
            with pytest.raises(WebSocketDisconnect) as closed:
                ws.receive_json()
            assert closed.value.code == 1008


def test_the_socket_closes_at_the_sessions_expiry(tmp_path: Path) -> None:
    with client_for(tmp_path, session_absolute_lifetime=timedelta(seconds=1)) as client:
        headers = session(client)
        with client.websocket_connect(f"/v1/realtime/socket?ticket={ticket(client, headers)}") as ws:
            ws.receive_json()
            started = time.monotonic()
            with pytest.raises(WebSocketDisconnect) as closed:
                keep_pinging(ws)  # the client keeps pinging; the expiry closes the socket anyway
            assert closed.value.code == 1008 and time.monotonic() - started < 5


def test_the_recheck_closes_a_socket_whose_revocation_was_dropped(tmp_path: Path) -> None:
    with client_for(tmp_path, session_recheck_interval=timedelta(milliseconds=300)) as client:
        headers = session(client)
        container: AppContainer = client.app.state.container  # type: ignore[attr-defined]
        with client.websocket_connect(f"/v1/realtime/socket?ticket={ticket(client, headers)}") as ws:
            ws.receive_json()
            topics = container.infra.get_topics()
            assert isinstance(topics, TopicsMemoryImpl)
            topics.accepting = False  # the bus drops SESSION_REVOKED
            token = headers["Authorization"].removeprefix("Bearer ")
            storage = container.storage.get_tenancy_storage()
            before = client.portal.call(storage.read_session_by_digest, digest(token))  # type: ignore[union-attr]
            assert client.post("/v1/auth/logout", headers=headers).status_code == 204
            with pytest.raises(WebSocketDisconnect) as closed:
                ws.receive_json()
            assert closed.value.code == 1008
            after = client.portal.call(storage.read_session_by_digest, digest(token))  # type: ignore[union-attr]
            assert after is not None and before is not None and after.last_seen_at == before.last_seen_at
