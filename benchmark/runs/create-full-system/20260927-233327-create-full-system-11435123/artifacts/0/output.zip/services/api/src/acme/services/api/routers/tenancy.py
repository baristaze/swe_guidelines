"""The tenancy routes: sign-up, sign-in, the exchange, sign-out, the org, its members, and API keys."""

from uuid import UUID

from fastapi import APIRouter, Depends, Query, status

from acme.services.api.deps import TenancySvc
from acme.services.api.gateway.auth import Ctx, External, Identity, Rctx
from acme.services.api.gateway.idempotency import CreatedWithSecret
from acme.services.api.gateway.ratelimit import limited_by_address
from acme.services.api.types.common import ErrorResponse
from acme.services.api.types.tenancy import (
    AddApiKeyRequest,
    ApiKeyView,
    ExchangeRequest,
    ExternalSignInRequest,
    IssuedApiKeyView,
    IssuedSessionView,
    IssuedSignInView,
    MembershipChoiceView,
    MembershipView,
    MemberView,
    OrgView,
    SignInRequest,
    SignUpRequest,
    UpdateMemberRoleRequest,
    UpdateUserRequest,
    UserView,
)

router = APIRouter(tags=["tenancy"], responses={"default": {"model": ErrorResponse}})


@router.post("/auth/signup", dependencies=[Depends(limited_by_address("auth.signup"))])
async def sign_up(rctx: Rctx, body: SignUpRequest, tenancy: TenancySvc) -> IssuedSignInView:
    return await tenancy.sign_up(rctx, body)


@router.post("/auth/login", dependencies=[Depends(limited_by_address("auth.login"))])
async def sign_in(rctx: Rctx, body: SignInRequest, tenancy: TenancySvc) -> IssuedSignInView:
    return await tenancy.sign_in(rctx, body)


@router.post("/auth/external", dependencies=[Depends(limited_by_address("auth.external"))])
async def sign_in_external(
    rctx: Rctx, identity: External, body: ExternalSignInRequest, tenancy: TenancySvc
) -> IssuedSignInView:
    return await tenancy.sign_in_external(rctx, identity)


@router.get("/auth/memberships")
async def get_memberships(
    ictx: Identity, tenancy: TenancySvc, limit: int = Query(default=50, ge=1, le=500)
) -> list[MembershipChoiceView]:
    return await tenancy.get_memberships(ictx, limit)


@router.post("/auth/exchange", dependencies=[Depends(limited_by_address("auth.exchange"))])
async def exchange(ictx: Identity, body: ExchangeRequest, tenancy: TenancySvc) -> IssuedSessionView:
    return await tenancy.exchange(ictx, body)


@router.post("/auth/logout", status_code=status.HTTP_204_NO_CONTENT)
async def sign_out(ictx: Identity, tenancy: TenancySvc) -> None:
    return await tenancy.sign_out(ictx)


@router.get("/org")
async def get_org(ctx: Ctx, tenancy: TenancySvc) -> OrgView:
    return await tenancy.get_org(ctx)


@router.get("/members")
async def get_members(ctx: Ctx, tenancy: TenancySvc, limit: int = Query(default=50, ge=1, le=500)) -> list[MemberView]:
    return await tenancy.get_members(ctx, limit)


@router.patch("/members/{user_id}")
async def update_member_role(
    ctx: Ctx, user_id: UUID, body: UpdateMemberRoleRequest, tenancy: TenancySvc
) -> MembershipView:
    return await tenancy.update_member_role(ctx, user_id, body)


@router.delete("/members/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_member(ctx: Ctx, user_id: UUID, tenancy: TenancySvc) -> None:
    return await tenancy.remove_member(ctx, user_id)


@router.get("/me")
async def get_me(ctx: Ctx, tenancy: TenancySvc) -> UserView:
    return await tenancy.get_me(ctx)


@router.patch("/me")
async def update_me(ctx: Ctx, body: UpdateUserRequest, tenancy: TenancySvc) -> UserView:
    return await tenancy.update_me(ctx, body)


@router.post("/api-keys", status_code=status.HTTP_201_CREATED)
async def create_api_key(
    ctx: Ctx, created: CreatedWithSecret, body: AddApiKeyRequest, tenancy: TenancySvc
) -> IssuedApiKeyView:
    return await tenancy.create_api_key(ctx, created.target_id, created.guard, body)


@router.get("/api-keys")
async def get_api_keys(ctx: Ctx, tenancy: TenancySvc, limit: int = Query(default=50, ge=1, le=500)) -> list[ApiKeyView]:
    return await tenancy.get_api_keys(ctx, limit)


@router.delete("/api-keys/{key_id}", status_code=status.HTTP_204_NO_CONTENT)
async def revoke_api_key(ctx: Ctx, key_id: UUID, tenancy: TenancySvc) -> None:
    return await tenancy.revoke_api_key(ctx, key_id)
