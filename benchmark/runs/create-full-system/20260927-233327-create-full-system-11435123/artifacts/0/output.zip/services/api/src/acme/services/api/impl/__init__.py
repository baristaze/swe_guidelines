"""The services root: every in-process service impl, built once over the managers the container wired."""

from acme.om.root import Managers
from acme.services.api.impl.admin import AdminServiceImpl
from acme.services.api.impl.diagnostics import DiagnosticsServiceImpl
from acme.services.api.impl.events import EventServiceImpl
from acme.services.api.impl.journalists import JournalistServiceImpl
from acme.services.api.impl.realtime import RealtimeServiceImpl
from acme.services.api.impl.tenancy import TenancyServiceImpl
from acme.services.api.services import ServicesInterface
from acme.services.api.services.admin import AdminServiceInterface
from acme.services.api.services.diagnostics import DiagnosticsServiceInterface
from acme.services.api.services.events import EventServiceInterface
from acme.services.api.services.journalists import JournalistServiceInterface
from acme.services.api.services.realtime import RealtimeServiceInterface
from acme.services.api.services.tenancy import TenancyServiceInterface


class ServicesImpl(ServicesInterface):
    def __init__(self, managers: Managers) -> None:
        self._tenancy: TenancyServiceInterface = TenancyServiceImpl(managers.tenancy)
        self._admin: AdminServiceInterface = AdminServiceImpl(managers.tenancy, managers.events)
        self._events: EventServiceInterface = EventServiceImpl(managers.events)
        self._journalists: JournalistServiceInterface = JournalistServiceImpl(managers.journalists)
        self._realtime: RealtimeServiceInterface = RealtimeServiceImpl(managers.tenancy, managers.events)
        self._diagnostics: DiagnosticsServiceInterface = DiagnosticsServiceImpl()

    def get_tenancy_service(self) -> TenancyServiceInterface:
        return self._tenancy

    def get_admin_service(self) -> AdminServiceInterface:
        return self._admin

    def get_event_service(self) -> EventServiceInterface:
        return self._events

    def get_journalist_service(self) -> JournalistServiceInterface:
        return self._journalists

    def get_realtime_service(self) -> RealtimeServiceInterface:
        return self._realtime

    def get_diagnostics_service(self) -> DiagnosticsServiceInterface:
        return self._diagnostics
