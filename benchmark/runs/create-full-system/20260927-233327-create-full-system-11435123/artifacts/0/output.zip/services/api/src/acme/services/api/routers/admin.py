"""The operator plane, under /v1/admin, behind the operator gate. The tenant is a path parameter, never a context."""

from uuid import UUID

from fastapi import APIRouter, Query, status

from acme.services.api.deps import AdminSvc
from acme.services.api.gateway.admin import OperatorCtx
from acme.services.api.gateway.idempotency import OperatorCreated, OperatorCreatedWithSecret
from acme.services.api.types.admin import (
    AddMemberRequest,
    AddOperatorTokenRequest,
    AddOrgRequest,
    AdminEventView,
    AdminMemberView,
    AdminOrgView,
    ConfirmTotpRequest,
    IssuedOperatorTokenView,
    OperatorView,
    SizeView,
    TotpEnrolmentView,
)
from acme.services.api.types.common import ErrorResponse

router = APIRouter(prefix="/admin", tags=["admin"], responses={"default": {"model": ErrorResponse}})


@router.get("/me")
async def get_me(octx: OperatorCtx, admin: AdminSvc) -> OperatorView:
    return await admin.get_me(octx)


@router.get("/size")
async def get_size(octx: OperatorCtx, admin: AdminSvc) -> SizeView:
    return await admin.get_size(octx)


@router.get("/orgs")
async def get_orgs(
    octx: OperatorCtx, admin: AdminSvc, limit: int = Query(default=50, ge=1, le=500)
) -> list[AdminOrgView]:
    return await admin.get_orgs(octx, limit)


@router.get("/orgs/{org_id}")
async def get_org(octx: OperatorCtx, org_id: UUID, admin: AdminSvc) -> AdminOrgView:
    return await admin.get_org(octx, org_id)


@router.get("/orgs/{org_id}/members")
async def get_members(
    octx: OperatorCtx, org_id: UUID, admin: AdminSvc, limit: int = Query(default=50, ge=1, le=500)
) -> list[AdminMemberView]:
    return await admin.get_members(octx, org_id, limit)


@router.get("/orgs/{org_id}/events")
async def get_events(
    octx: OperatorCtx,
    org_id: UUID,
    admin: AdminSvc,
    after_seq: int = Query(default=0, ge=0),
    limit: int = Query(default=100, ge=1, le=500),
) -> list[AdminEventView]:
    return await admin.get_events(octx, org_id, after_seq, limit)


@router.post("/orgs", status_code=status.HTTP_201_CREATED)
async def create_org(octx: OperatorCtx, created: OperatorCreated, body: AddOrgRequest, admin: AdminSvc) -> AdminOrgView:
    return await admin.create_org(octx, created.target_id, body)


@router.post("/orgs/{org_id}/members", status_code=status.HTTP_201_CREATED)
async def add_member(
    octx: OperatorCtx, org_id: UUID, created: OperatorCreated, body: AddMemberRequest, admin: AdminSvc
) -> AdminMemberView:
    return await admin.add_member(octx, org_id, created.target_id, body)


@router.delete("/orgs/{org_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_org(octx: OperatorCtx, org_id: UUID, admin: AdminSvc) -> None:
    return await admin.delete_org(octx, org_id)


@router.post("/me/totp")
async def enrol_totp(octx: OperatorCtx, admin: AdminSvc) -> TotpEnrolmentView:
    return await admin.enrol_totp(octx)


@router.post("/me/totp/confirm", status_code=status.HTTP_204_NO_CONTENT)
async def confirm_totp(octx: OperatorCtx, body: ConfirmTotpRequest, admin: AdminSvc) -> None:
    return await admin.confirm_totp(octx, body)


@router.post("/me/tokens", status_code=status.HTTP_201_CREATED)
async def issue_token(
    octx: OperatorCtx, created: OperatorCreatedWithSecret, body: AddOperatorTokenRequest, admin: AdminSvc
) -> IssuedOperatorTokenView:
    return await admin.issue_token(octx, body)
