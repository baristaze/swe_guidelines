"""The API suites' fixtures: the app over the memory roots, driven in-process inside its lifespan."""

from collections.abc import AsyncIterator
from pathlib import Path

import httpx
import pytest
from api_harness import Api, api_settings

from acme.infra.impl.local import InfraLocalImpl
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.services.api.app import create_app
from acme.services.api.container import AppContainer
from acme.services.api.settings import ApiSettings


@pytest.fixture
def settings() -> ApiSettings:
    return api_settings()


@pytest.fixture
async def api(tmp_path: Path, settings: ApiSettings) -> AsyncIterator[Api]:
    container = AppContainer.for_tests(StorageMemoryImpl(), InfraLocalImpl(tmp_path), settings)
    app = create_app(container)
    async with (
        app.router.lifespan_context(app),
        httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test") as client,
    ):
        yield Api(app=app, client=client, container=container)
