"""Credentials by prefix, and the dependencies that mint the request stage and run the transitions above it.

No route and no service builds a context from a header or a token: the stages come from here, through the
tenancy manager's transitions.
"""

from typing import TYPE_CHECKING, Annotated
from uuid import UUID

import jwt
from fastapi import Depends, Request, WebSocket
from starlette.requests import HTTPConnection

from acme.integrations.identity import ExternalIdentity
from acme.om.exceptions import NotAuthenticated, ValidationFailed
from acme.om.opcontext import AppContext, AppType, IdentityContext, OpContext, RequestContext
from acme.om.tenancy.types import SocketGrant
from acme.services.api.gateway.observability import current_trace_id, current_traceparent, parse_request_id

if TYPE_CHECKING:
    from acme.services.api.container import AppContainer

INTERNAL_PREFIX = "fji_"
APP_TYPE_HEADER = "x-app-type"
APP_VERSION_HEADER = "x-app-version"


def container_of(connection: HTTPConnection) -> AppContainer:
    return connection.app.state.container


def _app(connection: HTTPConnection) -> AppContext:
    """The app header check: an app the platform does not know is refused; no header is an API caller."""
    raw = connection.headers.get(APP_TYPE_HEADER, AppType.API.value)
    try:
        app_type = AppType(raw)
    except ValueError as exc:
        raise NotAuthenticated(f"unknown app {raw!r}") from exc
    version = connection.headers.get(APP_VERSION_HEADER, f"{app_type.value}@unknown")[:64]
    return AppContext(type=app_type, version=version)


def _request_stage(connection: HTTPConnection) -> RequestContext:
    state_id = getattr(connection.state, "request_id", None)
    return RequestContext(
        request_id=parse_request_id(state_id),
        app=_app(connection),
        trace_id=current_trace_id(),
        traceparent=current_traceparent(),
    )


async def request_context(request: Request) -> RequestContext:
    return _request_stage(request)


Rctx = Annotated[RequestContext, Depends(request_context)]


def _bearer(connection: HTTPConnection) -> str:
    header = connection.headers.get("authorization", "")
    scheme, _, token = header.partition(" ")
    if scheme.lower() != "bearer" or not token:
        raise NotAuthenticated("a bearer credential is required")
    return token.strip()


async def _internal(connection: HTTPConnection, rctx: RequestContext, token: str) -> OpContext:
    """A peer service's per-call credential: signed with the process's internal key, audience this service."""
    container = container_of(connection)
    try:
        claims = jwt.decode(
            token.removeprefix(INTERNAL_PREFIX),
            container.settings.internal_signing_key,
            algorithms=["HS256"],
            audience="acme-api",
            options={"require": ["exp", "sub", "org", "rid", "aud"]},
        )
    except jwt.PyJWTError as exc:
        raise NotAuthenticated("the internal credential does not verify") from exc
    caused = rctx.model_copy(update={"caused_by_request_id": UUID(claims["rid"])})
    return await container.managers.tenancy.authenticate_internal(
        caused, UUID(claims["org"]), UUID(claims["sub"]), UUID(claims.get("jti", claims["rid"]))
    )


async def current_context(request: Request, rctx: Rctx) -> OpContext:
    token = _bearer(request)
    if token.startswith(INTERNAL_PREFIX):
        return await _internal(request, rctx, token)
    return await container_of(request).managers.tenancy.authenticate(rctx, token)


Ctx = Annotated[OpContext, Depends(current_context)]


async def current_identity(request: Request, rctx: Rctx) -> IdentityContext:
    return await container_of(request).managers.tenancy.authenticate_login(rctx, _bearer(request))


Identity = Annotated[IdentityContext, Depends(current_identity)]


async def socket_context(websocket: WebSocket) -> SocketGrant:
    """The socket's stage: the request stage from the websocket scope, then the ticket redeemed by the manager."""
    ticket = websocket.query_params.get("ticket", "")
    rctx = _request_stage(websocket)
    return await container_of(websocket).managers.tenancy.redeem_socket_ticket(rctx, ticket)


SocketCtx = Annotated[SocketGrant, Depends(socket_context)]


async def external_identity(request: Request) -> ExternalIdentity:
    """The identity provider's code or token, verified against the provider (its published keys, or the twin)."""
    body = await request.json()
    provider = container_of(request).integrations.identity_provider
    if isinstance(body, dict) and body.get("code"):
        return await provider.exchange_code(str(body["code"]), str(body.get("redirect_uri", "")))
    if isinstance(body, dict) and body.get("token"):
        return await provider.verify_token(str(body["token"]))
    raise ValidationFailed("a provider code or token is required")


External = Annotated[ExternalIdentity, Depends(external_identity)]
