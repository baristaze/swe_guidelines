"""The one error envelope: every failure answers `{"error": {code, message, request_id}}`."""

import json
import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from acme.infra.exceptions import InfraException
from acme.om.exceptions import PlatformException, TooManyRequests

logger = logging.getLogger(__name__)


def envelope(request: Request, status: int, code: str, message: str) -> JSONResponse:
    request_id = getattr(request.state, "request_id", "")
    return JSONResponse(
        status_code=status,
        content={"error": {"code": code, "message": message, "request_id": request_id}},
    )


class IdempotentReplay(PlatformException):
    """Raised by the edge idempotency dependency: the stored outcome answers, and the header says so."""

    http_status = 200
    code = "replayed"

    def __init__(self, status: int, body: str) -> None:
        super().__init__("replay")
        self.status = status
        self.body = body


def install(app: FastAPI) -> None:
    @app.exception_handler(PlatformException)
    async def platform(request: Request, exc: PlatformException) -> JSONResponse:
        response = envelope(request, exc.http_status, exc.code, str(exc) or exc.code)
        if isinstance(exc, TooManyRequests):
            response.headers["Retry-After"] = str(exc.retry_after)
        return response

    @app.exception_handler(InfraException)
    async def infra(request: Request, exc: InfraException) -> JSONResponse:
        return envelope(request, exc.http_status, exc.code, str(exc) or exc.code)

    @app.exception_handler(RequestValidationError)
    async def validation(request: Request, exc: RequestValidationError) -> JSONResponse:
        first = exc.errors()[0] if exc.errors() else {}
        where = ".".join(str(p) for p in first.get("loc", ()))
        return envelope(request, 422, "validation_failed", f"{where}: {first.get('msg', 'invalid')}")

    @app.exception_handler(StarletteHTTPException)
    async def http(request: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = {404: "not_found", 405: "method_not_allowed"}.get(exc.status_code, "http_error")
        return envelope(request, exc.status_code, code, str(exc.detail))

    @app.exception_handler(IdempotentReplay)
    async def replay(request: Request, exc: IdempotentReplay) -> JSONResponse:
        response = JSONResponse(status_code=exc.status, content=json.loads(exc.body) if exc.body else None)
        response.headers["Idempotent-Replayed"] = "true"
        return response

    @app.exception_handler(Exception)
    async def unexpected(request: Request, exc: Exception) -> JSONResponse:
        logger.error("unhandled failure", exc_info=exc)
        response = envelope(request, 500, "internal_error", "an unexpected failure")
        # This handler answers from the outermost error middleware, outside the request id's stamp, so it stamps
        # the header itself: a 500 is the answer a caller most needs to quote.
        request_id = getattr(request.state, "request_id", "")
        if request_id:
            response.headers["x-request-id"] = request_id
        return response
