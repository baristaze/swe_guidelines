"""The worker's own settings. The database settings are the OM's StorageSettings, the backends InfraSettings."""

from datetime import timedelta

from pydantic_settings import BaseSettings, SettingsConfigDict


class WorkerSettings(BaseSettings):
    """The capacity is set against the pool this process opens (ACME_DATABASE_POOL_SIZE), never on its own:
    a worker running more items at once than its pool serves spends the difference waiting on a checkout."""

    model_config = SettingsConfigDict(env_prefix="ACME_WORKER_", env_file=".env", extra="ignore", env_ignore_empty=True)

    name: str = "maintenance"
    host: str = "127.0.0.1"
    port: int = 9100  # /healthz and /metrics, the worker's only surface
    lane: str = "default"
    capacity: int = 4
    lease_seconds: float = 60.0
    heartbeat_seconds: float = 5.0
    poll_interval_seconds: float = 3.0  # bounds the delay a dropped WORK_AVAILABLE costs an item
    sweep_interval_seconds: float = 2.0  # the relay from the sweep answers within this interval
    beats_missed_limit: int = 3  # /healthz answers non-2xx once the loop missed this many beats
    item_retention: timedelta = timedelta(days=7)
    outbox_retention: timedelta = timedelta(days=14)
    idempotency_retention: timedelta = timedelta(days=1)
    purge_batch: int = 500
    sweep_batch: int = 100
