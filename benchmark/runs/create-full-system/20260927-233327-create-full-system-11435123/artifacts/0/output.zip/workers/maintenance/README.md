# The maintenance worker

A worker whose only work today is the maintenance sweep, ready for real kinds. It claims items of the kinds it
handles from the work queue (`NOOP` for now) within its capacity, renews each item's lease while it works, and
completes, fails, or hands the item back. On its own timer it runs the sweep: it relays what the request path's relay
left in the outbox, requeues items whose lease passed, purges what is past retention (done outbox rows, finished work
items, idempotency markers, spent socket tickets, ended sessions), and sets the gauges the alarms read
(`acme_outbox_lag_seconds`, `acme_queue_oldest_age_seconds`, `acme_work_failed`, `acme_records_parked`).

It serves `/healthz` (from its in-memory heartbeat) and `/metrics` on its own port, `ACME_WORKER_PORT`. On a stop
signal it hands its work back first and goes offline last. `acme-maintenance serve` runs it; `ACME_WORKER_*`
settings, documented in `.env.example`, tune it.
