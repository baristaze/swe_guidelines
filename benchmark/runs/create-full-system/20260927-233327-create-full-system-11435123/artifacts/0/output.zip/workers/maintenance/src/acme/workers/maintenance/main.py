"""The worker binary: `serve` runs the loop and serves /healthz and /metrics alone on the worker's own port."""

import argparse
import asyncio
import logging
import signal
import sys

from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from acme.workers.maintenance.container import WorkerContainer
from acme.workers.maintenance.loop import WorkerLoop

logger = logging.getLogger(__name__)


def http_answer(loop: WorkerLoop, path: str) -> tuple[int, str, bytes]:
    """/healthz answers from the loop's in-memory beat, with no I/O of its own; /metrics the exposition."""
    if path == "/healthz":
        healthy = loop.healthy()
        return (200 if healthy else 503), "application/json", b'{"status":"ok"}' if healthy else b'{"status":"stalled"}'
    if path == "/metrics":
        return 200, CONTENT_TYPE_LATEST, generate_latest()
    return 404, "text/plain", b"not found"


async def serve_http(loop: WorkerLoop, host: str, port: int) -> asyncio.Server:
    async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            request_line = (await asyncio.wait_for(reader.readline(), 5)).decode("latin-1")
            while (await asyncio.wait_for(reader.readline(), 5)) not in (b"\r\n", b"\n", b""):
                pass
            parts = request_line.split()
            status, kind, body = http_answer(loop, parts[1] if len(parts) > 1 else "/")
            reason = {200: "OK", 404: "Not Found", 503: "Service Unavailable"}[status]
            head = (
                f"HTTP/1.1 {status} {reason}\r\nContent-Type: {kind}\r\n"
                f"Content-Length: {len(body)}\r\nConnection: close\r\n\r\n"
            )
            writer.write(head.encode() + body)
            await writer.drain()
        except TimeoutError, ConnectionError:
            pass
        finally:
            writer.close()

    return await asyncio.start_server(handle, host, port)


async def serve() -> int:
    container = WorkerContainer.from_environment()
    await container.start()
    loop = WorkerLoop(container)
    server = await serve_http(loop, container.settings.host, container.settings.port)
    stopped = asyncio.Event()
    running = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        running.add_signal_handler(sig, stopped.set)
    work = asyncio.create_task(loop.run())
    logger.info("worker %s serving /healthz and /metrics on %s", loop.worker_id, container.settings.port)
    await stopped.wait()
    await loop.stop()
    work.cancel()
    await asyncio.gather(work, return_exceptions=True)
    server.close()
    await container.close()
    return 0


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="acme-maintenance")
    parser.add_argument("command", choices=["serve"], nargs="?", default="serve")
    parser.parse_args(argv)
    logging.basicConfig(stream=sys.stderr, level=logging.INFO)
    return asyncio.run(serve())
