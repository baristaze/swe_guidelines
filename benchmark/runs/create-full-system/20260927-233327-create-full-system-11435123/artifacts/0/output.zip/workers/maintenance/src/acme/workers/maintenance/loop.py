"""The loop: claim while a slot is free, handle each item as a task that renews its lease, complete it; wake on
WORK_AVAILABLE and poll besides; beat liveness in memory; run the maintenance sweep on a timer; drain on stop."""

import asyncio
import contextlib
import json
import logging
import time
from dataclasses import dataclass
from datetime import timedelta
from typing import Any
from uuid import UUID

from opentelemetry import trace
from opentelemetry.trace import Link, NonRecordingSpan, SpanContext, TraceFlags
from prometheus_client import Gauge

from acme.infra.cache import CacheScope
from acme.infra.observability import OUTCOMES, caused_by_var, request_id_var
from acme.infra.topics import TopicPayload, Topics
from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.opcontext import AppContext, AppType, OpContext, RequestContext
from acme.om.work.types.work_item import WorkItem, WorkKind
from acme.workers.maintenance.container import VERSION, WorkerContainer

logger = logging.getLogger(__name__)
tracer = trace.get_tracer("acme.worker")

OUTBOX_LAG = Gauge("acme_outbox_lag_seconds", "Age of the oldest pending outbox row")
QUEUE_AGE = Gauge("acme_queue_oldest_age_seconds", "Age of the oldest waiting work item")
WORK_FAILED = Gauge("acme_work_failed", "Work items failed for good and not yet purged")
RECORDS_PARKED = Gauge("acme_records_parked", "Parked records across every entity that parks")

TENANT_STEPS_EVERY = 30  # sweep passes between the steps that walk every tenant and the purges


def link_to(traceparent: str | None) -> list[Link]:
    """The span a run raises links to the causing request's trace, never becoming its child."""
    if not traceparent:
        return []
    try:
        _, trace_id, span_id, flags = traceparent.split("-")
        context = SpanContext(
            int(trace_id, 16), int(span_id, 16), is_remote=True, trace_flags=TraceFlags(int(flags, 16))
        )
    except ValueError:
        return []
    return [Link(NonRecordingSpan(context).get_span_context())]


@dataclass
class Holding:
    item: WorkItem
    lost: bool = False


class WorkerLoop:
    def __init__(self, container: WorkerContainer, worker_id: str | None = None) -> None:
        self._c = container
        self._s = container.settings
        self.worker_id = worker_id or f"{self._s.name}-{new_id().hex[-8:]}"
        self._lease = timedelta(seconds=self._s.lease_seconds)
        self._kinds: tuple[WorkKind, ...] = tuple(container.handlers)
        self.running: dict[UUID, asyncio.Task[None]] = {}
        self.last_beat = time.monotonic()
        self._wake = asyncio.Event()
        self._stopping = asyncio.Event()
        self._background: list[asyncio.Task[None]] = []
        self.passes = 0

    # --- liveness

    def healthy(self) -> bool:
        return time.monotonic() - self.last_beat < self._s.heartbeat_seconds * self._s.beats_missed_limit

    def _stage(self) -> RequestContext:
        """One request stage per claim and per sweep pass; the run gets a request id of its own."""
        return RequestContext(
            request_id=new_id(), app=AppContext(type=AppType.WORKER, version=f"{self._s.name}@{VERSION}")
        )

    async def _heartbeat(self) -> None:
        cache = self._c.infra.get_cache(CacheScope.WORKER_LIVENESS)
        while True:
            self.last_beat = time.monotonic()
            beat = json.dumps({"worker": self.worker_id, "running": len(self.running)}).encode()
            try:
                async with asyncio.timeout(self._s.heartbeat_seconds):
                    await cache.put(
                        EMPTY_UUID, f"worker:{self.worker_id}", beat, timedelta(seconds=self._s.heartbeat_seconds * 3)
                    )
                OUTCOMES.labels("worker", "liveness", "published").inc()
            except Exception:  # a cache outage never pauses claiming
                OUTCOMES.labels("worker", "liveness", "failed").inc()
                logger.warning("liveness publish failed; claiming goes on")
            await asyncio.sleep(self._s.heartbeat_seconds)

    # --- claiming

    async def _on_wake(self, payload: TopicPayload) -> None:
        self._wake.set()

    async def run(self) -> None:
        unsubscribe = self._c.infra.get_topics().subscribe(Topics.WORK_AVAILABLE, self.worker_id, self._on_wake)
        self._background = [asyncio.create_task(self._heartbeat()), asyncio.create_task(self._sweep_loop())]
        try:
            while not self._stopping.is_set():
                await self._claim_while_free()
                self._wake.clear()
                with contextlib.suppress(TimeoutError):
                    async with asyncio.timeout(self._s.poll_interval_seconds):
                        await self._wake.wait()
        finally:
            unsubscribe()

    async def _claim_while_free(self) -> None:
        while len(self.running) < self._s.capacity and not self._stopping.is_set():
            try:
                claimed = await self._c.managers.work.claim(
                    self._stage(), self._s.lane, self._kinds, self.worker_id, self._lease
                )
            except Exception:
                logger.exception("claim failed; the next poll tries again")
                OUTCOMES.labels("worker", "claim", "error").inc()
                return
            if claimed is None:
                return
            ctx, item = claimed
            OUTCOMES.labels("worker", "claim", "claimed").inc()
            task = asyncio.create_task(self._run_item(ctx, item))
            self.running[item.id] = task
            task.add_done_callback(lambda _t, key=item.id: self._finished(key))

    def _finished(self, item_id: UUID) -> None:
        self.running.pop(item_id, None)
        self._wake.set()

    async def _run_item(self, ctx: OpContext, item: WorkItem) -> None:
        work = self._c.managers.work
        request_token = request_id_var.set(str(ctx.request_id))
        caused_token = caused_by_var.set(str(ctx.caused_by_request_id) if ctx.caused_by_request_id else None)
        holding = Holding(item=item)
        handler = self._c.handlers.get(item.kind)
        try:
            if handler is None:
                await work.release(ctx, item, f"{self.worker_id} does not handle {item.kind.value}")
                return
            handled = asyncio.create_task(self._handle(ctx, holding, handler))
            renewal = asyncio.create_task(self._renew(ctx, holding, handled))
            try:
                await handled
            except asyncio.CancelledError:
                if holding.lost:
                    OUTCOMES.labels("worker", "item", "lease_lost").inc()
                    return
                raise
            except Exception as error:
                await work.fail(ctx, holding.item, f"{type(error).__name__}: {error}")
                OUTCOMES.labels("worker", "item", "failed").inc()
                return
            finally:
                renewal.cancel()
            await work.complete(ctx, holding.item)
            OUTCOMES.labels("worker", "item", "done").inc()
        except asyncio.CancelledError:
            # Drain-first shutdown: the item goes back to the queue with a note, no attempt spent.
            if not holding.lost:
                with contextlib.suppress(Exception):
                    await asyncio.shield(work.release(ctx, holding.item, f"released by {self.worker_id} on shutdown"))
            raise
        except Conflict:
            OUTCOMES.labels("worker", "item", "stale").inc()  # another holder has it now; drop it, no attempt spent
        finally:
            request_id_var.reset(request_token)
            caused_by_var.reset(caused_token)

    async def _handle(self, ctx: OpContext, holding: Holding, handler: Any) -> None:
        with tracer.start_as_current_span(
            f"work {holding.item.kind.value}", links=link_to(holding.item.traceparent)
        ) as span:
            span.set_attribute("acme.request_id", str(ctx.request_id))
            await handler.handle(ctx, holding.item)

    async def _renew(self, ctx: OpContext, holding: Holding, handled: asyncio.Task[None]) -> None:
        interval = self._s.lease_seconds / 3
        last_ok = time.monotonic()
        while True:
            await asyncio.sleep(interval)
            try:
                holding.item = await asyncio.wait_for(
                    self._c.managers.work.extend_lease(ctx, holding.item, self._lease), interval
                )
                last_ok = time.monotonic()
            except Conflict:
                holding.lost = True  # definitive: another worker holds the item now
                handled.cancel()
                return
            except Exception:
                if time.monotonic() - last_ok > self._s.lease_seconds / 2:
                    holding.lost = True  # self-fencing before the lease expires under us
                    handled.cancel()
                    return

    # --- the sweep

    async def _sweep_loop(self) -> None:
        while True:
            await self.sweep_once()
            await asyncio.sleep(self._s.sweep_interval_seconds)

    async def _step(self, name: str, step: Any) -> None:
        try:
            await step
            OUTCOMES.labels("worker", f"sweep_{name}", "ok").inc()
        except Exception:
            OUTCOMES.labels("worker", f"sweep_{name}", "error").inc()
            logger.exception("sweep step %s failed; the next pass runs it again", name)

    async def sweep_once(self) -> None:
        """One pass: relay what a crash or a dropped publish left, the gauges, and, every few passes, the steps that
        walk every tenant and the purges. Every step is idempotent and serialized by the database."""
        m = self._c.managers
        rctx = self._stage()
        token = request_id_var.set(str(rctx.request_id))
        try:
            await self._step("relay", m.relay.relay_pending(rctx, self._s.sweep_batch))
            await self._step("gauges", self._gauges(rctx))
            if self.passes % TENANT_STEPS_EVERY == 0:
                await self._step("requeue", self._requeue_stale(rctx))
                await self._step("purge_outbox", m.relay.purge_done(rctx))
                await self._step("purge_items", m.work.purge_items(rctx))
                await self._step("purge_markers", m.idempotency.purge_markers(rctx))
                await self._step("purge_tickets", m.tenancy.purge_socket_tickets(rctx))
                await self._step("purge_sessions", m.tenancy.purge_sessions(rctx))
            self.passes += 1
        finally:
            request_id_var.reset(token)

    async def _requeue_stale(self, rctx: RequestContext) -> None:
        for ctx in await self._c.managers.work.maintenance_contexts(rctx):
            await self._c.managers.work.requeue_stale(ctx)

    async def _gauges(self, rctx: RequestContext) -> None:
        gauges = await self._c.managers.work.read_gauges(rctx)
        now = utcnow()
        QUEUE_AGE.set(
            0 if gauges.oldest_waiting_at is None else max(0.0, (now - gauges.oldest_waiting_at).total_seconds())
        )
        WORK_FAILED.set(gauges.failed)
        RECORDS_PARKED.set(0)  # no entity parks yet; each that does adds its count here
        OUTBOX_LAG.set((await self._c.managers.relay.read_lag(rctx)).total_seconds())

    # --- shutdown

    async def stop(self) -> None:
        """Hand the work back first and go offline last: stop claiming, cancel and release, stop the beat."""
        self._stopping.set()
        self._wake.set()
        for task in list(self.running.values()):
            task.cancel()
        await asyncio.gather(*self.running.values(), return_exceptions=True)
        for task in self._background:
            task.cancel()
        await asyncio.gather(*self._background, return_exceptions=True)
        with contextlib.suppress(Exception):
            await self._c.infra.get_cache(CacheScope.WORKER_LIVENESS).invalidate(EMPTY_UUID, f"worker:{self.worker_id}")
        logger.info("worker %s offline", self.worker_id)
