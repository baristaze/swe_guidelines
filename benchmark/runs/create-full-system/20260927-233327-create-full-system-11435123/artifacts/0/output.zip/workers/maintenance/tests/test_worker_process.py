"""The process: every setting documented, every environment passing what has no local default, and the entry point
installing the trust store before a cloud TLS context opens."""

import re
import subprocess
import sys
from pathlib import Path

from acme.workers.maintenance.settings import WorkerSettings

ROOT = Path(__file__).resolve().parents[3]


def test_every_setting_is_in_env_example() -> None:
    lines = (ROOT / ".env.example").read_text().splitlines()
    documented = {line.split("=", 1)[0] for line in lines if "=" in line and not line.startswith("#")}
    missing = {f"ACME_WORKER_{name.upper()}" for name in WorkerSettings.model_fields} - documented
    assert not missing, f"undocumented worker settings: {sorted(missing)}"


def test_every_environment_runs_the_worker_with_its_settings() -> None:
    for env in ("staging", "prod"):
        text = (ROOT / f"deployment/terraform/environments/{env}/main.tf").read_text()
        assert re.search(r"acme-\$\{[^}]+\}-maintenance|maintenance", text)
        for name in ("ACME_WORKER_NAME", "ACME_WORKER_CAPACITY", "ACME_WORKER_LEASE_SECONDS"):
            assert name in text, f"{env} does not pass {name}"


def test_the_entry_point_installs_the_trust_store_first() -> None:
    replay = (
        "import sys; sys.argv = ['acme-maintenance', '--help']\n"
        "from acme.workers.maintenance import entry\n"
        "try:\n    entry.main()\nexcept SystemExit:\n    pass\n"
        "import ssl, botocore.httpsession\n"
        "botocore.httpsession.create_urllib3_context().load_default_certs()\n"
        "assert ssl.SSLContext.__module__.startswith('truststore')\nprint('ok')"
    )
    result = subprocess.run([sys.executable, "-c", replay], capture_output=True, text=True, timeout=60, cwd=ROOT)
    assert result.returncode == 0, result.stderr
