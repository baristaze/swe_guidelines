"""The loop: capacity, the poll behind a dropped wake-up, lease renewal and self-fencing, liveness, and drain."""

import asyncio
from pathlib import Path

from worker_harness import (
    Blocking,
    Delegating,
    a_tenant_context,
    an_item,
    container,
    eventually,
    with_handler,
    with_work,
)

from acme.infra.cache import CacheScope
from acme.infra.topics.memory import TopicsMemoryImpl
from acme.om.exceptions import Conflict
from acme.om.work.types.work_item import WorkStatus
from acme.workers.maintenance.loop import WorkerLoop
from acme.workers.maintenance.main import http_answer


async def status_of(c, ctx, item_id):  # type: ignore[no-untyped-def]
    found = await c.storage.get_work_storage().read_item(ctx.org_id, item_id)
    return None if found is None else found.status


async def test_claims_within_capacity(tmp_path: Path) -> None:
    handler = Blocking()
    c = with_handler(container(tmp_path), handler)
    ctx = await a_tenant_context(c)
    for _ in range(3):
        await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(lambda: handler.started == 2)
    await asyncio.sleep(0.1)
    assert len(loop.running) == 2
    handler.finish.set()
    await eventually(lambda: handler.started == 3)
    await loop.stop()
    task.cancel()


async def test_an_item_is_claimed_on_the_poll_when_its_wake_up_never_came(tmp_path: Path) -> None:
    c = container(tmp_path)
    topics = c.infra.get_topics()
    assert isinstance(topics, TopicsMemoryImpl)
    ctx = await a_tenant_context(c)
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await asyncio.sleep(0.05)
    topics.accepting = False  # the bus drops WORK_AVAILABLE
    item = await c.managers.work.enqueue(ctx, an_item())
    await eventually(_done(c, ctx, item.id))
    await loop.stop()
    task.cancel()


def _done(c, ctx, item_id):  # type: ignore[no-untyped-def]
    async def check() -> bool:
        return await status_of(c, ctx, item_id) == WorkStatus.DONE

    return check


async def test_a_long_item_renews_its_lease_and_completes(tmp_path: Path) -> None:
    handler = Blocking()
    c = with_handler(container(tmp_path, lease_seconds=0.3), handler)
    renewals: list[int] = []
    real = c.managers.work

    async def extend(ctx, item, lease):  # type: ignore[no-untyped-def]
        renewals.append(1)
        return await real.extend_lease(ctx, item, lease)

    c = with_work(c, Delegating(real, extend_lease=extend))
    ctx = await a_tenant_context(c)
    item = await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(lambda: len(renewals) >= 2)
    handler.finish.set()
    await eventually(_done(c, ctx, item.id))
    await loop.stop()
    task.cancel()


async def test_a_renewal_refused_with_conflict_cancels_at_once(tmp_path: Path) -> None:
    handler = Blocking()
    c = with_handler(container(tmp_path, lease_seconds=0.3), handler)

    async def refuse(ctx, item, lease):  # type: ignore[no-untyped-def]
        raise Conflict("another worker holds it")

    c = with_work(c, Delegating(c.managers.work, extend_lease=refuse))
    ctx = await a_tenant_context(c)
    item = await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(lambda: handler.started == 1)
    await eventually(lambda: not loop.running, seconds=1.0)
    assert await status_of(c, ctx, item.id) == WorkStatus.CLAIMED  # dropped, never completed by the stale holder
    await loop.stop()
    task.cancel()


async def test_a_renewal_that_times_out_is_retried(tmp_path: Path) -> None:
    handler = Blocking()
    c = with_handler(container(tmp_path, lease_seconds=0.9), handler)
    real = c.managers.work
    calls: list[int] = []

    async def flaky(ctx, item, lease):  # type: ignore[no-untyped-def]
        calls.append(1)
        if len(calls) == 1:
            raise TimeoutError("the engine was slow")
        return await real.extend_lease(ctx, item, lease)

    c = with_work(c, Delegating(real, extend_lease=flaky))
    ctx = await a_tenant_context(c)
    item = await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(lambda: len(calls) >= 2)
    handler.finish.set()
    await eventually(_done(c, ctx, item.id))
    await loop.stop()
    task.cancel()


async def test_a_lease_that_cannot_be_renewed_cancels_its_own_task(tmp_path: Path) -> None:
    handler = Blocking()
    c = with_handler(container(tmp_path, lease_seconds=0.3), handler)

    async def unreachable(ctx, item, lease):  # type: ignore[no-untyped-def]
        raise OSError("engine out of reach")

    c = with_work(c, Delegating(c.managers.work, extend_lease=unreachable))
    ctx = await a_tenant_context(c)
    await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(lambda: handler.started == 1)
    await eventually(lambda: not loop.running, seconds=2.0)
    await loop.stop()
    task.cancel()


async def test_a_failed_liveness_publish_leaves_claiming_running(tmp_path: Path) -> None:
    c = container(tmp_path)
    cache = c.infra.get_cache(CacheScope.WORKER_LIVENESS)

    async def broken(*args, **kwargs):  # type: ignore[no-untyped-def]
        raise OSError("cache down")

    cache.put = broken  # type: ignore[method-assign]
    ctx = await a_tenant_context(c)
    item = await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(_done(c, ctx, item.id))
    assert http_answer(loop, "/healthz")[0] == 200  # answered from the in-memory beat
    await loop.stop()
    task.cancel()


async def test_stop_hands_the_work_back_first(tmp_path: Path) -> None:
    handler = Blocking()
    c = with_handler(container(tmp_path), handler)
    ctx = await a_tenant_context(c)
    item = await c.managers.work.enqueue(ctx, an_item())
    loop = WorkerLoop(c)
    task = asyncio.create_task(loop.run())
    await eventually(lambda: handler.started == 1)
    await loop.stop()
    task.cancel()
    assert await status_of(c, ctx, item.id) == WorkStatus.QUEUED


async def test_healthz_fails_once_the_beats_stop(tmp_path: Path) -> None:
    loop = WorkerLoop(container(tmp_path))
    assert http_answer(loop, "/healthz")[0] == 200
    await asyncio.sleep(0.2)  # three missed beats at 0.05s
    assert http_answer(loop, "/healthz")[0] == 503
    assert http_answer(loop, "/metrics")[0] == 200
