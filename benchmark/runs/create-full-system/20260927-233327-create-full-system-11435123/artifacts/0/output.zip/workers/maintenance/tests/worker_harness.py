"""The harness of the worker suites: the worker container over the memory roots, and items to feed it."""

import asyncio
import dataclasses
import inspect
from datetime import timedelta
from pathlib import Path
from typing import Any

from acme.infra.impl.local import InfraLocalImpl
from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.opcontext import AppContext, AppType, OpContext, RequestContext
from acme.om.storage.impl.memory import StorageMemoryImpl
from acme.om.work.manager import WorkManagerInterface
from acme.om.work.types.handler import WorkHandlerInterface
from acme.om.work.types.work_item import WorkItem, WorkKind
from acme.workers.maintenance.container import WorkerContainer
from acme.workers.maintenance.settings import WorkerSettings


def settings(**overrides: Any) -> WorkerSettings:
    values: dict[str, Any] = {
        "_env_file": None,
        "capacity": 2,
        "lease_seconds": 0.6,
        "heartbeat_seconds": 0.05,
        "poll_interval_seconds": 0.05,
        "sweep_interval_seconds": 0.05,
        **overrides,
    }
    return WorkerSettings(**values)


def container(tmp_path: Path, **overrides: Any) -> WorkerContainer:
    return WorkerContainer.for_tests(StorageMemoryImpl(), InfraLocalImpl(tmp_path), settings(**overrides))


def with_handler(c: WorkerContainer, handler: WorkHandlerInterface) -> WorkerContainer:
    return dataclasses.replace(c, handlers={WorkKind.NOOP: handler})


def with_work(c: WorkerContainer, work: WorkManagerInterface) -> WorkerContainer:
    return dataclasses.replace(c, managers=dataclasses.replace(c.managers, work=work))


async def a_tenant_context(c: WorkerContainer) -> OpContext:
    rctx = RequestContext(request_id=new_id(), app=AppContext(type=AppType.BOOTSTRAP, version="test"))
    return await c.managers.tenancy.bootstrap(
        rctx, "Desk", f"desk-{new_id().hex[:6]}", f"{new_id().hex[:8]}@acme.example", "pswd_1234", "Owner"
    )


def an_item() -> WorkItem:
    now = utcnow()
    return WorkItem(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
        kind=WorkKind.NOOP,
        target_id=new_id(),
        idempotency_key=new_id(),
        request_id=new_id(),
        available_at=now,
    )


class Blocking(WorkHandlerInterface):
    """A handler that holds its item until told to finish."""

    def __init__(self) -> None:
        self.started = 0
        self.finish = asyncio.Event()

    async def handle(self, ctx: OpContext, item: WorkItem) -> None:
        self.started += 1
        await self.finish.wait()


class Delegating(WorkManagerInterface):
    """The real work manager, with one operation replaced by a test."""

    def __init__(self, inner: WorkManagerInterface, **replaced: Any) -> None:
        self._inner = inner
        self._replaced = replaced

    def __getattribute__(self, name: str) -> Any:
        replaced = object.__getattribute__(self, "_replaced")
        if name in replaced:
            return replaced[name]
        if name.startswith("_"):
            return object.__getattribute__(self, name)
        return getattr(object.__getattribute__(self, "_inner"), name)

    async def enqueue(self, ctx, item): ...  # type: ignore[no-untyped-def,override]
    async def enqueue_relayed(self, org_id, row): ...  # type: ignore[no-untyped-def,override]
    async def claim(self, rctx, lane, kinds, worker_id, lease): ...  # type: ignore[no-untyped-def,override]
    async def complete(self, ctx, item): ...  # type: ignore[no-untyped-def,override]
    async def fail(self, ctx, item, error): ...  # type: ignore[no-untyped-def,override]
    async def defer(self, ctx, item, delay): ...  # type: ignore[no-untyped-def,override]
    async def release(self, ctx, item, note): ...  # type: ignore[no-untyped-def,override]
    async def extend_lease(self, ctx, item, lease): ...  # type: ignore[no-untyped-def,override]
    async def requeue_stale(self, ctx): ...  # type: ignore[no-untyped-def,override]
    async def purge_items(self, rctx): ...  # type: ignore[no-untyped-def,override]
    async def read_gauges(self, rctx): ...  # type: ignore[no-untyped-def,override]
    async def maintenance_contexts(self, rctx): ...  # type: ignore[no-untyped-def,override]


async def eventually(check: Any, seconds: float = 3.0) -> None:
    deadline = asyncio.get_running_loop().time() + seconds
    while asyncio.get_running_loop().time() < deadline:
        if await check() if inspect.iscoroutinefunction(check) else check():
            return
        await asyncio.sleep(0.02)
    raise AssertionError("the condition never held")


LEASE = timedelta(seconds=0.6)
