"""The console script's first module: the OS trust store before any other import, then the worker."""

import sys


def main() -> int:
    from acme.infra import trust

    trust.install()
    from acme.workers.maintenance import main as commands

    return commands.main(sys.argv[1:])


if __name__ == "__main__":
    sys.exit(main())
