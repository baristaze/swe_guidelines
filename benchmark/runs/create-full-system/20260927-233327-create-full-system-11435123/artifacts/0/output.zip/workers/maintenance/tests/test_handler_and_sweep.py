"""The handler, run twice with the same item, and one sweep pass over the memory roots."""

from pathlib import Path

from prometheus_client import REGISTRY
from worker_harness import a_tenant_context, an_item, container

from acme.workers.maintenance.handler import NoopHandlerImpl
from acme.workers.maintenance.loop import WorkerLoop


async def test_the_handler_is_idempotent(tmp_path: Path) -> None:
    c = container(tmp_path)
    ctx = await a_tenant_context(c)
    item = an_item()
    handler = NoopHandlerImpl()
    await handler.handle(ctx, item)
    await handler.handle(ctx, item)


async def test_a_sweep_pass_relays_what_was_left_and_sets_the_gauges(tmp_path: Path) -> None:
    c = container(tmp_path)
    ctx = await a_tenant_context(c)
    user = await c.managers.tenancy.get_user(ctx, ctx.user_id)
    c.infra.get_topics().accepting = False  # type: ignore[attr-defined]  # the request path's relay is refused
    await c.managers.tenancy.update_user(ctx, user.model_copy(update={"name": "Renamed"}))
    assert await c.storage.get_outbox_storage().read_pending(10)
    c.infra.get_topics().accepting = True  # type: ignore[attr-defined]
    loop = WorkerLoop(c)
    await loop.sweep_once()
    assert await c.storage.get_outbox_storage().read_pending(10) == []
    assert REGISTRY.get_sample_value("acme_outbox_lag_seconds") == 0.0
    assert REGISTRY.get_sample_value("acme_queue_oldest_age_seconds") is not None
