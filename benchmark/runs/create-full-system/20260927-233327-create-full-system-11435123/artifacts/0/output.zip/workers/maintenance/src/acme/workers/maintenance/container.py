"""The worker's container: storage, then infra, then the managers, in the same order as a service's."""

import logging
from dataclasses import dataclass
from datetime import timedelta

from acme.infra.impl.configured import InfraConfiguredImpl
from acme.infra.impl.settings import InfraSettings
from acme.infra.observability import configure_error_tracking, configure_logging, configure_tracing
from acme.infra.root import InfraInterface
from acme.om.audit.impl.manager import AuditOptions
from acme.om.events.impl.manager import EventsOptions
from acme.om.idempotency.impl.manager import IdempotencyOptions
from acme.om.journalists.impl.manager import JournalistsOptions
from acme.om.outbox.impl.manager import OutboxOptions
from acme.om.root import ManagerOptions, Managers, build_managers
from acme.om.storage.impl.postgres import StoragePostgresImpl
from acme.om.storage.root import StorageInterface
from acme.om.storage.settings import StorageSettings
from acme.om.tenancy.impl.manager import TenancyOptions
from acme.om.work.impl.manager import WorkOptions
from acme.om.work.types.handler import WorkHandlerInterface
from acme.om.work.types.work_item import WorkKind
from acme.workers.maintenance.handler import NoopHandlerImpl
from acme.workers.maintenance.settings import WorkerSettings

logger = logging.getLogger(__name__)

SERVICE = "acme-maintenance"
VERSION = "0.1.0"


def boot(infra_settings: InfraSettings) -> None:
    """Logging, error reporting, tracing; the trust store is the entry module's, before this."""
    configure_logging(SERVICE, infra_settings.environment, infra_settings.log_json, infra_settings.log_level)
    configure_error_tracking(
        infra_settings.error_tracking_dsn, SERVICE, infra_settings.release, infra_settings.environment
    )
    configure_tracing(infra_settings.otel_exporter_endpoint, SERVICE, infra_settings.environment)


def manager_options(settings: WorkerSettings) -> ManagerOptions:
    return ManagerOptions(
        tenancy=TenancyOptions(
            signup_enabled=False,
            session_idle=timedelta(hours=24),
            session_absolute=timedelta(days=7),
            login_ttl=timedelta(minutes=15),
            socket_ticket_ttl=timedelta(seconds=30),
            api_key_max_expiry=timedelta(days=365),
            operator_token_max=timedelta(hours=1),
            touch_interval=timedelta(minutes=1),
            sign_in_delay_base=timedelta(seconds=1),
            sign_in_delay_cap=timedelta(minutes=15),
            page_size=settings.sweep_batch,
            purge_batch=settings.purge_batch,
            totp_encryption_key=None,  # a worker never enrols a second factor
            totp_issuer="Free Journalism",
        ),
        events=EventsOptions(page_size=settings.sweep_batch),
        audit=AuditOptions(page_size=settings.sweep_batch),
        outbox=OutboxOptions(retention=settings.outbox_retention, purge_batch=settings.purge_batch),
        idempotency=IdempotencyOptions(
            lease=timedelta(seconds=30), retention=settings.idempotency_retention, purge_batch=settings.purge_batch
        ),
        work=WorkOptions(
            item_retention=settings.item_retention,
            retry_base=timedelta(seconds=5),
            retry_cap=timedelta(minutes=10),
            purge_batch=settings.purge_batch,
            sweep_batch=settings.sweep_batch,
        ),
        journalists=JournalistsOptions(page_size=settings.sweep_batch),
    )


@dataclass(frozen=True)
class WorkerContainer:
    settings: WorkerSettings
    storage: StorageInterface
    infra: InfraInterface
    managers: Managers
    handlers: dict[WorkKind, WorkHandlerInterface]

    @classmethod
    def from_environment(cls) -> WorkerContainer:
        infra_settings = InfraSettings()
        boot(infra_settings)
        return cls.build(WorkerSettings(), infra_settings)

    @classmethod
    def build(cls, settings: WorkerSettings, infra_settings: InfraSettings) -> WorkerContainer:
        return cls._wire(settings, StoragePostgresImpl(StorageSettings()), InfraConfiguredImpl(infra_settings))

    @classmethod
    def for_tests(cls, storage: StorageInterface, infra: InfraInterface, settings: WorkerSettings) -> WorkerContainer:
        return cls._wire(settings, storage, infra)

    @classmethod
    def _wire(cls, settings: WorkerSettings, storage: StorageInterface, infra: InfraInterface) -> WorkerContainer:
        return cls(
            settings=settings,
            storage=storage,
            infra=infra,
            managers=build_managers(storage, infra, manager_options(settings)),
            handlers={WorkKind.NOOP: NoopHandlerImpl()},
        )

    async def start(self) -> None:
        await self.infra.start()
        logger.info("backends: %s; %s", self.storage.describe(), "; ".join(self.infra.describe()))

    async def close(self) -> None:
        await self.infra.close()
        await self.storage.close()
