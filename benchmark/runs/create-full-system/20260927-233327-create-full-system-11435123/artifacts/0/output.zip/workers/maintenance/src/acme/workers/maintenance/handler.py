"""The handler of the NOOP kind: it does nothing, and doing nothing twice is still nothing."""

from acme.om.opcontext import OpContext
from acme.om.work.types.handler import WorkHandlerInterface
from acme.om.work.types.work_item import WorkItem


class NoopHandlerImpl(WorkHandlerInterface):
    """Holds no manager: the maintenance worker's real work is the sweep. A kind added later writes its record by
    compare-and-set on the record's version, and makes its effects happen through an outbox row or a work item."""

    async def handle(self, ctx: OpContext, item: WorkItem) -> None:
        return None
