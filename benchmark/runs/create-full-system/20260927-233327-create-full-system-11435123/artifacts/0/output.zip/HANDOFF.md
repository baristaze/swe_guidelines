# Handoff

The run of `arch-scaffold-new free-journalism acme --codeowners acme --first journalists Journalist display_name:str`
against guideline release v0.37.0. Product: `/var/tmp/.../target/product-spec.md` (independent journalism platform).
Decisions are recorded as ADRs under `docs/adr/` (0001–0008); this note only points at them. Nothing is committed:
the first commit is the user's.

## Status

| Step | What | State |
|------|------|-------|
| 1 | skeleton, OM, infra, integrations, `make setup` | done |
| 2 | `arch-scaffold-service api --realtime --container` | done |
| 3 | `clients/python/`, `ops/` (incl. `ops/audit/`) | done |
| 4 | `arch-scaffold-worker maintenance NOOP --container` | done |
| 5 | `arch-scaffold-app portal --kind portal` | done (`apps/portal`, 57 vitest tests, build green) |
| 6 | `arch-scaffold-namespace journalists Journalist display_name:str` | done |
| 7 | `make check`, `make openapi`, infra-up, migrate, migrate-check, seed ×2, test-integration | done, all green |
| 8 | negative control on `core.journalists` | done, recorded in `docs/runbooks/tenant-isolation.md` |
| 9 | `make devx-up`, `make test-telemetry`, `make traffic PROFILE=light DURATION=30` | **stopped**: `make test-telemetry` fails (below) |
| 10 | the four-miss sweep, `arch-review-full`, reruns | not run (the stop came first) |

## Where it stopped, and the fix to make first

`make test-telemetry` fails with "the log line did not arrive within 90s". The cause is in
`services/api/src/acme/services/api/gateway/observability.py`, `RequestIdMiddleware.__call__`: its `finally` block
runs `request_id_var.reset(token)` before it writes the per-request log line, so that line carries
`request_id: null` and the round trip can't find it by request id. The fix: move the reset to after the log line
(the end of the `finally`), add a unit test asserting the request line carries the id, then rerun step 9 from
`make devx-up`. The counter, trace, and error-event reads come after the log read, so they are still unverified.

The runs of step 9 (run + 3 reruns, the bound the user set):
1. `make devx-up` failed: Docker could not bind host port 59090 (transient; nothing held it afterwards).
2. `make test-telemetry` failed: the shell had no `ACME_OPS_HOME`, so the env file was looked up in `~/.config`.
   This run keeps the ops home inside the tree at `.data/ops-home` (gitignored); export
   `ACME_OPS_HOME=$PWD/.data/ops-home` before `make seed`, `make test-telemetry`, `make traffic`.
3. Failed: the Prometheus container had come up without its published port after (1); recreated with
   `docker compose ... up -d --force-recreate prometheus`.
4. Failed: an unhandled 500 answered with no `x-request-id`, because Starlette's catch-all handler runs outside
   the request-id middleware. **Fixed** in `gateway/errors.py` (the handler stamps the header), with a test in
   `services/api/tests/test_health.py`.
5. (last allowed rerun) Failed: the log line, the defect above.

## Decisions taken in this session

- Portal: React 19, react-router 7 (v8 exists; the router line was held), TanStack Query 5, Zustand 5,
  @sentry/react 10 (11.0.0 is five days old), Vite 8, Vitest 5, openapi-typescript 7.13 (runs under TS 6.0.3
  despite its peer warning). The external sign-in button is left out of the portal for now.
- `scripts/dev.sh` writes `apps/portal/public/config.json` from `.env`; `ACME_PORTAL_ERROR_TRACKING_DSN` (empty
  locally) is documented in `.env.example`.
- Journalist: `Identifiable + Trackable + SoftDeletable`, core role, org scope, not versioned, no manager-owned
  fields, no unique key besides the id (ADR 0008). A `JournalistsOptions(page_size)` joined `ManagerOptions`.
- Migration `core/202609281630_journalists` (down revision `202609281200`).
- GlitchTip seed (`deployment/local/glitchtip/seed.py`): user `devx@acme.example`, org `acme`, project `acme-api`
  (id 1) with the DSN key `.env.example` names, API token from `ACME_LOCAL_GLITCHTIP_TOKEN`; idempotent.

## Left

- Fix the log-line defect above and rerun step 9, then step 10 (the sweep for the four misses, then
  `arch-review-full` once, close high findings, rerun steps 7 and 9).
- Optional: the deploy workflows' `jq` lines could write `requestTimeoutMs` into the portal's `config.json`
  (`deploy-staging.yml:182`, `deploy-production.yml:280` and `:400`); the portal falls back to 15 s without it.
- arch-check ASY-16 is excepted for `work_items` (ADR 0007): a checker defect worth reporting upstream.
- The compose stack (project `acme`) is left running; `make down` stops it.
