"""The database calls of every endpoint and worker flow, counted at the driver over an audit database.

    uv run python ops/audit/dbcalls.py run audit_<slug> --out <calls.json> [--flows <file.py>] [--only <flow,...>]
                                                         [--repeat <n>]
    uv run python ops/audit/dbcalls.py summary <calls.json>

`run` holds the API and the worker in one process over the audit database, with the provider twins and the local
infra in place of the backends: the API's container over the Postgres storage root, driven in-process through
`httpx.ASGITransport` over `create_app`, and the worker's container beside it. It runs the built-in flows of
`dbcalls_flows.py` (`seed` always first; `--only` picks among the rest) and every flow of a run's own flows file
(`--flows`, plain Python whose `FLOWS` lists `async def flow(w)`), each `--repeat` times (2 by default; `seed` once).
A flow calls `w.http(area, name, method, path, ...)` for a request and `w.measure(area, name, lambda: <awaitable>)`
for a manager or worker call. Every round trip (BEGIN, each statement, COMMIT or ROLLBACK, the pool's pre-ping),
every transaction, and its role (the schema its statements name) is counted by the SQLAlchemy engine events, and
each transaction is labelled with the storage method that opened it. The counts are warm: a statement's preparation
is not a round trip here. A flow that fails is named, the rest run, and `run` exits 1.

`summary` prints the table of a result file. The shared `acme` database is refused by name, like any database that
is not an audit database on the local machine.
"""

import argparse
import asyncio
import importlib.util
import inspect
import json
import logging
import re
import subprocess
import sys
import tempfile
import time
from collections import Counter
from collections.abc import Awaitable, Callable, Iterable, Iterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from types import FrameType
from typing import Any, TypeVar
from urllib.parse import urlparse
from uuid import uuid4

import auditdb
import dbcalls_flows
import greenlet
import httpx
from cryptography.fernet import Fernet
from fastapi import FastAPI
from sqlalchemy import event
from sqlalchemy.engine import Connection, Engine
from sqlalchemy.pool import Pool

from acme.infra.impl.local import InfraLocalImpl
from acme.om.storage.impl.postgres import StoragePostgresImpl
from acme.om.storage.settings import StorageSettings
from acme.services.api.app import create_app
from acme.services.api.container import AppContainer
from acme.services.api.settings import ApiSettings
from acme.workers.maintenance.container import WorkerContainer
from acme.workers.maintenance.settings import WorkerSettings

logger = logging.getLogger("dbcalls")

T = TypeVar("T")
Flow = Callable[["World"], Awaitable[None]]

ROLE_REFERENCE = re.compile(r"(?<![\w.])\"?(core|activity|queue)\"?\.\"?[a-z_]", re.IGNORECASE)
STORAGE_FILE = re.compile(r"acme/om/(?:[a-z_]+/)?storage/impl/postgres\.py$")
UNLABELLED = "(no storage method)"
SET_CONFIG = "set_config"


class FlowError(Exception):
    """A step of a flow that did not answer what the flow needs."""


def role_of(statement: str) -> str | None:
    """The database role a statement touches, by the schema its tables are qualified with."""
    roles = {m.group(1).lower() for m in ROLE_REFERENCE.finditer(statement)}
    if not roles:
        return None
    return "+".join(sorted(roles))


def storage_label(frames: Iterable[tuple[str, str]]) -> str:
    """The first frame, innermost out, inside a namespace's Postgres storage impl: its qualified function name."""
    for filename, qualname in frames:
        if STORAGE_FILE.search(filename.replace("\\", "/")):
            return qualname
    return UNLABELLED


def _walk(frame: FrameType | None) -> Iterator[tuple[str, str]]:
    while frame is not None:
        yield frame.f_code.co_filename, frame.f_code.co_qualname
        frame = frame.f_back


def current_frames() -> Iterator[tuple[str, str]]:
    """The stack of the running greenlet, then of each parent: SQLAlchemy's asyncio runs the driver in a child
    greenlet, whose own stack ends where it was spawned; the awaiting coroutines are in the parent's frame."""
    yield from _walk(sys._getframe(1))
    parent = greenlet.getcurrent().parent
    while parent is not None:
        yield from _walk(parent.gr_frame)
        parent = parent.parent


def shorten(statement: str, width: int = 160) -> str:
    text = " ".join(statement.split())
    return text if len(text) <= width else text[: width - 3] + "..."


@dataclass
class Transaction:
    login: str
    label: str
    statements: list[str] = field(default_factory=list)
    scope: dict[str, str] = field(default_factory=dict)
    end: str = ""

    @property
    def roles(self) -> list[str]:
        return sorted({r for r in (role_of(s) for s in self.statements) if r})

    @property
    def role(self) -> str:
        return "+".join(self.roles) or "none"

    @property
    def round_trips(self) -> int:
        return 1 + len(self.statements) + (1 if self.end else 0)

    def detail(self) -> str:
        scope = " ".join(f"{k.removeprefix('app.')}={v}" for k, v in self.scope.items() if k.startswith("app."))
        folded: list[str] = []
        for text, count in _runs(shorten(s) for s in self.statements):
            folded.append(text if count == 1 else f"{text} x{count}")
        body = "; ".join(["BEGIN", *folded, self.end or "(open)"])
        return f"{self.role} | {self.login} | {scope or 'no scope'} | {self.label} | {body}"


def _runs(items: Iterable[str]) -> list[tuple[str, int]]:
    out: list[tuple[str, int]] = []
    for item in items:
        if out and out[-1][0] == item:
            out[-1] = (item, out[-1][1] + 1)
        else:
            out.append((item, 1))
    return out


@dataclass
class Sample:
    """One measured call: its transactions, the pool's pre-pings, and the new connections it opened."""

    transactions: list[Transaction] = field(default_factory=list)
    pings: int = 0
    connects: int = 0
    sizes: dict[str, int] = field(default_factory=dict)

    @property
    def round_trips(self) -> int:
        return sum(t.round_trips for t in self.transactions) + self.pings

    def per_role(self) -> dict[str, int]:
        out: Counter[str] = Counter()
        for t in self.transactions:
            out[t.role] += t.round_trips
        return dict(out)

    def per_method(self) -> dict[str, int]:
        return dict(Counter(t.label for t in self.transactions))


class Recorder:
    """The engine and pool events of every engine in the process, kept while a call is measured."""

    def __init__(self) -> None:
        self.current: Sample | None = None
        self._open: dict[int, Transaction] = {}
        self._fresh: set[int] = set()

    def install(self) -> None:
        event.listen(Engine, "begin", self._begin)
        event.listen(Engine, "commit", self._commit)
        event.listen(Engine, "rollback", self._rollback)
        event.listen(Engine, "before_cursor_execute", self._execute)
        event.listen(Pool, "connect", self._connect)
        event.listen(Pool, "checkout", self._checkout)

    def uninstall(self) -> None:
        event.remove(Engine, "begin", self._begin)
        event.remove(Engine, "commit", self._commit)
        event.remove(Engine, "rollback", self._rollback)
        event.remove(Engine, "before_cursor_execute", self._execute)
        event.remove(Pool, "connect", self._connect)
        event.remove(Pool, "checkout", self._checkout)

    def _transaction(self, conn: Connection) -> Transaction | None:
        if self.current is None:
            return None
        found = self._open.get(id(conn))
        if found is None:
            found = Transaction(login=str(conn.engine.url.username), label=storage_label(current_frames()))
            self._open[id(conn)] = found
            self.current.transactions.append(found)
        return found

    def _begin(self, conn: Connection) -> None:
        self._open.pop(id(conn), None)
        self._transaction(conn)

    def _end(self, conn: Connection, verb: str) -> None:
        found = self._open.pop(id(conn), None)
        if found is not None and self.current is not None:
            found.end = verb

    def _commit(self, conn: Connection) -> None:
        self._end(conn, "COMMIT")

    def _rollback(self, conn: Connection) -> None:
        self._end(conn, "ROLLBACK")

    def _execute(
        self, conn: Connection, cursor: Any, statement: str, parameters: Any, context: Any, executemany: bool
    ) -> None:
        found = self._transaction(conn)
        if found is None:
            return
        found.statements.append(statement)
        if SET_CONFIG in statement and isinstance(parameters, tuple | list) and len(parameters) == 2:
            found.scope[str(parameters[0])] = str(parameters[1])

    def _connect(self, dbapi_connection: Any, record: Any) -> None:
        self._fresh.add(id(record))
        if self.current is not None:
            self.current.connects += 1

    def _checkout(self, dbapi_connection: Any, record: Any, proxy: Any) -> None:
        if id(record) in self._fresh:
            self._fresh.discard(id(record))  # a new connection is not pinged on its first checkout
        elif self.current is not None:
            self.current.pings += 1

    def start(self) -> Sample:
        self._open.clear()
        self.current = Sample()
        return self.current

    def stop(self) -> None:
        self.current = None
        self._open.clear()


@dataclass
class CallResult:
    area: str
    name: str
    samples: list[Sample] = field(default_factory=list)

    def to_json(self) -> dict[str, Any]:
        trips = [s.round_trips for s in self.samples]
        txs = [len(s.transactions) for s in self.samples]
        roles: dict[str, int] = {}
        methods: dict[str, int] = {}
        for s in self.samples:
            for role, count in s.per_role().items():
                roles[role] = max(roles.get(role, 0), count)
            for label, count in s.per_method().items():
                methods[label] = max(methods.get(label, 0), count)
        most = max(self.samples, key=lambda s: s.round_trips)
        return {
            "area": self.area,
            "name": self.name,
            "samples": len(self.samples),
            "round_trips": {"min": min(trips), "max": max(trips)},
            "transactions": {"min": min(txs), "max": max(txs)},
            "roles": roles,
            "methods": methods,
            "pings": max(s.pings for s in self.samples),
            "connects": max(s.connects for s in self.samples),
            "sizes": [s.sizes for s in self.samples if s.sizes],
            "detail": [t.detail() for t in most.transactions]
            + ([f"pool pre-ping x{most.pings} (a round trip each, outside the transactions)"] if most.pings else []),
        }


@dataclass
class FlowResult:
    flow: str
    source: str
    calls: dict[tuple[str, str], CallResult] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    def to_json(self) -> dict[str, Any]:
        return {
            "flow": self.flow,
            "source": self.source,
            "status": "failed" if self.errors else "ok",
            "errors": self.errors,
            "calls": [c.to_json() for c in self.calls.values()],
        }


class World:
    """What a flow drives: the API over HTTP in-process, both containers, and what `seed` left in `state`."""

    def __init__(
        self, app: FastAPI, client: httpx.AsyncClient, api: AppContainer, worker: WorkerContainer, recorder: Recorder
    ) -> None:
        self.app = app
        self.client = client
        self.api = api
        self.worker = worker
        self.state: dict[str, Any] = {}
        self._recorder = recorder
        self._flow: FlowResult | None = None

    def begin_flow(self, flow: FlowResult) -> None:
        self._flow = flow

    @staticmethod
    def unique() -> str:
        return uuid4().hex[:10]

    async def measure(
        self, area: str, name: str, call: Callable[[], Awaitable[T]], sizes: dict[str, int] | None = None
    ) -> T:
        if self._flow is None:
            raise FlowError("a call is measured inside a flow")
        sample = self._recorder.start()
        try:
            return await call()
        finally:
            self._recorder.stop()
            sample.sizes = dict(sizes or {})
            key = (area, name)
            self._flow.calls.setdefault(key, CallResult(area, name)).samples.append(sample)

    def note(self, area: str, name: str, **sizes: int) -> None:
        """Sizes learned from a call's answer (a list's length), on its latest sample."""
        if self._flow is None or (area, name) not in self._flow.calls:
            raise FlowError(f"no call {area}/{name} was measured in this flow")
        self._flow.calls[(area, name)].samples[-1].sizes.update(sizes)

    async def http(
        self,
        area: str,
        name: str,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        json: Any = None,
        params: dict[str, Any] | None = None,
        expect: int | None = None,
        sizes: dict[str, int] | None = None,
    ) -> httpx.Response:
        response = await self.measure(
            area,
            name,
            lambda: self.client.request(method, path, headers=headers, json=json, params=params),
            sizes,
        )
        ok = response.status_code == expect if expect is not None else response.status_code < 400
        if not ok:
            raise FlowError(f"{method} {path} answered {response.status_code}: {response.text[:300]}")
        return response


def load_flows(path: str) -> list[Flow]:
    """A run's own flows file: plain Python whose FLOWS lists async callables that take the world."""
    spec = importlib.util.spec_from_file_location(f"audit_flows_{Path(path).stem}", path)
    if spec is None or spec.loader is None:
        raise auditdb.Refused(f"refused: {path} is not a Python file")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    flows = getattr(module, "FLOWS", None)
    if not isinstance(flows, list) or not all(inspect.iscoroutinefunction(f) for f in flows):
        raise auditdb.Refused(f"refused: {path} has no FLOWS list of async functions")
    return list(flows)


def select_builtin(flows: list[Flow], only: str | None) -> list[Flow]:
    """`seed` first, always; `--only` names some of the rest."""
    by_name = {f.__name__: f for f in flows}
    if "seed" not in by_name:
        raise auditdb.Refused("refused: the built-in flows have no seed")
    if only is None:
        rest = [f for f in flows if f.__name__ != "seed"]
    else:
        wanted = [n.strip() for n in only.split(",") if n.strip() and n.strip() != "seed"]
        unknown = sorted(set(wanted) - set(by_name))
        if unknown:
            raise auditdb.Refused(f"refused: no built-in flow named {unknown}; there are {sorted(by_name)}")
        rest = [by_name[n] for n in wanted]
    return [by_name["seed"], *rest]


def commit_of() -> str:
    try:
        found = subprocess.run(
            ["git", "rev-parse", "HEAD"],  # noqa: S607 - git from PATH
            cwd=auditdb.ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
    except OSError, subprocess.CalledProcessError:
        return "unknown (not a git checkout)"
    return found.stdout.strip()


def point_at(target: auditdb.Target) -> StorageSettings:
    """The storage settings of the audit database alone, every URL local and naming it; nothing read from .env."""
    settings = StorageSettings(
        _env_file=None,  # type: ignore[call-arg]
        database_url=target.runtime_url,
        database_system_url=target.system_url,
        database_migration_url=target.migration_url,
        database_master_url="",
        database_url_core="",
        database_url_activity="",
        database_url_queue="",
        database_system_url_core="",
        database_system_url_activity="",
        database_system_url_queue="",
    )
    for url in settings.all_urls():
        auditdb.check_local(url)
        if urlparse(url).path.lstrip("/") != target.name:
            raise auditdb.Refused(f"refused: a storage URL names another database than {target.name}")
    return settings


async def run_flows(target: auditdb.Target, flows: list[tuple[Flow, str]], repeat: int) -> list[FlowResult]:
    settings = point_at(target)
    api_settings = ApiSettings(
        _env_file=None,  # type: ignore[call-arg]
        totp_encryption_key=Fernet.generate_key().decode(),
        internal_signing_key="audit-internal-signing-key",
        rate_limit_auth="100000/60",
        rate_limit_writes="100000/60",
    )
    recorder = Recorder()
    recorder.install()
    results: list[FlowResult] = []
    with tempfile.TemporaryDirectory(prefix="acme-dbcalls-") as scratch:
        api = AppContainer.for_tests(StoragePostgresImpl(settings), InfraLocalImpl(Path(scratch) / "api"), api_settings)
        worker = WorkerContainer.for_tests(
            StoragePostgresImpl(settings),
            InfraLocalImpl(Path(scratch) / "worker"),
            WorkerSettings(_env_file=None),  # type: ignore[call-arg]
        )
        app = create_app(api)
        try:
            await worker.start()
            async with (
                app.router.lifespan_context(app),
                httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://audit") as client,
            ):
                world = World(app, client, api, worker, recorder)
                for flow, source in flows:
                    result = FlowResult(flow.__name__, source)
                    results.append(result)
                    world.begin_flow(result)
                    runs = 1 if (flow.__name__ == "seed" and source == "built-in") else repeat
                    for attempt in range(runs):
                        started = time.monotonic()
                        try:
                            await flow(world)
                        except Exception as error:
                            result.errors.append(f"run {attempt + 1}: {type(error).__name__}: {error}")
                            logger.exception("flow %s failed on run %d", flow.__name__, attempt + 1)
                            break
                        logger.info("flow %s run %d: %.2fs", flow.__name__, attempt + 1, time.monotonic() - started)
        finally:
            await worker.close()
            recorder.uninstall()
    return results


def run(name: str, out: str, flows_file: str | None, only: str | None, repeat: int) -> int:
    target = auditdb.require(name)
    chosen = [(f, "built-in") for f in select_builtin(list(dbcalls_flows.FLOWS), only)]
    if flows_file:
        chosen += [(f, flows_file) for f in load_flows(flows_file)]
    started = datetime.now(UTC)
    results = asyncio.run(run_flows(target, chosen, repeat))
    document = {
        "database": name,
        "commit": commit_of(),
        "started_at": started.isoformat(),
        "repeat": repeat,
        "counted": "warm round trips at the driver: BEGIN, each statement, COMMIT or ROLLBACK, the pool's pre-ping",
        "flows": [r.to_json() for r in results],
    }
    path = Path(out).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(document, indent=2) + "\n")
    failed = [r.flow for r in results if r.errors]
    print(f"wrote {path}: {len(results)} flows, {sum(len(r.calls) for r in results)} calls, {len(failed)} failed")
    if failed:
        logger.error("failed flows: %s", ", ".join(failed))
    return 1 if failed else 0


def _span(values: dict[str, int]) -> str:
    return str(values["min"]) if values["min"] == values["max"] else f"{values['min']}-{values['max']}"


def render_summary(document: dict[str, Any]) -> str:
    """The table of a result file: one row per measured call, then the failed flows."""
    headers = ["flow", "area", "call", "min", "max", "tx", "roles", "storage methods"]
    rows: list[list[str]] = []
    for flow in document["flows"]:
        for call in flow["calls"]:
            methods = ", ".join(
                f"{label.rsplit('.', 1)[-1]}" + (f" x{count}" if count > 1 else "")
                for label, count in call["methods"].items()
            )
            rows.append(
                [
                    flow["flow"],
                    call["area"],
                    call["name"],
                    str(call["round_trips"]["min"]),
                    str(call["round_trips"]["max"]),
                    _span(call["transactions"]),
                    " ".join(f"{role}:{count}" for role, count in sorted(call["roles"].items())) or "-",
                    methods or "-",
                ]
            )
    widths = [max([len(h)] + [len(r[i]) for r in rows]) for i, h in enumerate(headers)]

    def line(cells: list[str]) -> str:
        return " | ".join(c.ljust(w) for c, w in zip(cells, widths, strict=True)).rstrip()

    out = [
        f"{document['database']} at {document['commit']}, {document['repeat']} run(s) per flow; {document['counted']}",
        "",
        line(headers),
        line(["-" * w for w in widths]),
        *(line(r) for r in rows),
    ]
    failed = [f for f in document["flows"] if f["status"] == "failed"]
    if failed:
        out += ["", "Failed flows:"]
        out += [f"- {f['flow']} ({f['source']}): {'; '.join(f['errors'])}" for f in failed]
    return "\n".join(out)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="dbcalls.py", description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)
    run_p = sub.add_parser("run", help="run the flows over an audit database and write the counts")
    run_p.add_argument("name", help="audit_<slug>, made with auditdb.py create")
    run_p.add_argument("--out", required=True, help="the result file (JSON)")
    run_p.add_argument("--flows", help="a run's own flows file: FLOWS, a list of async def flow(w)")
    run_p.add_argument("--only", help="some built-in flows, comma-separated; seed always runs first")
    run_p.add_argument("--repeat", type=int, default=2, help="runs of each flow, for min and max (default 2)")
    summary_p = sub.add_parser("summary", help="print the table of a result file")
    summary_p.add_argument("file")
    return p


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="%(name)s: %(message)s")
    for noisy in ("acme", "httpx"):  # the application's own request lines; its warnings and errors still show
        logging.getLogger(noisy).setLevel(logging.WARNING)
    args = parser().parse_args(argv)
    try:
        if args.command == "run":
            if args.repeat < 1:
                raise auditdb.Refused("refused: --repeat is at least 1")
            return run(args.name, args.out, args.flows, args.only, args.repeat)
        print(render_summary(json.loads(Path(args.file).expanduser().read_text())))
    except auditdb.Refused as refused:
        logger.error("%s", refused)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
