"""The stress runner: the traffic generator with a scenario, and a verdict against the target stated before."""
