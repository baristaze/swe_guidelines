"""The ops tool's own units: the env file's guard, the report's arithmetic, and the scenario's verdict."""

import os
from pathlib import Path

import pytest

from acme.ops import envfile
from acme.ops.stress.scenario import load, verdict
from acme.ops.traffic.profiles import PROFILES
from acme.ops.traffic.report import Recorder, percentile
from acme.ops.traffic.session import socket_url

ROOT = Path(__file__).resolve().parents[2]


@pytest.fixture(autouse=True)
def ops_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    monkeypatch.setenv("ACME_OPS_HOME", str(tmp_path))
    return tmp_path


def test_the_env_file_is_refused_unless_owner_only(ops_home: Path) -> None:
    envfile.write_value("local", "ACME_API_URL", "http://localhost:8000")
    assert envfile.read("local")["ACME_API_URL"] == "http://localhost:8000"
    assert oct((ops_home / "local.env").stat().st_mode & 0o777) == "0o600"
    os.chmod(ops_home / "local.env", 0o644)
    with pytest.raises(envfile.EnvFileError, match="owner-only"):
        envfile.read("local")


def test_writing_a_token_replaces_its_line(ops_home: Path) -> None:
    envfile.write_value("local", envfile.OPERATOR_TOKEN, "first")
    envfile.write_value("local", envfile.OPERATOR_TOKEN, "second")
    assert envfile.read("local")[envfile.OPERATOR_TOKEN] == "second"
    assert (ops_home / "local.env").read_text().count(envfile.OPERATOR_TOKEN) == 1


def test_an_empty_token_names_the_command_that_mints_one() -> None:
    with pytest.raises(envfile.EnvFileError, match="acme-ops token --env staging --identity provisioner"):
        envfile.require({}, envfile.PROVISIONER_TOKEN, "staging")


def test_an_unknown_environment_is_refused() -> None:
    with pytest.raises(envfile.EnvFileError):
        envfile.path_for("qa")


def test_percentiles_and_the_error_ratio() -> None:
    assert percentile([0.1, 0.2, 0.3, 0.4], 0.5) == 0.2
    recorder = Recorder()
    for status in (200, 200, 503, "transport"):
        recorder.record("GET /v1/org", status, 0.01)
    assert recorder.errors() == 2 and recorder.error_ratio() == 0.5
    assert recorder.summary()["by_route"]["GET /v1/org"]["count"] == 4


def test_the_four_profiles_grow() -> None:
    names = ["light", "regular", "heavy", "stress"]
    assert list(PROFILES) == names
    assert [PROFILES[n].concurrency for n in names] == sorted(PROFILES[n].concurrency for n in names)


def test_the_baseline_scenario_loads_and_judges() -> None:
    scenario = load(ROOT / "ops/stress/baseline.yaml")
    assert scenario.profile.name == "regular" and scenario.target.p95_ms == 500
    assert verdict(scenario, 120.0, 0.0)[0]
    assert not verdict(scenario, 900.0, 0.0)[0]


def test_the_socket_url_follows_the_scheme() -> None:
    assert socket_url("https://api.example", "t").startswith("wss://api.example/v1/realtime/socket?ticket=t")
    assert socket_url("http://localhost:8000", "t").startswith("ws://localhost:8000/")
