"""The telemetry round trip: start the API for real, drive one session through the edge (one call failing on purpose
locally), and read every signal back by the request id the response carried: the log line, the counter, the trace,
and the error event. Against a deployed environment it is the smoke test: nothing fails on purpose, the base is the
environment's, and the operator plane is reached with the smoke identity's token.

    ACME_OPS_ENV=local make test-telemetry         # needs `make devx-up`, `make migrate`, `make seed`
    ACME_OPS_ENV=staging ACME_SMOKE_TOKEN=... uv run pytest -m telemetry ops/tests/test_telemetry_roundtrip.py
"""

import asyncio
import os
import secrets
import socket
import subprocess
import time
from collections.abc import Callable, Iterator
from pathlib import Path

import httpx
import pytest

from acme.clients.api import models
from acme.ops import api
from acme.ops.envfile import OPERATOR_TOKEN, read, require
from acme.ops.main import readers
from acme.ops.signals import SignalsInterface

pytestmark = pytest.mark.telemetry

ENV = os.environ.get("ACME_OPS_ENV", "local")
ROOT = Path(__file__).resolve().parents[2]
DEADLINE_SECONDS = 90


def wait_for(what: str, probe: Callable[[], bool]) -> None:
    deadline = time.monotonic() + DEADLINE_SECONDS
    while time.monotonic() < deadline:
        try:
            if probe():
                return
        except httpx.HTTPError, OSError, ValueError, KeyError:
            pass
        time.sleep(2)
    pytest.fail(f"{what} did not arrive within {DEADLINE_SECONDS}s")


@pytest.fixture(scope="module")
def base_url(tmp_path_factory: pytest.TempPathFactory) -> Iterator[tuple[str, Path | None]]:
    """Locally, the API as a real process with the OTLP endpoint and the DSN set; deployed, the environment's edge."""
    values = read(ENV)
    if ENV != "local":
        yield values["ACME_API_URL"], None
        return
    port = int(os.environ.get("ACME_API_PORT", "8000"))
    with socket.socket() as probe:
        if probe.connect_ex(("127.0.0.1", port)) == 0:
            pytest.fail(f"port {port} is taken; stop the host API (scripts/dev.sh stop) so the test starts its own")
    log = tmp_path_factory.mktemp("api") / "api.log"
    handle = log.open("w")
    process = subprocess.Popen(
        ["uv", "run", "acme-api", "serve"],
        cwd=ROOT,
        stdout=handle,
        stderr=subprocess.STDOUT,
        env={**os.environ, "ACME_API_PORT": str(port), "ACME_LOG_JSON": "true"},
    )
    url = f"http://localhost:{port}"
    try:
        wait_for("the API", lambda: httpx.get(f"{url}/healthz", timeout=2).status_code == 200)
        yield url, log
    finally:
        process.terminate()
        process.wait(timeout=20)
        handle.close()


async def one_session(url: str, operator_token: str) -> tuple[str, str | None]:
    """Sign up, enter the desk, read it; the operator plane read with a token; locally one call fails on purpose.
    Answers the request id of the read and of the failure."""
    anonymous = api.client(url)
    operator = api.client(url, operator_token)
    try:
        assert (await operator.admin_get_size()).tenants >= 0
        slug = f"smoke-{secrets.token_hex(3)}"
        signed = await anonymous.tenancy_sign_up(
            models.SignUpRequest(
                email=f"{slug}@acme.example",
                password=secrets.token_urlsafe(16),
                display_name="Smoke",
                org_name="Smoke",
                org_slug=slug,
            )
        )
        login = anonymous.with_bearer(signed.token)
        session = await login.tenancy_exchange(models.ExchangeRequest(org_id=signed.memberships[0].org_id))
        await login.aclose()
    finally:
        await operator.aclose()
        await anonymous.aclose()
    async with httpx.AsyncClient(base_url=url, timeout=10) as raw:
        read_response = await raw.get("/v1/org", headers={"Authorization": f"Bearer {session.token}"})
        assert read_response.status_code == 200
        failed_id = None
        if ENV == "local":
            failed = await raw.post("/v1/diagnostics/failure")
            assert failed.status_code == 500
            failed_id = failed.headers["x-request-id"]
    return read_response.headers["x-request-id"], failed_id


def test_every_signal_reads_back_by_request_id(base_url: tuple[str, Path | None]) -> None:
    url, log = base_url
    values = read(ENV)
    token = os.environ.get("ACME_SMOKE_TOKEN") or require(values, OPERATOR_TOKEN, ENV)
    signals: SignalsInterface = readers(ENV, values, log)
    before = signals.metric_value("acme_http_requests_total", {"route": "/v1/org", "status": "200"})
    read_id, failed_id = asyncio.run(one_session(url, token))

    wait_for("the log line", lambda: bool(signals.log_lines(read_id, 15)))
    wait_for(
        "the counter",
        lambda: signals.metric_value("acme_http_requests_total", {"route": "/v1/org", "status": "200"}) > before,
    )
    wait_for("the trace", lambda: signals.trace(read_id, 15))
    if failed_id is not None:
        wait_for("the error event", lambda: signals.error_event(failed_id, 15))
