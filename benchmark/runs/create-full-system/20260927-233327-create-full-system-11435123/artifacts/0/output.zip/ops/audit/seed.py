"""A heavy synthetic shape in an audit database, written as the superuser, then ANALYZE.

    uv run python ops/audit/seed.py audit_<slug> --scale <n>      # 1 by default; 0.01 is a quick run, same shape

No login the application holds walks past the row-level policies, so the rows go in as the stack's superuser, with
INSERT ... SELECT over generate_series. At scale 1: 5,000 people, each an identity with a personal org, its user,
membership, identity membership, a live session and ten events; one team org of 1,000 of those people holding
100,000 work items across queued, claimed, done, and failed (and 100,000 journalists when core.journalists exists),
1,000,000 events with its gapless seq and cursor head, 100,000 audit entries, 50,000 outbox rows, 50,000 idempotency
markers, 1,000 API keys, and the expired sessions, socket tickets, and sign-in failures the purges walk. Every count
is linear in the scale (at least 1). Every seeded person signs in with the password `pswd_seed_1234`.

Each table's columns are read from the migrated schema: a column the shape does not name gets a value by its type,
so a migration that adds one does not break the seed. Standard output carries the rows per table.
"""

import argparse
import importlib
import logging
import pkgutil
import sys
import time
from dataclasses import dataclass
from enum import StrEnum
from typing import LiteralString, cast

import auditdb
import psycopg

from acme.om.tenancy.impl.credentials import hash_password

logger = logging.getLogger("seed")

SEED_PASSWORD = "pswd_seed_1234"
TEAM = "md5('team:1')::uuid"
APP = """'{"type": "bootstrap", "version": "seed@0"}'::jsonb"""
BASE = {
    "people": 5_000,
    "team_members": 1_000,
    "items": 100_000,
    "journalists": 100_000,
    "events": 1_000_000,
    "events_per_person": 10,
    "audit_entries": 100_000,
    "outbox": 50_000,
    "markers": 50_000,
    "api_keys": 1_000,
    "stale_sessions": 20_000,
    "socket_tickets": 10_000,
    "sign_in_failures": 500,
    "operators": 5,
}


def uid(namespace: str, expr: str = "g.i") -> str:
    """A deterministic id per row, so rows of different tables name each other without a join."""
    return f"md5('{namespace}:' || ({expr}))::uuid"


def sha256_hex(expr: str) -> str:
    return f"encode(sha256(convert_to({expr}, 'UTF8')), 'hex')"


def ago(expr: str, unit: str = "minute") -> str:
    return f"now() - ({expr}) * interval '1 {unit}'"


def counts(scale: float) -> dict[str, int]:
    """Every count at a scale, linear, never below one; team members never more than the people."""
    if scale <= 0:
        raise ValueError("the scale is positive")
    out = {key: max(1, round(value * scale)) for key, value in BASE.items()}
    out["events_per_person"] = BASE["events_per_person"]
    out["team_members"] = min(out["team_members"], out["people"])
    return out


@dataclass(frozen=True)
class Column:
    name: str
    data_type: str
    nullable: bool


@dataclass
class Batch:
    """One INSERT ... SELECT: a table, its row count, and the expressions of the columns the shape names."""

    table: str
    rows: int
    values: dict[str, str]
    label: str = ""


def default_for(table: str, column: Column) -> str | None:
    """A value by type for a NOT NULL column the shape does not name; None leaves a nullable column NULL."""
    if column.nullable:
        return None
    kind = column.data_type
    if kind == "uuid":
        return uid(f"{table}.{column.name}")
    if kind in ("character varying", "text"):
        return f"'{column.name}-' || g.i"
    if kind in ("integer", "bigint", "smallint", "numeric"):
        return "0"
    if kind == "boolean":
        return "false"
    if kind in ("jsonb", "json"):
        return "'{}'::jsonb"
    if kind.startswith("timestamp") or kind == "date":
        return "now()"
    raise ValueError(f"{table}.{column.name} is NOT NULL of type {kind}, which the seed has no value for")


def insert_sql(batch: Batch, columns: list[Column]) -> str:
    """The statement of one batch over the table's columns as migrated."""
    known = {c.name for c in columns}
    unknown = sorted(set(batch.values) - known)
    if unknown:
        raise ValueError(f"the seed names {unknown}, which {batch.table} does not have")
    names: list[str] = []
    exprs: list[str] = []
    for column in columns:
        expr = batch.values.get(column.name) or default_for(batch.table, column)
        if expr is not None:
            names.append(f'"{column.name}"')
            exprs.append(expr)
    # The shape's own expressions over the migrated schema's names: no outside input reaches the statement.
    target = f"{batch.table} ({', '.join(names)})"
    rows = f"generate_series(1, {int(batch.rows)}) AS g(i)"
    return f"INSERT INTO {target} SELECT {', '.join(exprs)} FROM {rows}"  # noqa: S608


def batches(n: dict[str, int], journalist_states: list[str] | None) -> list[Batch]:
    people, members = n["people"], n["team_members"]
    per = n["events_per_person"]
    team_user = uid("team-user", f"1 + g.i % {members}")
    out = [
        Batch("core.orgs", 1, {"id": TEAM, "name": "'Seed Team'", "slug": "'seed-team'"}, "team org"),
        Batch(
            "core.orgs",
            people,
            {"id": uid("org"), "name": "'Person ' || g.i", "slug": "'person-' || g.i", "created_at": ago("g.i")},
            "personal orgs",
        ),
        Batch(
            "core.identities",
            people,
            {
                "id": uid("identity"),
                "identity_id": uid("identity"),
                "email": "'person' || g.i || '@seed.example'",
                "email_digest": sha256_hex("'person' || g.i || '@seed.example'"),
                "display_name": "'Person ' || g.i",
                "password_hash": f"'{hash_password(SEED_PASSWORD)}'",  # scrypt$n$r$p$salt$hash: no quote in it
            },
        ),
        Batch(
            "core.users",
            people,
            {"id": uid("user"), "org_id": uid("org"), "identity_id": uid("identity"), "name": "'Person ' || g.i"},
            "personal users",
        ),
        Batch(
            "core.memberships",
            people,
            {"id": uid("membership"), "org_id": uid("org"), "user_id": uid("user"), "role": "'owner'"},
            "personal memberships",
        ),
        Batch(
            "core.identity_memberships",
            people,
            {
                "id": uid("identity-membership"),
                "identity_id": uid("identity"),
                "tenant_id": uid("org"),
                "user_id": uid("user"),
                "role": "'owner'",
            },
            "personal identity memberships",
        ),
        Batch(
            "core.users",
            members,
            {"id": uid("team-user"), "org_id": TEAM, "identity_id": uid("identity"), "name": "'Member ' || g.i"},
            "team users",
        ),
        Batch(
            "core.memberships",
            members,
            {
                "id": uid("team-membership"),
                "org_id": TEAM,
                "user_id": uid("team-user"),
                "role": "CASE WHEN g.i = 1 THEN 'owner' ELSE (ARRAY['admin','member','viewer'])[1 + g.i % 3] END",
            },
            "team memberships",
        ),
        Batch(
            "core.identity_memberships",
            members,
            {
                "id": uid("team-identity-membership"),
                "identity_id": uid("identity"),
                "tenant_id": TEAM,
                "user_id": uid("team-user"),
                "role": "CASE WHEN g.i = 1 THEN 'owner' ELSE 'member' END",
            },
            "team identity memberships",
        ),
        Batch(
            "core.sessions",
            people,
            {
                "id": uid("session"),
                "identity_id": uid("identity"),
                "created_at": ago("g.i % 1440"),
                "kind": "'tenant'",
                "tenant_id": uid("org"),
                "user_id": uid("user"),
                "digest": sha256_hex("'seed-session-' || g.i"),
                "second_factor": "false",
                "last_seen_at": ago("g.i % 60"),
                "expires_at": "now() + interval '7 days'",
            },
            "live sessions",
        ),
        Batch(
            "core.sessions",
            n["stale_sessions"],
            {
                "id": uid("stale-session"),
                "identity_id": uid("identity", f"1 + g.i % {people}"),
                "created_at": ago("20 + g.i % 20", "day"),
                "kind": "(ARRAY['login','tenant'])[1 + g.i % 2]",
                "tenant_id": uid("org", f"1 + g.i % {people}"),
                "digest": sha256_hex("'seed-stale-session-' || g.i"),
                "second_factor": "false",
                "last_seen_at": ago("10 + g.i % 10", "day"),
                "expires_at": ago("1 + g.i % 10", "day"),
                "ended_at": f"CASE WHEN g.i % 2 = 0 THEN {ago('1 + g.i % 10', 'day')} END",
            },
            "expired and ended sessions",
        ),
        Batch(
            "core.socket_tickets",
            n["socket_tickets"],
            {
                "id": uid("ticket"),
                "identity_id": uid("identity", f"1 + g.i % {people}"),
                "created_at": ago("g.i"),
                "tenant_id": uid("org", f"1 + g.i % {people}"),
                "user_id": uid("user", f"1 + g.i % {people}"),
                "credential_kind": "'tenant_session'",
                "credential_id": uid("session", f"1 + g.i % {people}"),
                "digest": sha256_hex("'seed-ticket-' || g.i"),
                "expires_at": ago("g.i"),
                "redeemed_at": f"CASE WHEN g.i % 3 = 0 THEN {ago('g.i')} END",
            },
            "expired socket tickets",
        ),
        Batch(
            "core.sign_in_failures",
            n["sign_in_failures"],
            {
                "id": uid("failure"),
                "email_digest": sha256_hex("'nobody' || g.i || '@seed.example'"),
                "failures": "1 + g.i % 5",
                "retry_at": ago("g.i"),
            },
        ),
        Batch(
            "core.operators",
            n["operators"],
            {
                "id": uid("operator"),
                "identity_id": uid("identity", f"1 + (g.i - 1) % {people}"),
                "permission": "(ARRAY['read','write'])[1 + g.i % 2]",
            },
        ),
        Batch(
            "core.api_keys",
            n["api_keys"],
            {
                "id": uid("api-key"),
                "org_id": TEAM,
                "name": "'key ' || g.i",
                "created_at": ago("g.i", "hour"),
                "issued_by": team_user,
                "digest": sha256_hex("'seed-key-' || g.i"),
                "role": "'member'",
                "expires_at": "now() + interval '30 days'",
                "revoked_at": f"CASE WHEN g.i % 10 = 0 THEN {ago('g.i', 'hour')} END",
            },
        ),
        Batch(
            "core.outbox",
            n["outbox"],
            {
                "id": uid("outbox"),
                "org_id": TEAM,
                "created_at": ago("g.i"),
                "kind": "'tenancy.user.updated'",
                "target_id": team_user,
                "payload": "'{}'::jsonb",
                "actor_id": uid("team-user", "1"),
                "request_id": uid("outbox-request"),
                "app": APP,
                "done_at": f"CASE WHEN g.i % 100 <> 0 THEN {ago('g.i')} + interval '1 second' END",
            },
        ),
        Batch(
            "core.idempotency_markers",
            n["markers"],
            {
                "id": uid("marker"),
                "org_id": TEAM,
                "created_at": ago("g.i % 2880"),
                "user_id": team_user,
                "key": "'seed-' || g.i",
                "request_digest": "md5('seed-request-' || g.i)",
                "target_id": uid("marker-target"),
                "status": "201",
                "body": "'{}'",
            },
        ),
        Batch(
            "activity.events",
            n["events"],
            {
                "id": uid("event"),
                "org_id": TEAM,
                "seq": "g.i",
                "kind": "'tenancy.user.updated'",
                "target_id": team_user,
                "actor_id": uid("team-user", "1"),
                "payload": "'{}'::jsonb",
                "version": "1",
                "request_id": uid("event-request"),
                "app": APP,
            },
            "team events",
        ),
        Batch("activity.event_cursors", 1, {"id": uid("team-event-cursor"), "org_id": TEAM, "head": str(n["events"])}),
        Batch(
            "activity.events",
            people * per,
            {
                "id": uid("person-event"),
                "org_id": uid("org", f"1 + (g.i - 1) / {per}"),
                "seq": f"1 + (g.i - 1) % {per}",
                "kind": "'tenancy.user.updated'",
                "target_id": uid("user", f"1 + (g.i - 1) / {per}"),
                "actor_id": uid("user", f"1 + (g.i - 1) / {per}"),
                "payload": "'{}'::jsonb",
                "version": "1",
                "request_id": uid("person-event-request"),
                "app": APP,
            },
            "personal events",
        ),
        Batch(
            "activity.event_cursors",
            people,
            {"id": uid("person-event-cursor"), "org_id": uid("org"), "head": str(per)},
            "personal event cursors",
        ),
        Batch(
            "activity.audit_entries",
            n["audit_entries"],
            {
                "id": uid("audit"),
                "org_id": TEAM,
                "seq": "g.i",
                "kind": "'tenancy.member.updated'",
                "target_id": team_user,
                "actor_id": uid("team-user", "1"),
                "payload": "'{}'::jsonb",
                "request_id": uid("audit-request"),
                "app": APP,
            },
        ),
        Batch(
            "activity.audit_cursors",
            1,
            {"id": uid("team-audit-cursor"), "org_id": TEAM, "head": str(n["audit_entries"])},
        ),
        Batch("queue.work_items", n["items"], work_items(), "team work items"),
    ]
    if journalist_states is not None:
        values = {"id": uid("journalist"), "org_id": TEAM}
        if journalist_states:
            quoted = ",".join(f"'{s}'" for s in journalist_states)
            values["status"] = f"(ARRAY[{quoted}])[1 + g.i % {len(journalist_states)}]"
        out.append(Batch("core.journalists", n["journalists"], values, "team journalists"))
    return out


def work_items() -> dict[str, str]:
    """Across the states: 10% queued, 5% claimed (half with an expired lease), 80% done, 5% failed."""
    state = "CASE WHEN g.i % 100 < 10 THEN 'queued' WHEN g.i % 100 < 15 THEN 'claimed' WHEN g.i % 100 < 95 " + (
        "THEN 'done' ELSE 'failed' END"
    )
    claimed = "g.i % 100 BETWEEN 10 AND 14"
    return {
        "id": uid("item"),
        "org_id": TEAM,
        "created_at": ago("g.i"),
        "updated_at": ago("g.i") + " + interval '1 second'",
        "created_by": uid("team-user", "1"),
        "updated_by": uid("team-user", "1"),
        "kind": "'NOOP'",
        "target_id": uid("item-target"),
        "idempotency_key": uid("item-key"),
        "request_id": uid("item-request"),
        "payload": "'{}'::jsonb",
        "lane": "'default'",
        "status": state,
        "available_at": ago("g.i"),
        "claimed_by": f"CASE WHEN {claimed} THEN 'seed-worker' END",
        "claim_token": f"CASE WHEN {claimed} THEN {uid('item-claim')} END",
        "lease_expires_at": f"CASE WHEN {claimed} THEN now() + (g.i % 2 * 2 - 1) * interval '1 hour' END",
        "attempts": "CASE WHEN g.i % 100 < 10 THEN 0 WHEN g.i % 100 < 95 THEN 1 ELSE 3 END",
        "max_attempts": "3",
        "last_error": "CASE WHEN g.i % 100 >= 95 THEN 'seeded failure' END",
    }


def journalist_states() -> list[str]:
    """The states of the journalist, from a `*Status` enum in the namespace's types, when the namespace has one."""
    try:
        package = importlib.import_module("acme.om.journalists.types")
    except ImportError:
        return []
    modules = [package]
    for info in pkgutil.iter_modules(getattr(package, "__path__", [])):
        modules.append(importlib.import_module(f"{package.__name__}.{info.name}"))
    found = {
        obj
        for module in modules
        for obj in vars(module).values()
        if isinstance(obj, type) and issubclass(obj, StrEnum) and obj.__name__.endswith("Status")
    }
    return [str(member.value) for member in next(iter(found))] if len(found) == 1 else []


def columns_of(conn: psycopg.Connection, table: str) -> list[Column]:
    schema, name = table.split(".")
    rows = conn.execute(
        "SELECT column_name, data_type, is_nullable = 'YES' FROM information_schema.columns "
        "WHERE table_schema = %s AND table_name = %s ORDER BY ordinal_position",
        (schema, name),
    ).fetchall()
    if not rows:
        raise ValueError(f"{table} is not in the migrated schema")
    return [Column(str(r[0]), str(r[1]), bool(r[2])) for r in rows]


def seed(name: str, scale: float) -> list[tuple[str, int]]:
    target = auditdb.require(name)
    n = counts(scale)
    written: list[tuple[str, int]] = []
    with psycopg.connect(target.admin_url, autocommit=True) as conn:
        if conn.execute("SELECT count(*) FROM core.orgs").fetchone() != (0,):
            raise auditdb.Refused(f"refused: {name} holds orgs already; seed a database once, on a fresh one")
        conn.execute("SET synchronous_commit = off")
        has_journalists = conn.execute("SELECT to_regclass('core.journalists')").fetchone() not in (None, (None,))
        for batch in batches(n, journalist_states() if has_journalists else None):
            started = time.monotonic()
            statement = insert_sql(batch, columns_of(conn, batch.table))
            conn.execute(cast(LiteralString, statement))
            written.append((f"{batch.table} ({batch.label})" if batch.label else batch.table, batch.rows))
            logger.info("%s: %d rows in %.1fs", written[-1][0], batch.rows, time.monotonic() - started)
        logger.info("ANALYZE")
        conn.execute("ANALYZE")
    return written


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="seed.py", description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument("name", help="audit_<slug>, made with auditdb.py create")
    p.add_argument("--scale", type=float, default=1.0, help="every count times this; fractions allowed (default 1)")
    return p


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="%(name)s: %(message)s")
    args = parser().parse_args(argv)
    if args.scale <= 0:
        logger.error("refused: the scale is positive")
        return 2
    try:
        written = seed(args.name, args.scale)
    except auditdb.Refused as refused:
        logger.error("%s", refused)
        return 2
    for table, rows in written:
        print(f"{rows}\t{table}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
