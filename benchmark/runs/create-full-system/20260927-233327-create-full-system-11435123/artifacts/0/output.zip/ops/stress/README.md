# Stress scenarios

A scenario is a YAML file here, run with `acme-ops stress --scenario ops/stress/<name>.yaml --env <env>`. It holds:

- `profile`: one of the generator's four (`light`, `regular`, `heavy`, `stress`), which sets the tenants, the people
  in each, how many sessions run at once, and the think time between steps;
- `duration_seconds`, `ramp_seconds` (sessions start spread across the ramp), and `soak_seconds` (how long the run
  holds its full concurrency after the ramp);
- `target`: the p95 in milliseconds and the error ratio the run must stay within; stated before the run, never after;
- `steps`: the weight of each session step.

The runner drives the edge through the traffic generator, reads the result back, and answers pass or fail against
the target. The numbers are the team's: they follow from a service objective and the capacity behind it.
