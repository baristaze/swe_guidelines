# Operating the platform

People steer and agents maintain. Every operational task is a skill under `.claude/skills/` that a person runs with an
agent, and the safety boundary is the credential the skill holds, never the prompt.

## Roles and profiles

| Role | Who | Cloud profile | What it may do |
|------|-----|---------------|----------------|
| administrator | a person, granted for the run | `acme-<env>-admin` | create and destroy an environment; break-glass |
| deployer | the pipeline | assumed by the workflow | apply the environment root |
| investigator | a person or an agent | `acme-<env>-investigate` | read every log, metric, trace, alarm, and resource description; nothing else |
| supporter | the investigator plus an operator `read` token | `acme-<env>-investigate` | read a named tenant's rows through the operator plane, every read recorded |

Two credentials sit beside them: the **provisioner**, the traffic generator's operator identity whose allowlist
entry writes (it creates and removes the run's own tenants), and the smoke test's read grant. Production keeps the
provisioner disabled until a run needs it.

## The env file

One owner-only file per environment, `~/.config/acme/ops/<env>.env` (mode `0600`, its folder `0700`):

| Line | Holds |
|------|-------|
| `ACME_API_URL` | the environment's API base URL |
| `ACME_OPERATOR_TOKEN` | a `read` operator token, for the investigator and the supporter |
| `ACME_PROVISIONER_TOKEN` | the provisioner's `write` token, for the traffic generator |
| `ACME_ERROR_TRACKER_URL`, `ACME_ERROR_TRACKER_TOKEN` | the error tracker's API |
| `ACME_PROMETHEUS_URL`, `ACME_JAEGER_URL` | locally, the devx profile's metrics and traces |

It never holds a password or a TOTP secret: an agent never signs in with one. `make seed` writes the local file;
`scripts/cloud_create.sh` writes a cloud one with its token lines empty. An operator token lasts an hour at most;
`acme-ops token --env <env> --identity operator|provisioner` writes a fresh one without printing it (for the
operator, the person runs it in their own terminal and types the password and the code there).

## The tool

`acme-ops`, the operator's binary:

- `traffic --env <env> --profile light|regular|heavy|stress [--duration S] [--orgs N] [--report path]`: realistic
  sessions at the edge (sign in, enter the desk, read, add a handful, edit, delete one, read the event stream, a
  socket that sees its own change, sign out) in tenants the provisioner creates for the run and removes at its end.
  `make traffic PROFILE=light DURATION=30` is the gate's thirty-second wiring check, never a capacity claim.
- `stress --scenario ops/stress/<name>.yaml --env <env>`: the same generator with a scenario and a target, answered
  pass or fail (see [`stress/README.md`](stress/README.md)).
- `signals check --env <env> --request-id <id>`: the log line, the counter, the trace, and the error event of one
  request, read back through each signal's own API (the devx twins locally, CloudWatch, X-Ray, and the tracker in
  the cloud).
- `size --env <env>`: tenants, users, and the rows written in the last day, leaving out the generator's tenants.
- `token --env <env> --identity operator|provisioner`: a fresh operator token into the env file.

The telemetry round trip (`ops/tests/test_telemetry_roundtrip.py`, `make test-telemetry`) starts the API for real,
drives one session, and reads every signal back by request id; run against a deployed environment it is the smoke
test.

## The skills

| Skill | Role | Env file | Environments |
|-------|------|----------|--------------|
| `ops-investigate` | investigator | read | local, staging, production |
| `ops-watch` | investigator | read | local, staging, production |
| `ops-root-cause` | supporter | read | local, staging, production |
| `ops-infra-as-code` | investigator | none | staging, production |
| `ops-cloud-deployment-create` | administrator | writes it | staging, production |
| `ops-cloud-deployment-nuke` | administrator | removes it | staging, production |
| `ops-simulate-traffic` | provisioner | read | local, staging, production |
| `stress-test-create-or-update` | none | none | writes a scenario file |
| `stress-test-run` | provisioner, investigator | read | local, staging, production |
| `audit-retention` | investigator | none | local, staging, production |
| `audit-query-indexes` | none | none | a database of its own on the local stack |
| `audit-database-calls` | none | none | a database of its own on the local stack |
| `audit-deploy-time` | investigator | none | staging, production |
| `audit-credential-lifetimes` (optional) | none | none | reads the checkout alone |
| `audit-provider-calls` (optional) | none | none | reads the checkout alone |

An audit answers a question that repeats (after a large change, before a release, as the product grows), reads
only, reports its answer first with a verdict per row, and proposes tickets; it never fixes. The three audits of
the database build a database of their own on the local stack with the tools under [`audit/`](audit/), seed it at
the scale the run states, and drop it at the end, so they never log in to a shared one.

## Alarms

The first responder to an alarm is an agent. Before it escalates it reads whose traffic raised it (tenants, users,
the last day's volume, and whether the generator's own tenants were involved). Outside production an alarm raised by
the team's own traffic may be suppressed with that reason; in production an alarm is never suppressed.
