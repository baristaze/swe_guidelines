"""The four profiles: how many tenants, how many people in each, how many sessions at once, and the think time."""

from dataclasses import dataclass


@dataclass(frozen=True)
class Profile:
    name: str
    orgs: int
    members_per_org: int
    concurrency: int
    think_seconds: float


PROFILES: dict[str, Profile] = {
    "light": Profile("light", orgs=2, members_per_org=2, concurrency=4, think_seconds=0.5),
    "regular": Profile("regular", orgs=5, members_per_org=4, concurrency=16, think_seconds=1.0),
    "heavy": Profile("heavy", orgs=20, members_per_org=5, concurrency=64, think_seconds=0.5),
    "stress": Profile("stress", orgs=50, members_per_org=10, concurrency=200, think_seconds=0.1),
}
