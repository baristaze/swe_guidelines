"""A deploy's timeline: the pipeline's jobs and long steps, and the container service's events in a window.

    uv run python ops/audit/deploy_timeline.py steps <run.json> [--min-step <seconds>]
    uv run python ops/audit/deploy_timeline.py steps --run <run id> [--repo <owner/repo>] [--min-step <seconds>]
    uv run python ops/audit/deploy_timeline.py events <services.json> --since <iso> [--until <iso>]
    uv run python ops/audit/deploy_timeline.py events --env <staging|production> --service <name> [--service ...]
                                                      --since <iso> [--until <iso>] [--cluster <name>]

`steps` reads a run's record: a file written by `gh run view <id> --json createdAt,updatedAt,jobs`, or one written
from the jobs API (`gh api repos/{owner}/{repo}/actions/runs/<id>/jobs`, which `--run` fetches itself). It prints
each job's id, name, start, end, and duration in UTC, and under each job the steps that took at least `--min-step`
seconds (30 by default; 0 prints every step).

`events` reads the services' events: a file written by `aws ecs describe-services`, or, with `--env`, the same call
through boto3 under the profile `acme-<env>-investigate` in the region of `deployment/cloud/environments.json`. It
prints every event of every service between `--since` and `--until` (now by default), oldest first, in UTC.
Standard output carries the timeline; logs go to standard error.
"""

import argparse
import json
import logging
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError

logger = logging.getLogger("deploy_timeline")

ROOT = Path(__file__).resolve().parents[2]
ENVIRONMENTS = ROOT / "deployment" / "cloud" / "environments.json"


def parse_time(value: Any) -> datetime | None:
    """An ISO time (a `Z` suffix allowed), an epoch number, or a datetime, as an aware UTC datetime."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        found = value
    elif isinstance(value, int | float):
        found = datetime.fromtimestamp(value, UTC)
    else:
        text = str(value).strip()
        if text.startswith("0001-01-01"):
            return None  # the GitHub CLI's zero time: the step never ran
        found = datetime.fromisoformat(text.replace("Z", "+00:00"))
    return found.replace(tzinfo=UTC) if found.tzinfo is None else found.astimezone(UTC)


def utc(value: datetime | None) -> str:
    return "-" if value is None else value.strftime("%Y-%m-%dT%H:%M:%SZ")


def seconds(start: datetime | None, end: datetime | None) -> float | None:
    return None if start is None or end is None else (end - start).total_seconds()


def duration(value: float | None) -> str:
    if value is None:
        return "-"
    minutes, rest = divmod(round(value), 60)
    return f"{minutes}m{rest:02d}s" if minutes else f"{rest}s"


def _field(record: dict[str, Any], *names: str) -> Any:
    for name in names:
        if name in record:
            return record[name]
    return None


@dataclass
class Step:
    name: str
    number: int
    conclusion: str
    started: datetime | None
    completed: datetime | None

    @property
    def seconds(self) -> float | None:
        return seconds(self.started, self.completed)


@dataclass
class Job:
    id: str
    name: str
    conclusion: str
    started: datetime | None
    completed: datetime | None
    steps: list[Step] = field(default_factory=list)

    @property
    def seconds(self) -> float | None:
        return seconds(self.started, self.completed)


def parse_jobs(document: dict[str, Any]) -> list[Job]:
    """The jobs of a run record, from `gh run view --json jobs` (camelCase) or the jobs API (snake_case)."""
    jobs: list[Job] = []
    for raw in document.get("jobs") or []:
        steps = [
            Step(
                name=str(s.get("name", "")),
                number=int(s.get("number", 0)),
                conclusion=str(s.get("conclusion") or s.get("status") or ""),
                started=parse_time(_field(s, "startedAt", "started_at")),
                completed=parse_time(_field(s, "completedAt", "completed_at")),
            )
            for s in raw.get("steps") or []
        ]
        jobs.append(
            Job(
                id=str(_field(raw, "databaseId", "id")),
                name=str(raw.get("name", "")),
                conclusion=str(raw.get("conclusion") or raw.get("status") or ""),
                started=parse_time(_field(raw, "startedAt", "started_at")),
                completed=parse_time(_field(raw, "completedAt", "completed_at")),
                steps=steps,
            )
        )
    return sorted(jobs, key=lambda j: (j.started or datetime.max.replace(tzinfo=UTC), j.name))


def render_steps(document: dict[str, Any], min_step: float) -> str:
    jobs = parse_jobs(document)
    created = parse_time(_field(document, "createdAt", "created_at"))
    updated = parse_time(_field(document, "updatedAt", "updated_at"))
    lines: list[str] = []
    if created or updated:
        lines.append(f"run {utc(created)} -> {utc(updated)} ({duration(seconds(created, updated))})")
    for job in jobs:
        lines.append(
            f"job {job.id}  {job.name}  {utc(job.started)} -> {utc(job.completed)}  "
            f"{duration(job.seconds)}  {job.conclusion}"
        )
        for step in job.steps:
            if (step.seconds or 0) >= min_step:
                lines.append(
                    f"    step {step.number:>2}  {step.name}  {utc(step.started)} -> {utc(step.completed)}  "
                    f"{duration(step.seconds)}  {step.conclusion}"
                )
    return "\n".join(lines)


def fetch_run_jobs(run_id: str, repo: str | None) -> dict[str, Any]:
    """The jobs API of one run, through the GitHub CLI under the person's own sign-in."""
    slug = repo or "{owner}/{repo}"
    found = subprocess.run(  # noqa: S603 - a fixed command, no shell
        ["gh", "api", f"repos/{slug}/actions/runs/{run_id}/jobs?per_page=100"],  # noqa: S607 - gh from PATH
        capture_output=True,
        text=True,
        check=True,
    )
    return json.loads(found.stdout)


@dataclass(frozen=True)
class ServiceEvent:
    service: str
    at: datetime
    message: str


def parse_events(document: dict[str, Any], since: datetime, until: datetime | None) -> list[ServiceEvent]:
    """Every event of every service in `describe-services` output within [since, until], oldest first."""
    out: list[ServiceEvent] = []
    for service in document.get("services") or []:
        name = str(service.get("serviceName", ""))
        for raw in service.get("events") or []:
            at = parse_time(raw.get("createdAt"))
            if at is None or at < since or (until is not None and at > until):
                continue
            out.append(ServiceEvent(name, at, str(raw.get("message", ""))))
    return sorted(out, key=lambda e: (e.at, e.service))


def render_events(events: list[ServiceEvent]) -> str:
    return "\n".join(f"{utc(e.at)}  {e.service}  {e.message}" for e in events)


def region_of() -> str:
    return str(json.loads(ENVIRONMENTS.read_text())["region"])


def describe_services(env: str, cluster: str, services: list[str]) -> dict[str, Any]:
    """`describe_services` under the investigate profile, read-only, in the environments' region."""
    session = boto3.Session(profile_name=f"acme-{env}-investigate", region_name=region_of())
    answer = session.client("ecs").describe_services(cluster=cluster, services=services)
    return {"services": answer.get("services", [])}


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="deploy_timeline.py", description=__doc__, formatter_class=argparse.RawTextHelpFormatter
    )
    sub = p.add_subparsers(dest="command", required=True)
    steps_p = sub.add_parser("steps", help="a run's jobs and long steps")
    steps_p.add_argument("file", nargs="?", help="gh run view --json createdAt,updatedAt,jobs, or the jobs API")
    steps_p.add_argument("--file", dest="file_option", help="the same file, as an option")
    steps_p.add_argument("--run", help="a run id, whose jobs `gh api` fetches")
    steps_p.add_argument("--repo", help="owner/repo for --run; the checkout's own by default")
    steps_p.add_argument("--min-step", type=float, default=30.0, help="the shortest step printed, seconds (30)")
    events_p = sub.add_parser("events", help="the services' events in a window")
    events_p.add_argument("file", nargs="?", help="aws ecs describe-services output")
    events_p.add_argument("--env", choices=["staging", "production"], help="read the services live under investigate")
    events_p.add_argument("--service", action="append", default=[], help="a service name, repeatable")
    events_p.add_argument("--cluster", help="the cluster, acme-<env> by default")
    events_p.add_argument("--since", required=True, help="the window's start, ISO 8601")
    events_p.add_argument("--until", help="the window's end, ISO 8601; now by default")
    return p


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="%(name)s: %(message)s")
    args = parser().parse_args(argv)
    try:
        if args.command == "steps":
            path = args.file or args.file_option
            if bool(path) == bool(args.run):
                logger.error("give a run record file or --run, one of the two")
                return 2
            document = json.loads(Path(path).expanduser().read_text()) if path else fetch_run_jobs(args.run, args.repo)
            print(render_steps(document, args.min_step))
            return 0
        since, until = parse_time(args.since), parse_time(args.until)
        if since is None:
            logger.error("--since is a time")
            return 2
        if bool(args.file) == bool(args.env):
            logger.error("give a describe-services file or --env with --service, one of the two")
            return 2
        if args.file:
            document = json.loads(Path(args.file).expanduser().read_text())
        else:
            if not args.service:
                logger.error("--env reads the services --service names; name at least one")
                return 2
            document = describe_services(args.env, args.cluster or f"acme-{args.env}", args.service)
        print(render_events(parse_events(document, since, until)))
    except (OSError, ValueError, subprocess.CalledProcessError, BotoCoreError, ClientError) as error:
        logger.error("%s", error)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
