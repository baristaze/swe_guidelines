"""The generator: tenants provisioned for the run through the operator plane, sessions at the profile's
concurrency until the duration ends, the run's tenants removed at the end (a failure included), and the report."""

import asyncio
import logging
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID

from acme.clients.api import ApiClient, ApiError, models
from acme.ops import api
from acme.ops.envfile import PROVISIONER_TOKEN, EnvFileError, read, require
from acme.ops.traffic.profiles import Profile
from acme.ops.traffic.report import Recorder
from acme.ops.traffic.session import Person, SessionState, run_session

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class RunPlan:
    env: str
    profile: Profile
    duration: float
    orgs: int
    ramp: float = 0.0


async def provision(
    admin: ApiClient, run_id: str, plan: RunPlan, recorder: Recorder
) -> tuple[list[UUID], list[Person]]:
    org_ids: list[UUID] = []
    people: list[Person] = []
    for i in range(plan.orgs):
        org = await admin.admin_create_org(
            models.AddOrgRequest(name=f"Traffic {run_id} {i}", slug=f"traffic-{run_id}-{i}")
        )
        org_ids.append(org.id)
        for j in range(plan.profile.members_per_org):
            email = f"traffic-{run_id}-{i}-{j}@acme.example"
            password = secrets.token_urlsafe(18)
            await admin.admin_add_member(
                org.id,
                models.AddMemberRequest(email=email, display_name=f"Traffic {i}.{j}", role="admin", password=password),
            )
            people.append(Person(email=email, password=password, org_id=org.id))
    recorder.record("provisioning", 201, 0.0)
    return org_ids, people


async def remove(admin: ApiClient, org_ids: list[UUID], recorder: Recorder) -> None:
    for org_id in org_ids:
        try:
            await admin.admin_delete_org(org_id)
        except (ApiError, OSError) as error:
            recorder.not_removed.append(f"{org_id} ({error})")


async def drive(base_url: str, people: list[Person], plan: RunPlan, recorder: Recorder) -> None:
    deadline = time.monotonic() + plan.duration
    started = time.monotonic()
    turn = {"next": 0}

    async def worker(index: int) -> None:
        if plan.ramp:
            await asyncio.sleep(plan.ramp * index / max(1, plan.profile.concurrency))
        while time.monotonic() < deadline:
            person = people[turn["next"] % len(people)]
            turn["next"] += 1
            state = SessionState(person, base_url, recorder, plan.profile.think_seconds, api.client(base_url))
            try:
                await run_session(state)
            except Exception as error:  # a failed session is reported and the run goes on
                recorder.fail(f"{person.email}: {type(error).__name__}: {error}")

    await asyncio.gather(*(worker(i) for i in range(plan.profile.concurrency)))
    logger.info("drove %d sessions' worth of requests in %.1fs", recorder.total(), time.monotonic() - started)


async def run(plan: RunPlan, report: Path | None) -> Recorder:
    values = read(plan.env)
    base_url = values.get("ACME_API_URL", "")
    if not base_url:
        raise EnvFileError(f"ACME_API_URL is empty in the {plan.env} env file")
    recorder = Recorder()
    if plan.orgs == 0:
        if plan.env != "local":
            raise EnvFileError("--orgs 0 drives the seeded people, which exist only on the local stack")
        people = [
            Person(
                os.environ.get("ACME_SEED_OWNER_EMAIL", "owner@acme.example"),
                os.environ.get("ACME_SEED_OWNER_PASSWORD", "pswd_1234"),
                None,
            )
        ]
        await drive(base_url, people, plan, recorder)
    else:
        run_id = secrets.token_hex(3)
        admin = api.client(base_url, require(values, PROVISIONER_TOKEN, plan.env))
        org_ids: list[UUID] = []
        try:
            try:
                org_ids, people = await provision(admin, run_id, plan, recorder)
            except ApiError as error:
                raise api.expired_hint(error, plan.env, "provisioner") from error
            await drive(base_url, people, plan, recorder)
        finally:
            await remove(admin, org_ids, recorder)
            await admin.aclose()
    if report is not None:
        recorder.write(report)
    return recorder
