"""The operator's own tool: it drives the edge through the client and the operator plane, never a manager."""
