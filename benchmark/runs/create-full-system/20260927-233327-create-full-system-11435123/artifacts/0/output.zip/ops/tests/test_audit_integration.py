"""The audit tools end to end on the local stack: make a database of the test's own, seed it small, read its
inventory, count one small flow set, and drop it whatever happened. Needs `make infra-up`; runs as the skills run
the tools, one command line at a time from the repository root.

    uv run pytest -q -m integration ops/tests/test_audit_integration.py
"""

import json
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse
from uuid import uuid4

import pytest

from acme.om.storage.settings import StorageSettings

pytestmark = pytest.mark.integration

ROOT = Path(__file__).resolve().parents[2]
AUDIT = ROOT / "ops" / "audit"
LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1"}


def only_local() -> None:
    """Every URL the settings resolve, and so every URL the tools derive, names the local machine."""
    remote = [u for u in StorageSettings().all_urls() if urlparse(u).hostname not in LOCAL_HOSTS]
    if remote:
        pytest.exit("the audit integration test refuses a database URL that is not a local address", returncode=2)


def tool(*args: str) -> str:
    done = subprocess.run(
        [sys.executable, str(AUDIT / args[0]), *args[1:]], cwd=ROOT, capture_output=True, text=True, check=False
    )
    assert done.returncode == 0, f"{' '.join(args)} exited {done.returncode}:\n{done.stderr[-4000:]}"
    return done.stdout


def test_make_seed_read_count_and_drop(tmp_path: Path) -> None:
    only_local()
    name = f"audit_itest_{uuid4().hex[:8]}"
    assert name not in tool("auditdb.py", "list")
    try:
        assert tool("auditdb.py", "create", name).strip() == f"created {name}"
        assert name in tool("auditdb.py", "list")
        assert f"/{name}" in tool("auditdb.py", "env", name)

        seeded = tool("seed.py", name, "--scale", "0.001")
        assert "1000\tactivity.events (team events)" in seeded
        assert "100\tqueue.work_items (team work items)" in seeded

        tool("explain.py", "reset", name)
        inventory = tool("explain.py", "inventory", name)
        events = next(line for line in inventory.splitlines() if line.startswith("activity.events "))
        assert int(events.split()[1]) >= 1000
        team = tool("explain.py", "rows", name, "SELECT id FROM core.orgs WHERE slug = 'seed-team'").splitlines()
        assert team[0] == "id" and len(team) == 2

        out = tmp_path / "calls.json"
        tool("dbcalls.py", "run", name, "--out", str(out), "--only", "events", "--repeat", "1")
        document = json.loads(out.read_text())
        assert [f["flow"] for f in document["flows"]] == ["seed", "events"]
        for flow in document["flows"]:
            assert flow["status"] == "ok", flow["errors"]
            assert flow["calls"], f"{flow['flow']} measured nothing"
            assert all(call["round_trips"]["min"] > 0 for call in flow["calls"])
            assert sum(call["transactions"]["max"] for call in flow["calls"]) > 0
        assert "replay one" in tool("dbcalls.py", "summary", str(out))
    finally:
        tool("auditdb.py", "drop", name)
    assert name not in tool("auditdb.py", "list")
