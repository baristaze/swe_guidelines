"""One realistic session of one person: sign in, enter the desk, read, write, edit, delete one, read the event
stream, watch one socket see its own change, and sign out. Every call goes through the client, at the edge."""

import asyncio
import json
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any
from uuid import UUID

import httpx
import websockets

from acme.clients.api import ApiClient, ApiError, models
from acme.ops.traffic.report import Recorder


@dataclass(frozen=True)
class Person:
    email: str
    password: str
    org_id: UUID | None  # None: the person's first desk


@dataclass
class SessionState:
    person: Person
    base_url: str
    recorder: Recorder
    think_seconds: float
    client: ApiClient
    user_id: UUID | None = None
    created: list[UUID] = field(default_factory=list)

    async def call(self, route: str, work: Awaitable[Any], ok: int = 200) -> Any:
        started = time.perf_counter()
        try:
            answer = await work
        except ApiError as error:
            self.recorder.record(route, error.status, time.perf_counter() - started)
            raise
        except httpx.TransportError, OSError:
            self.recorder.record(route, "transport", time.perf_counter() - started)
            raise
        self.recorder.record(route, ok, time.perf_counter() - started)
        return answer

    async def think(self) -> None:
        if self.think_seconds:
            await asyncio.sleep(self.think_seconds)


Step = Callable[[SessionState], Awaitable[None]]


async def keys_step(state: SessionState) -> None:
    """Add a handful of keys, list them, and revoke one: the writes every desk has from day one."""
    c = state.client
    for i in range(3):
        key = await state.call(
            "POST /v1/api-keys",
            c.tenancy_create_api_key(models.AddApiKeyRequest(name=f"traffic-{i}", role="member", expires_in=3600)),
            201,
        )
        state.created.append(key.id)
    await state.call("GET /v1/api-keys", c.tenancy_get_api_keys(limit=50))
    await state.think()
    await state.call("DELETE /v1/api-keys/{key_id}", c.tenancy_revoke_api_key(state.created.pop()), 204)


async def edit_step(state: SessionState) -> None:
    c = state.client
    me = await state.call("GET /v1/me", c.tenancy_get_me())
    state.user_id = me.id
    await state.call(
        "PATCH /v1/me",
        c.tenancy_update_me(models.UpdateUserRequest(name=f"{me.name.split(' #')[0]} #{int(time.time()) % 1000}")),
    )


async def journalists_step(state: SessionState) -> None:
    """Add a profile, list, read, rename, and remove it: the journalists namespace's every route."""
    c = state.client
    made = await state.call(
        "POST /v1/journalists",
        c.journalists_create_journalist(models.AddJournalistRequest(display_name="Traffic Reporter")),
        201,
    )
    await state.call("GET /v1/journalists", c.journalists_get_journalists(limit=50))
    await state.call("GET /v1/journalists/{journalist_id}", c.journalists_get_journalist(made.id))
    await state.think()
    await state.call(
        "PATCH /v1/journalists/{journalist_id}",
        c.journalists_update_journalist(
            made.id, models.UpdateJournalistRequest(display_name=f"Traffic Reporter #{int(time.time()) % 1000}")
        ),
    )
    await state.call("DELETE /v1/journalists/{journalist_id}", c.journalists_delete_journalist(made.id), 204)


# The entity steps a session runs, in order. Each namespace scaffold appends the steps of its own entities.
ENTITY_STEPS: list[Step] = [keys_step, edit_step, journalists_step]


def socket_url(base_url: str, ticket: str) -> str:
    scheme = "wss" if base_url.startswith("https") else "ws"
    return f"{scheme}://{base_url.split('://', 1)[1].rstrip('/')}/v1/realtime/socket?ticket={ticket}"


async def socket_step(state: SessionState) -> None:
    """One socket that sees its own change: the hello frame, a write, and the event hint that names it."""
    c = state.client
    ticket = await state.call("POST /v1/realtime/tickets", c.realtime_issue_ticket(), 201)
    started = time.perf_counter()
    async with websockets.connect(socket_url(state.base_url, ticket.ticket or ""), open_timeout=10) as ws:
        hello = json.loads(await asyncio.wait_for(ws.recv(), 10))
        if hello.get("type") != "hello":
            raise RuntimeError(f"the socket opened with {hello.get('type')!r}, not hello")
        me = await state.call("PATCH /v1/me", c.tenancy_update_me(models.UpdateUserRequest(name="Seen on the socket")))
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            frame = json.loads(await asyncio.wait_for(ws.recv(), max(0.1, deadline - time.monotonic())))
            if frame.get("type") == "event" and frame.get("target_id") == str(me.id):
                state.recorder.record("WS /v1/realtime/socket (own change)", 101, time.perf_counter() - started)
                return
        raise RuntimeError("the socket never saw its own change")


async def run_session(state: SessionState) -> None:
    c = state.client
    p = state.person
    signed = await state.call(
        "POST /v1/auth/login", c.tenancy_sign_in(models.SignInRequest(email=p.email, password=p.password))
    )
    login = c.with_bearer(signed.token)
    try:
        org_id = p.org_id or signed.memberships[0].org_id
        session = await state.call(
            "POST /v1/auth/exchange", login.tenancy_exchange(models.ExchangeRequest(org_id=org_id))
        )
    finally:
        await login.aclose()
    state.client = c.with_bearer(session.token)
    try:
        await state.call("GET /v1/org", state.client.tenancy_get_org())
        await state.call("GET /v1/members", state.client.tenancy_get_members(limit=50))
        await state.think()
        for step in ENTITY_STEPS:
            await step(state)
            await state.think()
        await state.call("GET /v1/events", state.client.events_get_events(after_seq=0, limit=100))
        await socket_step(state)
        await state.call("POST /v1/auth/logout", state.client.tenancy_sign_out(), 204)
    finally:
        await state.client.aclose()
