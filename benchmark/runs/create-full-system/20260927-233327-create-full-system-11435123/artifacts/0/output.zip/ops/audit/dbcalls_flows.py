"""The built-in flows of `dbcalls.py run`: one per area of the API, the worker's items, and the sweep.

    seed          a tenant and its owner's session, and an operator token from the tenancy manager's grant job
    auth          sign-up, sign-in, the memberships, the exchange, sign-out
    members       the org, the person, and the members: read, rename, add (operator), change a role, remove
    api_keys      create, list, a request authenticated by the key, revoke
    events        the replay: one event, a full page, and past the head
    operator      the operator plane: me, size, orgs, one org, its members and events, provision and delete an org
    journalists   the journalists routes, when the API mounts them
    worker_items  enqueue a NOOP item, claim it, handle it, and complete it as the worker loop does
    sweep         one sweep pass, then nine more tenants and another pass

Each takes the world `w` of `dbcalls.py` and calls `w.http(area, name, method, path, ...)` for a request and
`w.measure(area, name, lambda: <awaitable>)` for a manager or worker call. `seed` leaves in `w.state` what the
others use: `owner` (the owner's tenant-session headers), `owner_token`, `org_id`, and `operator` (headers).
A run's own flows file follows the same shape, with `FLOWS` listing its flows.
"""

import logging
import re
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any
from uuid import uuid4

from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.opcontext import AppContext, AppType, OperatorPermission, RequestContext
from acme.om.work.types.work_item import WorkItem, WorkKind
from acme.workers.maintenance.loop import WorkerLoop

if TYPE_CHECKING:
    from dbcalls import World

logger = logging.getLogger("dbcalls")

PASSWORD = "pswd_audit_1234"
OPERATOR_PASSWORD = "pswd_audit_operator"
JOURNALISTS = "/v1/journalists"


def bearer(token: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {token}"}


def stage(kind: AppType = AppType.OPS) -> RequestContext:
    """The request stage of a manager or worker call the flow makes itself."""
    return RequestContext(request_id=new_id(), app=AppContext(type=kind, version="dbcalls@0"))


def signup_body(tag: str) -> dict[str, str]:
    return {
        "email": f"owner-{tag}@audit.example",
        "password": PASSWORD,
        "display_name": f"Owner {tag}",
        "org_name": f"Desk {tag}",
        "org_slug": f"desk-{tag}",
    }


async def seed(w: World) -> None:
    tag = w.unique()
    signed = await w.http("seed", "sign up", "POST", "/v1/auth/signup", json=signup_body(tag))
    login = signed.json()
    org_id = login["memberships"][0]["org_id"]
    exchanged = await w.http(
        "seed", "exchange", "POST", "/v1/auth/exchange", json={"org_id": org_id}, headers=bearer(login["token"])
    )
    token = exchanged.json()["token"]
    w.state.update(owner=bearer(token), owner_token=token, org_id=org_id)

    tenancy = w.api.managers.tenancy
    email = f"operator-{tag}@audit.example"
    await w.measure(
        "operator", "ensure identity", lambda: tenancy.ensure_identity(stage(), email, OPERATOR_PASSWORD, "Operator")
    )
    await w.measure(
        "operator", "grant operator", lambda: tenancy.grant_operator(stage(), email, OperatorPermission.WRITE)
    )
    issued = await w.measure(
        "operator", "grant operator token", lambda: tenancy.grant_operator_token(stage(), email, None)
    )
    w.state["operator"] = bearer(issued.token)


async def auth(w: World) -> None:
    tag = w.unique()
    body = signup_body(tag)
    signed = await w.http("tenancy", "sign up", "POST", "/v1/auth/signup", json=body)
    login = await w.http(
        "tenancy", "sign in", "POST", "/v1/auth/login", json={"email": body["email"], "password": PASSWORD}
    )
    headers = bearer(login.json()["token"])
    await w.http("tenancy", "memberships", "GET", "/v1/auth/memberships", headers=headers)
    org_id = signed.json()["memberships"][0]["org_id"]
    await w.http("tenancy", "exchange", "POST", "/v1/auth/exchange", json={"org_id": org_id}, headers=headers)
    await w.http("tenancy", "sign out", "POST", "/v1/auth/logout", headers=headers, expect=204)


async def members(w: World) -> None:
    owner, org_id = w.state["owner"], w.state["org_id"]
    await w.http("tenancy", "org", "GET", "/v1/org", headers=owner)
    await w.http("tenancy", "me", "GET", "/v1/me", headers=owner)
    await w.http("tenancy", "rename me", "PATCH", "/v1/me", headers=owner, json={"name": f"Owner {w.unique()}"})
    added: list[str] = []
    for _ in range(3):
        tag = w.unique()
        member = await w.http(
            "tenancy",
            "add member (operator)",
            "POST",
            f"/v1/admin/orgs/{org_id}/members",
            headers={**w.state["operator"], "Idempotency-Key": tag},
            json={"email": f"member-{tag}@audit.example", "display_name": f"Member {tag}", "role": "member"},
            expect=201,
        )
        added.append(member.json()["user_id"])
    listed = await w.http("tenancy", "members", "GET", "/v1/members", headers=owner, params={"limit": 500})
    w.note("tenancy", "members", members=len(listed.json()))
    await w.http("tenancy", "change a role", "PATCH", f"/v1/members/{added[0]}", headers=owner, json={"role": "admin"})
    await w.http("tenancy", "remove member", "DELETE", f"/v1/members/{added[1]}", headers=owner, expect=204)


async def api_keys(w: World) -> None:
    owner = w.state["owner"]
    created = await w.http(
        "api_keys",
        "create",
        "POST",
        "/v1/api-keys",
        headers={**owner, "Idempotency-Key": w.unique()},
        json={"name": f"key {w.unique()}", "role": "member"},
        expect=201,
    )
    key = created.json()
    await w.http("api_keys", "list", "GET", "/v1/api-keys", headers=owner, params={"limit": 500})
    await w.http("api_keys", "request with a key", "GET", "/v1/me", headers=bearer(key["token"]))
    await w.http("api_keys", "revoke", "DELETE", f"/v1/api-keys/{key['id']}", headers=owner, expect=204)


async def events(w: World) -> None:
    owner = w.state["owner"]
    page = await w.http("events", "replay one", "GET", "/v1/events", headers=owner, params={"limit": 1})
    full = await w.http("events", "replay a page", "GET", "/v1/events", headers=owner, params={"limit": 500})
    seqs = [e["seq"] for e in full.json()] or [e["seq"] for e in page.json()] or [0]
    await w.http("events", "replay past the head", "GET", "/v1/events", headers=owner, params={"after_seq": max(seqs)})


async def operator(w: World) -> None:
    headers, org_id = w.state["operator"], w.state["org_id"]
    await w.http("operator", "me", "GET", "/v1/admin/me", headers=headers)
    await w.http("operator", "size", "GET", "/v1/admin/size", headers=headers)
    await w.http("operator", "orgs", "GET", "/v1/admin/orgs", headers=headers, params={"limit": 500})
    await w.http("operator", "org", "GET", f"/v1/admin/orgs/{org_id}", headers=headers)
    await w.http("operator", "members", "GET", f"/v1/admin/orgs/{org_id}/members", headers=headers)
    await w.http("operator", "events", "GET", f"/v1/admin/orgs/{org_id}/events", headers=headers)
    tag = w.unique()
    created = await w.http(
        "operator",
        "provision an org",
        "POST",
        "/v1/admin/orgs",
        headers={**headers, "Idempotency-Key": tag},
        json={"name": f"Provisioned {tag}", "slug": f"prov-{tag}"},
        expect=201,
    )
    new_org = created.json()["id"]
    await w.http(
        "operator",
        "add a member",
        "POST",
        f"/v1/admin/orgs/{new_org}/members",
        headers={**headers, "Idempotency-Key": f"{tag}-m"},
        json={"email": f"prov-{tag}@audit.example", "display_name": "P", "role": "owner", "password": PASSWORD},
        expect=201,
    )
    await w.http("operator", "delete an org", "DELETE", f"/v1/admin/orgs/{new_org}", headers=headers, expect=204)


def _resolve(spec: dict[str, Any], schema: dict[str, Any]) -> dict[str, Any]:
    while "$ref" in schema:
        schema = spec["components"]["schemas"][schema["$ref"].rsplit("/", 1)[-1]]
    if "anyOf" in schema:
        schema = next((s for s in schema["anyOf"] if s.get("type") != "null"), schema["anyOf"][0])
        return _resolve(spec, schema)
    return schema


def example_value(spec: dict[str, Any], schema: dict[str, Any], name: str) -> Any:
    """A value that satisfies a property of the OpenAPI schema: its first enum, or one by its type and format."""
    schema = _resolve(spec, schema)
    if "enum" in schema:
        return schema["enum"][0]
    kind, fmt = schema.get("type"), schema.get("format", "")
    if kind == "string":
        if fmt == "email" or "email" in name:
            return f"{uuid4().hex[:8]}@audit.example"
        if fmt == "uuid":
            return str(uuid4())
        if fmt == "date-time":
            return datetime.now(UTC).isoformat()
        if fmt == "date":
            return datetime.now(UTC).date().isoformat()
        text = f"audit-{uuid4().hex[:8]}"
        return text.ljust(int(schema.get("minLength", 0)), "x")[: int(schema.get("maxLength", 120))]
    if kind == "integer":
        return int(schema.get("minimum", 1))
    if kind == "number":
        return float(schema.get("minimum", 1))
    if kind == "boolean":
        return False
    if kind == "array":
        return []
    return example_body(spec, schema, every=False)


def example_body(spec: dict[str, Any], schema: dict[str, Any], *, every: bool) -> dict[str, Any]:
    """The required properties of a request body (every property with `every`), each with an example value."""
    schema = _resolve(spec, schema)
    properties: dict[str, Any] = schema.get("properties", {})
    names = list(properties) if every else list(schema.get("required", []))
    return {n: example_value(spec, properties[n], n) for n in names}


def _body_schema(operation: dict[str, Any]) -> dict[str, Any]:
    return operation.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema", {})


async def journalists(w: World) -> None:
    spec = w.app.openapi()
    paths: dict[str, dict[str, Any]] = {p: o for p, o in spec["paths"].items() if p.startswith(JOURNALISTS)}
    if not paths:
        logger.info("the API mounts no journalists routes; nothing to measure")
        return
    owner = w.state["owner"]
    collection = paths.get(JOURNALISTS, {})
    created_id: str | None = None
    if "post" in collection:
        body = example_body(spec, _body_schema(collection["post"]), every=False)
        created = await w.http(
            "journalists", "create", "POST", JOURNALISTS, headers={**owner, "Idempotency-Key": w.unique()}, json=body
        )
        created_id = str(created.json().get("id")) if created.json().get("id") else None
    if "get" in collection:
        await w.http("journalists", "list", "GET", JOURNALISTS, headers=owner)
    one = next((p for p in paths if re.fullmatch(re.escape(JOURNALISTS) + r"/\{[^}/]+\}", p)), None)
    if one is None or created_id is None:
        return
    path = re.sub(r"\{[^}/]+\}", created_id, one)
    if "get" in paths[one]:
        await w.http("journalists", "read one", "GET", path, headers=owner)
    if "patch" in paths[one]:
        body = example_body(spec, _body_schema(paths[one]["patch"]), every=True)
        await w.http("journalists", "update", "PATCH", path, headers=owner, json=body)
    if "delete" in paths[one]:
        await w.http("journalists", "delete", "DELETE", path, headers=owner)


async def worker_items(w: World) -> None:
    ctx = await w.api.managers.tenancy.authenticate(stage(AppType.API), w.state["owner_token"])
    now = utcnow()
    item = WorkItem(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
        kind=WorkKind.NOOP,
        target_id=new_id(),
        idempotency_key=new_id(),
        request_id=ctx.request_id,
        available_at=now,
    )
    await w.measure("worker", "enqueue", lambda: w.api.managers.work.enqueue(ctx, item))
    work, settings = w.worker.managers.work, w.worker.settings
    lease = timedelta(seconds=settings.lease_seconds)
    claimed = await w.measure(
        "worker",
        "claim",
        lambda: work.claim(stage(AppType.WORKER), settings.lane, (WorkKind.NOOP,), "dbcalls-worker", lease),
    )
    if claimed is None:
        raise RuntimeError("the claim found no item though one was enqueued")
    claim_ctx, claimed_item = claimed
    handler = w.worker.handlers[claimed_item.kind]
    await w.measure("worker", "handle", lambda: handler.handle(claim_ctx, claimed_item))
    await w.measure("worker", "complete", lambda: work.complete(claim_ctx, claimed_item))


async def sweep(w: World) -> None:
    work = w.worker.managers.work
    before = len(await work.maintenance_contexts(stage(AppType.WORKER)))
    await w.measure("sweep", "pass", lambda: WorkerLoop(w.worker).sweep_once(), sizes={"tenants": before})
    for _ in range(9):
        tag = w.unique()
        await w.api.managers.tenancy.bootstrap(
            stage(AppType.BOOTSTRAP), f"Sweep {tag}", f"sweep-{tag}", f"sweep-{tag}@audit.example", PASSWORD, "Owner"
        )
    after = len(await work.maintenance_contexts(stage(AppType.WORKER)))
    await w.measure(
        "sweep", "pass, 9 more tenants", lambda: WorkerLoop(w.worker).sweep_once(), sizes={"tenants": after}
    )


FLOWS = [seed, auth, members, api_keys, events, operator, journalists, worker_items, sweep]
