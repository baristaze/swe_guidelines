"""The one traffic generator: realistic sessions at the edge, at a chosen profile."""
