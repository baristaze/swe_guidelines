"""The audit databases on the local Postgres: made, listed, described, and dropped.

    uv run python ops/audit/auditdb.py create audit_<slug>   # made by the superuser, grants, every role migrated
    uv run python ops/audit/auditdb.py drop audit_<slug>     # its connections ended, then dropped
    uv run python ops/audit/auditdb.py env audit_<slug>      # the export lines of its three logins' URLs
    uv run python ops/audit/auditdb.py list                  # the audit databases there are

A name is `audit_<slug>` with a slug of 1 to 40 of [a-z0-9_]; any other name is refused, and so is any database
host that is not the local machine. The stack's superuser stands as the master locally and owns the database; the
migration login gets CREATE on it, the three logins CONNECT, and `acme-migrate upgrade --all` runs as the migration
login. Logs go to standard error; standard output carries only the answer.
"""

import argparse
import logging
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote, urlparse, urlunparse

import psycopg
from psycopg import sql
from pydantic_settings import BaseSettings, SettingsConfigDict

from acme.om.storage.settings import StorageSettings

logger = logging.getLogger("auditdb")

ROOT = Path(__file__).resolve().parents[2]
NAME = re.compile(r"^audit_[a-z0-9_]{1,40}$")
LOCAL_HOSTS = frozenset({"localhost", "127.0.0.1", "::1"})
SHARED_DATABASE = "acme"
LOGINS = ("acme_migration", "acme_runtime", "acme_system")


class Refused(Exception):
    """A name, a host, or a state the tools will not act on."""


class LocalStack(BaseSettings):
    """The local stack's superuser, from the environment or .env, as the compose file sets it."""

    model_config = SettingsConfigDict(env_prefix="ACME_LOCAL_", env_file=".env", extra="ignore", env_ignore_empty=True)

    postgres_admin_user: str = "acme_admin"
    postgres_admin_password: str = "admin_pswd"


@dataclass(frozen=True)
class Target:
    """One audit database: the superuser's URL to it and to the maintenance database, and each login's URL."""

    name: str
    admin_url: str
    maintenance_url: str
    migration_url: str
    runtime_url: str
    system_url: str

    def login_url(self, login: str) -> str:
        return {
            "acme_migration": self.migration_url,
            "acme_runtime": self.runtime_url,
            "acme_system": self.system_url,
        }[login]

    def environment(self) -> dict[str, str]:
        """The settings that point the application and the migration runner at this database, and nowhere else."""
        return {
            "ACME_DATABASE_URL": self.runtime_url,
            "ACME_DATABASE_SYSTEM_URL": self.system_url,
            "ACME_DATABASE_MIGRATION_URL": self.migration_url,
        }


def check_name(name: str) -> str:
    if name == SHARED_DATABASE or not NAME.match(name):
        raise Refused(f"refused: {name!r} is not an audit database name (audit_ and 1 to 40 of [a-z0-9_])")
    return name


def check_local(url: str) -> str:
    host = urlparse(url).hostname
    if host not in LOCAL_HOSTS:
        raise Refused(f"refused: the database host {host!r} is not local (localhost, 127.0.0.1, ::1)")
    return url


def with_database(url: str, database: str) -> str:
    return urlunparse(urlparse(url)._replace(path=f"/{database}"))


def with_login(url: str, user: str, password: str, database: str) -> str:
    parsed = urlparse(url)
    host = parsed.hostname or "localhost"
    netloc_host = f"[{host}]" if ":" in host else host
    port = f":{parsed.port}" if parsed.port else ""
    netloc = f"{quote(user, safe='')}:{quote(password, safe='')}@{netloc_host}{port}"
    return urlunparse(parsed._replace(netloc=netloc, path=f"/{database}"))


def superuser_url(database: str, settings: StorageSettings | None = None) -> str:
    """The stack's superuser on the host and port of the migration login's configured URL."""
    configured = settings or StorageSettings()
    stack = LocalStack()
    url = with_login(
        configured.database_migration_url, stack.postgres_admin_user, stack.postgres_admin_password, database
    )
    return check_local(url)


def target(name: str, settings: StorageSettings | None = None) -> Target:
    """The URLs of an audit database, from the logins' configured URLs with the database name replaced."""
    check_name(name)
    configured = settings or StorageSettings()
    migration = check_local(with_database(configured.database_migration_url, name))
    runtime = check_local(with_database(configured.database_url, name))
    system = check_local(with_database(configured.database_system_url, name))
    return Target(
        name=name,
        admin_url=superuser_url(name, configured),
        maintenance_url=superuser_url("postgres", configured),
        migration_url=migration,
        runtime_url=runtime,
        system_url=system,
    )


def exists(t: Target) -> bool:
    with psycopg.connect(t.maintenance_url, autocommit=True) as conn:
        return conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (t.name,)).fetchone() is not None


def require(name: str) -> Target:
    """The target of an audit database that must already exist, for the tools that read or write it."""
    t = target(name)
    if not exists(t):
        raise Refused(f"refused: {name} does not exist; make it with `auditdb.py create {name}`")
    return t


def migrate(t: Target) -> None:
    """Every role's migrations, with the migrate command, as the migration login, on this database alone."""
    env = {**os.environ, **t.environment(), "ACME_DATABASE_MASTER_URL": ""}
    for key in [k for k in env if k.startswith(("ACME_DATABASE_URL_", "ACME_DATABASE_SYSTEM_URL_"))]:
        env[key] = ""
    subprocess.run(
        ["uv", "run", "acme-migrate", "upgrade", "--all"],  # noqa: S607 - uv from PATH, as every make target runs it
        cwd=ROOT,
        env=env,
        check=True,
        stdout=sys.stderr,
    )


def create(name: str) -> Target:
    t = target(name)
    stack = LocalStack()
    with psycopg.connect(t.maintenance_url, autocommit=True) as conn:
        if conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (name,)).fetchone():
            raise Refused(f"refused: {name} exists already; another run may hold it")
        database = sql.Identifier(name)
        conn.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(database, sql.Identifier(stack.postgres_admin_user)))
        conn.execute(
            sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(
                database, sql.SQL(", ").join(sql.Identifier(login) for login in LOGINS)
            )
        )
        conn.execute(sql.SQL("GRANT CREATE ON DATABASE {} TO acme_migration").format(database))
    logger.info("created %s; migrating every role", name)
    try:
        migrate(t)
    except subprocess.CalledProcessError:
        logger.error("the migrations failed; dropping %s", name)
        drop(name)
        raise
    return t


def drop(name: str) -> bool:
    """Ends every connection to the database and drops it; answers whether there was one to drop."""
    t = target(name)
    with psycopg.connect(t.maintenance_url, autocommit=True) as conn:
        if not conn.execute("SELECT 1 FROM pg_database WHERE datname = %s", (name,)).fetchone():
            return False
        conn.execute(
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = %s AND pid <> pg_backend_pid()",
            (name,),
        )
        conn.execute(sql.SQL("DROP DATABASE {} WITH (FORCE)").format(sql.Identifier(name)))
    return True


def listed() -> list[tuple[str, str]]:
    """Every audit database on the local Postgres with its size."""
    with psycopg.connect(superuser_url("postgres"), autocommit=True) as conn:
        rows = conn.execute(
            "SELECT datname, pg_size_pretty(pg_database_size(datname)) FROM pg_database "
            "WHERE datname LIKE 'audit\\_%%' ORDER BY datname"
        ).fetchall()
    return [(str(r[0]), str(r[1])) for r in rows]


def export_lines(t: Target) -> list[str]:
    return [f"export {key}={value}" for key, value in t.environment().items()]


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="auditdb.py", description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)
    for command, text in (
        ("create", "make the database, grant the logins, and migrate every role"),
        ("drop", "end its connections and drop it"),
        ("env", "print the export lines of its logins' URLs"),
    ):
        sub.add_parser(command, help=text).add_argument("name", help="audit_<slug>")
    sub.add_parser("list", help="list the audit databases on the local Postgres")
    return p


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="%(name)s: %(message)s")
    args = parser().parse_args(argv)
    try:
        if args.command == "create":
            create(args.name)
            print(f"created {args.name}")
        elif args.command == "drop":
            print(f"dropped {args.name}" if drop(args.name) else f"absent {args.name}")
        elif args.command == "env":
            print("\n".join(export_lines(target(args.name))))
        else:
            for name, size in listed():
                print(f"{name}\t{size}")
    except Refused as refused:
        logger.error("%s", refused)
        return 2
    except subprocess.CalledProcessError as failed:
        logger.error("the migrate command failed with exit status %s", failed.returncode)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
