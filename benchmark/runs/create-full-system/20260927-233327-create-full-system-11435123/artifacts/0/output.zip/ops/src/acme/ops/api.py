"""The client the ops tool drives the edge with, built from the env file of the environment it was given."""

from acme.clients.api import ApiClient, ApiError, ClientConfig
from acme.ops.envfile import EnvFileError

TIMEOUT_SECONDS = 15.0


def client(base_url: str, credential: str | None = None) -> ApiClient:
    return ApiClient(
        ClientConfig(base_url=base_url, timeout=TIMEOUT_SECONDS, app_type="ops", app_version="ops@0.1.0"), credential
    )


def expired_hint(error: ApiError, env: str, identity: str) -> Exception:
    """An operator token past its hour answers 401; the command that mints a fresh one is named."""
    if error.status == 401:
        return EnvFileError(
            f"the {identity} token was refused (expired?); run `acme-ops token --env {env} --identity {identity}`"
        )
    return error
