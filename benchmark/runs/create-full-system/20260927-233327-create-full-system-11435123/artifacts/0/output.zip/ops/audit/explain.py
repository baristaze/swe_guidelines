"""Plans, sizes, scan counters, candidate indexes, and rows of an audit database.

    uv run python ops/audit/explain.py plans audit_<slug> <file.sql>      # EXPLAIN (ANALYZE, BUFFERS) of each statement
    uv run python ops/audit/explain.py inventory audit_<slug>             # every table's rows and size, every index's
    uv run python ops/audit/explain.py reset audit_<slug>                 # the scan counters zeroed (pg_stat_reset)
    uv run python ops/audit/explain.py index audit_<slug> "CREATE INDEX ix_try ON <table> (<columns>)"
    uv run python ops/audit/explain.py index audit_<slug> "DROP INDEX <schema>.ix_try"
    uv run python ops/audit/explain.py rows audit_<slug> "<SELECT>" [--scope <org id | system>] [--user <id>]
                                                                          [--identity <id>]

`plans` runs each statement of the file on a connection of its own, under the login and the scope the storage funnel
sets: the runtime login with `app.org_id` (and `app.user_id`, `app.identity_id`) set by `set_config(..., true)`, or
the system login with the all-zero org for the system scope, in a transaction it rolls back. A statement ends with a
`;` at the end of a line, or at a blank line. The comment lines above a statement describe it:

    -- name: <label>
    -- scope: <org id> | system | org=<uuid> user=<uuid> identity=<uuid>
    -- user: <uuid>
    -- identity: <uuid>
    -- params: <literal>, <literal>, ...

A statement with `$1`-style parameters gets its generic plan (EXPLAIN (GENERIC_PLAN)); given `-- params:` it is also
prepared and run with them under EXPLAIN (ANALYZE, BUFFERS). The inventory's rows are the planner's estimate from the
last ANALYZE, which a counter reset keeps. `index` applies one CREATE INDEX or DROP INDEX as the migration login.
`rows` prints what one SELECT returns, as the superuser (every row the seed made) unless a scope is given, and then
under the login and scope as `plans` does. Standard output carries the answer, logs go to stderr.
"""

import argparse
import logging
import re
import sys
from dataclasses import dataclass, field
from typing import LiteralString, cast
from uuid import UUID

import auditdb
import psycopg

logger = logging.getLogger("explain")

EMPTY_UUID = UUID(int=0)
PARAMETER = re.compile(r"\$\d+")
META = re.compile(r"^--\s*(name|scope|user|identity|params)\s*:\s*(.*)$", re.IGNORECASE)
INDEX_STATEMENT = re.compile(
    r"^\s*(CREATE\s+(UNIQUE\s+)?INDEX(\s+CONCURRENTLY)?|DROP\s+INDEX(\s+CONCURRENTLY)?)\s", re.IGNORECASE
)
READ_STATEMENT = re.compile(r"^\s*(SELECT|WITH|TABLE|VALUES)\b", re.IGNORECASE)


class ScopeError(ValueError):
    """A scope line or argument the tool cannot read."""


@dataclass(frozen=True)
class Scope:
    """What the storage funnel sets: the org (the all-zero org is the system scope), the user, the identity."""

    org_id: UUID | None = None
    user_id: UUID | None = None
    identity_id: UUID | None = None

    @property
    def system(self) -> bool:
        return self.org_id == EMPTY_UUID

    @property
    def login(self) -> str:
        return "acme_system" if self.system else "acme_runtime"

    def settings(self) -> dict[str, str]:
        out: dict[str, str] = {}
        if self.org_id is not None:
            out["app.org_id"] = str(self.org_id)
        if self.user_id is not None:
            out["app.user_id"] = str(self.user_id)
        if self.identity_id is not None:
            out["app.identity_id"] = str(self.identity_id)
        return out

    def describe(self) -> str:
        parts = ["system" if self.system else f"org={self.org_id}" if self.org_id else "no org"]
        if self.user_id:
            parts.append(f"user={self.user_id}")
        if self.identity_id:
            parts.append(f"identity={self.identity_id}")
        return f"{self.login} " + " ".join(parts)


def _uuid(value: str, what: str) -> UUID:
    try:
        return UUID(value)
    except ValueError as exc:
        raise ScopeError(f"{what} {value!r} is not a uuid") from exc


def parse_scope(text: str, base: Scope | None = None) -> Scope:
    """`system`, a bare org id, or `org=`, `user=`, `identity=` pairs (`org=system` allowed), onto a base scope."""
    scope = base or Scope()
    org, user, identity = scope.org_id, scope.user_id, scope.identity_id
    for token in text.replace(",", " ").split():
        key, sep, value = token.partition("=")
        if not sep:
            key, value = "org", token
        key = key.lower()
        if key == "org":
            org = EMPTY_UUID if value.lower() == "system" else _uuid(value, "the org")
        elif key == "user":
            user = _uuid(value, "the user")
        elif key == "identity":
            identity = _uuid(value, "the identity")
        else:
            raise ScopeError(f"the scope names {key!r}; it takes org, user, and identity")
    return Scope(org, user, identity)


def split_literals(text: str) -> list[str]:
    """The `-- params:` literals, split on the commas outside single quotes."""
    out: list[str] = []
    current: list[str] = []
    quoted = False
    for char in text:
        if char == "'":
            quoted = not quoted
        if char == "," and not quoted:
            out.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    tail = "".join(current).strip()
    if tail or out:
        out.append(tail)
    return [p for p in out if p]


@dataclass
class Statement:
    sql: str
    name: str = ""
    scope: Scope = field(default_factory=Scope)
    params: list[str] = field(default_factory=list)

    @property
    def parameterized(self) -> bool:
        return bool(PARAMETER.search(self.sql))

    @property
    def label(self) -> str:
        return self.name or " ".join(self.sql.split())[:80]


def parse_statements(text: str) -> list[Statement]:
    """The statements of a file, each with the comment lines above it; one ends at `;` at a line's end or a blank."""
    out: list[Statement] = []
    meta: dict[str, str] = {}
    lines: list[str] = []

    def close() -> None:
        body = "\n".join(lines).strip()
        if body:
            body = body.removesuffix(";").rstrip()
            scope = parse_scope(meta.get("scope", ""))
            if "user" in meta:
                scope = parse_scope(f"user={meta['user']}", scope)
            if "identity" in meta:
                scope = parse_scope(f"identity={meta['identity']}", scope)
            out.append(Statement(body, meta.get("name", ""), scope, split_literals(meta.get("params", ""))))
            meta.clear()
        lines.clear()

    for raw in text.splitlines():
        line = raw.rstrip()
        stripped = line.strip()
        if not stripped:
            close()
            continue
        found = META.match(stripped)
        if found:
            if lines:
                close()
            meta[found.group(1).lower()] = found.group(2).strip()
            continue
        if stripped.startswith("--"):
            continue
        lines.append(line)
        if stripped.endswith(";"):
            close()
    close()
    return out


def _q(text: str) -> LiteralString:
    """A statement from the audit's own file or argument, on a local database the run made."""
    return cast(LiteralString, text)


def _scoped(conn: psycopg.Connection, scope: Scope) -> None:
    for name, value in scope.settings().items():
        conn.execute("SELECT set_config(%s, %s, true)", (name, value))


def plan_lines(conn: psycopg.Connection, query: str) -> list[str]:
    return [str(row[0]) for row in conn.execute(_q(query)).fetchall()]


def explain_statement(target: auditdb.Target, statement: Statement) -> list[str]:
    """The plans of one statement on a connection of its own, in a transaction rolled back."""
    out: list[str] = []
    with psycopg.connect(target.login_url(statement.scope.login)) as conn:
        try:
            _scoped(conn, statement.scope)
            if statement.parameterized:
                out.append("-- generic plan")
                out += plan_lines(conn, f"EXPLAIN (GENERIC_PLAN) {statement.sql}")
                if statement.params:
                    conn.execute(_q(f"PREPARE audit_statement AS {statement.sql}"))
                    out.append(f"-- with params: {', '.join(statement.params)}")
                    execute = f"EXECUTE audit_statement({', '.join(statement.params)})"
                    out += plan_lines(conn, f"EXPLAIN (ANALYZE, BUFFERS) {execute}")
            else:
                out += plan_lines(conn, f"EXPLAIN (ANALYZE, BUFFERS) {statement.sql}")
        finally:
            conn.rollback()
    return out


def plans(name: str, path: str) -> int:
    target = auditdb.require(name)
    with open(path) as handle:
        statements = parse_statements(handle.read())
    if not statements:
        logger.error("no statement in %s", path)
        return 1
    failed = 0
    for number, statement in enumerate(statements, start=1):
        print(f"== {number}. {statement.label}  [{statement.scope.describe()}]")
        try:
            print("\n".join(explain_statement(target, statement)))
        except psycopg.Error as error:
            failed += 1
            print(f"ERROR: {str(error).strip()}")
        print()
    if failed:
        logger.error("%d of %d statements failed", failed, len(statements))
    return 1 if failed else 0


INVENTORY_TABLES = """
SELECT s.schemaname || '.' || s.relname,
       CASE WHEN c.reltuples < 0 THEN s.n_live_tup ELSE c.reltuples::bigint END,
       pg_total_relation_size(s.relid), pg_relation_size(s.relid), s.seq_scan, coalesce(s.idx_scan, 0)
FROM pg_stat_user_tables s JOIN pg_class c ON c.oid = s.relid
ORDER BY pg_total_relation_size(s.relid) DESC, 1
"""
INVENTORY_INDEXES = """
SELECT i.schemaname || '.' || i.indexrelname, i.schemaname || '.' || i.relname,
       pg_relation_size(i.indexrelid), i.idx_scan, i.idx_tup_read
FROM pg_stat_user_indexes i ORDER BY pg_relation_size(i.indexrelid) DESC, 1
"""


def table(headers: list[str], rows: list[list[str]]) -> str:
    """A plain aligned table, numbers to the right."""
    widths = [max(len(h), *(len(r[i]) for r in rows)) if rows else len(h) for i, h in enumerate(headers)]

    def line(cells: list[str]) -> str:
        return "  ".join(
            c.rjust(w) if c.replace(".", "").isdigit() else c.ljust(w) for c, w in zip(cells, widths, strict=True)
        )

    return "\n".join([line(headers), line(["-" * w for w in widths]), *(line(r) for r in rows)]).rstrip()


def size(value: int) -> str:
    if value < 1024:
        return f"{value} B"
    amount = value / 1024
    for unit in ("kB", "MB"):
        if amount < 1024:
            return f"{amount:.1f} {unit}"
        amount /= 1024
    return f"{amount:.1f} GB"


def inventory(name: str) -> str:
    target = auditdb.require(name)
    with psycopg.connect(target.admin_url, autocommit=True) as conn:
        tables = conn.execute(INVENTORY_TABLES).fetchall()
        indexes = conn.execute(INVENTORY_INDEXES).fetchall()
    table_rows = [[str(t[0]), str(t[1]), size(int(t[2])), size(int(t[3])), str(t[4]), str(t[5])] for t in tables]
    index_rows = [[str(i[0]), str(i[1]), size(int(i[2])), str(i[3]), str(i[4])] for i in indexes]
    return "\n".join(
        [
            "Tables",
            table(["table", "rows", "total size", "heap size", "seq scans", "index scans"], table_rows),
            "",
            "Indexes",
            table(["index", "table", "size", "scans", "tuples read"], index_rows),
        ]
    )


def reset(name: str) -> None:
    target = auditdb.require(name)
    with psycopg.connect(target.admin_url, autocommit=True) as conn:
        conn.execute("SELECT pg_stat_reset()")


def check_index_statement(statement: str) -> str:
    body = statement.strip().removesuffix(";").strip()
    if not INDEX_STATEMENT.match(body + " ") or ";" in body:
        raise auditdb.Refused("refused: `index` takes one CREATE INDEX or DROP INDEX statement")
    return body


def index(name: str, statement: str) -> str:
    body = check_index_statement(statement)
    target = auditdb.require(name)
    with psycopg.connect(target.migration_url, autocommit=True) as conn:
        conn.execute(_q(body))
    return body


def check_read_statement(statement: str) -> str:
    body = statement.strip().removesuffix(";").strip()
    if not READ_STATEMENT.match(body) or ";" in body:
        raise auditdb.Refused("refused: `rows` takes one SELECT")
    return body


def rows(name: str, statement: str, scope: Scope | None, limit: int) -> str:
    body = check_read_statement(statement)
    target = auditdb.require(name)
    url = target.admin_url if scope is None else target.login_url(scope.login)
    with psycopg.connect(url) as conn:
        try:
            conn.execute("SET TRANSACTION READ ONLY")
            if scope is not None:
                _scoped(conn, scope)
            cursor = conn.execute(_q(body))
            headers = [d.name for d in cursor.description or []]
            found = cursor.fetchmany(limit + 1)
        finally:
            conn.rollback()
    if len(found) > limit:
        logger.warning("more than %d rows; the first %d are printed", limit, limit)
    lines = ["\t".join(headers)]
    lines += ["\t".join("" if v is None else str(v) for v in row) for row in found[:limit]]
    return "\n".join(lines)


def scope_from(args: argparse.Namespace) -> Scope | None:
    if args.scope is None and args.user is None and args.identity is None:
        return None
    scope = parse_scope(args.scope or "")
    if args.user:
        scope = parse_scope(f"user={args.user}", scope)
    if args.identity:
        scope = parse_scope(f"identity={args.identity}", scope)
    return scope


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="explain.py", description=__doc__, formatter_class=argparse.RawTextHelpFormatter)
    sub = p.add_subparsers(dest="command", required=True)
    plans_p = sub.add_parser("plans", help="EXPLAIN (ANALYZE, BUFFERS) each statement of a file under its scope")
    plans_p.add_argument("name", help="audit_<slug>")
    plans_p.add_argument("file", help="the statements, each under its -- name/scope/user/identity/params lines")
    sub.add_parser("inventory", help="every table's rows and size, every index's size and scans").add_argument("name")
    sub.add_parser("reset", help="zero the scan counters").add_argument("name")
    index_p = sub.add_parser("index", help="apply one CREATE INDEX or DROP INDEX as the migration login")
    index_p.add_argument("name")
    index_p.add_argument("statement")
    rows_p = sub.add_parser("rows", help="what one SELECT returns (the superuser's view unless a scope is given)")
    rows_p.add_argument("name")
    rows_p.add_argument("statement")
    rows_p.add_argument("--scope", help="<org id> | system | org=<uuid> user=<uuid> identity=<uuid>")
    rows_p.add_argument("--user", help="app.user_id")
    rows_p.add_argument("--identity", help="app.identity_id")
    rows_p.add_argument("--limit", type=int, default=1000, help="the most rows printed (default 1000)")
    return p


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(level=logging.INFO, stream=sys.stderr, format="%(name)s: %(message)s")
    args = parser().parse_args(argv)
    try:
        if args.command == "plans":
            return plans(args.name, args.file)
        if args.command == "inventory":
            print(inventory(args.name))
        elif args.command == "reset":
            reset(args.name)
            print(f"scan counters reset on {args.name}")
        elif args.command == "index":
            print(f"applied: {index(args.name, args.statement)}")
        else:
            print(rows(args.name, args.statement, scope_from(args), args.limit))
    except (auditdb.Refused, ScopeError) as refused:
        logger.error("%s", refused)
        return 2
    except psycopg.Error as error:
        logger.error("%s: %s", args.command, str(error).strip())
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
