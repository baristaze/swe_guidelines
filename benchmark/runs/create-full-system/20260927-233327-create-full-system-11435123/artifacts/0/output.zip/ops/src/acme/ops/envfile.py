"""The owner-only env file per environment, `~/.config/acme/ops/<env>.env`: operator tokens and the base URL,
never a password or a TOTP secret. Refused unless it is 0600; no command prints a value from it."""

import os
import stat
from pathlib import Path

ENVIRONMENTS = ("local", "staging", "production")
OPERATOR_TOKEN = "ACME_OPERATOR_TOKEN"
PROVISIONER_TOKEN = "ACME_PROVISIONER_TOKEN"


class EnvFileError(Exception):
    pass


def path_for(env: str) -> Path:
    if env not in ENVIRONMENTS:
        raise EnvFileError(f"unknown environment {env!r}; one of {', '.join(ENVIRONMENTS)}")
    home = Path(os.environ.get("ACME_OPS_HOME", Path.home() / ".config" / "acme" / "ops"))
    return home / f"{env}.env"


def read(env: str) -> dict[str, str]:
    path = path_for(env)
    if not path.exists():
        hint = "make seed" if env == "local" else "the create run (scripts/cloud_create.sh)"
        raise EnvFileError(f"{path} does not exist; {hint} writes it")
    mode = path.stat().st_mode
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        raise EnvFileError(f"{path} must be owner-only (chmod 600)")
    values: dict[str, str] = {}
    for line in path.read_text().splitlines():
        if "=" in line and not line.lstrip().startswith("#"):
            key, _, value = line.partition("=")
            values[key.strip()] = value.strip()
    return values


def write_value(env: str, key: str, value: str) -> None:
    """Sets one line of the env file, keeping it owner-only; the value is never echoed."""
    path = path_for(env)
    lines = path.read_text().splitlines() if path.exists() else []
    kept = [line for line in lines if not line.startswith(f"{key}=")]
    kept.append(f"{key}={value}")
    path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(path.parent, 0o700)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as handle:
        handle.write("\n".join(kept) + "\n")
    os.chmod(path, 0o600)


def require(values: dict[str, str], key: str, env: str) -> str:
    value = values.get(key, "")
    if not value:
        identity = "operator" if key == OPERATOR_TOKEN else "provisioner"
        raise EnvFileError(
            f"{key} is empty in the {env} env file; run `acme-ops token --env {env} --identity {identity}`"
        )
    return value
