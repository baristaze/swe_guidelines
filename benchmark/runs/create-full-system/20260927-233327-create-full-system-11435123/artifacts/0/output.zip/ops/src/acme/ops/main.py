"""`acme-ops`: traffic, stress, signals, size, and token, against `local`, `staging`, or `production`.

Every command reaches the platform at the edge, the operator plane with an operator token from the owner-only env
file; none prints a value from that file.
"""

import asyncio
import getpass
import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Annotated

import boto3
import typer

from acme.clients.api import ApiError, models
from acme.ops import api
from acme.ops.envfile import (
    ENVIRONMENTS,
    OPERATOR_TOKEN,
    PROVISIONER_TOKEN,
    EnvFileError,
    read,
    require,
    write_value,
)
from acme.ops.signals import SignalReport, SignalsInterface
from acme.ops.signals.cloud import SignalsCloudImpl
from acme.ops.signals.local import SignalsLocalImpl
from acme.ops.stress.scenario import load, verdict
from acme.ops.traffic.generator import RunPlan
from acme.ops.traffic.generator import run as run_traffic
from acme.ops.traffic.profiles import PROFILES

app = typer.Typer(help=__doc__, no_args_is_help=True)
signals_app = typer.Typer(help="read one request's signals back")
app.add_typer(signals_app, name="signals")

Env = Annotated[str, typer.Option("--env", help="local, staging, or production")]
ENVIRONMENTS_FILE = Path("deployment/cloud/environments.json")


def _check_env(env: str) -> None:
    if env not in ENVIRONMENTS:
        raise typer.BadParameter(f"one of {', '.join(ENVIRONMENTS)}")


def _fail(message: str) -> None:
    typer.echo(message, err=True)
    raise typer.Exit(2)


def _environment(env: str) -> dict[str, object]:
    data = json.loads(ENVIRONMENTS_FILE.read_text())
    return {"region": data["region"], **data["environments"][env]}


@app.command()
def traffic(
    env: Env,
    profile: Annotated[str, typer.Option(help="light, regular, heavy, or stress")] = "light",
    duration: Annotated[float, typer.Option(help="seconds")] = 30.0,
    orgs: Annotated[
        int | None, typer.Option(help="tenants to provision; 0 drives the seeded people, local only")
    ] = None,
    report: Annotated[Path | None, typer.Option(help="write the report as JSON")] = None,
) -> None:
    """Drive realistic sessions at the edge; exits non-zero on any server error or failed session."""
    _check_env(env)
    chosen = PROFILES[profile]
    plan = RunPlan(env=env, profile=chosen, duration=duration, orgs=chosen.orgs if orgs is None else orgs)
    try:
        recorder = asyncio.run(run_traffic(plan, report))
    except EnvFileError as error:
        _fail(str(error))
        return
    typer.echo(recorder.render())
    if recorder.errors() or recorder.failures or recorder.not_removed:
        raise typer.Exit(1)


@app.command()
def stress(
    scenario: Annotated[Path, typer.Option(help="ops/stress/<name>.yaml")],
    env: Env,
    report: Annotated[Path | None, typer.Option()] = None,
) -> None:
    """Run a scenario and answer pass or fail against the target it states."""
    _check_env(env)
    loaded = load(scenario)
    plan = RunPlan(
        env=env, profile=loaded.profile, duration=loaded.duration + loaded.soak, orgs=loaded.orgs, ramp=loaded.ramp
    )
    try:
        recorder = asyncio.run(run_traffic(plan, report))
    except EnvFileError as error:
        _fail(str(error))
        return
    summary = recorder.summary()
    passed, line = verdict(loaded, summary["p95_ms"], summary["error_ratio"])
    typer.echo(recorder.render())
    typer.echo(line)
    raise typer.Exit(0 if passed else 1)


def readers(env: str, values: dict[str, str], log_file: Path | None) -> SignalsInterface:
    if env == "local":
        return SignalsLocalImpl(
            values.get("ACME_PROMETHEUS_URL", ""),
            values.get("ACME_JAEGER_URL", ""),
            values.get("ACME_ERROR_TRACKER_URL", ""),
            values.get("ACME_ERROR_TRACKER_TOKEN", ""),
            log_file,
        )
    environment = _environment(env)
    return SignalsCloudImpl(
        env,
        f"acme-{env}-investigate",
        str(environment["region"]),
        values.get("ACME_ERROR_TRACKER_URL", ""),
        values.get("ACME_ERROR_TRACKER_TOKEN", ""),
    )


def collect(signals: SignalsInterface, request_id: str, route: str, status: str, since_minutes: int) -> SignalReport:
    return SignalReport(
        log_lines=len(signals.log_lines(request_id, since_minutes)),
        metric_value=signals.metric_value("acme_http_requests_total", {"route": route, "status": status}),
        trace_found=signals.trace(request_id, since_minutes),
        error_event_found=signals.error_event(request_id, since_minutes),
    )


@signals_app.command("check")
def signals_check(
    env: Env,
    request_id: Annotated[str, typer.Option()],
    since_minutes: Annotated[int, typer.Option()] = 15,
    log_file: Annotated[Path | None, typer.Option(help="the process's captured stdout, locally")] = None,
    route: Annotated[str, typer.Option()] = "/v1/org",
    status: Annotated[str, typer.Option()] = "200",
) -> None:
    """Read the log line, the counter, the trace, and the error event of one request back."""
    _check_env(env)
    try:
        values = read(env)
    except EnvFileError as error:
        _fail(str(error))
        return
    found = collect(readers(env, values, log_file), request_id, route, status, since_minutes)
    typer.echo(
        f"log lines {found.log_lines}  counter {found.metric_value:g}  "
        f"trace {'yes' if found.trace_found else 'no'}  error event {'yes' if found.error_event_found else 'no'}"
    )


@app.command()
def size(env: Env) -> None:
    """Tenants, users, and the rows written in the last day, leaving out the traffic generator's tenants."""
    _check_env(env)

    async def work() -> models.SizeView:
        values = read(env)
        client = api.client(values["ACME_API_URL"], require(values, OPERATOR_TOKEN, env))
        try:
            return await client.admin_get_size()
        except ApiError as error:
            raise api.expired_hint(error, env, "operator") from error
        finally:
            await client.aclose()

    try:
        found = asyncio.run(work())
    except EnvFileError as error:
        _fail(str(error))
        return
    typer.echo(f"tenants {found.tenants}  users {found.users}  written in the last day {found.events_last_day}")


@app.command()
def token(
    env: Env, identity: Annotated[str, typer.Option(help="operator (read) or provisioner (write)")] = "operator"
) -> None:
    """Write a fresh operator token into the env file, without printing it."""
    _check_env(env)
    if identity not in ("operator", "provisioner"):
        raise typer.BadParameter("operator or provisioner")
    key = OPERATOR_TOKEN if identity == "operator" else PROVISIONER_TOKEN
    if env == "local":
        email_var = "ACME_SEED_OPERATOR_EMAIL" if identity == "operator" else "ACME_SEED_PROVISIONER_EMAIL"
        email = _dotenv().get(email_var, f"{identity}@acme.example")
        permission = "read" if identity == "operator" else "write"
        minted = subprocess.run(  # noqa: S603 - a fixed command of this repository
            ["uv", "run", "acme-api", "grant-operator", "--email", email, "--permission", permission, "--mint-token"],  # noqa: S607
            capture_output=True,
            text=True,
            check=False,
        )
        if minted.returncode != 0:
            _fail(f"grant-operator failed: {minted.stderr.strip().splitlines()[-1:]}")
        write_value(env, key, minted.stdout.strip())
    elif identity == "provisioner":
        environment = _environment(env)
        session = boto3.Session(profile_name=str(environment["sso_profile"]), region_name=str(environment["region"]))
        secret = session.client("secretsmanager").get_secret_value(SecretId=f"acme-{env}-provisioner-token")
        write_value(env, key, secret["SecretString"])
    else:
        # The person runs this in their own terminal: email, password, and code are asked here, never by an agent.
        email = input("operator email: ")
        password = getpass.getpass("password: ")
        code = input("TOTP code: ")
        write_value(env, key, asyncio.run(_mint_as_person(env, email, password, code)))
    typer.echo(f"wrote {key} into the {env} env file")


async def _mint_as_person(env: str, email: str, password: str, code: str) -> str:
    """Signs the person in with the second factor and mints a `read` token for their agent."""
    base = read(env)["ACME_API_URL"]
    anonymous = api.client(base)
    try:
        signed = await anonymous.tenancy_sign_in(models.SignInRequest(email=email, password=password, totp_code=code))
        person = anonymous.with_bearer(signed.token)
        try:
            minted = await person.admin_issue_token(models.AddOperatorTokenRequest(permission="read"))
        finally:
            await person.aclose()
    finally:
        await anonymous.aclose()
    return minted.token or ""


def _dotenv() -> dict[str, str]:
    path = Path(".env")
    if not path.exists():
        return {}
    return {
        k.strip(): v.strip()
        for k, _, v in (line.partition("=") for line in path.read_text().splitlines())
        if k and not k.startswith("#")
    }


def run_cli() -> None:
    logging.basicConfig(stream=sys.stderr, level=logging.WARNING)
    app()
