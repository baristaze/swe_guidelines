"""What a run reports: requests by route and status, p50, p95, p99, and the error ratio."""

import json
import math
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


def percentile(values: list[float], share: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    rank = max(0, math.ceil(share * len(ordered)) - 1)
    return ordered[rank]


@dataclass
class Recorder:
    latencies: dict[str, list[float]] = field(default_factory=lambda: defaultdict(list))
    statuses: dict[tuple[str, str], int] = field(default_factory=lambda: defaultdict(int))
    failures: list[str] = field(default_factory=list)
    not_removed: list[str] = field(default_factory=list)

    def record(self, route: str, status: int | str, seconds: float) -> None:
        self.latencies[route].append(seconds)
        self.statuses[(route, str(status))] += 1

    def fail(self, what: str) -> None:
        self.failures.append(what)

    def errors(self) -> int:
        return sum(n for (_, status), n in self.statuses.items() if status == "transport" or status.startswith("5"))

    def total(self) -> int:
        return sum(self.statuses.values())

    def error_ratio(self) -> float:
        total = self.total()
        return self.errors() / total if total else 0.0

    def summary(self) -> dict[str, Any]:
        everything = [s for values in self.latencies.values() for s in values]
        return {
            "requests": self.total(),
            "error_ratio": round(self.error_ratio(), 6),
            "p50_ms": round(percentile(everything, 0.50) * 1000, 1),
            "p95_ms": round(percentile(everything, 0.95) * 1000, 1),
            "p99_ms": round(percentile(everything, 0.99) * 1000, 1),
            "by_route": {
                route: {
                    "count": len(values),
                    "p95_ms": round(percentile(values, 0.95) * 1000, 1),
                    "statuses": {s: n for (r, s), n in sorted(self.statuses.items()) if r == route},
                }
                for route, values in sorted(self.latencies.items())
            },
            "session_failures": self.failures[:50],
            "tenants_not_removed": self.not_removed,
        }

    def render(self) -> str:
        summary = self.summary()
        lines = [
            f"requests {summary['requests']}  error ratio {summary['error_ratio']:.4f}  "
            f"p50 {summary['p50_ms']}ms  p95 {summary['p95_ms']}ms  p99 {summary['p99_ms']}ms",
        ]
        for route, row in summary["by_route"].items():
            statuses = " ".join(f"{s}:{n}" for s, n in row["statuses"].items())
            lines.append(f"  {route:<48} {row['count']:>6}  p95 {row['p95_ms']:>8}ms  {statuses}")
        if summary["session_failures"]:
            lines.append(f"session failures: {len(self.failures)} (first: {self.failures[0]})")
        if summary["tenants_not_removed"]:
            lines.append("tenants not removed: " + ", ".join(summary["tenants_not_removed"]))
        return "\n".join(lines)

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.summary(), indent=2) + "\n")
