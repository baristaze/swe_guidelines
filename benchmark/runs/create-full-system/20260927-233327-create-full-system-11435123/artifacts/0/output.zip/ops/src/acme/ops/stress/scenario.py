"""A scenario file (`ops/stress/<name>.yaml`): a profile, a duration, a ramp, a soak, and the target."""

from dataclasses import dataclass
from pathlib import Path

import yaml

from acme.ops.traffic.profiles import PROFILES, Profile


@dataclass(frozen=True)
class Target:
    p95_ms: float
    error_ratio: float


@dataclass(frozen=True)
class Scenario:
    name: str
    profile: Profile
    duration: float
    ramp: float
    soak: float
    target: Target
    orgs: int


def load(path: Path) -> Scenario:
    data = yaml.safe_load(path.read_text())
    profile = PROFILES[data["profile"]]
    target = data["target"]
    return Scenario(
        name=data.get("name", path.stem),
        profile=profile,
        duration=float(data["duration_seconds"]),
        ramp=float(data.get("ramp_seconds", 0)),
        soak=float(data.get("soak_seconds", 0)),
        target=Target(p95_ms=float(target["p95_ms"]), error_ratio=float(target["error_ratio"])),
        orgs=int(data.get("orgs", profile.orgs)),
    )


def verdict(scenario: Scenario, p95_ms: float, error_ratio: float) -> tuple[bool, str]:
    passed = p95_ms <= scenario.target.p95_ms and error_ratio <= scenario.target.error_ratio
    line = (
        f"{scenario.name}: {'PASS' if passed else 'FAIL'}  p95 {p95_ms}ms (target {scenario.target.p95_ms}ms), "
        f"error ratio {error_ratio:.4f} (target {scenario.target.error_ratio})"
    )
    return passed, line
