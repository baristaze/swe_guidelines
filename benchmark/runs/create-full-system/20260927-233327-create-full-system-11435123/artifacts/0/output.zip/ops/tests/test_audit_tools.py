"""The audit tools' own units, with no database: auditdb's refusals, explain's statements and scopes, the seed's
statement shape, dbcalls' role and storage-method labels and its summary, and the deploy timeline's parsers."""

import importlib
import sys
from datetime import UTC, datetime
from pathlib import Path
from types import ModuleType
from uuid import UUID

import pytest

from acme.om.storage.settings import StorageSettings

AUDIT = Path(__file__).resolve().parents[1] / "audit"


def tool(name: str) -> ModuleType:
    """A tool by its file: ops/audit is a folder of scripts, which import each other by name."""
    if str(AUDIT) not in sys.path:
        sys.path.insert(0, str(AUDIT))
    return importlib.import_module(name)


auditdb = tool("auditdb")
explain = tool("explain")
seed = tool("seed")
dbcalls = tool("dbcalls")
timeline = tool("deploy_timeline")

ORG = "4695ba0d-8921-ae68-4217-0b26bcb5c5ff"
USER = "29e1497f-37fe-3f23-cb32-6fefb6442c8c"


def settings(host: str = "localhost") -> StorageSettings:
    return StorageSettings(
        _env_file=None,  # type: ignore[call-arg]
        database_url=f"postgresql://acme_runtime:runtime_pswd@{host}:55432/acme",
        database_system_url=f"postgresql://acme_system:system_pswd@{host}:55432/acme",
        database_migration_url=f"postgresql://acme_migration:migration_pswd@{host}:55432/acme",
    )


# --- auditdb


@pytest.mark.parametrize(
    "name", ["acme", "audit_", "audit_Upper", "audit_with-dash", "other_db", "audit_" + "x" * 41, "audit_a;drop"]
)
def test_a_name_that_is_not_an_audit_database_is_refused(name: str) -> None:
    with pytest.raises(auditdb.Refused):
        auditdb.check_name(name)


def test_an_audit_name_is_taken_as_it_is() -> None:
    assert auditdb.check_name("audit_query_indexes_20260928") == "audit_query_indexes_20260928"
    assert auditdb.check_name("audit_" + "x" * 40)


@pytest.mark.parametrize("host", ["db.internal", "10.0.0.5", "acme.cluster.eu-central-1.rds.amazonaws.com", "postgres"])
def test_a_host_that_is_not_local_is_refused(host: str) -> None:
    with pytest.raises(auditdb.Refused, match="not local"):
        auditdb.target("audit_x", settings(host))


def test_the_target_points_every_login_at_the_audit_database() -> None:
    t = auditdb.target("audit_x", settings("127.0.0.1"))
    assert t.runtime_url == "postgresql://acme_runtime:runtime_pswd@127.0.0.1:55432/audit_x"
    assert t.maintenance_url.endswith("@127.0.0.1:55432/postgres")
    assert t.admin_url.startswith("postgresql://acme_admin:")
    assert auditdb.export_lines(t) == [
        "export ACME_DATABASE_URL=postgresql://acme_runtime:runtime_pswd@127.0.0.1:55432/audit_x",
        "export ACME_DATABASE_SYSTEM_URL=postgresql://acme_system:system_pswd@127.0.0.1:55432/audit_x",
        "export ACME_DATABASE_MIGRATION_URL=postgresql://acme_migration:migration_pswd@127.0.0.1:55432/audit_x",
    ]


def test_the_cli_refuses_the_shared_database(capsys: pytest.CaptureFixture[str]) -> None:
    assert auditdb.main(["drop", "acme"]) == 2
    assert capsys.readouterr().out == ""


# --- explain

STATEMENTS = f"""
-- a note that describes nothing
-- name: events page
-- scope: {ORG}
-- user: {USER}
SELECT *
FROM activity.events
WHERE seq > 0;
-- name: generic
-- scope: system
-- params: '{ORG}'::uuid, 'it''s, quoted', 42
SELECT * FROM activity.events WHERE org_id = $1 AND kind = $2 AND seq > $3;

SELECT 1

-- scope: org={ORG} user={USER} identity={USER}
DELETE FROM core.sessions WHERE expires_at < now()
"""


def test_statements_split_on_a_closing_semicolon_and_on_a_blank_line() -> None:
    found = explain.parse_statements(STATEMENTS)
    assert [s.name for s in found] == ["events page", "generic", "", ""]
    assert found[0].sql == "SELECT *\nFROM activity.events\nWHERE seq > 0"
    assert found[2].sql == "SELECT 1"
    assert found[3].sql.startswith("DELETE FROM core.sessions")


def test_the_scope_comments_set_what_the_funnel_sets() -> None:
    first, generic, bare, last = explain.parse_statements(STATEMENTS)
    assert first.scope.login == "acme_runtime"
    assert first.scope.settings() == {"app.org_id": ORG, "app.user_id": USER}
    assert generic.scope.system and generic.scope.login == "acme_system"
    assert generic.scope.settings() == {"app.org_id": "00000000-0000-0000-0000-000000000000"}
    assert bare.scope.settings() == {}
    assert last.scope.settings() == {"app.org_id": ORG, "app.user_id": USER, "app.identity_id": USER}


def test_the_params_split_outside_quotes_and_mark_a_generic_plan() -> None:
    generic = explain.parse_statements(STATEMENTS)[1]
    assert generic.parameterized
    assert generic.params == [f"'{ORG}'::uuid", "'it''s, quoted'", "42"]
    assert not explain.parse_statements(STATEMENTS)[0].parameterized


def test_a_scope_that_is_not_a_uuid_is_refused() -> None:
    with pytest.raises(explain.ScopeError):
        explain.parse_scope("org=nobody")
    with pytest.raises(explain.ScopeError):
        explain.parse_scope(f"tenant={ORG}")
    assert explain.parse_scope("org=system").org_id == UUID(int=0)


def test_index_takes_one_create_or_drop_index_and_rows_one_select() -> None:
    assert explain.check_index_statement("CREATE INDEX ix_try ON core.orgs (slug);") == (
        "CREATE INDEX ix_try ON core.orgs (slug)"
    )
    assert explain.check_index_statement("drop index core.ix_try")
    for refused in ("DROP TABLE core.orgs", "CREATE INDEX a ON t (c); DROP TABLE t", "CREATE TABLE t (c int)"):
        with pytest.raises(auditdb.Refused):
            explain.check_index_statement(refused)
    assert explain.check_read_statement("with x as (select 1) select * from x")
    with pytest.raises(auditdb.Refused):
        explain.check_read_statement("DELETE FROM core.orgs")


# --- seed


def test_every_count_is_linear_in_the_scale_and_never_zero() -> None:
    one, tiny = seed.counts(1), seed.counts(0.001)
    assert one["items"] == 100_000 and one["events"] == 1_000_000
    assert seed.counts(2)["events"] == 2_000_000
    assert tiny["events"] == 1_000 and tiny["operators"] == 1 and tiny["team_members"] <= tiny["people"]
    with pytest.raises(ValueError, match="positive"):
        seed.counts(0)


def test_a_column_the_shape_does_not_name_gets_a_value_by_its_type() -> None:
    columns = [
        seed.Column("id", "uuid", False),
        seed.Column("note", "character varying", True),
        seed.Column("label", "character varying", False),
        seed.Column("payload", "jsonb", False),
    ]
    statement = seed.insert_sql(seed.Batch("core.things", 10, {"id": seed.uid("thing")}), columns)
    assert statement.startswith('INSERT INTO core.things ("id", "label", "payload") SELECT md5(')
    assert "'label-' || g.i" in statement and "generate_series(1, 10)" in statement
    with pytest.raises(ValueError, match="does not have"):
        seed.insert_sql(seed.Batch("core.things", 1, {"missing": "1"}), columns)


# --- dbcalls


@pytest.mark.parametrize(
    ("statement", "role"),
    [
        ("SELECT core.sessions.id FROM core.sessions WHERE core.sessions.digest = $1", "core"),
        ('INSERT INTO "activity"."events" (id) VALUES ($1)', "activity"),
        ("UPDATE queue.work_items SET status = $1", "queue"),
        ("SELECT set_config($1, $2, true)", None),
        ("SELECT app.org_id FROM x", None),
    ],
)
def test_a_statement_is_classified_by_the_schema_it_names(statement: str, role: str | None) -> None:
    assert dbcalls.role_of(statement) == role


def test_a_transaction_is_labelled_with_the_first_storage_method_on_the_stack() -> None:
    frames = [
        ("/x/sqlalchemy/engine/base.py", "Connection.begin"),
        ("/repo/om/src/acme/om/storage/impl/pg_base.py", "PgStorageBase._session_for"),
        ("/repo/om/src/acme/om/tenancy/storage/impl/postgres.py", "TenancyStoragePostgresImpl.read_org"),
        ("/repo/om/src/acme/om/tenancy/impl/manager.py", "TenancyManagerImpl.get_org"),
    ]
    assert dbcalls.storage_label(frames) == "TenancyStoragePostgresImpl.read_org"
    assert dbcalls.storage_label(frames[:2]) == dbcalls.UNLABELLED
    windows = [("C:\\repo\\om\\src\\acme\\om\\work\\storage\\impl\\postgres.py", "WorkStoragePostgresImpl.claim_next")]
    assert dbcalls.storage_label(windows) == "WorkStoragePostgresImpl.claim_next"


def test_a_transaction_counts_its_begin_statements_and_end() -> None:
    tx = dbcalls.Transaction(login="acme_runtime", label="EventsStoragePostgresImpl.read_after")
    tx.statements += ["SELECT set_config($1, $2, true)"] * 2 + ["SELECT activity.events.id FROM activity.events"]
    tx.scope["app.org_id"] = ORG
    tx.end = "COMMIT"
    assert tx.round_trips == 5 and tx.role == "activity"
    assert tx.detail() == (
        f"activity | acme_runtime | org_id={ORG} | EventsStoragePostgresImpl.read_after | "
        "BEGIN; SELECT set_config($1, $2, true) x2; SELECT activity.events.id FROM activity.events; COMMIT"
    )


def test_only_seed_and_the_named_flows_run(tmp_path: Path) -> None:
    async def seed(w: object) -> None: ...

    async def members(w: object) -> None: ...

    async def events(w: object) -> None: ...

    chosen = dbcalls.select_builtin([seed, members, events], "events")
    assert [f.__name__ for f in chosen] == ["seed", "events"]
    assert [f.__name__ for f in dbcalls.select_builtin([seed, members, events], None)] == ["seed", "members", "events"]
    with pytest.raises(auditdb.Refused):
        dbcalls.select_builtin([seed, members], "nothing")
    flows = tmp_path / "flows.py"
    flows.write_text("async def mine(w):\n    pass\n\nFLOWS = [mine]\n")
    assert [f.__name__ for f in dbcalls.load_flows(str(flows))] == ["mine"]


def test_the_summary_is_a_row_per_call_and_names_the_failed_flows() -> None:
    document = {
        "database": "audit_x",
        "commit": "abc123",
        "repeat": 2,
        "counted": "warm round trips",
        "flows": [
            {
                "flow": "events",
                "source": "built-in",
                "status": "ok",
                "errors": [],
                "calls": [
                    {
                        "area": "events",
                        "name": "replay one",
                        "round_trips": {"min": 17, "max": 18},
                        "transactions": {"min": 3, "max": 3},
                        "roles": {"core": 10, "activity": 5},
                        "methods": {
                            "TenancyStoragePostgresImpl.read_session_by_digest": 1,
                            "EventsStoragePostgresImpl.read_after": 2,
                        },
                    }
                ],
            },
            {"flow": "mine", "source": "flows.py", "status": "failed", "errors": ["run 1: KeyError: 'x'"], "calls": []},
        ],
    }
    text = dbcalls.render_summary(document)
    row = next(line for line in text.splitlines() if line.startswith("events"))
    cells = [c.strip() for c in row.split("|")]
    assert cells == [
        "events",
        "events",
        "replay one",
        "17",
        "18",
        "3",
        "activity:5 core:10",
        "read_session_by_digest, read_after x2",
    ]
    assert "- mine (flows.py): run 1: KeyError: 'x'" in text


# --- deploy timeline

GH_RUN = {
    "createdAt": "2026-09-28T10:00:00Z",
    "updatedAt": "2026-09-28T10:09:30Z",
    "jobs": [
        {
            "databaseId": 7,
            "name": "deploy",
            "conclusion": "success",
            "startedAt": "2026-09-28T10:02:00Z",
            "completedAt": "2026-09-28T10:09:00Z",
            "steps": [
                {
                    "name": "Set up job",
                    "number": 1,
                    "conclusion": "success",
                    "startedAt": "2026-09-28T10:02:00Z",
                    "completedAt": "2026-09-28T10:02:02Z",
                },
                {
                    "name": "terraform apply",
                    "number": 2,
                    "conclusion": "success",
                    "startedAt": "2026-09-28T10:02:02Z",
                    "completedAt": "2026-09-28T10:08:40Z",
                },
                {
                    "name": "skipped",
                    "number": 3,
                    "conclusion": "skipped",
                    "startedAt": "0001-01-01T00:00:00Z",
                    "completedAt": "0001-01-01T00:00:00Z",
                },
            ],
        },
        {
            "databaseId": 6,
            "name": "build",
            "conclusion": "success",
            "startedAt": "2026-09-28T10:00:10Z",
            "completedAt": "2026-09-28T10:01:50Z",
            "steps": [],
        },
    ],
}
API_JOBS = {
    "total_count": 1,
    "jobs": [
        {
            "id": 99,
            "name": "migrate",
            "status": "completed",
            "conclusion": "success",
            "started_at": "2026-09-28T10:03:00+00:00",
            "completed_at": "2026-09-28T10:04:30+00:00",
            "steps": [
                {
                    "name": "run task",
                    "number": 4,
                    "conclusion": "success",
                    "started_at": "2026-09-28T10:03:05Z",
                    "completed_at": "2026-09-28T10:04:25Z",
                }
            ],
        }
    ],
}


def test_the_run_record_gives_every_job_in_order_and_its_long_steps() -> None:
    jobs = timeline.parse_jobs(GH_RUN)
    assert [(j.id, j.name, j.seconds) for j in jobs] == [("6", "build", 100.0), ("7", "deploy", 420.0)]
    assert jobs[1].steps[2].started is None
    text = timeline.render_steps(GH_RUN, 30)
    assert text.splitlines()[0] == "run 2026-09-28T10:00:00Z -> 2026-09-28T10:09:30Z (9m30s)"
    assert "job 7  deploy  2026-09-28T10:02:00Z -> 2026-09-28T10:09:00Z  7m00s  success" in text
    assert "terraform apply" in text and "Set up job" not in text and "skipped" not in text
    assert "Set up job" in timeline.render_steps(GH_RUN, 0)


def test_the_jobs_api_shape_reads_the_same() -> None:
    (job,) = timeline.parse_jobs(API_JOBS)
    assert (job.id, job.seconds, job.steps[0].seconds) == ("99", 90.0, 80.0)
    assert "step  4  run task" in timeline.render_steps(API_JOBS, 60)


def test_the_service_events_in_the_window_come_oldest_first() -> None:
    services = {
        "services": [
            {
                "serviceName": "acme-api",
                "events": [
                    {"createdAt": "2026-09-28T10:07:00.123000+00:00", "message": "has reached a steady state."},
                    {"createdAt": "2026-09-28T10:03:00+00:00", "message": "has started 1 tasks: (task abc)."},
                    {"createdAt": "2026-09-28T09:00:00+00:00", "message": "before the window"},
                ],
            },
            {
                "serviceName": "acme-worker",
                "events": [{"createdAt": datetime(2026, 9, 28, 10, 5, tzinfo=UTC), "message": "stopped 1 task"}],
            },
        ]
    }
    since = timeline.parse_time("2026-09-28T10:00:00Z")
    until = timeline.parse_time("2026-09-28T10:10:00Z")
    found = timeline.parse_events(services, since, until)
    assert [(e.service, e.message) for e in found] == [
        ("acme-api", "has started 1 tasks: (task abc)."),
        ("acme-worker", "stopped 1 task"),
        ("acme-api", "has reached a steady state."),
    ]
    assert timeline.render_events(found).splitlines()[0] == (
        "2026-09-28T10:03:00Z  acme-api  has started 1 tasks: (task abc)."
    )
    assert len(timeline.parse_events(services, since, timeline.parse_time("2026-09-28T10:04:00Z"))) == 1
