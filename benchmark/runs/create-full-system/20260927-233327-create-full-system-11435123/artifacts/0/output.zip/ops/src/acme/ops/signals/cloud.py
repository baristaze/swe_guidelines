"""The cloud readers: CloudWatch Logs Insights, GetMetricData on the product's namespace, X-Ray, and the error
tracker's REST API. They hold the investigate profile, which reads every signal and writes nothing."""

import time
from datetime import UTC, datetime, timedelta
from typing import Any

import boto3
import httpx

from acme.ops.signals import SignalsInterface

NAMESPACE = "Acme"


class SignalsCloudImpl(SignalsInterface):
    def __init__(self, env: str, profile: str, region: str, tracker_url: str, tracker_token: str) -> None:
        session = boto3.Session(profile_name=profile, region_name=region)
        self._env = env
        self._logs: Any = session.client("logs")
        self._metrics: Any = session.client("cloudwatch")
        self._xray: Any = session.client("xray")
        self._tracker = tracker_url.rstrip("/")
        self._token = tracker_token

    def log_lines(self, request_id: str, since_minutes: int) -> list[str]:
        now = int(time.time())
        query = self._logs.start_query(
            logGroupNames=[f"/acme/{self._env}/api"],
            startTime=now - since_minutes * 60,
            endTime=now,
            queryString=f'fields @message | filter @message like "{request_id}" | limit 20',
        )
        for _ in range(30):
            result = self._logs.get_query_results(queryId=query["queryId"])
            if result["status"] in ("Complete", "Failed", "Cancelled"):
                return [f["value"] for row in result.get("results", []) for f in row if f["field"] == "@message"]
            time.sleep(1)
        return []

    def metric_value(self, name: str, labels: dict[str, str]) -> float:
        end = datetime.now(UTC)
        result = self._metrics.get_metric_data(
            MetricDataQueries=[
                {
                    "Id": "m",
                    "MetricStat": {
                        "Metric": {
                            "Namespace": NAMESPACE,
                            "MetricName": name,
                            "Dimensions": [{"Name": k, "Value": v} for k, v in labels.items()]
                            + [{"Name": "environment", "Value": self._env}],
                        },
                        "Period": 60,
                        "Stat": "Sum",
                    },
                }
            ],
            StartTime=end - timedelta(minutes=30),
            EndTime=end,
        )
        values = result["MetricDataResults"][0]["Values"]
        return float(sum(values))

    def trace(self, request_id: str, since_minutes: int) -> bool:
        end = datetime.now(UTC)
        summaries = self._xray.get_trace_summaries(
            StartTime=end - timedelta(minutes=since_minutes),
            EndTime=end,
            FilterExpression=f'annotation.acme_request_id = "{request_id}"',
        )
        return bool(summaries.get("TraceSummaries"))

    def error_event(self, request_id: str, since_minutes: int) -> bool:
        response = httpx.get(
            f"{self._tracker}/api/0/organizations/acme/issues/",
            params={"query": f"request_id:{request_id}"},
            headers={"Authorization": f"Bearer {self._token}"},
            timeout=10.0,
        )
        return response.status_code == 200 and bool(response.json())
