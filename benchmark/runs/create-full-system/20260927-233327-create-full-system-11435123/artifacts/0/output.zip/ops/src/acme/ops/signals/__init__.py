"""The signal readers: the log line, the counter, the trace, and the error event of one request, read back through
each signal's own API. One interface, a local impl over the devx twins and a cloud impl over the cloud's APIs."""

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass(frozen=True)
class SignalReport:
    log_lines: int
    metric_value: float
    trace_found: bool
    error_event_found: bool

    def complete(self, expect_error: bool) -> bool:
        return (
            self.log_lines > 0
            and self.metric_value > 0
            and self.trace_found
            and (self.error_event_found or not expect_error)
        )


class SignalsInterface(ABC):
    @abstractmethod
    def log_lines(self, request_id: str, since_minutes: int) -> list[str]:
        """The process's log lines that name the request id."""
        ...

    @abstractmethod
    def metric_value(self, name: str, labels: dict[str, str]) -> float:
        """The current value of a counter series; a delta is two reads."""
        ...

    @abstractmethod
    def trace(self, request_id: str, since_minutes: int) -> bool:
        """Whether a trace carrying the request id exists."""
        ...

    @abstractmethod
    def error_event(self, request_id: str, since_minutes: int) -> bool:
        """Whether the error tracker holds an event tagged with the request id."""
        ...
