"""The local readers: Prometheus's HTTP API, Jaeger's HTTP API, GlitchTip's REST API, and the captured log file."""

import json
from pathlib import Path

import httpx

from acme.ops.signals import SignalsInterface

SERVICE = "acme-api"


class SignalsLocalImpl(SignalsInterface):
    def __init__(
        self, prometheus_url: str, jaeger_url: str, tracker_url: str, tracker_token: str, log_file: Path | None
    ) -> None:
        self._prometheus = prometheus_url.rstrip("/")
        self._jaeger = jaeger_url.rstrip("/")
        self._tracker = tracker_url.rstrip("/")
        self._token = tracker_token
        self._log_file = log_file
        self._http = httpx.Client(timeout=10.0)

    def log_lines(self, request_id: str, since_minutes: int) -> list[str]:
        if self._log_file is None or not self._log_file.exists():
            return []
        return [line for line in self._log_file.read_text(errors="replace").splitlines() if request_id in line]

    def metric_value(self, name: str, labels: dict[str, str]) -> float:
        selector = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        response = self._http.get(f"{self._prometheus}/api/v1/query", params={"query": f"sum({name}{{{selector}}})"})
        response.raise_for_status()
        result = response.json()["data"]["result"]
        return float(result[0]["value"][1]) if result else 0.0

    def trace(self, request_id: str, since_minutes: int) -> bool:
        response = self._http.get(
            f"{self._jaeger}/api/traces",
            params={
                "service": SERVICE,
                "tags": json.dumps({"acme.request_id": request_id}),
                "lookback": f"{since_minutes}m",
                "limit": 5,
            },
        )
        response.raise_for_status()
        return bool(response.json().get("data"))

    def error_event(self, request_id: str, since_minutes: int) -> bool:
        headers = {"Authorization": f"Bearer {self._token}"}
        response = self._http.get(
            f"{self._tracker}/api/0/organizations/acme/issues/",
            params={"query": f"request_id:{request_id}", "statsPeriod": f"{max(1, since_minutes)}m"},
            headers=headers,
        )
        if response.status_code == 200 and response.json():
            return True
        events = self._http.get(
            f"{self._tracker}/api/0/projects/acme/acme-api/events/", params={"query": request_id}, headers=headers
        )
        return events.status_code == 200 and any(request_id in json.dumps(e) for e in events.json())
