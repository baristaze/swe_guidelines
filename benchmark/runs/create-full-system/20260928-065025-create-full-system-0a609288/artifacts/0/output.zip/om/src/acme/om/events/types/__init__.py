"""The event: the record behind every push. It carries the identity of a change and never a field's value."""

from typing import ClassVar
from uuid import UUID

from pydantic import Field

from acme.om.base import FrozenMapping, Identifiable
from acme.om.opcontext import AppContext


class Event(Identifiable):
    """Append-only: its birth time is the one in its id. `seq` is per tenant and gapless, assigned by storage."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    org_id: UUID  # carried on the entity: the relay and the operator plane read it with no tenant context
    seq: int
    kind: str
    target_id: UUID
    actor_id: UUID  # the principal of the write; EMPTY_UUID for the platform
    payload: FrozenMapping = Field(default_factory=dict, validate_default=True)  # ids only
    version: int | None = None  # the entity's compare-and-set version, when it carries one
    request_id: UUID  # the request that made the write, for the operator's feed; never on a socket frame
    app: AppContext  # the app that made it
