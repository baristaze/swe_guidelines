-- Reverses 202609281200_core_initial.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.users;
DROP TABLE IF EXISTS core.users;
DROP POLICY IF EXISTS tenant_fence ON core.socket_tickets;
DROP TABLE IF EXISTS core.socket_tickets;
DROP TABLE IF EXISTS core.sign_in_failures;
DROP POLICY IF EXISTS tenant_fence ON core.sessions;
DROP TABLE IF EXISTS core.sessions;
DROP POLICY IF EXISTS tenant_fence ON core.outbox;
DROP TABLE IF EXISTS core.outbox;
DROP TABLE IF EXISTS core.orgs;
DROP TABLE IF EXISTS core.operators;
DROP POLICY IF EXISTS tenant_fence ON core.memberships;
DROP TABLE IF EXISTS core.memberships;
DROP POLICY IF EXISTS tenant_fence ON core.identity_memberships;
DROP TABLE IF EXISTS core.identity_memberships;
DROP POLICY IF EXISTS tenant_fence ON core.identities;
DROP TABLE IF EXISTS core.identities;
DROP POLICY IF EXISTS tenant_fence ON core.idempotency_markers;
DROP TABLE IF EXISTS core.idempotency_markers;
DROP POLICY IF EXISTS tenant_fence ON core.api_keys;
DROP TABLE IF EXISTS core.api_keys;
ALTER DEFAULT PRIVILEGES IN SCHEMA core REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM acme_runtime, acme_system;
REVOKE USAGE ON SCHEMA core FROM acme_runtime, acme_system;
