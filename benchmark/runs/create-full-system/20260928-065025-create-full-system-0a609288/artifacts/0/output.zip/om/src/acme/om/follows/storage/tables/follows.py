"""The journalists a reader's account follows, in the core role, fenced by the reader's own tenant."""

from uuid import UUID

from sqlalchemy import Index, text
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, CreatedMixin, FeedIdentifiableMixin, SoftDeletableMixin


class Follows(FeedIdentifiableMixin, CreatedMixin, SoftDeletableMixin, Base):
    __tablename__ = "follows"
    __table_args__ = (
        Index(
            "ix_follows_org_id_journalist_id",
            "org_id",
            "journalist_id",
            unique=True,
            postgresql_where=text("deleted_at IS NULL"),
        ),
    )

    desk_id: Mapped[UUID]
    journalist_id: Mapped[UUID]
