"""Each recipient desk's submissions, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281741"
down_revision = "202609281740"


def upgrade() -> None:
    run_sql("core", "202609281741_submissions.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281741_submissions.down.sql")
