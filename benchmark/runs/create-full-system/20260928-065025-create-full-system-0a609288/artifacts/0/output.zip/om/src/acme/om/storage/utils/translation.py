"""Mechanical translation between an OM entity and a table row.

Nested value objects, enums, and tuples are dumped in JSON mode into JSON columns; scalars natively.
The column type decides which, so a namespace with plain shapes writes no translation code.
"""

from typing import Any

from pydantic import BaseModel
from sqlalchemy import JSON
from sqlalchemy.orm import DeclarativeBase


def _values(entity: BaseModel, row_type: type[DeclarativeBase]) -> dict[str, Any]:
    native = entity.model_dump(mode="python")
    as_json = entity.model_dump(mode="json")
    out: dict[str, Any] = {}
    for column in row_type.__table__.columns:  # type: ignore[attr-defined]
        if column.name not in native:
            continue
        out[column.name] = as_json[column.name] if isinstance(column.type, JSON) else native[column.name]
    return out


def to_values(entity: BaseModel, row_type: type[DeclarativeBase], **extra: Any) -> dict[str, Any]:
    """The column values of a row built from an entity, for a statement that inserts without a session."""
    return {**_values(entity, row_type), **extra}


def to_row[R: DeclarativeBase](entity: BaseModel, row_type: type[R], **extra: Any) -> R:
    """Build a row from an entity; `extra` carries storage-only columns such as org_id."""
    return row_type(**{**_values(entity, row_type), **extra})


def to_model[M: BaseModel](row: Any, model_type: type[M]) -> M:
    return model_type.model_validate(row, from_attributes=True)


def apply_row(row: Any, entity: BaseModel) -> None:
    """Copy entity values onto an existing row in place, never touching org_id."""
    for name, value in _values(entity, type(row)).items():
        if name not in {"org_id", "id"}:
            setattr(row, name, value)
