"""The implementations of the audit interfaces."""
