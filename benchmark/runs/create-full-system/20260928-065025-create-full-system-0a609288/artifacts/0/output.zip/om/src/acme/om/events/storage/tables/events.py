"""The event stream and the per-tenant cursor that numbers it, both in the activity role."""

from typing import Any
from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from acme.om.storage.tables.base import Base, FeedIdentifiableMixin


class Events(FeedIdentifiableMixin, Base):
    __tablename__ = "events"
    __table_args__ = (Index("ix_events_org_id_seq", "org_id", "seq", unique=True),)

    seq: Mapped[int]
    kind: Mapped[str]
    target_id: Mapped[UUID]
    actor_id: Mapped[UUID]
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    version: Mapped[int | None]
    request_id: Mapped[UUID]
    app: Mapped[dict[str, Any]] = mapped_column(JSONB)


class EventCursors(FeedIdentifiableMixin, Base):
    """One row per tenant; its id is the tenant's id, and `head` is the tenant's latest seq."""

    __tablename__ = "event_cursors"
    __table_args__ = (Index("ix_event_cursors_org_id", "org_id", unique=True),)

    head: Mapped[int]
