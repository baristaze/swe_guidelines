# Tenancy

**Nouns.** A **desk** (the tenant), a **person** (an identity), a **user** (a person inside one desk), a
**membership** (the user's role there), a **session** (a person signed in), a **key** (a program acting for a
member), a **socket ticket** (a one-time pass to open the live channel), the **operator allowlist**, and an
**operator token**.

**What can happen.**

- A person **signs up**, which opens their first desk with them as its owner, or **signs in** with a password or a
  hosted sign-in. Signing in names no desk; the person then picks one of their desks and gets a session for it.
  Switching desks ends the old session.
- A person **signs out**, which ends the credential they used; any live channel it opened closes.
- An owner or admin **changes a member's role** (never above their own) or **removes a member**; removal also
  revokes every key that member issued in the desk and ends their sessions there.
- A member **issues a key** for a program, with an expiry, and a role no higher than their own; the key is shown
  once. A key's role is checked against its issuer's role every time it is used.
- An operator is **granted** or **disabled** on the allowlist by the platform's grant job; enrols a **second
  factor** once; and mints **operator tokens** for programs.

**Rules that hold.**

- Nothing stored can be presented as a credential: passwords are stored as slow hashes, every token as a digest,
  shown once.
- A session ends after a period of inactivity and after an absolute lifetime, whichever comes first.
- Repeated failed sign-ins for one address wait longer each time, whether or not the address exists.
- The operator plane admits only a sign-in with a second factor or an operator token, never a desk's session or key.
- A deleted desk frees its short name for someone else.
