-- Reverses 202609281700_journalist_public_profile.up.sql.

ALTER TABLE core.journalists DROP COLUMN IF EXISTS payout_account_id;
ALTER TABLE core.journalists DROP COLUMN IF EXISTS published;
ALTER TABLE core.journalists DROP COLUMN IF EXISTS public_key;
ALTER TABLE core.journalists DROP COLUMN IF EXISTS bio;
