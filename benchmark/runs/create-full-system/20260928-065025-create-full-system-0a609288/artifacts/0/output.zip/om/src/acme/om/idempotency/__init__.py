"""Edge idempotency: the marker that turns a retried create into a replay or a rerun on the same id."""

from acme.om.idempotency.manager import IdempotencyManagerInterface

__all__ = ["IdempotencyManagerInterface"]
