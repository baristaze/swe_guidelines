"""The receipts of work items' outside effects, in the queue role beside the items, fenced by the tenant."""

from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, CreatedMixin, IdentifiableMixin


class WorkReceipts(IdentifiableMixin, CreatedMixin, Base):
    __tablename__ = "work_receipts"
    __table_args__ = (Index("ix_work_receipts_created_at", "created_at"),)  # the purge's

    item_id: Mapped[UUID]
