"""The follows storage over Postgres: every statement opens through the funnel under the reader's account."""

from uuid import UUID

from sqlalchemy import select

from acme.om.follows.storage import FollowsStorageInterface
from acme.om.follows.storage.tables.follows import Follows
from acme.om.follows.types.follow import Follow
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome


class FollowsStoragePostgresImpl(PgStorageBase, FollowsStorageInterface):
    async def read_follows(self, org_id: UUID, limit: int) -> list[Follow]:
        stmt = (
            select(Follows)
            .where(Follows.org_id == org_id, Follows.deleted_at.is_(None))
            .order_by(Follows.id)
            .limit(limit)
        )
        return await self._read_all(stmt, Follow, org_id=org_id)

    async def read_follow(self, org_id: UUID, follow_id: UUID) -> Follow | None:
        stmt = select(Follows).where(Follows.org_id == org_id, Follows.id == follow_id)
        return await self._read_one(stmt, Follow, org_id=org_id)

    async def read_follow_by_journalist(self, org_id: UUID, journalist_id: UUID) -> Follow | None:
        stmt = select(Follows).where(
            Follows.org_id == org_id, Follows.journalist_id == journalist_id, Follows.deleted_at.is_(None)
        )
        return await self._read_one(stmt, Follow, org_id=org_id)

    async def create_follow(self, org_id: UUID, follow: Follow, outbox_rows: tuple[OutboxRow, ...]) -> InsertOutcome:
        return await self._insert(Follows, follow, outbox_rows, org_id=org_id)

    async def write_follow(self, org_id: UUID, follow: Follow, outbox_rows: tuple[OutboxRow, ...]) -> None:
        await self._upsert(Follows, follow, outbox_rows, org_id=org_id)
