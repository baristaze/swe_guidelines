# The Free Journalism object model

These are the nouns of the platform and how they relate. Everything else in the system, the services, the apps,
the tables, is built on them.

## Who is who

- A **person** is an **identity**: one per human, across the whole platform, with the address they sign in with.
  A person signs in with a password or through a hosted sign-in (an email code, or a Google, Apple, GitHub, or
  Microsoft account).
- An **account** is the platform's tenant: what belongs to one account is never visible to another. Every person
  who signs up opens one. A **desk** is an account that presents a journalist: the journalist and anyone they bring
  in later.
- A person inside a desk is a **user** of that desk, and their **membership** gives them a **role**: the **owner**
  (the journalist who opened the desk), an **admin**, a **member**, or a **viewer**. Each role can do everything the
  next one can, and more. One person can belong to several desks, and works in one at a time.
- A **reader** follows journalists and may support them; a **patron** supports one with money every month; a
  **source** sends a journalist information. These are things a person does from their own account, not roles in a
  desk, and a source may send information without ever having an account at all.

## What a desk holds

- The desk's **journalist profiles**: the name and bio readers see, the public key sources seal reports for, and
  whether the profile is **published**. Most desks present one; a small team may present several.
- Its **updates**: short texts it publishes under a profile, which followers read in their feed.
- Its **submissions**: each report a source sent it, sealed so only the desk can open it, with the desk's working
  state and tags, and each submission's **thread** of replies, the source's answers, and the desk's own notes.
- Its **contributions**: each payment it received from a supporter.
- Its members and their **credentials**: the **sessions** of people signed in to it, and **keys** for programs that
  act for a member, which never carry a role above the member who issued them.
- Its **events**: a numbered record of every change, one per change, which is what keeps every open screen current.
- Its **audit trail**: who did what, when, from which app, including every time someone on the desk opens a
  sensitive report.

## What a reader's account holds

- Its **follows**: the journalists it follows.
- Its **pledges**: its support to journalists, once or monthly, and their history.

## What no account holds

- A **sealed report**: the one encrypted copy of a report, sealed on the source's device. It belongs to no account,
  because nobody can read it without a recipient's key; each recipient desk holds its own key in its submission.

## The platform's own

- **Operators** run the platform. They are people on the operator **allowlist**, who read or also write across
  desks, always with a second factor, and whose every look inside a desk is recorded.
- An **operator token** is a short-lived credential an operator mints for a program (the traffic generator, the
  smoke test, a support agent), carrying one permission and lasting an hour at most.

## Where to read more

Each group of nouns has its own page, one level down:

- [Tenancy](src/acme/om/tenancy/README.md): desks, people, users, memberships, roles, sessions, keys, the operator
  allowlist.
- [Events](src/acme/om/events/README.md): the numbered record of changes behind every live update.
- [Audit](src/acme/om/audit/README.md): who did what, when, and from where.
- [Outbox](src/acme/om/outbox/README.md): the note every change leaves, so nothing it sets off is ever lost.
- [Idempotency](src/acme/om/idempotency/README.md): why doing the same request twice creates one thing.
- [Work](src/acme/om/work/README.md): the background work the platform owes, and how it is done exactly once.
- [Journalists](src/acme/om/journalists/README.md): the profiles a desk presents to its readers.
- [Follows](src/acme/om/follows/README.md): the journalists a reader follows.
- [Updates](src/acme/om/updates/README.md): the short updates a desk publishes.
- [Support](src/acme/om/support/README.md): pledges, and the contributions a desk receives.
- [Reports](src/acme/om/reports/README.md): sealed reports, submissions, and their threads.
