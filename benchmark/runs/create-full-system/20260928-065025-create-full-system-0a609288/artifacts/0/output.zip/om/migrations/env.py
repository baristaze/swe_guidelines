"""Alembic's environment: one role per run, its version table inside its own schema, one transaction per file."""

from alembic import context
from sqlalchemy import create_engine, text

config = context.config
role = config.attributes["role"]
url = config.get_main_option("sqlalchemy.url")
if url is None:
    raise SystemExit("the migration login's URL is not configured")

engine = create_engine(url)
with engine.connect() as connection:
    # The version table lives in the role's schema, so the schema exists before the first migration runs;
    # the first migration of each chain creates it again with IF NOT EXISTS and grants the two logins on it.
    connection.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{role}"'))
    connection.commit()
    context.configure(
        connection=connection,
        version_table="alembic_version",
        version_table_schema=role,
        transaction_per_migration=True,
    )
    with context.begin_transaction():
        context.run_migrations()
engine.dispose()
