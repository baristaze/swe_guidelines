"""The events manager impl."""

import logging
from dataclasses import dataclass
from datetime import datetime
from uuid import UUID

from acme.om.events.manager import EventsManagerInterface
from acme.om.events.storage import EventsStorageInterface
from acme.om.events.types import Event
from acme.om.opcontext import OpContext, OperatorContext, OperatorPermission, Permission
from acme.om.outbox.types import OutboxRow

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class EventsOptions:
    page_size: int


class EventsManagerImpl(EventsManagerInterface):
    def __init__(self, storage: EventsStorageInterface, options: EventsOptions) -> None:
        self._storage = storage
        self._options = options

    def _clamp(self, limit: int) -> int:
        return max(1, min(limit, self._options.page_size))

    async def append_relayed(self, org_id: UUID, row: OutboxRow) -> Event:
        version = row.payload.get("version")
        event = Event(
            id=row.id,  # the row's id, so a second relay of the row finds the first event
            org_id=org_id,
            seq=0,  # storage assigns it
            kind=row.kind,
            target_id=row.target_id,
            actor_id=row.actor_id,
            payload={k: v for k, v in row.payload.items() if k != "version"},
            version=int(version) if isinstance(version, int) else None,
            request_id=row.request_id,
            app=row.app,
        )
        return await self._storage.append_event(org_id, event)

    async def get_events(self, ctx: OpContext, after_seq: int, limit: int) -> list[Event]:
        ctx.require(Permission.READ)
        return await self._storage.read_after(ctx.org_id, after_seq, self._clamp(limit))

    async def get_head(self, ctx: OpContext) -> int:
        ctx.require(Permission.READ)
        return await self._storage.read_head(ctx.org_id)

    async def count_events_for_operator(
        self, octx: OperatorContext, since: datetime, excluded: tuple[UUID, ...]
    ) -> int:
        octx.require(OperatorPermission.READ)
        return await self._storage.count_since(since, excluded)

    async def get_events_for_operator(
        self, octx: OperatorContext, org_id: UUID, after_seq: int, limit: int
    ) -> list[Event]:
        octx.require(OperatorPermission.READ)
        logger.info(
            "operator read a tenant's events",
            extra={"org_id": str(org_id), "operator_identity_id": str(octx.identity_id)},
        )
        return await self._storage.read_after(org_id, after_seq, self._clamp(limit))
