-- Reverses 202609281740_sealed_reports.up.sql.

DROP TABLE IF EXISTS core.sealed_reports;
