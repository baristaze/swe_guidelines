"""The follows manager impl: authorize, verify, copy, write with the outbox row, relay at once."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.base import utcnow
from acme.om.exceptions import Conflict, NotFound
from acme.om.follows.manager import FollowsManagerInterface
from acme.om.follows.storage import FollowsStorageInterface
from acme.om.follows.types.follow import Follow
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.opcontext import OpContext, Permission
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, outbox_row
from acme.om.storage.root import InsertOutcome


@dataclass(frozen=True)
class FollowsOptions:
    page_size: int  # the most one list answers


class FollowsManagerImpl(FollowsManagerInterface):
    def __init__(
        self,
        storage: FollowsStorageInterface,
        relay: OutboxRelayInterface,
        journalists: JournalistsManagerInterface,
        options: FollowsOptions,
    ) -> None:
        self._storage = storage
        self._relay = relay
        self._journalists = journalists
        self._options = options

    async def get_follows(self, ctx: OpContext, limit: int) -> list[Follow]:
        ctx.require(Permission.READ)
        return await self._storage.read_follows(ctx.org_id, max(1, min(limit, self._options.page_size)))

    async def get_follow(self, ctx: OpContext, follow_id: UUID) -> Follow:
        ctx.require(Permission.READ)
        found = await self._storage.read_follow(ctx.org_id, follow_id)
        if found is None or found.deleted_at is not None:
            raise NotFound("no such follow")
        return found

    async def create_follow(self, ctx: OpContext, follow: Follow) -> Follow:
        ctx.require(Permission.WRITE)
        # The fact the follow rests on: the journalist is published by that desk (read under the desk's tenant).
        await self._journalists.get_published_journalist(ctx, follow.desk_id, follow.journalist_id)
        copy = follow.model_copy(update={"deleted_at": None, "deleted_by": None})
        rows = (outbox_row(ctx, "follows.follow.created", copy.id, {}),)
        outcome = await self._storage.create_follow(ctx.org_id, copy, rows)
        if outcome == InsertOutcome.INSERTED:
            await self._relay_all(ctx.org_id, rows)
            return copy
        stored = (
            await self._storage.read_follow(ctx.org_id, copy.id)
            if outcome == InsertOutcome.ID_EXISTS
            else await self._storage.read_follow_by_journalist(ctx.org_id, copy.journalist_id)
        )
        if stored is None:
            raise Conflict("that follow id is taken")
        return stored

    async def delete_follow(self, ctx: OpContext, follow_id: UUID) -> None:
        ctx.require(Permission.WRITE)
        current = await self.get_follow(ctx, follow_id)
        copy = current.model_copy(update={"deleted_at": utcnow(), "deleted_by": ctx.user_id})
        rows = (outbox_row(ctx, "follows.follow.deleted", copy.id, {}),)
        await self._storage.write_follow(ctx.org_id, copy, rows)
        await self._relay_all(ctx.org_id, rows)

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; the write has committed, a failure is the sweep's
