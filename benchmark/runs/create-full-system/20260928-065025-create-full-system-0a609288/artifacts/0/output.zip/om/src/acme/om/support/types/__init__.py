"""One module per entity of the support namespace."""
