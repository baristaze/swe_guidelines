"""The desk's journalist profiles, in the core role, fenced by the tenant."""

from sqlalchemy.orm import Mapped, mapped_column

from acme.om.storage.tables.base import Base, IdentifiableMixin, SoftDeletableMixin, TrackableMixin


class Journalists(IdentifiableMixin, TrackableMixin, SoftDeletableMixin, Base):
    __tablename__ = "journalists"

    display_name: Mapped[str]
    bio: Mapped[str] = mapped_column(server_default="")
    public_key: Mapped[str | None]
    published: Mapped[bool] = mapped_column(server_default="false")
    payout_account_id: Mapped[str | None]
