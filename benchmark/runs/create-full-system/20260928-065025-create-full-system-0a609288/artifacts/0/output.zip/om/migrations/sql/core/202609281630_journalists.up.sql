-- The desk's journalist profiles: the first product entity, org scope.

-- journalists: org scope
CREATE TABLE core.journalists (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE,
    deleted_by UUID,
    display_name VARCHAR NOT NULL,
    CONSTRAINT pk_journalists PRIMARY KEY (id)
);
CREATE INDEX ix_journalists_org_id ON core.journalists (org_id);
CREATE POLICY tenant_fence ON core.journalists
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.journalists ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.journalists FORCE ROW LEVEL SECURITY;
