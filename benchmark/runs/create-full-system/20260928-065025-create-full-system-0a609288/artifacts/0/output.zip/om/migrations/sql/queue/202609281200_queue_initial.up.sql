-- The queue role's first migration: its schema, the two logins' grants, and the work queue
-- with its policy.

CREATE SCHEMA IF NOT EXISTS queue;
GRANT USAGE ON SCHEMA queue TO acme_runtime, acme_system;
ALTER DEFAULT PRIVILEGES IN SCHEMA queue GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO acme_runtime, acme_system;

-- work_items: org scope
CREATE TABLE queue.work_items (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    kind VARCHAR NOT NULL,
    target_id UUID NOT NULL,
    idempotency_key UUID NOT NULL,
    request_id UUID NOT NULL,
    traceparent VARCHAR,
    payload JSONB NOT NULL,
    lane VARCHAR NOT NULL,
    status VARCHAR NOT NULL,
    available_at TIMESTAMP WITH TIME ZONE NOT NULL,
    claimed_by VARCHAR,
    claim_token UUID,
    lease_expires_at TIMESTAMP WITH TIME ZONE,
    attempts INTEGER NOT NULL,
    max_attempts INTEGER NOT NULL,
    last_error VARCHAR,
    CONSTRAINT pk_work_items PRIMARY KEY (id)
);
CREATE INDEX ix_work_items_lane_status_available_at ON queue.work_items (lane, status, available_at);
CREATE UNIQUE INDEX ix_work_items_org_id_idempotency_key ON queue.work_items (org_id, idempotency_key);
CREATE INDEX ix_work_items_status_lease_expires_at ON queue.work_items (status, lease_expires_at);
CREATE POLICY tenant_fence ON queue.work_items
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE queue.work_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE queue.work_items FORCE ROW LEVEL SECURITY;
