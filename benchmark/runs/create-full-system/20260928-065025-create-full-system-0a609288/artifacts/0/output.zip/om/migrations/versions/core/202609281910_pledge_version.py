"""The pledge's compare-and-set version."""

from acme.om.storage.migrate import run_sql

revision = "202609281910"
down_revision = "202609281742"


def upgrade() -> None:
    run_sql("core", "202609281910_pledge_version.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281910_pledge_version.down.sql")
