"""The queue role's first migration: its schema, the two logins' grants, and the work queue."""

from acme.om.storage.migrate import run_sql

revision = "202609281200"
down_revision = None


def upgrade() -> None:
    run_sql("queue", "202609281200_queue_initial.up.sql")


def downgrade() -> None:
    run_sql("queue", "202609281200_queue_initial.down.sql")
