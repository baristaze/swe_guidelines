"""The updates storage over Postgres: every statement opens through the funnel under the desk's tenant."""

from uuid import UUID

from sqlalchemy import select

from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome
from acme.om.updates.storage import UpdatesStorageInterface
from acme.om.updates.storage.tables.updates import Updates
from acme.om.updates.types.update import Update


class UpdatesStoragePostgresImpl(PgStorageBase, UpdatesStorageInterface):
    async def read_updates(self, org_id: UUID, limit: int, journalist_id: UUID | None = None) -> list[Update]:
        stmt = select(Updates).where(Updates.org_id == org_id)
        if journalist_id is not None:
            stmt = stmt.where(Updates.journalist_id == journalist_id)
        return await self._read_all(stmt.order_by(Updates.id.desc()).limit(limit), Update, org_id=org_id)

    async def read_update(self, org_id: UUID, update_id: UUID) -> Update | None:
        stmt = select(Updates).where(Updates.org_id == org_id, Updates.id == update_id)
        return await self._read_one(stmt, Update, org_id=org_id)

    async def create_update(self, org_id: UUID, update: Update, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        outcome = await self._insert(Updates, update, outbox_rows, org_id=org_id)
        return outcome == InsertOutcome.INSERTED
