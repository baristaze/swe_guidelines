"""One module per entity of the updates namespace."""
