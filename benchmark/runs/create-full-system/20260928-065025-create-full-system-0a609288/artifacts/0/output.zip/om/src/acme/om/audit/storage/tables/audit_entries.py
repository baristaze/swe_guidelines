"""The audit stream and its per-tenant cursor, in the activity role."""

from typing import Any
from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from acme.om.storage.tables.base import Base, FeedIdentifiableMixin


class AuditEntries(FeedIdentifiableMixin, Base):
    __tablename__ = "audit_entries"
    __table_args__ = (Index("ix_audit_entries_org_id_seq", "org_id", "seq", unique=True),)

    seq: Mapped[int]
    kind: Mapped[str]
    target_id: Mapped[UUID]
    actor_id: Mapped[UUID]
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    request_id: Mapped[UUID]
    app: Mapped[dict[str, Any]] = mapped_column(JSONB)


class AuditCursors(FeedIdentifiableMixin, Base):
    """One row per tenant; its id is the tenant's id."""

    __tablename__ = "audit_cursors"
    __table_args__ = (Index("ix_audit_cursors_org_id", "org_id", unique=True),)

    head: Mapped[int]
