"""The marker in memory, with the same guards the engine's statements carry."""

from datetime import datetime
from uuid import UUID

from acme.om.idempotency.storage import IdempotencyStorageInterface
from acme.om.idempotency.types import BeginOutcome, IdempotencyMarker, MarkerOutcome, attempt_started_at
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase


class IdempotencyStorageMemoryImpl(MemoryStorageBase, IdempotencyStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._markers: dict[tuple[UUID, UUID, str], IdempotencyMarker] = {}

    def _by_id(
        self, org_id: UUID, user_id: UUID, marker_id: UUID
    ) -> tuple[tuple[UUID, UUID, str], IdempotencyMarker] | None:
        for key, marker in self._markers.items():
            if key[0] == org_id and key[1] == user_id and marker.id == marker_id:
                return key, marker
        return None

    async def begin(self, org_id: UUID, marker: IdempotencyMarker, stale_before: datetime) -> MarkerOutcome:
        """Named atomic: writes the marker pending, or takes over a released one or one whose attempt began
        before `stale_before`, keeping its digest and target id; exactly one of two racing callers starts."""
        key = (org_id, marker.user_id, marker.key)
        current = self._markers.get(key)
        if current is None:
            self._markers[key] = marker
            return MarkerOutcome(outcome=BeginOutcome.STARTED, marker=marker)
        if current.request_digest != marker.request_digest:
            return MarkerOutcome(outcome=BeginOutcome.MISMATCH, marker=current)
        if current.status is not None:
            return MarkerOutcome(outcome=BeginOutcome.REPLAY, marker=current)
        held = current.attempt_token
        if held is not None and attempt_started_at(held) >= stale_before:
            return MarkerOutcome(outcome=BeginOutcome.RUNNING, marker=current)
        taken = current.model_copy(update={"attempt_token": marker.attempt_token})
        self._markers[key] = taken
        return MarkerOutcome(outcome=BeginOutcome.STARTED, marker=taken)

    async def finish(
        self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID, status: int, body: str
    ) -> bool:
        found = self._by_id(org_id, user_id, marker_id)
        if found is None or found[1].attempt_token != attempt_token or found[1].status is not None:
            return False
        self._markers[found[0]] = found[1].model_copy(update={"status": status, "body": body})
        return True

    async def release(self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID) -> bool:
        found = self._by_id(org_id, user_id, marker_id)
        if found is None or found[1].attempt_token != attempt_token or found[1].status is not None:
            return False
        self._markers[found[0]] = found[1].model_copy(update={"attempt_token": None})
        return True

    async def holds_attempt(self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID) -> bool:
        """Whether the marker is still pending under this attempt: the guard a rerun's re-mint reads."""
        found = self._by_id(org_id, user_id, marker_id)
        return found is not None and found[1].attempt_token == attempt_token and found[1].status is None

    async def read_marker(self, org_id: UUID, user_id: UUID, key: str) -> IdempotencyMarker | None:
        return self._markers.get((org_id, user_id, key))

    async def purge_markers(self, before: datetime, limit: int) -> int:
        """Tenant-less: the sweep's purge of markers created before `before`, across tenants, in the system scope."""
        doomed = [k for k, m in self._markers.items() if m.created_at < before][:limit]
        for key in doomed:
            del self._markers[key]
        return len(doomed)
