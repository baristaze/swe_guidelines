"""The messages of each submission's thread, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281742"
down_revision = "202609281741"


def upgrade() -> None:
    run_sql("core", "202609281742_messages.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281742_messages.down.sql")
