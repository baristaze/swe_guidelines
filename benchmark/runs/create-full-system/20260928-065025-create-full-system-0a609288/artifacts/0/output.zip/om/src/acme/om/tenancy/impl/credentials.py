"""Credential material: minting secrets, their digests, password hashes, and the TOTP secret's encryption.

Nothing the tenancy namespace stores can be presented as a credential: a password is a scrypt hash under
its own salt, every token is stored as its SHA-256 digest and shown once.
"""

import base64
import hashlib
import hmac
import os
import secrets
from enum import StrEnum

from cryptography.fernet import Fernet, InvalidToken

SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1


class TokenPrefix(StrEnum):
    """Every credential kind has a distinct prefix; the prefix decides which gateway dependency accepts it."""

    LOGIN = "fjl_"
    TENANT_SESSION = "fjs_"
    API_KEY = "fjk_"
    SOCKET_TICKET = "fjt_"
    OPERATOR_TOKEN = "fjo_"


def mint(prefix: TokenPrefix) -> str:
    return f"{prefix.value}{secrets.token_urlsafe(32)}"


def digest(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def email_digest(email: str) -> str:
    return digest(email.strip().lower())


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    derived = hashlib.scrypt(password.encode(), salt=salt, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P, dklen=32)
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt.hex()}${derived.hex()}"


def verify_password(password: str, stored: str | None) -> bool:
    """Constant work whether or not a hash exists, so an unknown email costs what a known one does."""
    candidate = stored or DUMMY_HASH
    try:
        _, n, r, p, salt, expected = candidate.split("$")
    except ValueError:
        return False
    derived = hashlib.scrypt(
        password.encode(), salt=bytes.fromhex(salt), n=int(n), r=int(r), p=int(p), dklen=len(expected) // 2
    )
    return stored is not None and hmac.compare_digest(derived.hex(), expected)


DUMMY_HASH = hash_password("not a password anyone holds")


def new_totp_secret() -> bytes:
    return os.urandom(20)


def base32(secret: bytes) -> str:
    return base64.b32encode(secret).decode().rstrip("=")


class TotpCipher:
    """Encrypts an operator's TOTP secret under the key the options carry, from the secret store in the cloud."""

    def __init__(self, key: str) -> None:
        self._fernet = Fernet(key.encode())

    def encrypt(self, secret: bytes) -> str:
        return self._fernet.encrypt(secret).decode()

    def decrypt(self, stored: str) -> bytes | None:
        try:
            return self._fernet.decrypt(stored.encode())
        except InvalidToken:
            return None
