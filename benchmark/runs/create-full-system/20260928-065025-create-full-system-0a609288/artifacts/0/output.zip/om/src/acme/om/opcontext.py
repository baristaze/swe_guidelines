"""The context stages, the scopes, and the vocabulary they carry.

A stage says what a request has established; a scope says what a consumer sees.
Only a transition of the tenancy manager builds a stage above the request stage.
"""

from enum import StrEnum
from typing import Protocol
from uuid import UUID

from acme.om.base import Platform
from acme.om.exceptions import NotAuthorized, SecondFactorNotEnrolled


class Role(StrEnum):
    """A member's role, ordered owner > admin > member > viewer; each holds the permissions of the next."""

    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"
    VIEWER = "viewer"
    SERVICE = "service"  # reserved for services: outside the order, never minted for a person


class Permission(StrEnum):
    READ = "read"
    WRITE = "write"
    MANAGE_MEMBERS = "manage_members"
    MANAGE_KEYS = "manage_keys"
    READ_AUDIT = "read_audit"
    MANAGE_ORG = "manage_org"  # the owner's alone: the org itself, its billing, its deletion


class OperatorPermission(StrEnum):
    READ = "read"
    WRITE = "write"
    ENROL = "enrol"  # an operator with no confirmed second factor yet holds this alone


class CredentialKind(StrEnum):
    PASSWORD = "password"  # the sign-in credential, which names no tenant
    API_KEY = "api_key"
    TENANT_SESSION = "tenant_session"
    OPERATOR_TOKEN = "operator_token"
    INTERNAL = "internal"  # the per-call credential a peer service mints


class AppType(StrEnum):
    PORTAL = "portal"
    ADMIN = "admin"
    CLI = "cli"
    API = "api"
    WORKER = "worker"
    OPS = "ops"
    BOOTSTRAP = "bootstrap"


class AppContext(Platform):
    type: AppType
    version: str  # e.g. "portal@0.1.0"


class SecurityContext(Platform):
    user_id: UUID
    org_id: UUID
    role: Role
    permissions: tuple[Permission, ...]
    teams: tuple[UUID, ...] = ()
    credential_kind: CredentialKind
    credential_id: UUID


class RequestContext(Platform):
    """A request exists; nobody is known yet."""

    request_id: UUID
    app: AppContext
    trace_id: str | None = None
    traceparent: str | None = None  # the trace context a handoff carries on
    caused_by_request_id: UUID | None = None  # the request behind this one across a handoff


class IdentityContext(RequestContext):
    """A person is verified by their own sign-in; no tenant is chosen."""

    identity_id: UUID
    email: str
    credential_kind: CredentialKind
    credential_id: UUID


class OperatorContext(IdentityContext):
    """The operator plane. No org_id, on purpose."""

    permissions: tuple[OperatorPermission, ...]  # what the allowlist entry grants

    def has(self, permission: OperatorPermission) -> bool:
        return permission in self.permissions

    def require(self, permission: OperatorPermission) -> None:
        if permission in self.permissions:
            return
        if self.permissions == (OperatorPermission.ENROL,):
            raise SecondFactorNotEnrolled("enrol a second factor first")
        raise NotAuthorized(f"the operator plane requires {permission.value}")


class OpContext(RequestContext):
    """A membership is established: one tenant, one user, one role."""

    security: SecurityContext

    @property
    def org_id(self) -> UUID:
        return self.security.org_id

    @property
    def user_id(self) -> UUID:
        return self.security.user_id

    @property
    def credential_kind(self) -> CredentialKind:
        return self.security.credential_kind

    @property
    def credential_id(self) -> UUID:
        return self.security.credential_id

    def has(self, permission: Permission) -> bool:
        return permission in self.security.permissions

    def require(self, permission: Permission) -> None:
        if permission not in self.security.permissions:
            raise NotAuthorized(f"this operation requires {permission.value}")

    def in_team(self, team_id: UUID) -> bool:
        return team_id in self.security.teams


class RequestScope(Protocol):
    @property
    def request_id(self) -> UUID: ...
    @property
    def app(self) -> AppContext: ...
    @property
    def traceparent(self) -> str | None: ...


class TenantScope(Protocol):
    @property
    def org_id(self) -> UUID: ...


class ActorScope(TenantScope, Protocol):  # there is no actor without a tenant
    @property
    def user_id(self) -> UUID: ...


class CredentialScope(Protocol):
    @property
    def credential_kind(self) -> CredentialKind: ...
    @property
    def credential_id(self) -> UUID: ...


class ProvenanceScope(ActorScope, RequestScope, Protocol): ...
