"""The outbox's storage. Rows land through the writing namespace's own atomic method, never through here."""

from abc import ABC, abstractmethod
from datetime import datetime
from uuid import UUID

from acme.om.outbox.types import OutboxRow


class OutboxStorageInterface(ABC):
    @abstractmethod
    async def read_row(self, org_id: UUID, row_id: UUID) -> OutboxRow | None: ...

    @abstractmethod
    async def mark_done(self, org_id: UUID, row_id: UUID, done_at: datetime) -> bool: ...  # False: not this tenant's

    @abstractmethod
    async def read_pending(self, limit: int) -> list[OutboxRow]:
        """Tenant-less: a cross-tenant sweep in the system scope; each row names its own tenant."""
        ...

    @abstractmethod
    async def read_oldest_pending(self) -> datetime | None:
        """Tenant-less: the creation time of the oldest pending row across tenants, for the lag gauge."""
        ...

    @abstractmethod
    async def purge_done(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges up to `limit` rows done before `before`, across tenants, in the system scope."""
        ...
