"""Every database setting: the three logins' URLs, the per-role URLs, the master URL, the pools and deadlines."""

from pydantic_settings import BaseSettings, SettingsConfigDict

from acme.om.storage.roles import DatabaseRole


class StorageSettings(BaseSettings):
    """URLs are plain `postgresql://` URLs; an empty per-role value means the shared one."""

    model_config = SettingsConfigDict(env_prefix="ACME_", env_file=".env", extra="ignore", env_ignore_empty=True)

    database_url: str = "postgresql://acme_runtime:runtime_pswd@localhost:55432/acme"  # the runtime login
    database_system_url: str = "postgresql://acme_system:system_pswd@localhost:55432/acme"  # the system login
    database_migration_url: str = "postgresql://acme_migration:migration_pswd@localhost:55432/acme"
    database_master_url: str = ""  # read only by `migrate ensure-logins`, in the cloud's migration task
    database_migrations_dir: str = ""  # empty: om/migrations beside the source; an image sets its own path

    database_url_core: str = ""
    database_url_activity: str = ""
    database_url_queue: str = ""
    database_system_url_core: str = ""
    database_system_url_activity: str = ""
    database_system_url_queue: str = ""

    database_pool_size: int = 10
    database_pool_checkout_timeout: float = 5.0  # seconds a checkout waits before it fails
    database_statement_timeout: float = 10.0  # seconds a statement runs before it is cancelled
    database_pool_size_core: int | None = None
    database_pool_size_activity: int | None = None
    database_pool_size_queue: int | None = None
    database_pool_checkout_timeout_core: float | None = None
    database_pool_checkout_timeout_activity: float | None = None
    database_pool_checkout_timeout_queue: float | None = None
    database_statement_timeout_core: float | None = None
    database_statement_timeout_activity: float | None = None
    database_statement_timeout_queue: float | None = None

    def runtime_url(self, role: DatabaseRole) -> str:
        return getattr(self, f"database_url_{role.value}") or self.database_url

    def system_url(self, role: DatabaseRole) -> str:
        return getattr(self, f"database_system_url_{role.value}") or self.database_system_url

    def pool_size(self, role: DatabaseRole) -> int:
        value = getattr(self, f"database_pool_size_{role.value}")
        return self.database_pool_size if value is None else value

    def pool_checkout_timeout(self, role: DatabaseRole) -> float:
        value = getattr(self, f"database_pool_checkout_timeout_{role.value}")
        return self.database_pool_checkout_timeout if value is None else value

    def statement_timeout(self, role: DatabaseRole) -> float:
        value = getattr(self, f"database_statement_timeout_{role.value}")
        return self.database_statement_timeout if value is None else value

    def all_urls(self) -> list[str]:
        """Every URL the settings resolve, for the check that a seed or a test runs only against a local host."""
        urls = [self.database_url, self.database_system_url, self.database_migration_url]
        urls += [self.runtime_url(r) for r in DatabaseRole] + [self.system_url(r) for r in DatabaseRole]
        if self.database_master_url:
            urls.append(self.database_master_url)
        return urls
