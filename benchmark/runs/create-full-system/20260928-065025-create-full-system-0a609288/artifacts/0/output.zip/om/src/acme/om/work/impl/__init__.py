"""The implementations of the work interfaces."""
