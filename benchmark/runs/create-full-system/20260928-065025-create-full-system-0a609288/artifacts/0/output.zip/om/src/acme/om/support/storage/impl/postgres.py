"""The support storage over Postgres: every statement opens through the funnel under the tenant it names."""

from uuid import UUID

from sqlalchemy import select, update

from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome
from acme.om.storage.utils.translation import to_values
from acme.om.support.storage import SupportStorageInterface
from acme.om.support.storage.tables.contributions import Contributions
from acme.om.support.storage.tables.pledges import Pledges
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge


class SupportStoragePostgresImpl(PgStorageBase, SupportStorageInterface):
    async def read_pledges(self, org_id: UUID, limit: int) -> list[Pledge]:
        stmt = select(Pledges).where(Pledges.org_id == org_id).order_by(Pledges.id.desc()).limit(limit)
        return await self._read_all(stmt, Pledge, org_id=org_id)

    async def read_pledge(self, org_id: UUID, pledge_id: UUID) -> Pledge | None:
        stmt = select(Pledges).where(Pledges.org_id == org_id, Pledges.id == pledge_id)
        return await self._read_one(stmt, Pledge, org_id=org_id)

    async def create_pledge(self, org_id: UUID, pledge: Pledge, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        return await self._insert(Pledges, pledge, outbox_rows, org_id=org_id) == InsertOutcome.INSERTED

    async def write_pledge(
        self, org_id: UUID, pledge: Pledge, expected_version: int, outbox_rows: tuple[OutboxRow, ...]
    ) -> bool:
        values = {k: v for k, v in to_values(pledge, Pledges).items() if k not in {"id", "org_id"}}
        stmt = (
            update(Pledges)
            .where(Pledges.org_id == org_id, Pledges.id == pledge.id, Pledges.version == expected_version)
            .values(**values)
            .returning(Pledges.id)
        )
        async with self._session_for(stmt, org_id=org_id) as session:
            if (await session.execute(stmt)).scalar_one_or_none() is None:
                return False
            await self._land(session, outbox_rows)
            return True

    async def read_contributions(self, org_id: UUID, limit: int) -> list[Contribution]:
        stmt = (
            select(Contributions).where(Contributions.org_id == org_id).order_by(Contributions.id.desc()).limit(limit)
        )
        return await self._read_all(stmt, Contribution, org_id=org_id)

    async def read_contribution(self, org_id: UUID, contribution_id: UUID) -> Contribution | None:
        stmt = select(Contributions).where(Contributions.org_id == org_id, Contributions.id == contribution_id)
        return await self._read_one(stmt, Contribution, org_id=org_id)

    async def append_contribution(self, org_id: UUID, contribution: Contribution) -> bool:
        return await self._insert(Contributions, contribution, org_id=org_id) == InsertOutcome.INSERTED
