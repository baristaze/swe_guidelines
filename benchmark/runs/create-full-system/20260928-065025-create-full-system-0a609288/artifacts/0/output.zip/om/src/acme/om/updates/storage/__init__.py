"""The updates storage. Every method runs under the desk's tenant; an update is written once and never changed."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.outbox.types import OutboxRow
from acme.om.updates.types.update import Update


class UpdatesStorageInterface(ABC):
    @abstractmethod
    async def read_updates(self, org_id: UUID, limit: int, journalist_id: UUID | None = None) -> list[Update]:
        """The desk's updates, the newest first (by id, descending), at most `limit`; one profile's when named."""
        ...

    @abstractmethod
    async def read_update(self, org_id: UUID, update_id: UUID) -> Update | None: ...

    @abstractmethod
    async def create_update(self, org_id: UUID, update: Update, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        """False when the id is already written, under any tenant; nothing changes then."""
        ...
