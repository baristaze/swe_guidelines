"""The idempotency marker table, in the core role."""

from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, CreatedMixin, FeedIdentifiableMixin


class IdempotencyMarkers(FeedIdentifiableMixin, CreatedMixin, Base):
    __tablename__ = "idempotency_markers"
    __table_args__ = (
        Index("ix_idempotency_markers_org_id_user_id_key", "org_id", "user_id", "key", unique=True),
        Index("ix_idempotency_markers_created_at", "created_at"),
    )

    user_id: Mapped[UUID]
    key: Mapped[str]
    request_digest: Mapped[str]
    target_id: Mapped[UUID]
    attempt_token: Mapped[UUID | None]
    status: Mapped[int | None]
    body: Mapped[str | None]
