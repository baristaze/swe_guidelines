"""The tenancy storage in memory: the same keys, the same refusals, the same tenant fence as the engine."""

from datetime import datetime, timedelta
from uuid import UUID

from acme.om.base import EMPTY_UUID
from acme.om.exceptions import Conflict
from acme.om.idempotency.storage import IdempotencyStorageInterface
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase, by_uuid
from acme.om.storage.root import InsertOutcome
from acme.om.tenancy import rules
from acme.om.tenancy.storage import TenancyStorageInterface
from acme.om.tenancy.types import (
    ApiKey,
    ApiKeyInsert,
    Identity,
    IdentityMembership,
    Membership,
    OperatorEntry,
    Org,
    Session,
    SessionKind,
    SignInThrottle,
    SocketTicket,
    TenancySize,
    User,
)


class TenancyStorageMemoryImpl(MemoryStorageBase, TenancyStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger, idempotency: IdempotencyStorageInterface) -> None:
        super().__init__(ledger)
        self._idempotency = idempotency  # the re-mint's guard reads the marker, as the engine's statement does
        self._orgs: dict[UUID, Org] = {}
        self._identities: dict[UUID, Identity] = {}
        self._users: dict[tuple[UUID, UUID], User] = {}
        self._memberships: dict[tuple[UUID, UUID], Membership] = {}
        self._mirrors: dict[tuple[UUID, UUID], IdentityMembership] = {}
        self._sessions: dict[UUID, Session] = {}
        self._keys: dict[UUID, tuple[UUID, ApiKey]] = {}
        self._tickets: dict[UUID, SocketTicket] = {}
        self._failures: dict[str, SignInThrottle] = {}
        self._operators: dict[UUID, OperatorEntry] = {}

    # --- orgs

    def _slug_held(self, slug: str, other_than: UUID | None = None) -> bool:
        return any(o.slug == slug and o.deleted_at is None and o.id != other_than for o in self._orgs.values())

    def _identity_key_held(self, identity: Identity) -> bool:
        for other in self._identities.values():
            if other.id == identity.id:
                continue
            if other.email_digest == identity.email_digest:
                return True
            if identity.issuer is not None and (other.issuer, other.subject) == (identity.issuer, identity.subject):
                return True
        return False

    def _member_held(self, org_id: UUID, user: User, membership: Membership) -> bool:
        if (org_id, user.id) in self._users or (org_id, membership.user_id) in self._memberships:
            return True
        if any(u.identity_id == user.identity_id for (o, _), u in self._users.items() if o == org_id):
            return True
        if any(u.id == user.id for u in self._users.values()):  # a user id is unique across tenants, as in the engine
            return True
        return any(m.id == membership.id for m in self._memberships.values())

    def _add_member(self, org_id: UUID, identity_id: UUID, user: User, membership: Membership) -> None:
        self._users[(org_id, user.id)] = user
        self._memberships[(org_id, membership.user_id)] = membership
        self._mirrors[(identity_id, org_id)] = IdentityMembership(
            id=membership.id,
            created_at=membership.created_at,
            tenant_id=org_id,
            user_id=membership.user_id,
            role=membership.role,
        )

    async def create_signup(
        self,
        org_id: UUID,
        org: Org,
        identity: Identity,
        user: User,
        membership: Membership,
        outbox_rows: tuple[OutboxRow, ...],
    ) -> InsertOutcome:
        """Named atomic: the identity, its first org, the owner's user and membership, in one transaction.
        KEY_EXISTS when the email or the slug is held; nothing is written then."""
        if identity.id in self._identities or self._identity_key_held(identity):
            return InsertOutcome.KEY_EXISTS
        if org.id in self._orgs or self._slug_held(org.slug):
            return InsertOutcome.KEY_EXISTS
        self._identities[identity.id] = identity
        self._orgs[org_id] = org
        self._add_member(org_id, identity.id, user, membership)
        self._land(org_id, outbox_rows)
        return InsertOutcome.INSERTED

    async def create_org(self, org_id: UUID, org: Org, outbox_rows: tuple[OutboxRow, ...]) -> InsertOutcome:
        if org_id in self._orgs:
            return InsertOutcome.ID_EXISTS
        if self._slug_held(org.slug):
            return InsertOutcome.KEY_EXISTS
        self._orgs[org_id] = org
        self._land(org_id, outbox_rows)
        return InsertOutcome.INSERTED

    async def read_org(self, org_id: UUID) -> Org | None:
        return self._orgs.get(org_id)

    async def write_org(self, org_id: UUID, org: Org, outbox_rows: tuple[OutboxRow, ...]) -> None:
        if org.id != org_id:
            raise ValueError("an org is written under its own id")
        if org.deleted_at is None and self._slug_held(org.slug, other_than=org_id):
            raise Conflict("the row is held under another key")
        self._orgs[org_id] = org
        self._land(org_id, outbox_rows)

    async def read_orgs(self, limit: int) -> list[Org]:
        """Tenant-less: the global list of live tenants, for the operator plane."""
        return by_uuid(o for o in self._orgs.values() if o.deleted_at is None)[:limit]

    async def read_live_org_ids(self, after: UUID | None, limit: int) -> list[UUID]:
        """Tenant-less: a page of live tenant ids after `after`, for the sweeps' service contexts."""
        live = sorted((o.id for o in self._orgs.values() if o.deleted_at is None), key=lambda i: i.int)
        return [i for i in live if after is None or i.int > after.int][:limit]

    async def read_size(self) -> TenancySize:
        """Tenant-less: the operator plane's count of live tenants and users, across tenants, in the system scope."""
        provisioned = {o.id for o in self._orgs.values() if o.provisioned_by is not None}
        return TenancySize(
            tenants=sum(1 for o in self._orgs.values() if o.deleted_at is None and o.id not in provisioned),
            users=sum(1 for (org_id, _) in self._users if org_id not in provisioned),
        )

    async def read_provisioned_org_ids(self, limit: int) -> list[UUID]:
        """Tenant-less: the live tenants an operator provisioned, which the operator plane's counts leave out."""
        return sorted(
            (o.id for o in self._orgs.values() if o.deleted_at is None and o.provisioned_by is not None),
            key=lambda i: i.int,
        )[:limit]

    # --- identities

    async def create_identity(self, identity_id: UUID, identity: Identity) -> InsertOutcome:
        if identity_id in self._identities:
            return InsertOutcome.ID_EXISTS
        if self._identity_key_held(identity):
            return InsertOutcome.KEY_EXISTS
        self._identities[identity_id] = identity
        return InsertOutcome.INSERTED

    async def read_identity(self, identity_id: UUID) -> Identity | None:
        return self._identities.get(identity_id)

    async def write_identity(self, identity_id: UUID, identity: Identity) -> None:
        if identity.id != identity_id:
            raise ValueError("an identity is written under its own id")
        if self._identity_key_held(identity):
            raise Conflict("the row is held under another key")
        self._identities[identity_id] = identity

    async def read_identity_by_email_digest(self, email_digest: str) -> Identity | None:
        """Tenant-less: the sign-in lookup, before an identity is known, in the system scope."""
        return next((i for i in self._identities.values() if i.email_digest == email_digest), None)

    async def read_identity_by_issuer_subject(self, issuer: str, subject: str) -> Identity | None:
        """Tenant-less: the external provider's find-or-create lookup, before an identity is known."""
        return next((i for i in self._identities.values() if (i.issuer, i.subject) == (issuer, subject)), None)

    async def read_identity_memberships(self, identity_id: UUID, limit: int) -> list[IdentityMembership]:
        found = [m for (i, _), m in self._mirrors.items() if i == identity_id]
        return sorted(found, key=lambda m: m.tenant_id.int)[:limit]

    # --- users and memberships

    async def create_member(
        self, org_id: UUID, identity_id: UUID, user: User, membership: Membership, outbox_rows: tuple[OutboxRow, ...]
    ) -> InsertOutcome:
        """Named atomic: the user, the membership, and the identity's copy of it; KEY_EXISTS when already a member."""
        if self._member_held(org_id, user, membership) or (identity_id, org_id) in self._mirrors:
            return InsertOutcome.KEY_EXISTS
        self._add_member(org_id, identity_id, user, membership)
        self._land(org_id, outbox_rows)
        return InsertOutcome.INSERTED

    async def read_user(self, org_id: UUID, user_id: UUID) -> User | None:
        return self._users.get((org_id, user_id))

    async def read_user_by_identity(self, org_id: UUID, identity_id: UUID) -> User | None:
        return next((u for (o, _), u in self._users.items() if o == org_id and u.identity_id == identity_id), None)

    async def read_users(self, org_id: UUID, limit: int) -> list[User]:
        return by_uuid(u for (o, _), u in self._users.items() if o == org_id)[:limit]

    async def write_user(self, org_id: UUID, user: User, outbox_rows: tuple[OutboxRow, ...]) -> None:
        if any(u.id == user.id for (o, _), u in self._users.items() if o != org_id):
            raise Conflict("the row is held under another key")
        self._users[(org_id, user.id)] = user
        self._land(org_id, outbox_rows)

    async def read_membership(self, org_id: UUID, user_id: UUID) -> Membership | None:
        return self._memberships.get((org_id, user_id))

    async def read_memberships(self, org_id: UUID, limit: int) -> list[Membership]:
        return by_uuid(m for (o, _), m in self._memberships.items() if o == org_id)[:limit]

    async def write_membership(
        self, org_id: UUID, identity_id: UUID, membership: Membership, outbox_rows: tuple[OutboxRow, ...]
    ) -> None:
        """Named atomic: the membership and the identity's copy of it together."""
        current = self._memberships.get((org_id, membership.user_id))
        if current is None or current.id != membership.id:
            return
        self._memberships[(org_id, membership.user_id)] = current.model_copy(
            update={"role": membership.role, "updated_at": membership.updated_at, "updated_by": membership.updated_by}
        )
        mirror = self._mirrors.get((identity_id, org_id))
        if mirror is not None:
            self._mirrors[(identity_id, org_id)] = mirror.model_copy(update={"role": membership.role})
        self._land(org_id, outbox_rows)

    async def remove_membership(
        self, org_id: UUID, user_id: UUID, identity_id: UUID, ended_at: datetime, outbox_rows: tuple[OutboxRow, ...]
    ) -> list[UUID]:
        """Named atomic: deletes the membership and its copy, revokes every key the member issued in the tenant,
        and ends the member's sessions there; returns the ids of the sessions it ended and the keys it revoked,
        empty when not a member."""
        if self._memberships.pop((org_id, user_id), None) is None:
            return []
        self._mirrors.pop((identity_id, org_id), None)
        revoked: list[UUID] = []
        for key_id, (key_org, key) in list(self._keys.items()):
            if key_org == org_id and key.issued_by == user_id and key.revoked_at is None:
                self._keys[key_id] = (key_org, key.model_copy(update={"revoked_at": ended_at}))
                revoked.append(key_id)
        ended: list[UUID] = []
        for session_id, s in list(self._sessions.items()):
            if (
                s.identity_id == identity_id
                and s.tenant_id == org_id
                and s.kind == SessionKind.TENANT
                and s.ended_at is None
            ):
                self._sessions[session_id] = s.model_copy(update={"ended_at": ended_at})
                ended.append(session_id)
        self._land(org_id, outbox_rows)
        return ended + revoked

    # --- sessions

    def _digest_held(self, digest: str) -> bool:
        return any(s.digest == digest for s in self._sessions.values())

    async def create_session(self, identity_id: UUID, session: Session) -> bool:
        if session.identity_id != identity_id:
            raise ValueError("a session is written under its own identity")
        if session.id in self._sessions or self._digest_held(session.digest):
            return False
        self._sessions[session.id] = session
        return True

    async def exchange_session(self, identity_id: UUID, ended_id: UUID, session: Session, ended_at: datetime) -> bool:
        """Named atomic: ends the presented session and creates its successor; False when it had already ended."""
        current = self._sessions.get(ended_id)
        if current is None or current.identity_id != identity_id or current.ended_at is not None:
            return False
        self._sessions[ended_id] = current.model_copy(update={"ended_at": ended_at})
        self._sessions[session.id] = session
        return True

    async def remint_operator_token(
        self, identity_id: UUID, session_id: UUID, digest: str, marker_id: UUID, attempt_token: UUID
    ) -> bool:
        """Named atomic: writes the new digest only while the operator's marker still holds this attempt. The
        operator plane's markers live in the system scope under the identity."""
        found = await self.read_session(identity_id, session_id)
        if found is None or found.kind != SessionKind.OPERATOR or found.ended_at is not None:
            return False
        if not await self._idempotency.holds_attempt(EMPTY_UUID, identity_id, marker_id, attempt_token):
            return False
        self._sessions[session_id] = found.model_copy(update={"digest": digest})
        return True

    async def read_session(self, identity_id: UUID, session_id: UUID) -> Session | None:
        found = self._sessions.get(session_id)
        return found if found is not None and found.identity_id == identity_id else None

    async def read_session_by_digest(self, digest: str) -> Session | None:
        """Tenant-less: the lookup of a presented session or operator token by its digest, in the system scope."""
        return next((s for s in self._sessions.values() if s.digest == digest), None)

    async def touch_session(self, identity_id: UUID, session_id: UUID, seen_at: datetime) -> bool:
        found = await self.read_session(identity_id, session_id)
        if found is None or found.ended_at is not None:
            return False
        self._sessions[session_id] = found.model_copy(update={"last_seen_at": seen_at})
        return True

    async def end_session(self, identity_id: UUID, session_id: UUID, ended_at: datetime) -> bool:
        found = await self.read_session(identity_id, session_id)
        if found is None or found.ended_at is not None:
            return False
        self._sessions[session_id] = found.model_copy(update={"ended_at": ended_at})
        return True

    async def purge_sessions(self, now: datetime, idle_before: datetime, limit: int) -> int:
        """Tenant-less: purges sessions ended, expired, or idle since before `idle_before`, across identities."""
        doomed = [
            i
            for i, s in self._sessions.items()
            if s.ended_at is not None or s.expires_at < now or s.last_seen_at < idle_before
        ][:limit]
        for session_id in doomed:
            del self._sessions[session_id]
        return len(doomed)

    # --- API keys

    async def create_api_key(self, org_id: UUID, api_key: ApiKey, outbox_rows: tuple[OutboxRow, ...]) -> ApiKeyInsert:
        """Named atomic: lands the key only while its issuer's membership is live, holding that row meanwhile."""
        if (org_id, api_key.issued_by) not in self._memberships:
            return ApiKeyInsert.NO_MEMBERSHIP
        if api_key.id in self._keys or any(k.digest == api_key.digest for _, k in self._keys.values()):
            return ApiKeyInsert.ID_EXISTS
        self._keys[api_key.id] = (org_id, api_key)
        self._land(org_id, outbox_rows)
        return ApiKeyInsert.INSERTED

    async def remint_api_key(
        self, org_id: UUID, key_id: UUID, digest: str, marker_id: UUID, attempt_token: UUID
    ) -> bool:
        """Named atomic: writes the new digest only while the idempotency marker still holds this attempt."""
        found = self._keys.get(key_id)
        if found is None or found[0] != org_id or found[1].revoked_at is not None:
            return False
        if not await self._idempotency.holds_attempt(org_id, found[1].issued_by, marker_id, attempt_token):
            return False
        self._keys[key_id] = (org_id, found[1].model_copy(update={"digest": digest}))
        return True

    async def read_api_key(self, org_id: UUID, key_id: UUID) -> ApiKey | None:
        found = self._keys.get(key_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def read_api_keys(self, org_id: UUID, limit: int) -> list[ApiKey]:
        return by_uuid(k for o, k in self._keys.values() if o == org_id)[:limit]

    async def read_api_key_by_digest(self, digest: str) -> tuple[UUID, ApiKey] | None:
        """Tenant-less: the lookup of a presented key by its digest; the tenant travels back with the key."""
        return next(((o, k) for o, k in self._keys.values() if k.digest == digest), None)

    async def revoke_api_key(
        self, org_id: UUID, key_id: UUID, revoked_at: datetime, outbox_rows: tuple[OutboxRow, ...]
    ) -> bool:
        found = self._keys.get(key_id)
        if found is None or found[0] != org_id or found[1].revoked_at is not None:
            return False
        self._keys[key_id] = (org_id, found[1].model_copy(update={"revoked_at": revoked_at}))
        self._land(org_id, outbox_rows)
        return True

    # --- socket tickets

    async def create_socket_ticket(self, identity_id: UUID, ticket: SocketTicket) -> bool:
        if ticket.identity_id != identity_id:
            raise ValueError("a ticket is written under its own identity")
        if ticket.id in self._tickets or any(t.digest == ticket.digest for t in self._tickets.values()):
            return False
        self._tickets[ticket.id] = ticket
        return True

    async def remint_socket_ticket(
        self, identity_id: UUID, ticket: SocketTicket, marker_id: UUID, attempt_token: UUID
    ) -> bool:
        """Named atomic: rewrites the unredeemed ticket only while its tenant's and user's marker holds this attempt."""
        found = self._tickets.get(ticket.id)
        if (
            found is None
            or found.identity_id != identity_id
            or (found.tenant_id, found.user_id) != (ticket.tenant_id, ticket.user_id)
            or found.redeemed_at is not None
        ):
            return False
        if not await self._idempotency.holds_attempt(ticket.tenant_id, ticket.user_id, marker_id, attempt_token):
            return False
        self._tickets[ticket.id] = found.model_copy(
            update={
                "credential_kind": ticket.credential_kind,
                "credential_id": ticket.credential_id,
                "digest": ticket.digest,
                "expires_at": ticket.expires_at,
            }
        )
        return True

    async def redeem_socket_ticket(self, digest: str, now: datetime) -> SocketTicket | None:
        """Tenant-less, named atomic: redeems an unexpired ticket once, found by its digest; exactly one caller wins."""
        found = next((t for t in self._tickets.values() if t.digest == digest), None)
        if found is None or found.redeemed_at is not None or found.expires_at <= now:
            return None
        redeemed = found.model_copy(update={"redeemed_at": now})
        self._tickets[found.id] = redeemed
        return redeemed

    async def purge_socket_tickets(self, now: datetime, limit: int) -> int:
        """Tenant-less: purges tickets redeemed or past their expiry, across identities, in the system scope."""
        doomed = [i for i, t in self._tickets.items() if t.redeemed_at is not None or t.expires_at < now][:limit]
        for ticket_id in doomed:
            del self._tickets[ticket_id]
        return len(doomed)

    # --- the sign-in delay

    async def read_sign_in_failures(self, email_digest: str) -> SignInThrottle | None:
        """Tenant-less: a system table keyed by the email's digest, read before an identity is known."""
        return self._failures.get(email_digest)

    async def record_sign_in_failure(
        self, email_digest: str, row_id: UUID, now: datetime, base_seconds: float, cap_seconds: float
    ) -> SignInThrottle:
        """Tenant-less: counts one failure and moves the retry time, in one statement."""
        current = self._failures.get(email_digest)
        failures = 1 if current is None else current.failures + 1
        delay = rules.sign_in_delay_seconds(failures, base_seconds, cap_seconds)
        recorded = SignInThrottle(failures=failures, retry_at=now + timedelta(seconds=delay))
        self._failures[email_digest] = recorded
        return recorded

    async def clear_sign_in_failures(self, email_digest: str) -> None:
        """Tenant-less: a success resets the delay."""
        self._failures.pop(email_digest, None)

    # --- the operator allowlist

    async def read_operator_entry(self, identity_id: UUID) -> OperatorEntry | None:
        """Tenant-less: the allowlist is a system table of the operator plane."""
        return self._operators.get(identity_id)

    async def write_operator_entry(self, entry: OperatorEntry) -> None:
        """Tenant-less: the allowlist is a system table of the operator plane."""
        current = self._operators.get(entry.identity_id)
        if current is not None and current.id != entry.id:
            raise Conflict("the row is held under another key")
        self._operators[entry.identity_id] = entry
