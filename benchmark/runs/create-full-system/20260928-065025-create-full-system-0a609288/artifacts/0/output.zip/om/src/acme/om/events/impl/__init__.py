"""The implementations of the events interfaces."""
