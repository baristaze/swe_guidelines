"""The work items and work receipts tables, in the queue role."""
