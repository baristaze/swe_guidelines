-- The updates a desk publishes, org scope (the desk's tenant).

-- updates: org scope
CREATE TABLE core.updates (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    journalist_id UUID NOT NULL,
    body VARCHAR NOT NULL,
    CONSTRAINT pk_updates PRIMARY KEY (id)
);
CREATE INDEX ix_updates_org_id_id ON core.updates (org_id, id);
CREATE INDEX ix_updates_org_id_journalist_id_id ON core.updates (org_id, journalist_id, id);
CREATE POLICY tenant_fence ON core.updates
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.updates FORCE ROW LEVEL SECURITY;
