"""The messages of each submission's thread, in the core role, fenced by the desk's tenant."""

from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, CreatedMixin, FeedIdentifiableMixin


class Messages(FeedIdentifiableMixin, CreatedMixin, Base):
    __tablename__ = "messages"
    __table_args__ = (Index("ix_messages_org_id_submission_id_id", "org_id", "submission_id", "id"),)

    submission_id: Mapped[UUID]
    direction: Mapped[str]
    sealed_body: Mapped[str]
    author_user_id: Mapped[UUID | None]
