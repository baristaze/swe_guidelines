"""The journalist profile gains the bio, the public key, the published flag, and the payout account."""

from acme.om.storage.migrate import run_sql

revision = "202609281700"
down_revision = "202609281630"


def upgrade() -> None:
    run_sql("core", "202609281700_journalist_public_profile.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281700_journalist_public_profile.down.sql")
