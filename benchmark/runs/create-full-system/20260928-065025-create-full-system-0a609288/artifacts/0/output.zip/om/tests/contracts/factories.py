"""Entity builders the contract cases share. Every case mints fresh ids, emails, and slugs, so cases never collide."""

from datetime import timedelta
from uuid import UUID

from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.opcontext import AppContext, AppType, CredentialKind, OperatorPermission, Role
from acme.om.outbox.types import OutboxRow
from acme.om.storage.root import StorageInterface
from acme.om.tenancy.impl.credentials import email_digest
from acme.om.tenancy.types import (
    ApiKey,
    Identity,
    Membership,
    OperatorEntry,
    Org,
    Session,
    SessionKind,
    SocketTicket,
    User,
)

APP = AppContext(type=AppType.API, version="api@test")


def unique(prefix: str) -> str:
    return f"{prefix}-{new_id().hex[-12:]}"


def org(org_id: UUID | None = None, slug: str | None = None) -> Org:
    now = utcnow()
    oid = org_id or new_id()
    return Org(
        id=oid,
        name="Desk",
        slug=slug or unique("desk"),
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
    )


def identity(email: str | None = None) -> Identity:
    now = utcnow()
    iid = new_id()
    address = email or f"{unique('person')}@acme.example"
    return Identity(
        id=iid,
        created_at=now,
        updated_at=now,
        created_by=iid,
        updated_by=iid,
        email=address,
        email_digest=email_digest(address),
        display_name="Person",
    )


def member(identity_id: UUID, role: Role = Role.OWNER) -> tuple[User, Membership]:
    now = utcnow()
    user = User(
        id=new_id(),
        name="Person",
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
        identity_id=identity_id,
    )
    membership = Membership(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
        user_id=user.id,
        role=role,
    )
    return user, membership


def row(org_id: UUID, kind: str = "tenancy.user.updated", target_id: UUID | None = None) -> OutboxRow:
    return OutboxRow(
        id=new_id(),
        created_at=utcnow(),
        org_id=org_id,
        kind=kind,
        target_id=target_id or new_id(),
        actor_id=EMPTY_UUID,
        request_id=new_id(),
        app=APP,
    )


def session(identity_id: UUID, kind: SessionKind = SessionKind.LOGIN, tenant_id: UUID = EMPTY_UUID) -> Session:
    now = utcnow()
    return Session(
        id=new_id(),
        created_at=now,
        identity_id=identity_id,
        kind=kind,
        tenant_id=tenant_id,
        digest=unique("digest"),
        last_seen_at=now,
        expires_at=now + timedelta(hours=1),
        permission=OperatorPermission.READ if kind == SessionKind.OPERATOR else None,
    )


def api_key(issued_by: UUID, role: Role = Role.MEMBER) -> ApiKey:
    now = utcnow()
    return ApiKey(
        id=new_id(),
        name="key",
        created_at=now,
        issued_by=issued_by,
        digest=unique("key"),
        role=role,
        expires_at=now + timedelta(days=1),
    )


def ticket(identity_id: UUID, tenant_id: UUID, user_id: UUID, ttl: timedelta = timedelta(seconds=30)) -> SocketTicket:
    now = utcnow()
    return SocketTicket(
        id=new_id(),
        created_at=now,
        identity_id=identity_id,
        tenant_id=tenant_id,
        user_id=user_id,
        credential_kind=CredentialKind.TENANT_SESSION,
        credential_id=new_id(),
        digest=unique("ticket"),
        expires_at=now + ttl,
    )


def operator_entry(identity_id: UUID, permission: OperatorPermission = OperatorPermission.READ) -> OperatorEntry:
    now = utcnow()
    return OperatorEntry(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
        identity_id=identity_id,
        permission=permission,
    )


class Tenant:
    """One signed-up tenant: its org, its owner's identity, user, and membership."""

    def __init__(self, org: Org, identity: Identity, user: User, membership: Membership) -> None:
        self.org = org
        self.identity = identity
        self.user = user
        self.membership = membership

    @property
    def org_id(self) -> UUID:
        return self.org.id


async def tenant(storage: StorageInterface) -> Tenant:
    o = org()
    i = identity()
    u, m = member(i.id)
    outcome = await storage.get_tenancy_storage().create_signup(o.id, o, i, u, m, ())
    assert outcome.value == "inserted"
    return Tenant(o, i, u, m)
