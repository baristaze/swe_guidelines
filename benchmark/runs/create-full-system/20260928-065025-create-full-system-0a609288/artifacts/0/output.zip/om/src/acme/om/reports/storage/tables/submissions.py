"""Each recipient desk's submissions, in the core role, fenced by the desk's tenant."""

from uuid import UUID

from sqlalchemy import ARRAY, Index, String
from sqlalchemy.orm import Mapped, mapped_column

from acme.om.storage.tables.base import Base, FeedIdentifiableMixin, TrackableMixin


class Submissions(FeedIdentifiableMixin, TrackableMixin, Base):
    __tablename__ = "submissions"
    __table_args__ = (Index("ix_submissions_org_id_id", "org_id", "id"),)

    report_id: Mapped[UUID]
    journalist_id: Mapped[UUID]
    wrapped_key: Mapped[str]
    source_public_key: Mapped[str]
    reply_digest: Mapped[str]
    sender_user_id: Mapped[UUID | None]
    sender_org_id: Mapped[UUID | None]
    sender_name: Mapped[str | None]
    contact_email: Mapped[str | None]
    state: Mapped[str]
    tags: Mapped[list[str]] = mapped_column(ARRAY(String))
