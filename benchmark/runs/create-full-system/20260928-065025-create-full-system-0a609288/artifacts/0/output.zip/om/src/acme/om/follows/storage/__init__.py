"""The follows storage. Every method runs under the reader's account (the tenant); a soft-deleted follow is still read
by id, and never listed."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.follows.types.follow import Follow
from acme.om.outbox.types import OutboxRow
from acme.om.storage.root import InsertOutcome


class FollowsStorageInterface(ABC):
    @abstractmethod
    async def read_follows(self, org_id: UUID, limit: int) -> list[Follow]:
        """The account's living follows, ordered by id, at most `limit`."""
        ...

    @abstractmethod
    async def read_follow(self, org_id: UUID, follow_id: UUID) -> Follow | None:
        """One follow of the account, a soft-deleted one included."""
        ...

    @abstractmethod
    async def read_follow_by_journalist(self, org_id: UUID, journalist_id: UUID) -> Follow | None:
        """The account's living follow of one journalist, the table's unique key."""
        ...

    @abstractmethod
    async def create_follow(self, org_id: UUID, follow: Follow, outbox_rows: tuple[OutboxRow, ...]) -> InsertOutcome:
        """ID_EXISTS when the id is already written, under any tenant; KEY_EXISTS when the account already follows the
        journalist; nothing changes then."""
        ...

    @abstractmethod
    async def write_follow(self, org_id: UUID, follow: Follow, outbox_rows: tuple[OutboxRow, ...]) -> None:
        """Writes the follow onto its row under the tenant; an id another tenant holds is a Conflict."""
        ...
