"""The migration runner: one Alembic chain and one version table per role, run as the migration login.

acme-migrate upgrade --all | --role <role>
acme-migrate check                 # ORM metadata against the migrated schema, per role
acme-migrate roundtrip             # downgrade the latest revision of every role, then upgrade it
acme-migrate ensure-logins         # the cloud migration task's first step; the one reader of the master URL
"""

import argparse
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urlparse

import psycopg
from alembic import command, op
from alembic.autogenerate import compare_metadata
from alembic.config import Config
from alembic.migration import MigrationContext
from psycopg import sql
from sqlalchemy import create_engine

from acme.om.storage.roles import DatabaseRole
from acme.om.storage.settings import StorageSettings

LOGINS = ("acme_migration", "acme_runtime", "acme_system")
ROLE_REFERENCE = re.compile(r"\b(" + "|".join(r.value for r in DatabaseRole) + r")\.([a-z_][a-z0-9_]*)", re.IGNORECASE)


def migrations_dir(settings: StorageSettings) -> Path:
    configured = settings.database_migrations_dir
    return Path(configured) if configured else Path(__file__).resolve().parents[4] / "migrations"


def sync_url(url: str) -> str:
    return url.replace("postgresql://", "postgresql+psycopg://", 1) if url.startswith("postgresql://") else url


def check_sql_role(role: str, text: str, name: str) -> None:
    """The runner refuses a file that names a table of another role."""
    for match in ROLE_REFERENCE.finditer(text):
        if match.group(1).lower() != role:
            raise SystemExit(f"{name} names {match.group(0)}, a table of another role than {role}")


def run_sql(role: str, file: str) -> None:
    """Runs one SQL file as one transaction, never split on `;`: a DO block holds semicolons of its own."""
    config = op.get_context().config
    if config is None:
        raise SystemExit("run_sql runs inside a migration")
    root = Path(config.get_main_option("script_location") or ".")
    path = root / "sql" / role / file
    text = path.read_text()
    check_sql_role(role, text, path.name)
    raw = op.get_bind().connection.driver_connection  # psycopg: no parameters, so the file runs whole
    if raw is None:
        raise SystemExit("the migration connection is closed")
    raw.execute(text)


def alembic_config(settings: StorageSettings, role: DatabaseRole) -> Config:
    directory = migrations_dir(settings)
    cfg = Config()
    cfg.set_main_option("script_location", str(directory))
    cfg.set_main_option("version_locations", str(directory / "versions" / role.value))
    cfg.set_main_option("sqlalchemy.url", sync_url(settings.database_migration_url).replace("%", "%%"))
    cfg.attributes["role"] = role.value
    return cfg


def roles_from(args: argparse.Namespace) -> list[DatabaseRole]:
    if args.all or not args.role:
        return [r for r in DatabaseRole if _has_chain(StorageSettings(), r)]
    return [DatabaseRole(args.role)]


def _has_chain(settings: StorageSettings, role: DatabaseRole) -> bool:
    folder = migrations_dir(settings) / "versions" / role.value
    return folder.is_dir() and any(folder.glob("*.py"))


def upgrade(roles: list[DatabaseRole]) -> None:
    settings = StorageSettings()
    for role in roles:
        command.upgrade(alembic_config(settings, role), "head")


def roundtrip(roles: list[DatabaseRole]) -> None:
    settings = StorageSettings()
    for role in roles:
        cfg = alembic_config(settings, role)
        command.downgrade(cfg, "-1")
        command.upgrade(cfg, "head")


def schema_diff(role: DatabaseRole) -> list[object]:
    """What differs between the ORM metadata of one role and its migrated schema."""
    from acme.om.storage.tables.base import Base
    from acme.om.storage.tables.registry import import_all_tables

    import_all_tables()
    settings = StorageSettings()
    engine = create_engine(sync_url(settings.database_migration_url))

    def include_name(name: str | None, kind: str, parent: dict[str, str | None]) -> bool:
        if kind == "schema":
            return name == role.value
        if kind == "table":
            return name != "alembic_version" and parent.get("schema_name") == role.value
        return True

    def include_object(obj: object, name: str | None, kind: str, reflected: bool, other: object) -> bool:
        return not (kind == "table" and getattr(obj, "schema", None) != role.value)

    try:
        with engine.connect() as conn:
            ctx = MigrationContext.configure(
                conn,
                opts={
                    "include_schemas": True,
                    "include_name": include_name,
                    "include_object": include_object,
                    "compare_type": True,
                },
            )
            return list(compare_metadata(ctx, Base.metadata))
    finally:
        engine.dispose()


def check(roles: list[DatabaseRole]) -> int:
    failed = 0
    for role in roles:
        diff = schema_diff(role)
        for entry in diff:
            print(f"{role.value}: {entry}")
        failed += len(diff)
        print(f"{role.value}: {'in step' if not diff else f'{len(diff)} difference(s)'}")
    return 1 if failed else 0


def ensure_logins() -> None:
    """Creates each of the three logins by its fixed name when absent, sets its password from its URL,
    and grants the migration login CREATE on the database. None is a superuser or carries BYPASSRLS."""
    settings = StorageSettings()
    if not settings.database_master_url:
        raise SystemExit("ACME_DATABASE_MASTER_URL is not set")
    urls = {
        "acme_migration": settings.database_migration_url,
        "acme_runtime": settings.database_url,
        "acme_system": settings.database_system_url,
    }
    with psycopg.connect(settings.database_master_url, autocommit=True) as conn:
        database = conn.execute("SELECT current_database()").fetchone()
        for login in LOGINS:
            parsed = urlparse(urls[login])
            if parsed.username != login:
                raise SystemExit(f"the URL for {login} names another login")
            password = unquote(parsed.password or "")
            exists = conn.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (login,)).fetchone()
            verb = "ALTER" if exists else "CREATE"
            conn.execute(
                sql.SQL("{} ROLE {} LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD {}").format(
                    sql.SQL(verb), sql.Identifier(login), sql.Literal(password)
                )
            )
        if database is not None:
            conn.execute(
                sql.SQL("GRANT CREATE ON DATABASE {} TO acme_migration").format(sql.Identifier(str(database[0])))
            )
    print("logins ensured: " + ", ".join(LOGINS))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="acme-migrate")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("upgrade", "check", "roundtrip"):
        p = sub.add_parser(name)
        p.add_argument("--role", choices=[r.value for r in DatabaseRole])
        p.add_argument("--all", action="store_true")
    sub.add_parser("ensure-logins")
    args = parser.parse_args(argv)
    if args.command == "upgrade":
        upgrade(roles_from(args))
        return 0
    if args.command == "roundtrip":
        roundtrip(roles_from(args))
        return 0
    if args.command == "check":
        return check(roles_from(args))
    ensure_logins()
    return 0


if __name__ == "__main__":
    sys.exit(main())
