-- Reverses 202609281200_activity_initial.up.sql.

DROP POLICY IF EXISTS tenant_fence ON activity.events;
DROP TABLE IF EXISTS activity.events;
DROP POLICY IF EXISTS tenant_fence ON activity.event_cursors;
DROP TABLE IF EXISTS activity.event_cursors;
DROP POLICY IF EXISTS tenant_fence ON activity.audit_entries;
DROP TABLE IF EXISTS activity.audit_entries;
DROP POLICY IF EXISTS tenant_fence ON activity.audit_cursors;
DROP TABLE IF EXISTS activity.audit_cursors;
ALTER DEFAULT PRIVILEGES IN SCHEMA activity REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM acme_runtime, acme_system;
REVOKE USAGE ON SCHEMA activity FROM acme_runtime, acme_system;
