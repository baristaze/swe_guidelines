-- Reverses 202609281741_submissions.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.submissions;
DROP TABLE IF EXISTS core.submissions;
