"""The ORM base and the table mixins. Rows are mutable by design and never leave a storage impl."""

from datetime import datetime
from typing import Any, ClassVar
from uuid import UUID

from sqlalchemy import DateTime, MetaData
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from acme.om.storage.roles import TABLE_ROLES

NAMING = {
    "ix": "ix_%(table_name)s_%(column_0_N_name)s",
    "uq": "uq_%(table_name)s_%(column_0_N_name)s",
    "pk": "pk_%(table_name)s",
}


class Base(DeclarativeBase):
    # Every datetime column is a timestamp with a time zone: a bare Mapped[datetime] would map to one without.
    type_annotation_map: ClassVar[dict[Any, Any]] = {datetime: DateTime(timezone=True)}
    metadata = MetaData(naming_convention=NAMING)

    def __init_subclass__(cls, **kwargs: Any) -> None:
        # The schema is the table's role, derived from the role map; no table declares its own.
        tablename = cls.__dict__.get("__tablename__")
        if tablename is not None:
            declared = cls.__dict__.get("__table_args__", ())
            cls.__table_args__ = (*declared, {"schema": TABLE_ROLES[tablename].value})
        super().__init_subclass__(**kwargs)


class IdentifiableMixin:
    id: Mapped[UUID] = mapped_column(primary_key=True, sort_order=-1000)
    org_id: Mapped[UUID] = mapped_column(index=True, sort_order=-999)  # storage-only


class FeedIdentifiableMixin:  # a feed table: (org_id, id) is declared compound, so no single index
    id: Mapped[UUID] = mapped_column(primary_key=True, sort_order=-1000)
    org_id: Mapped[UUID] = mapped_column(sort_order=-999)


class IdentityScopedMixin:  # an identity-scoped table: no org_id
    id: Mapped[UUID] = mapped_column(primary_key=True, sort_order=-1000)
    identity_id: Mapped[UUID] = mapped_column(index=True, sort_order=-999)


class GlobalIdentifiableMixin:
    id: Mapped[UUID] = mapped_column(primary_key=True, sort_order=-1000)


class NamedMixin:
    name: Mapped[str] = mapped_column(sort_order=-900)


class CreatedMixin:
    created_at: Mapped[datetime] = mapped_column(sort_order=-800)


class TrackableMixin(CreatedMixin):
    updated_at: Mapped[datetime] = mapped_column(sort_order=-799)
    created_by: Mapped[UUID] = mapped_column(sort_order=-798)
    updated_by: Mapped[UUID] = mapped_column(sort_order=-797)


class SoftDeletableMixin:
    deleted_at: Mapped[datetime | None] = mapped_column(sort_order=-700)
    deleted_by: Mapped[UUID | None] = mapped_column(sort_order=-699)
