# Idempotency

**Nouns.** A **marker** remembers a request that creates something, under the key the caller sent with it.

**What can happen.** When an app sends the same creating request again (because it never saw the answer), the
marker answers with the first answer instead of creating a second thing. If the first attempt failed or stalled, the
retry runs it again on the same identity, so it finishes the one thing rather than starting another.

**Rules that hold.**

- The same key with a different request is refused.
- Only answers a retry cannot change are remembered; a failure or a "slow down" lets the retry run again.
- Markers are cleared after a day.
