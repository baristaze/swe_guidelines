"""A submission: one recipient desk's copy of a report, holding that desk's wrapped key and its working state."""

from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from acme.om.base import Identifiable, Trackable


class SubmissionState(StrEnum):
    NEW = "new"
    REVIEWING = "reviewing"
    FOLLOW_UP = "follow-up"
    USEFUL = "useful"
    ARCHIVED = "archived"


class Submission(Identifiable, Trackable):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = (
        "report_id",
        "journalist_id",
        "wrapped_key",
        "source_public_key",
        "reply_digest",
        "sender_user_id",
        "sender_org_id",
        "sender_name",
        "contact_email",
    )

    report_id: UUID  # the sealed report, stored once for every recipient
    journalist_id: UUID  # the recipient profile, whose public key wrapped the report's key
    wrapped_key: str  # the report's key wrapped for this recipient alone
    source_public_key: str  # the source's own key, a reply is sealed to
    reply_digest: str  # SHA-256 of the reply secret the source's device keeps; never the secret
    sender_user_id: UUID | None = None  # set only when a signed-in reader chose to send under their name
    sender_org_id: UUID | None = None
    sender_name: str | None = None  # a personal field, seen by the recipient desks alone, never on an event
    contact_email: str | None = None  # an optional contact method for reply notices, apart from any identity
    state: SubmissionState = SubmissionState.NEW  # the desk's own working state
    tags: tuple[str, ...] = ()  # the desk's own tags, added after it read the report
