"""A contribution: one payment a desk received from a supporter, recorded once and never changed."""

from datetime import datetime
from typing import ClassVar
from uuid import UUID

from acme.om.base import Identifiable
from acme.om.support.types.pledge import SupportMode


class Contribution(Identifiable):
    """Append-only, in the desk's tenant; its id derives from the payment delivery, so a redelivery adds nothing."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    journalist_id: UUID
    pledge_id: UUID  # the supporter's pledge, in the supporter's own account
    supporter_org_id: UUID  # the supporter's account
    supporter_name: str  # a personal field, never on an event
    amount_minor: int
    currency: str
    mode: SupportMode
    platform_fee_minor: int
    received_at: datetime
