"""The core role's first migration: its schema, the two logins' grants, the tenancy tables."""

from acme.om.storage.migrate import run_sql

revision = "202609281200"
down_revision = None


def upgrade() -> None:
    run_sql("core", "202609281200_core_initial.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281200_core_initial.down.sql")
