"""The root of every exception raised inside the platform, and the shapes a namespace family inherits."""


class PlatformException(Exception):
    """Root of every exception raised inside the platform."""

    http_status: int = 500
    code: str = "platform_error"


class NotFound(PlatformException):
    http_status = 404
    code = "not_found"


class Conflict(PlatformException):
    http_status = 409
    code = "conflict"


class PreconditionFailed(PlatformException):  # the caller's expected version no longer matches
    http_status = 412
    code = "precondition_failed"


class ValidationFailed(PlatformException):
    http_status = 422
    code = "validation_failed"


class NotAuthenticated(PlatformException):
    http_status = 401
    code = "not_authenticated"


class NotAuthorized(PlatformException):
    http_status = 403
    code = "not_authorized"


class SecondFactorRequired(NotAuthenticated):
    """An enrolled operator's sign-in carried no verified second factor."""

    code = "second_factor_required"


class SecondFactorNotEnrolled(NotAuthorized):
    """An operator with no confirmed second factor reaches only the two enrolment operations."""

    code = "second_factor_not_enrolled"


class TooManyRequests(PlatformException):
    """A refusal a retry can change by waiting; `retry_after` says how long, in seconds."""

    http_status = 429
    code = "rate_limited"

    def __init__(self, message: str, retry_after: int = 1) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class Unavailable(PlatformException):
    """A dependency that cannot be reached right now: an open breaker, a refused admission, a backend down."""

    http_status = 503
    code = "unavailable"
