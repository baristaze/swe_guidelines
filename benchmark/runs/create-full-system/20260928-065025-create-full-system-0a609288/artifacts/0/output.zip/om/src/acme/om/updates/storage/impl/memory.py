"""The updates storage in memory: the same filters, order, and tenancy rule as the engine."""

from uuid import UUID

from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase, by_uuid
from acme.om.updates.storage import UpdatesStorageInterface
from acme.om.updates.types.update import Update


class UpdatesStorageMemoryImpl(MemoryStorageBase, UpdatesStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._rows: dict[UUID, tuple[UUID, Update]] = {}

    async def read_updates(self, org_id: UUID, limit: int, journalist_id: UUID | None = None) -> list[Update]:
        found = [
            u
            for o, u in self._rows.values()
            if o == org_id and (journalist_id is None or u.journalist_id == journalist_id)
        ]
        return list(reversed(by_uuid(found)))[:limit]

    async def read_update(self, org_id: UUID, update_id: UUID) -> Update | None:
        found = self._rows.get(update_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def create_update(self, org_id: UUID, update: Update, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        if update.id in self._rows:
            return False
        self._land(org_id, outbox_rows)
        self._rows[update.id] = (org_id, update)
        return True
