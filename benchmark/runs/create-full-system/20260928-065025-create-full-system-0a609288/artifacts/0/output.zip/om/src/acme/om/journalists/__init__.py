"""The journalists swimlane: the journalist profiles a desk presents to its readers."""

from acme.om.journalists.manager import JournalistsManagerInterface

__all__ = ["JournalistsManagerInterface"]
