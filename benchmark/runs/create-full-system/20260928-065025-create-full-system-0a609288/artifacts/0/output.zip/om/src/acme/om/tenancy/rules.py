"""The tenancy rules: the role-to-permission table, the role cap, the operator table, and TOTP arithmetic.

Plain functions over values: no storage, no clock, no settings.
"""

import hashlib
import hmac
import struct

from acme.om.opcontext import OperatorPermission, Permission, Role

ROLE_PERMISSIONS: dict[Role, frozenset[Permission]] = {
    Role.OWNER: frozenset(Permission),
    Role.ADMIN: frozenset(
        {Permission.READ, Permission.WRITE, Permission.MANAGE_MEMBERS, Permission.MANAGE_KEYS, Permission.READ_AUDIT}
    ),
    Role.MEMBER: frozenset({Permission.READ, Permission.WRITE}),
    Role.VIEWER: frozenset({Permission.READ}),
    Role.SERVICE: frozenset({Permission.READ, Permission.WRITE}),
}

PERSON_ROLES: tuple[Role, ...] = (Role.OWNER, Role.ADMIN, Role.MEMBER, Role.VIEWER)  # highest first

OPERATOR_PERMISSIONS: dict[OperatorPermission, tuple[OperatorPermission, ...]] = {
    OperatorPermission.READ: (OperatorPermission.READ,),
    OperatorPermission.WRITE: (OperatorPermission.READ, OperatorPermission.WRITE),  # write implies read
    OperatorPermission.ENROL: (OperatorPermission.ENROL,),
}

TOTP_STEP_SECONDS = 30
TOTP_DIGITS = 6


def permissions_of(role: Role) -> tuple[Permission, ...]:
    return tuple(sorted(ROLE_PERMISSIONS[role]))


def role_at_most(role: Role, cap: Role) -> bool:
    """A role is at most another when its permissions are a subset of the other's."""
    return ROLE_PERMISSIONS[role] <= ROLE_PERMISSIONS[cap]


def lower_role(a: Role, b: Role) -> Role:
    """The lower of two person roles: the later one in the order owner > admin > member > viewer."""
    return a if PERSON_ROLES.index(a) >= PERSON_ROLES.index(b) else b


def operator_permission_at_most(wanted: OperatorPermission, granted: OperatorPermission) -> bool:
    return wanted in OPERATOR_PERMISSIONS[granted]


def sign_in_delay_seconds(failures: int, base: float, cap: float) -> float:
    """Each failure doubles the delay before the next attempt is checked, from a base to a cap."""
    if failures <= 0:
        return 0.0
    return min(cap, base * (2 ** (failures - 1)))


def totp_step(unix_seconds: float) -> int:
    return int(unix_seconds // TOTP_STEP_SECONDS)


def totp_code(secret: bytes, step: int) -> str:
    """RFC 6238 over HMAC-SHA1, six digits."""
    digest = hmac.new(secret, struct.pack(">Q", step), hashlib.sha1).digest()
    offset = digest[-1] & 0x0F
    value = struct.unpack(">I", digest[offset : offset + 4])[0] & 0x7FFFFFFF
    return str(value % (10**TOTP_DIGITS)).zfill(TOTP_DIGITS)


def totp_match(secret: bytes, code: str, current_step: int, last_step: int | None) -> int | None:
    """The step a code matches within one step of drift, refusing a step already used; None when it fails."""
    for step in (current_step - 1, current_step, current_step + 1):
        if last_step is not None and step <= last_step:
            continue
        if hmac.compare_digest(totp_code(secret, step), code.strip()):
            return step
    return None
