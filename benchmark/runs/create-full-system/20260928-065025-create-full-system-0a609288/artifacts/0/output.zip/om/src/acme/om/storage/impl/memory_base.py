"""The memory base every namespace's memory storage shares: the outbox ledger its writes land rows in.

A memory impl is a full second implementation: the same filters, the same tenancy rule, the same
refusals as the engine. Its critical sections hold no await, so each method is atomic on the loop.
"""

from collections.abc import Iterable, Sequence
from typing import Any
from uuid import UUID

from acme.om.outbox.types import OutboxRow


class MemoryOutboxLedger:
    """The outbox rows of every tenant, keyed by id; the outbox's memory storage reads what writes land here."""

    def __init__(self) -> None:
        self.rows: dict[UUID, OutboxRow] = {}


class MemoryStorageBase:
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        self._ledger = ledger

    def _land(self, org_id: UUID, outbox_rows: Sequence[OutboxRow]) -> None:
        for row in outbox_rows:
            if row.org_id != org_id:
                raise ValueError("an outbox row lands under the tenant of the write it announces")
            self._ledger.rows.setdefault(row.id, row)


def by_uuid(items: Iterable[Any]) -> list[Any]:
    """Sort by the UUID value, never by its string, as the engine does."""
    return sorted(items, key=lambda item: item.id.int)
