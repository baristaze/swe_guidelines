"""The reports manager impl: authorize, verify, copy, write with the outbox rows, relay at once."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.audit.manager import AuditManagerInterface
from acme.om.base import EMPTY_UUID, PROVENANCE_FIELDS, utcnow
from acme.om.exceptions import Conflict, NotFound, ValidationFailed
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.opcontext import OpContext, Permission, RequestContext
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, outbox_row, platform_outbox_row
from acme.om.reports import rules
from acme.om.reports.manager import ReportsManagerInterface
from acme.om.reports.storage import ReportsStorageInterface
from acme.om.reports.types.message import Message, MessageDirection
from acme.om.reports.types.read_models import OpenedSubmission, Recipient, SourceThread
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission, SubmissionState
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.om.work.types.work_item import SEND_NOTIFICATION_ROW, NotificationTopic


@dataclass(frozen=True)
class ReportsOptions:
    page_size: int  # the most one list answers


@dataclass(frozen=True)
class _Sender:
    user_id: UUID
    org_id: UUID
    name: str


def _notice(rctx: RequestContext, org_id: UUID, target_id: UUID, topic: NotificationTopic) -> OutboxRow:
    return platform_outbox_row(rctx, org_id, SEND_NOTIFICATION_ROW, target_id, {"topic": topic.value})


class ReportsManagerImpl(ReportsManagerInterface):
    def __init__(
        self,
        storage: ReportsStorageInterface,
        relay: OutboxRelayInterface,
        journalists: JournalistsManagerInterface,
        tenancy: TenancyManagerInterface,
        audit: AuditManagerInterface,
        options: ReportsOptions,
    ) -> None:
        self._storage = storage
        self._relay = relay
        self._journalists = journalists
        self._tenancy = tenancy
        self._audit = audit
        self._options = options

    # --- the desk's inbox

    async def get_submissions(
        self, ctx: OpContext, limit: int, state: SubmissionState | None = None, tag: str | None = None
    ) -> list[Submission]:
        ctx.require(Permission.READ)
        return await self._storage.read_submissions(ctx.org_id, self._clamp(limit), state, tag)

    async def get_submission(self, ctx: OpContext, submission_id: UUID) -> Submission:
        ctx.require(Permission.READ)
        found = await self._storage.read_submission(ctx.org_id, submission_id)
        if found is None:
            raise NotFound("no such submission")
        return found

    async def open_submission(self, ctx: OpContext, submission_id: UUID) -> OpenedSubmission:
        submission = await self.get_submission(ctx, submission_id)
        report = await self._storage.read_sealed_report(submission.report_id)
        if report is None:
            raise NotFound("no such submission")
        await self._audit.record(ctx, "reports.submission.opened", submission.id, {})
        return OpenedSubmission(submission=submission, report=report)

    async def update_submission(self, ctx: OpContext, submission: Submission) -> Submission:
        ctx.require(Permission.WRITE)
        current = await self.get_submission(ctx, submission.id)
        copy = Submission.model_validate(
            {
                **current.model_dump(),
                **submission.model_dump(exclude=set(PROVENANCE_FIELDS) | set(Submission.MANAGER_OWNED_FIELDS)),
                "updated_at": utcnow(),
                "updated_by": ctx.user_id,
            }
        )
        copy = copy.model_copy(update={"tags": rules.normalized_tags(copy.tags)})
        rows = (outbox_row(ctx, "reports.submission.updated", copy.id, {}),)
        await self._storage.write_submission(ctx.org_id, copy, rows)
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def get_messages(self, ctx: OpContext, submission_id: UUID, limit: int) -> list[Message]:
        await self.get_submission(ctx, submission_id)
        return await self._storage.read_messages(ctx.org_id, submission_id, self._clamp(limit))

    async def create_message(self, ctx: OpContext, message: Message) -> Message:
        ctx.require(Permission.WRITE)
        if message.direction == MessageDirection.FROM_SOURCE:
            raise ValidationFailed("a desk writes a reply to the source or a note")
        submission = await self.get_submission(ctx, message.submission_id)
        copy = message.model_copy(update={"author_user_id": ctx.user_id})
        rows: tuple[OutboxRow, ...] = (outbox_row(ctx, "reports.message.created", copy.id, {}),)
        if copy.direction == MessageDirection.TO_SOURCE and submission.contact_email is not None:
            notice = {"topic": NotificationTopic.DESK_REPLIED.value}
            rows = (*rows, outbox_row(ctx, SEND_NOTIFICATION_ROW, submission.id, notice))
        return await self._create_message(ctx.org_id, copy, rows)

    # --- the intake

    async def submit_named_report(
        self,
        ctx: OpContext,
        report: SealedReport,
        recipients: tuple[Recipient, ...],
        reply_secret: str,
    ) -> list[Submission]:
        ctx.require(Permission.WRITE)
        user = await self._tenancy.get_user(ctx, ctx.user_id)
        return await self._submit(ctx, report, recipients, reply_secret, _Sender(ctx.user_id, ctx.org_id, user.name))

    async def submit_report(
        self,
        rctx: RequestContext,
        report: SealedReport,
        recipients: tuple[Recipient, ...],
        reply_secret: str,
    ) -> list[Submission]:
        return await self._submit(rctx, report, recipients, reply_secret, None)

    async def _submit(
        self,
        rctx: RequestContext,
        report: SealedReport,
        recipients: tuple[Recipient, ...],
        reply_secret: str,
        sender: _Sender | None,
    ) -> list[Submission]:
        if not 1 <= len(recipients) <= rules.MAX_RECIPIENTS:
            raise ValidationFailed(f"a report goes to between 1 and {rules.MAX_RECIPIENTS} journalists")
        if len({r.submission.id for r in recipients}) != len(recipients):
            raise ValidationFailed("each recipient takes its own submission id")
        for r in recipients:  # every recipient is a published profile that can be written to, before anything lands
            journalist = await self._journalists.get_published_journalist(rctx, r.desk_id, r.submission.journalist_id)
            if journalist.public_key is None:
                raise ValidationFailed("a recipient has no public key yet")
        if not await self._storage.create_sealed_report(report):
            stored = await self._storage.read_sealed_report(report.id)
            if stored is None or stored.ciphertext != report.ciphertext:
                raise Conflict("that report id is taken")
        digest = rules.reply_digest(reply_secret)
        landed: list[Submission] = []
        for r in recipients:
            copy = r.submission.model_copy(
                update={
                    "report_id": report.id,
                    "created_by": EMPTY_UUID,  # the platform wrote it through the intake; the source is nobody it knows
                    "updated_by": EMPTY_UUID,
                    "reply_digest": digest,
                    "sender_user_id": sender.user_id if sender else None,
                    "sender_org_id": sender.org_id if sender else None,
                    "sender_name": sender.name if sender else None,
                    "state": SubmissionState.NEW,
                    "tags": (),
                }
            )
            rows = (
                platform_outbox_row(rctx, r.desk_id, "reports.submission.created", copy.id, {}),
                _notice(rctx, r.desk_id, copy.id, NotificationTopic.SUBMISSION_RECEIVED),
            )
            if await self._storage.create_submission(r.desk_id, copy, rows):
                await self._relay_all(r.desk_id, rows)
                landed.append(copy)
                continue
            stored = await self._storage.read_submission(r.desk_id, copy.id)
            if stored is None or stored.report_id != report.id:
                raise Conflict("that submission id is taken")
            landed.append(stored)
        return landed

    # --- the source's side of the thread

    async def get_source_thread(
        self, rctx: RequestContext, org_id: UUID, submission_id: UUID, reply_secret: str
    ) -> SourceThread:
        submission = await self._source_submission(org_id, submission_id, reply_secret)
        report = await self._storage.read_sealed_report(submission.report_id)
        if report is None:
            raise NotFound("no such submission")
        messages = await self._storage.read_messages(org_id, submission_id, self._options.page_size, without_notes=True)
        return SourceThread(submission=submission, report=report, messages=tuple(messages))

    async def post_source_message(
        self, rctx: RequestContext, org_id: UUID, submission_id: UUID, reply_secret: str, message: Message
    ) -> Message:
        submission = await self._source_submission(org_id, submission_id, reply_secret)
        copy = message.model_copy(
            update={"submission_id": submission.id, "direction": MessageDirection.FROM_SOURCE, "author_user_id": None}
        )
        rows = (
            platform_outbox_row(rctx, org_id, "reports.message.created", copy.id, {}),
            _notice(rctx, org_id, submission.id, NotificationTopic.SOURCE_REPLIED),
        )
        return await self._create_message(org_id, copy, rows)

    async def _source_submission(self, org_id: UUID, submission_id: UUID, reply_secret: str) -> Submission:
        found = await self._storage.read_submission(org_id, submission_id)
        if found is None or not rules.secret_matches(reply_secret, found.reply_digest):
            raise NotFound("no such submission")  # a wrong secret reads as a missing submission
        return found

    async def _create_message(self, org_id: UUID, message: Message, rows: tuple[OutboxRow, ...]) -> Message:
        if not await self._storage.create_message(org_id, message, rows):
            stored = await self._storage.read_message(org_id, message.id)
            if stored is None or stored.submission_id != message.submission_id:
                raise Conflict("that message id is taken")
            return stored
        await self._relay_all(org_id, rows)
        return message

    def _clamp(self, limit: int) -> int:
        return max(1, min(limit, self._options.page_size))

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; the write has committed, a failure is the sweep's
