-- Reverses 202609281915_work_receipts.up.sql.

DROP POLICY IF EXISTS tenant_fence ON queue.work_receipts;
DROP TABLE IF EXISTS queue.work_receipts;
