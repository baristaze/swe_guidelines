"""One module per entity of the follows namespace."""
