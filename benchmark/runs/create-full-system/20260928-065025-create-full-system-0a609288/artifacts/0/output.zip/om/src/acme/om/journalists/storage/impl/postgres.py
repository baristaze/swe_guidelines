"""The journalists storage over Postgres: every statement opens through the funnel under the caller's tenant."""

from uuid import UUID

from sqlalchemy import select

from acme.om.journalists.storage import JournalistsStorageInterface
from acme.om.journalists.storage.tables.journalists import Journalists
from acme.om.journalists.types.journalist import Journalist
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome


class JournalistsStoragePostgresImpl(PgStorageBase, JournalistsStorageInterface):
    async def read_journalists(self, org_id: UUID, limit: int) -> list[Journalist]:
        stmt = (
            select(Journalists)
            .where(Journalists.org_id == org_id, Journalists.deleted_at.is_(None))
            .order_by(Journalists.id)
            .limit(limit)
        )
        return await self._read_all(stmt, Journalist, org_id=org_id)

    async def read_journalist(self, org_id: UUID, journalist_id: UUID) -> Journalist | None:
        stmt = select(Journalists).where(Journalists.org_id == org_id, Journalists.id == journalist_id)
        return await self._read_one(stmt, Journalist, org_id=org_id)

    async def create_journalist(self, org_id: UUID, journalist: Journalist, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        outcome = await self._insert(Journalists, journalist, outbox_rows, org_id=org_id)
        return outcome == InsertOutcome.INSERTED

    async def write_journalist(self, org_id: UUID, journalist: Journalist, outbox_rows: tuple[OutboxRow, ...]) -> None:
        await self._upsert(Journalists, journalist, outbox_rows, org_id=org_id)
