"""The business-layer root: builds every manager once, in dependency order, and hands back one frozen object."""

from dataclasses import dataclass

from acme.infra.root import InfraInterface
from acme.om.audit.impl.manager import AuditManagerImpl, AuditOptions
from acme.om.audit.manager import AuditManagerInterface
from acme.om.events.impl.manager import EventsManagerImpl, EventsOptions
from acme.om.events.manager import EventsManagerInterface
from acme.om.follows.impl.manager import FollowsManagerImpl, FollowsOptions
from acme.om.follows.manager import FollowsManagerInterface
from acme.om.idempotency.impl.manager import IdempotencyManagerImpl, IdempotencyOptions
from acme.om.idempotency.manager import IdempotencyManagerInterface
from acme.om.journalists.impl.manager import JournalistsManagerImpl, JournalistsOptions
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.outbox.impl.manager import OutboxOptions, OutboxRelayImpl
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.reports.impl.manager import ReportsManagerImpl, ReportsOptions
from acme.om.reports.manager import ReportsManagerInterface
from acme.om.storage.root import StorageInterface
from acme.om.support.impl.manager import SupportManagerImpl, SupportOptions
from acme.om.support.manager import SupportManagerInterface
from acme.om.tenancy.impl.manager import TenancyManagerImpl, TenancyOptions
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.om.updates.impl.manager import UpdatesManagerImpl, UpdatesOptions
from acme.om.updates.manager import UpdatesManagerInterface
from acme.om.work.impl.manager import WorkManagerImpl, WorkOptions
from acme.om.work.manager import WorkManagerInterface


@dataclass(frozen=True)
class ManagerOptions:
    """Built once by each process's root from its own settings and passed whole."""

    tenancy: TenancyOptions
    events: EventsOptions
    audit: AuditOptions
    outbox: OutboxOptions
    idempotency: IdempotencyOptions
    work: WorkOptions
    journalists: JournalistsOptions
    follows: FollowsOptions
    updates: UpdatesOptions
    support: SupportOptions
    reports: ReportsOptions


@dataclass(frozen=True)
class Managers:
    tenancy: TenancyManagerInterface
    events: EventsManagerInterface
    audit: AuditManagerInterface
    relay: OutboxRelayInterface
    idempotency: IdempotencyManagerInterface
    work: WorkManagerInterface
    journalists: JournalistsManagerInterface
    follows: FollowsManagerInterface
    updates: UpdatesManagerInterface
    support: SupportManagerInterface
    reports: ReportsManagerInterface


def build_managers(storage: StorageInterface, infra: InfraInterface, options: ManagerOptions) -> Managers:
    topics = infra.get_topics()
    events: EventsManagerInterface = EventsManagerImpl(storage.get_events_storage(), options.events)
    built: dict[str, WorkManagerInterface] = {}
    # The relay takes the work manager bound at call time: the work manager needs the tenancy manager,
    # which needs the relay.
    relay: OutboxRelayInterface = OutboxRelayImpl(
        storage.get_outbox_storage(), events, topics, options.outbox, lambda: built["work"]
    )
    audit: AuditManagerInterface = AuditManagerImpl(storage.get_audit_storage(), options.audit)
    idempotency: IdempotencyManagerInterface = IdempotencyManagerImpl(
        storage.get_idempotency_storage(), options.idempotency
    )
    tenancy: TenancyManagerInterface = TenancyManagerImpl(
        storage.get_tenancy_storage(), events, relay, topics, options.tenancy
    )
    work: WorkManagerInterface = WorkManagerImpl(storage.get_work_storage(), tenancy, audit, topics, options.work)
    built["work"] = work
    journalists: JournalistsManagerInterface = JournalistsManagerImpl(
        storage.get_journalist_storage(), relay, options.journalists
    )
    follows: FollowsManagerInterface = FollowsManagerImpl(
        storage.get_follow_storage(), relay, journalists, options.follows
    )
    updates: UpdatesManagerInterface = UpdatesManagerImpl(
        storage.get_update_storage(), relay, journalists, options.updates
    )
    support: SupportManagerInterface = SupportManagerImpl(
        storage.get_support_storage(), relay, journalists, options.support
    )
    reports: ReportsManagerInterface = ReportsManagerImpl(
        storage.get_report_storage(), relay, journalists, tenancy, audit, options.reports
    )
    return Managers(
        tenancy=tenancy,
        events=events,
        audit=audit,
        relay=relay,
        idempotency=idempotency,
        work=work,
        journalists=journalists,
        follows=follows,
        updates=updates,
        support=support,
        reports=reports,
    )
