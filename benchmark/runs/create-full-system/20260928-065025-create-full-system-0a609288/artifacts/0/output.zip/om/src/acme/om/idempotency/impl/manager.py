"""The idempotency manager impl. The operator plane's markers are keyed under EMPTY_UUID with the identity id."""

from dataclasses import dataclass
from datetime import timedelta
from uuid import UUID

from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.idempotency.manager import IdempotencyManagerInterface
from acme.om.idempotency.storage import IdempotencyStorageInterface
from acme.om.idempotency.types import IdempotencyMarker, MarkerOutcome
from acme.om.opcontext import OpContext, OperatorContext, OperatorPermission, Permission, RequestContext


@dataclass(frozen=True)
class IdempotencyOptions:
    lease: timedelta  # how long an attempt holds a pending marker before a retry takes it over
    retention: timedelta  # how long a marker is kept before the sweep purges it
    purge_batch: int


class IdempotencyManagerImpl(IdempotencyManagerInterface):
    def __init__(self, storage: IdempotencyStorageInterface, options: IdempotencyOptions) -> None:
        self._storage = storage
        self._options = options

    async def _begin(self, org_id: UUID, user_id: UUID, key: str, request_digest: str) -> MarkerOutcome:
        now = utcnow()
        marker = IdempotencyMarker(
            id=new_id(),
            created_at=now,
            user_id=user_id,
            key=key,
            request_digest=request_digest,
            target_id=new_id(),  # minted before the marker; a rerun keeps it
            attempt_token=new_id(),
        )
        return await self._storage.begin(org_id, marker, now - self._options.lease)

    async def begin(self, ctx: OpContext, key: str, request_digest: str) -> MarkerOutcome:
        ctx.require(Permission.READ)
        return await self._begin(ctx.org_id, ctx.user_id, key, request_digest)

    async def finish(self, ctx: OpContext, marker: IdempotencyMarker, status: int, body: str) -> bool:
        ctx.require(Permission.READ)
        if marker.attempt_token is None:
            return False
        return await self._storage.finish(ctx.org_id, ctx.user_id, marker.id, marker.attempt_token, status, body)

    async def release(self, ctx: OpContext, marker: IdempotencyMarker) -> bool:
        ctx.require(Permission.READ)
        if marker.attempt_token is None:
            return False
        return await self._storage.release(ctx.org_id, ctx.user_id, marker.id, marker.attempt_token)

    async def begin_for_operator(self, octx: OperatorContext, key: str, request_digest: str) -> MarkerOutcome:
        octx.require(OperatorPermission.READ)
        return await self._begin(EMPTY_UUID, octx.identity_id, key, request_digest)

    async def finish_for_operator(
        self, octx: OperatorContext, marker: IdempotencyMarker, status: int, body: str
    ) -> bool:
        octx.require(OperatorPermission.READ)
        if marker.attempt_token is None:
            return False
        return await self._storage.finish(EMPTY_UUID, octx.identity_id, marker.id, marker.attempt_token, status, body)

    async def release_for_operator(self, octx: OperatorContext, marker: IdempotencyMarker) -> bool:
        octx.require(OperatorPermission.READ)
        if marker.attempt_token is None:
            return False
        return await self._storage.release(EMPTY_UUID, octx.identity_id, marker.id, marker.attempt_token)

    async def purge_markers(self, rctx: RequestContext) -> int:
        return await self._storage.purge_markers(utcnow() - self._options.retention, self._options.purge_batch)
