"""The work item, its kinds and statuses, the payload map, the receipt, and the handler interface."""
