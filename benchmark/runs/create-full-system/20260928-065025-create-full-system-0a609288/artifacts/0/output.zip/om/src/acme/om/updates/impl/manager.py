"""The updates manager impl: authorize, verify, copy, write with the outbox row, relay at once."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.exceptions import Conflict, NotFound
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.opcontext import OpContext, Permission, RequestContext
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, outbox_row
from acme.om.updates.manager import UpdatesManagerInterface
from acme.om.updates.storage import UpdatesStorageInterface
from acme.om.updates.types.update import Update


@dataclass(frozen=True)
class UpdatesOptions:
    page_size: int  # the most one list answers


class UpdatesManagerImpl(UpdatesManagerInterface):
    def __init__(
        self,
        storage: UpdatesStorageInterface,
        relay: OutboxRelayInterface,
        journalists: JournalistsManagerInterface,
        options: UpdatesOptions,
    ) -> None:
        self._storage = storage
        self._relay = relay
        self._journalists = journalists
        self._options = options

    async def get_updates(self, ctx: OpContext, limit: int) -> list[Update]:
        ctx.require(Permission.READ)
        return await self._storage.read_updates(ctx.org_id, self._clamp(limit))

    async def get_update(self, ctx: OpContext, update_id: UUID) -> Update:
        ctx.require(Permission.READ)
        found = await self._storage.read_update(ctx.org_id, update_id)
        if found is None:
            raise NotFound("no such update")
        return found

    async def create_update(self, ctx: OpContext, update: Update) -> Update:
        ctx.require(Permission.WRITE)
        await self._journalists.get_journalist(ctx, update.journalist_id)  # a living profile of this desk
        rows = (outbox_row(ctx, "updates.update.created", update.id, {}),)
        if not await self._storage.create_update(ctx.org_id, update, rows):
            stored = await self._storage.read_update(ctx.org_id, update.id)
            if stored is None:
                raise Conflict("that update id is taken")
            return stored
        await self._relay_all(ctx.org_id, rows)
        return update

    async def get_published_updates(
        self, rctx: RequestContext, org_id: UUID, journalist_id: UUID, limit: int
    ) -> list[Update]:
        await self._journalists.get_published_journalist(rctx, org_id, journalist_id)
        return await self._storage.read_updates(org_id, self._clamp(limit), journalist_id)

    def _clamp(self, limit: int) -> int:
        return max(1, min(limit, self._options.page_size))

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; the write has committed, a failure is the sweep's
