-- Reverses 202609281730_pledges.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.pledges;
DROP TABLE IF EXISTS core.pledges;
