"""The ORM tables of the storage storage; rows never leave a storage impl."""
