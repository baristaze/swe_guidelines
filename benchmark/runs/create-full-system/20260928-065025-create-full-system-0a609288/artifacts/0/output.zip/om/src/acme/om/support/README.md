# Support

Readers support journalists with money. This page says what a **pledge** and a **contribution** are and what can
happen to them. It sits one level below [the object model](../../../../README.md).

## A pledge

A **pledge** is a reader's account supporting one journalist, either **once** or **every month**, with an amount
of its choosing in euros, dollars, or pounds. It belongs to the reader's account: it is their payment history.

- A reader pledges only to a published journalist whose desk has set up payouts.
- A pledge starts **pending** while the reader pays at the payment processor's checkout. When the processor
  confirms the payment, a one-time pledge is **paid**, and a monthly one is **active**: the reader is a **patron**
  of the journalist while it stays active.
- The platform keeps a share of each payment, set as a rate apart from the processor's own fees.

## A contribution

A **contribution** is one payment a desk received: from whom (the name the supporter chose to show), how much,
once or monthly, and the platform's share. It belongs to the desk, and it never changes.

## What can happen to them

- **Pledged**: anyone on an account who can write opens a pledge and is sent to the checkout.
- **Settled**: the payment processor confirms the payment. The pledge is paid or active, the desk gets its
  contribution shortly after, and the reader gets a receipt. A repeated confirmation, even one arriving at the same
  moment, changes nothing. A pledge the reader abandoned whose checkout was still paid is settled all the same.
- **Changed at once**: two changes to one pledge at the same moment never both win; the later one is refused and
  asked to look again.
- **Cancelled**: the reader ends an active monthly pledge, or abandons a pending one. A one-time pledge that was
  paid cannot be cancelled here.
- **Listed**: the account sees its pledges; the desk sees its contributions, the newest first.

## Rules that hold

- Supporting a journalist is never needed to follow them or to send them information.
- A contribution is recorded only from the payment processor's signed confirmation, never from a reader's word.
