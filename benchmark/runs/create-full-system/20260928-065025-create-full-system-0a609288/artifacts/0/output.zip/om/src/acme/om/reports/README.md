# Reports

A source brings a journalist information through a **report**. This page says what a report, a **submission**, and
a **message** are, and what can happen to them. It sits one level below [the object model](../../../../README.md).

## A report

A **report** is what a source sends: a subject, a description, tags, an approximate place and time if they wish,
and photos, videos, audio, or documents. It is sealed on the source's own device before it leaves it, under a key
made for that one report, and the platform keeps it once, sealed. The platform can never read it.

- A source sends a report to one or more journalists at once (up to ten), each a published profile.
- A source needs no account. A signed-in reader may instead send a report under their name; the name is then shown
  to the journalists who receive it, and to nobody else.
- A source may leave a contact address for notices of replies. It is theirs to give or not, and it is not an
  identity.

## A submission

A **submission** is one journalist's copy of a report, in that journalist's desk: the report's key sealed for that
journalist alone, the source's own key for replies, and the desk's working **state**: **new**, **reviewing**,
**follow-up**, **useful**, or **archived**, with the desk's own **tags**.

## A message

A **message** sits on a submission's thread: a journalist's **reply** to the source, the source's **answer**, or a
desk's internal **note**. Each is sealed on the device that wrote it; a note is sealed to the desk alone and the
source never sees it.

## What can happen to them

- **Sent**: a source sends a report; each recipient desk gets its submission, marked new, and its members are told
  that a report arrived, never what it says. Sending the same report twice, as a repeated request does, sends it
  once.
- **Worked**: anyone on the desk lists the inbox, filtered by state and tag, and opens a submission on their own
  device. Every opening is recorded in the desk's audit trail. A member moves it between states and tags it.
- **Answered**: a member replies to the source or leaves a note. A source who left a contact address is told a
  reply is waiting.
- **Followed up**: the source, holding the reply secret their device kept, reads the thread and answers. The desk
  is told.

## Rules that hold

- A report is private to the desks it was sent to, and never becomes public without an explicit editorial act.
- One journalist's key opens only that journalist's submission; the platform holds no key that opens any.
- Nothing the source sent can be changed by the desk: only the desk's own state and tags.
- A wrong reply secret is answered as if the submission did not exist.
