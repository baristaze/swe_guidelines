"""The journalists storage in memory: the same filters, tenancy rule, and refusals as the engine."""

from uuid import UUID

from acme.om.exceptions import Conflict
from acme.om.journalists.storage import JournalistsStorageInterface
from acme.om.journalists.types.journalist import Journalist
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase, by_uuid


class JournalistsStorageMemoryImpl(MemoryStorageBase, JournalistsStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._rows: dict[UUID, tuple[UUID, Journalist]] = {}

    async def read_journalists(self, org_id: UUID, limit: int) -> list[Journalist]:
        living = [j for o, j in self._rows.values() if o == org_id and j.deleted_at is None]
        return by_uuid(living)[:limit]

    async def read_journalist(self, org_id: UUID, journalist_id: UUID) -> Journalist | None:
        found = self._rows.get(journalist_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def create_journalist(self, org_id: UUID, journalist: Journalist, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        if journalist.id in self._rows:
            return False
        self._land(org_id, outbox_rows)
        self._rows[journalist.id] = (org_id, journalist)
        return True

    async def write_journalist(self, org_id: UUID, journalist: Journalist, outbox_rows: tuple[OutboxRow, ...]) -> None:
        found = self._rows.get(journalist.id)
        if found is not None and found[0] != org_id:
            raise Conflict("the row is held under another key")
        self._land(org_id, outbox_rows)
        self._rows[journalist.id] = (org_id, journalist)
