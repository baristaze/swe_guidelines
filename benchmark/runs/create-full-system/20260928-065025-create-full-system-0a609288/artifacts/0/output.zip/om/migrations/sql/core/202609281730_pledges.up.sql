-- A reader's pledges, org scope (the reader's own account).

-- pledges: org scope
CREATE TABLE core.pledges (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    desk_id UUID NOT NULL,
    journalist_id UUID NOT NULL,
    amount_minor INTEGER NOT NULL,
    currency VARCHAR NOT NULL,
    mode VARCHAR NOT NULL,
    supporter_name VARCHAR NOT NULL,
    status VARCHAR NOT NULL,
    platform_fee_minor INTEGER NOT NULL,
    checkout_session_id VARCHAR,
    subscription_id VARCHAR,
    settled_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_pledges PRIMARY KEY (id)
);
CREATE INDEX ix_pledges_org_id ON core.pledges (org_id);
CREATE POLICY tenant_fence ON core.pledges
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.pledges ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.pledges FORCE ROW LEVEL SECURITY;
