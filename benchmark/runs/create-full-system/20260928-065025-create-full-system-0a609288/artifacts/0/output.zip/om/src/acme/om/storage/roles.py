"""The single source of truth for where each table lives and whose rows it holds.

`TABLE_ROLES` maps a table to its database role, which is its schema, its pool, and its migration chain.
`TABLE_SCOPES` maps a table to its tenancy scope, which is the policy its migration creates.
"""

from enum import StrEnum


class DatabaseRole(StrEnum):
    CORE = "core"  # the system of record
    ACTIVITY = "activity"  # append-only streams: events, audit
    QUEUE = "queue"  # the work queue


class TenancyScope(StrEnum):
    SYSTEM = "system"  # the platform's rows: no policy, row-level security not enabled
    ORG = "org"  # a tenant's rows: the policy rests on org_id
    IDENTITY = "identity"  # an identity's rows across tenants: the policy rests on identity_id
    BOTH = "both"  # a tenant's rows narrowed to a person in it


TABLE_ROLES: dict[str, DatabaseRole] = {
    "orgs": DatabaseRole.CORE,
    "identities": DatabaseRole.CORE,
    "users": DatabaseRole.CORE,
    "memberships": DatabaseRole.CORE,
    "identity_memberships": DatabaseRole.CORE,
    "sessions": DatabaseRole.CORE,
    "api_keys": DatabaseRole.CORE,
    "socket_tickets": DatabaseRole.CORE,
    "sign_in_failures": DatabaseRole.CORE,
    "operators": DatabaseRole.CORE,
    "outbox": DatabaseRole.CORE,
    "idempotency_markers": DatabaseRole.CORE,
    "journalists": DatabaseRole.CORE,
    "follows": DatabaseRole.CORE,
    "updates": DatabaseRole.CORE,
    "pledges": DatabaseRole.CORE,
    "sealed_reports": DatabaseRole.CORE,
    "submissions": DatabaseRole.CORE,
    "messages": DatabaseRole.CORE,
    "contributions": DatabaseRole.ACTIVITY,
    "events": DatabaseRole.ACTIVITY,
    "event_cursors": DatabaseRole.ACTIVITY,
    "audit_entries": DatabaseRole.ACTIVITY,
    "audit_cursors": DatabaseRole.ACTIVITY,
    "work_items": DatabaseRole.QUEUE,
    "work_receipts": DatabaseRole.QUEUE,
}

# table -> (scope, the column the policy rests on; None for system and org, whose column is org_id)
TABLE_SCOPES: dict[str, tuple[TenancyScope, str | None]] = {
    "orgs": (TenancyScope.SYSTEM, None),
    "identities": (TenancyScope.IDENTITY, "identity_id"),
    "users": (TenancyScope.ORG, None),
    "memberships": (TenancyScope.ORG, None),
    "identity_memberships": (TenancyScope.IDENTITY, "identity_id"),
    "sessions": (TenancyScope.IDENTITY, "identity_id"),
    "api_keys": (TenancyScope.ORG, None),
    "socket_tickets": (TenancyScope.IDENTITY, "identity_id"),
    "sign_in_failures": (TenancyScope.SYSTEM, None),
    "operators": (TenancyScope.SYSTEM, None),
    "outbox": (TenancyScope.ORG, None),
    "idempotency_markers": (TenancyScope.ORG, None),
    "journalists": (TenancyScope.ORG, None),
    "follows": (TenancyScope.ORG, None),  # the reader's own account (ADR 0009)
    "updates": (TenancyScope.ORG, None),
    "pledges": (TenancyScope.ORG, None),  # the supporter's own account
    "contributions": (TenancyScope.ORG, None),  # the desk's
    "sealed_reports": (TenancyScope.SYSTEM, None),  # ciphertext only, in no tenant (ADR 0009)
    "submissions": (TenancyScope.ORG, None),  # the recipient desk's
    "messages": (TenancyScope.ORG, None),
    "events": (TenancyScope.ORG, None),
    "event_cursors": (TenancyScope.ORG, None),
    "audit_entries": (TenancyScope.ORG, None),
    "audit_cursors": (TenancyScope.ORG, None),
    "work_items": (TenancyScope.ORG, None),
    "work_receipts": (TenancyScope.ORG, None),
}


def role_of(table: str) -> DatabaseRole:
    return TABLE_ROLES[table]
