# Events

**Nouns.** An **event** is the record of one change in a desk: what kind of change, which thing changed, who changed
it, and its number in the desk's sequence.

**What can happen.** Every change leaves exactly one event. An open screen hears about the change at once; a screen
that was away asks for every event after the last number it saw.

**Rules that hold.**

- Numbers are per desk, start at one, and never skip, so a missing number always means a missed change.
- An event names what changed and who changed it, never the content: a screen reads the thing itself, through the
  same permission checks as any read.
- Operators can count events across desks, to see how busy the platform is; reading one desk's events is recorded.
