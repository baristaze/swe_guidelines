"""The support manager: the swimlane of a reader's pledges and the contributions a desk receives."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.opcontext import OpContext, RequestContext
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge


class SupportManagerInterface(ABC):
    # --- the supporter's account

    @abstractmethod
    async def get_pledges(self, ctx: OpContext, limit: int) -> list[Pledge]:
        """The account's payment history, the newest first."""
        ...

    @abstractmethod
    async def get_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge: ...

    @abstractmethod
    async def create_pledge(self, ctx: OpContext, pledge: Pledge) -> Pledge:
        """Opens a pledge to a published journalist whose desk takes payouts, pending until the processor settles it;
        a rerun under the same id returns it as stored."""
        ...

    @abstractmethod
    async def attach_checkout(self, ctx: OpContext, pledge_id: UUID, checkout_session_id: str) -> Pledge:
        """Records the processor's checkout opened for a pending pledge."""
        ...

    @abstractmethod
    async def cancel_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge:
        """Ends an active monthly pledge, or abandons a pending one; Conflict for any other."""
        ...

    # --- the desk

    @abstractmethod
    async def get_contributions(self, ctx: OpContext, limit: int) -> list[Contribution]:
        """The desk's received contributions, the newest first."""
        ...

    @abstractmethod
    async def get_contribution(self, ctx: OpContext, contribution_id: UUID) -> Contribution: ...

    # --- the request stage: a payment delivery whose signature the edge verified (ADR 0010)

    @abstractmethod
    async def settle_checkout(
        self,
        rctx: RequestContext,
        org_id: UUID,
        pledge_id: UUID,
        delivery_key: UUID,
        subscription_id: str | None,
    ) -> Pledge:
        """Settles the pledge in the supporter's account `org_id` by compare-and-set on its version, and lands with
        it the receipt and the APPEND_CONTRIBUTION work that records the contribution at the desk, every row's id
        derived from the delivery key, so a redelivery, concurrent or late, settles and enqueues nothing twice.
        NotFound for an unknown pledge."""
        ...

    # --- the work stage: the APPEND_CONTRIBUTION item a settlement queued (STO-20)

    @abstractmethod
    async def append_contribution(self, ctx: OpContext, pledge_id: UUID, contribution_id: UUID) -> Contribution:
        """Appends the settled pledge's contribution to its desk under `contribution_id`, the delivery's key: a replay
        appends nothing and answers the stored one. The service role's alone, under the supporter's account the item
        was queued in; Conflict for a pledge never settled."""
        ...
