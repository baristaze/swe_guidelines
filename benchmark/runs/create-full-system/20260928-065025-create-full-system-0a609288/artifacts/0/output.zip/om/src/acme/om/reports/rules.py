"""The reports rules: the reply secret's digest and how a presented secret is compared. Plain functions."""

import hashlib
import hmac

MAX_RECIPIENTS = 10


def reply_digest(secret: str) -> str:
    return hashlib.sha256(secret.encode()).hexdigest()


def secret_matches(secret: str, digest: str) -> bool:
    return hmac.compare_digest(reply_digest(secret), digest)


def normalized_tags(tags: tuple[str, ...]) -> tuple[str, ...]:
    """Trimmed, lower case, each once, in the order first given."""
    out: list[str] = []
    for tag in tags:
        t = tag.strip().lower()
        if t and t not in out:
            out.append(t)
    return tuple(out)
