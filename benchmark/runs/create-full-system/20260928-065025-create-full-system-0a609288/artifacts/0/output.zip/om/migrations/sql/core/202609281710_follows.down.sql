-- Reverses 202609281710_follows.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.follows;
DROP TABLE IF EXISTS core.follows;
