"""The support manager impl: authorize, verify, copy, write with the outbox rows, relay at once."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.base import EMPTY_UUID, utcnow
from acme.om.exceptions import Conflict, NotAuthorized, NotFound, ValidationFailed
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.opcontext import OpContext, Permission, RequestContext, Role
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, outbox_row, platform_outbox_row
from acme.om.support import rules
from acme.om.support.manager import SupportManagerInterface
from acme.om.support.storage import SupportStorageInterface
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge, PledgeStatus
from acme.om.work.types.work_item import APPEND_CONTRIBUTION_ROW, SEND_NOTIFICATION_ROW, NotificationTopic

PLEDGE_UPDATED = "support.pledge.updated"
SETTLE_ATTEMPTS = 3  # a settlement rereads and decides again this often while a concurrent write moves the row


@dataclass(frozen=True)
class SupportOptions:
    page_size: int  # the most one list answers
    platform_fee_basis_points: int  # the platform's share, configured apart from the processor's fees
    minimum_minor: int
    maximum_minor: int


class SupportManagerImpl(SupportManagerInterface):
    def __init__(
        self,
        storage: SupportStorageInterface,
        relay: OutboxRelayInterface,
        journalists: JournalistsManagerInterface,
        options: SupportOptions,
    ) -> None:
        self._storage = storage
        self._relay = relay
        self._journalists = journalists
        self._options = options

    async def get_pledges(self, ctx: OpContext, limit: int) -> list[Pledge]:
        ctx.require(Permission.READ)
        return await self._storage.read_pledges(ctx.org_id, self._clamp(limit))

    async def get_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge:
        ctx.require(Permission.READ)
        found = await self._storage.read_pledge(ctx.org_id, pledge_id)
        if found is None:
            raise NotFound("no such pledge")
        return found

    async def create_pledge(self, ctx: OpContext, pledge: Pledge) -> Pledge:
        ctx.require(Permission.WRITE)
        problem = rules.pledge_problem(
            pledge.amount_minor, pledge.currency, self._options.minimum_minor, self._options.maximum_minor
        )
        if problem is not None:
            raise ValidationFailed(problem)
        journalist = await self._journalists.get_published_journalist(ctx, pledge.desk_id, pledge.journalist_id)
        if journalist.payout_account_id is None:
            raise ValidationFailed("this journalist does not take support yet")
        copy = pledge.model_copy(
            update={
                "created_by": ctx.user_id,
                "updated_by": ctx.user_id,
                "status": PledgeStatus.PENDING,
                "platform_fee_minor": rules.platform_fee_minor(
                    pledge.amount_minor, self._options.platform_fee_basis_points
                ),
                "checkout_session_id": None,
                "subscription_id": None,
                "settled_at": None,
                "version": 1,
            }
        )
        rows = (outbox_row(ctx, "support.pledge.created", copy.id, {"version": copy.version}),)
        if not await self._storage.create_pledge(ctx.org_id, copy, rows):
            stored = await self._storage.read_pledge(ctx.org_id, copy.id)
            if stored is None:
                raise Conflict("that pledge id is taken")
            return stored
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def attach_checkout(self, ctx: OpContext, pledge_id: UUID, checkout_session_id: str) -> Pledge:
        ctx.require(Permission.WRITE)
        current = await self.get_pledge(ctx, pledge_id)
        if current.status != PledgeStatus.PENDING:
            raise Conflict("the pledge is no longer pending")
        copy = current.model_copy(
            update={
                "checkout_session_id": checkout_session_id,
                "updated_at": utcnow(),
                "updated_by": ctx.user_id,
                "version": current.version + 1,
            }
        )
        return await self._transition(ctx, current, copy)

    async def cancel_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge:
        ctx.require(Permission.WRITE)
        current = await self.get_pledge(ctx, pledge_id)
        if current.status == PledgeStatus.CANCELLED:
            return current
        if not rules.cancellable(current.status, current.mode):
            raise Conflict("only a pending pledge or an active monthly one can be cancelled")
        copy = current.model_copy(
            update={
                "status": PledgeStatus.CANCELLED,
                "updated_at": utcnow(),
                "updated_by": ctx.user_id,
                "version": current.version + 1,
            }
        )
        return await self._transition(ctx, current, copy)

    async def _transition(self, ctx: OpContext, current: Pledge, copy: Pledge) -> Pledge:
        """A caller's transition, decided on `current`: written only while the row still carries its version, so a
        settlement (or another transition) that landed since the read is never overwritten."""
        rows = (outbox_row(ctx, PLEDGE_UPDATED, copy.id, {"version": copy.version}),)
        if not await self._storage.write_pledge(ctx.org_id, copy, current.version, rows):
            raise Conflict("the pledge changed since it was read; read it again")
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def get_contributions(self, ctx: OpContext, limit: int) -> list[Contribution]:
        ctx.require(Permission.READ)
        return await self._storage.read_contributions(ctx.org_id, self._clamp(limit))

    async def get_contribution(self, ctx: OpContext, contribution_id: UUID) -> Contribution:
        ctx.require(Permission.READ)
        found = await self._storage.read_contribution(ctx.org_id, contribution_id)
        if found is None:
            raise NotFound("no such contribution")
        return found

    async def settle_checkout(
        self,
        rctx: RequestContext,
        org_id: UUID,
        pledge_id: UUID,
        delivery_key: UUID,
        subscription_id: str | None,
    ) -> Pledge:
        for _ in range(SETTLE_ATTEMPTS):
            current = await self._storage.read_pledge(org_id, pledge_id)
            if current is None:
                raise NotFound("no such pledge")
            if not rules.settles(current.settled_at):
                return current  # a redelivery, or a concurrent delivery that won: nothing to settle or enqueue again
            now = utcnow()
            settled = current.model_copy(
                update={
                    "status": rules.settled_status(current.mode),
                    "subscription_id": subscription_id,
                    "settled_at": now,
                    "updated_at": now,
                    "updated_by": EMPTY_UUID,  # the platform, on the processor's signed word
                    "version": current.version + 1,
                }
            )
            # The work rows' ids derive from the delivery key, so a second landing of the same delivery collides. The
            # event row keeps a new_id(): it becomes the event's id, which stays time-ordered, and the version's
            # compare-and-set already lands it once.
            rows = (
                platform_outbox_row(rctx, org_id, PLEDGE_UPDATED, settled.id, {"version": settled.version}),
                platform_outbox_row(
                    rctx,
                    org_id,
                    SEND_NOTIFICATION_ROW,
                    settled.id,
                    {"topic": NotificationTopic.SUPPORT_RECEIPT.value},
                    row_id=rules.delivery_row_id(delivery_key, SEND_NOTIFICATION_ROW),
                ),
                # The desk's record is the work that follows, never a second statement after this write (STO-20).
                platform_outbox_row(
                    rctx,
                    org_id,
                    APPEND_CONTRIBUTION_ROW,
                    settled.id,
                    {"contribution_id": str(delivery_key)},
                    row_id=rules.delivery_row_id(delivery_key, APPEND_CONTRIBUTION_ROW),
                ),
            )
            if await self._storage.write_pledge(org_id, settled, current.version, rows):
                await self._relay_all(org_id, rows)
                return settled
            # The row moved between the read and the write: read it again and decide again.
        raise Conflict("the pledge kept changing; the processor redelivers")

    async def append_contribution(self, ctx: OpContext, pledge_id: UUID, contribution_id: UUID) -> Contribution:
        ctx.require(Permission.WRITE)
        if ctx.security.role != Role.SERVICE:
            raise NotAuthorized("a contribution is recorded by the platform's work, never by a person")
        pledge = await self.get_pledge(ctx, pledge_id)
        if pledge.settled_at is None:
            raise Conflict("the pledge was never settled")
        contribution = Contribution(
            id=contribution_id,
            journalist_id=pledge.journalist_id,
            pledge_id=pledge.id,
            supporter_org_id=ctx.org_id,
            supporter_name=pledge.supporter_name,
            amount_minor=pledge.amount_minor,
            currency=pledge.currency,
            mode=pledge.mode,
            platform_fee_minor=pledge.platform_fee_minor,
            received_at=pledge.settled_at,
        )
        # Appended once, in the desk's tenant; a replay finds its id and answers what is stored.
        if await self._storage.append_contribution(pledge.desk_id, contribution):
            return contribution
        stored = await self._storage.read_contribution(pledge.desk_id, contribution_id)
        if stored is None:
            raise Conflict("that contribution id is taken")
        return stored

    def _clamp(self, limit: int) -> int:
        return max(1, min(limit, self._options.page_size))

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; the write has committed, a failure is the sweep's
