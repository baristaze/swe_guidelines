"""A message on a submission's thread: a desk's reply to the source, the source's answer, or the desk's own note."""

from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from acme.om.base import Created, Identifiable


class MessageDirection(StrEnum):
    TO_SOURCE = "to_source"  # sealed on the journalist's device to the source's key (and the desk's own)
    FROM_SOURCE = "from_source"  # sealed on the source's device to the recipient's key
    NOTE = "note"  # the desk's internal note, sealed to the desk's own key; the source never sees it


class Message(Identifiable, Created):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("author_user_id",)

    submission_id: UUID
    direction: MessageDirection
    sealed_body: str  # ciphertext; the platform never reads it
    author_user_id: UUID | None = None  # the desk member who wrote it; None for the source
