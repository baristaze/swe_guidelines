"""The reports swimlane: private source communication, sealed on the sender's device, per recipient desk."""

from acme.om.reports.manager import ReportsManagerInterface

__all__ = ["ReportsManagerInterface"]
