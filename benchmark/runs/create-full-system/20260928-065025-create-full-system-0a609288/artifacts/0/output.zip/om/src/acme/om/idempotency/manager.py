"""The idempotency manager: begin, finish, release, and take-over of the marker that owns a create's retry."""

from abc import ABC, abstractmethod

from acme.om.idempotency.types import IdempotencyMarker, MarkerOutcome
from acme.om.opcontext import OpContext, OperatorContext, RequestContext


class IdempotencyManagerInterface(ABC):
    @abstractmethod
    async def begin(self, ctx: OpContext, key: str, request_digest: str) -> MarkerOutcome: ...

    @abstractmethod
    async def finish(self, ctx: OpContext, marker: IdempotencyMarker, status: int, body: str) -> bool: ...

    @abstractmethod
    async def release(self, ctx: OpContext, marker: IdempotencyMarker) -> bool: ...

    @abstractmethod
    async def begin_for_operator(self, octx: OperatorContext, key: str, request_digest: str) -> MarkerOutcome: ...

    @abstractmethod
    async def finish_for_operator(
        self, octx: OperatorContext, marker: IdempotencyMarker, status: int, body: str
    ) -> bool: ...

    @abstractmethod
    async def release_for_operator(self, octx: OperatorContext, marker: IdempotencyMarker) -> bool: ...

    @abstractmethod
    async def purge_markers(self, rctx: RequestContext) -> int:
        """Bookkeeping with no principal: the sweep's purge of markers past their retention."""
        ...
