"""One module per table of the support namespace."""
