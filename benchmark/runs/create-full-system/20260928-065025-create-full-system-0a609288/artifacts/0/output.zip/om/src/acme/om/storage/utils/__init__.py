"""Shared helpers of the storage layer."""
