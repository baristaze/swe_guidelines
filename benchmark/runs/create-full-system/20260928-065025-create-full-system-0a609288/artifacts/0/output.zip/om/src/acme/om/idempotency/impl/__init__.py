"""The implementations of the idempotency interfaces."""
