"""An update: a short text a desk publishes under one of its journalist profiles, public by nature."""

from typing import ClassVar
from uuid import UUID

from acme.om.base import Created, Identifiable


class Update(Identifiable, Created):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    journalist_id: UUID  # the profile it is published under
    body: str  # published community activity: readers read it, so it carries nothing private
