"""The journalist profile: the name, the bio, and the public key a desk presents to its readers and sources."""

from typing import ClassVar

from acme.om.base import Identifiable, SoftDeletable, Trackable


class Journalist(Identifiable, Trackable, SoftDeletable):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ("payout_account_id",)

    display_name: str  # the name readers see; a personal field, so it never rides an event or an outbox row
    bio: str = ""
    public_key: str | None = None  # the key sources wrap a report's key for; its private half never leaves the desk
    published: bool = False  # readers and sources reach only a published profile
    payout_account_id: str | None = None  # the payment processor's connected account; set by the payout onboarding
