"""The follows storage in memory: the same filters, tenancy rule, unique key, and refusals as the engine."""

from uuid import UUID

from acme.om.exceptions import Conflict
from acme.om.follows.storage import FollowsStorageInterface
from acme.om.follows.types.follow import Follow
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase, by_uuid
from acme.om.storage.root import InsertOutcome


class FollowsStorageMemoryImpl(MemoryStorageBase, FollowsStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._rows: dict[UUID, tuple[UUID, Follow]] = {}

    async def read_follows(self, org_id: UUID, limit: int) -> list[Follow]:
        living = [f for o, f in self._rows.values() if o == org_id and f.deleted_at is None]
        return by_uuid(living)[:limit]

    async def read_follow(self, org_id: UUID, follow_id: UUID) -> Follow | None:
        found = self._rows.get(follow_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def read_follow_by_journalist(self, org_id: UUID, journalist_id: UUID) -> Follow | None:
        return self._living_key(org_id, journalist_id)

    async def create_follow(self, org_id: UUID, follow: Follow, outbox_rows: tuple[OutboxRow, ...]) -> InsertOutcome:
        if follow.id in self._rows:
            return InsertOutcome.ID_EXISTS
        if follow.deleted_at is None and self._living_key(org_id, follow.journalist_id) is not None:
            return InsertOutcome.KEY_EXISTS
        self._land(org_id, outbox_rows)
        self._rows[follow.id] = (org_id, follow)
        return InsertOutcome.INSERTED

    async def write_follow(self, org_id: UUID, follow: Follow, outbox_rows: tuple[OutboxRow, ...]) -> None:
        found = self._rows.get(follow.id)
        if found is not None and found[0] != org_id:
            raise Conflict("the row is held under another key")
        held = self._living_key(org_id, follow.journalist_id)
        if follow.deleted_at is None and held is not None and held.id != follow.id:
            raise Conflict("the row is held under another key")
        self._land(org_id, outbox_rows)
        self._rows[follow.id] = (org_id, follow)

    def _living_key(self, org_id: UUID, journalist_id: UUID) -> Follow | None:
        for o, f in self._rows.values():
            if o == org_id and f.journalist_id == journalist_id and f.deleted_at is None:
                return f
        return None
