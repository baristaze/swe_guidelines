"""The receipts of work items' outside effects, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281915"
down_revision = "202609281200"


def upgrade() -> None:
    run_sql("queue", "202609281915_work_receipts.up.sql")


def downgrade() -> None:
    run_sql("queue", "202609281915_work_receipts.down.sql")
