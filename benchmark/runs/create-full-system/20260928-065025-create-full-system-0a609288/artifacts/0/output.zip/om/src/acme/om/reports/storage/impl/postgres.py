"""The reports storage over Postgres: the sealed report under no tenant, everything else through the funnel under
the desk's tenant."""

from uuid import UUID

from sqlalchemy import any_, literal, select

from acme.om.outbox.types import OutboxRow
from acme.om.reports.storage import ReportsStorageInterface
from acme.om.reports.storage.tables.messages import Messages
from acme.om.reports.storage.tables.sealed_reports import SealedReports
from acme.om.reports.storage.tables.submissions import Submissions
from acme.om.reports.types.message import Message, MessageDirection
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission, SubmissionState
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome


class ReportsStoragePostgresImpl(PgStorageBase, ReportsStorageInterface):
    async def create_sealed_report(self, report: SealedReport) -> bool:
        return await self._insert(SealedReports, report) == InsertOutcome.INSERTED

    async def read_sealed_report(self, report_id: UUID) -> SealedReport | None:
        return await self._read_one(select(SealedReports).where(SealedReports.id == report_id), SealedReport)

    async def read_submissions(
        self, org_id: UUID, limit: int, state: SubmissionState | None = None, tag: str | None = None
    ) -> list[Submission]:
        stmt = select(Submissions).where(Submissions.org_id == org_id)
        if state is not None:
            stmt = stmt.where(Submissions.state == state.value)
        if tag is not None:
            stmt = stmt.where(literal(tag) == any_(Submissions.tags))
        return await self._read_all(stmt.order_by(Submissions.id.desc()).limit(limit), Submission, org_id=org_id)

    async def read_submission(self, org_id: UUID, submission_id: UUID) -> Submission | None:
        stmt = select(Submissions).where(Submissions.org_id == org_id, Submissions.id == submission_id)
        return await self._read_one(stmt, Submission, org_id=org_id)

    async def create_submission(self, org_id: UUID, submission: Submission, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        return await self._insert(Submissions, submission, outbox_rows, org_id=org_id) == InsertOutcome.INSERTED

    async def write_submission(self, org_id: UUID, submission: Submission, outbox_rows: tuple[OutboxRow, ...]) -> None:
        await self._upsert(Submissions, submission, outbox_rows, org_id=org_id)

    async def read_messages(
        self, org_id: UUID, submission_id: UUID, limit: int, *, without_notes: bool = False
    ) -> list[Message]:
        stmt = select(Messages).where(Messages.org_id == org_id, Messages.submission_id == submission_id)
        if without_notes:
            stmt = stmt.where(Messages.direction != MessageDirection.NOTE.value)
        return await self._read_all(stmt.order_by(Messages.id).limit(limit), Message, org_id=org_id)

    async def read_message(self, org_id: UUID, message_id: UUID) -> Message | None:
        stmt = select(Messages).where(Messages.org_id == org_id, Messages.id == message_id)
        return await self._read_one(stmt, Message, org_id=org_id)

    async def create_message(self, org_id: UUID, message: Message, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        return await self._insert(Messages, message, outbox_rows, org_id=org_id) == InsertOutcome.INSERTED
