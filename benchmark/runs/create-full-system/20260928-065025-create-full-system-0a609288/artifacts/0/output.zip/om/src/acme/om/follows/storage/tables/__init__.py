"""One module per table of the follows namespace."""
