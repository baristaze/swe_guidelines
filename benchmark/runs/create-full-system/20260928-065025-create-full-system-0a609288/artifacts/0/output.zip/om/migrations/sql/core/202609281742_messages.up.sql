-- The messages of each submission's thread, org scope (the desk's tenant).

-- messages: org scope
CREATE TABLE core.messages (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    submission_id UUID NOT NULL,
    direction VARCHAR NOT NULL,
    sealed_body VARCHAR NOT NULL,
    author_user_id UUID,
    CONSTRAINT pk_messages PRIMARY KEY (id)
);
CREATE INDEX ix_messages_org_id_submission_id_id ON core.messages (org_id, submission_id, id);
CREATE POLICY tenant_fence ON core.messages
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.messages FORCE ROW LEVEL SECURITY;
