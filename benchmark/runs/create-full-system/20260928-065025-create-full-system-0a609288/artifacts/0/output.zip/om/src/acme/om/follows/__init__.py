"""The follows swimlane: the journalists a reader follows from their own account."""

from acme.om.follows.manager import FollowsManagerInterface

__all__ = ["FollowsManagerInterface"]
