"""The journalists storage. Every method runs under the caller's tenant; a soft-deleted row is still read by id,
and never listed."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.journalists.types.journalist import Journalist
from acme.om.outbox.types import OutboxRow


class JournalistsStorageInterface(ABC):
    @abstractmethod
    async def read_journalists(self, org_id: UUID, limit: int) -> list[Journalist]:
        """The tenant's living profiles, ordered by id, at most `limit`."""
        ...

    @abstractmethod
    async def read_journalist(self, org_id: UUID, journalist_id: UUID) -> Journalist | None:
        """One profile of the tenant, a soft-deleted one included."""
        ...

    @abstractmethod
    async def create_journalist(self, org_id: UUID, journalist: Journalist, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        """False when the id is already written, under any tenant; nothing changes then."""
        ...

    @abstractmethod
    async def write_journalist(self, org_id: UUID, journalist: Journalist, outbox_rows: tuple[OutboxRow, ...]) -> None:
        """Writes the profile onto its row under the tenant; an id another tenant holds is a Conflict."""
        ...
