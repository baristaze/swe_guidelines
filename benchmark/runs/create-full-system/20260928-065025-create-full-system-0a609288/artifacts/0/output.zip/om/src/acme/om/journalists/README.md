# Journalists

A desk presents itself to readers through its **journalist profiles**. This page says what a profile is and
what can happen to it. It sits one level below [the object model](../../../../README.md).

## A journalist profile

A **journalist** is the public face of a desk: the **display name** readers see. In time it gains the bio,
the coverage areas and topics, the links, and the verification badge; today it holds the name.

- A profile belongs to one desk, and nobody outside that desk sees it through the desk's own screens.
- A desk may present more than one profile, for a small team that publishes together.

## What can happen to it

- **Listed**: anyone on the desk, a viewer included, sees the desk's profiles.
- **Read**: anyone on the desk opens one profile.
- **Added**: a member, an admin, or the owner adds a profile. Adding the same profile twice, as a repeated
  request does, adds it once.
- **Renamed**: a member, an admin, or the owner changes the display name. Who added the profile, and when,
  never changes.
- **Removed**: a member, an admin, or the owner removes a profile. It leaves every list at once; the record is
  kept for a while and then erased.

## Rules that hold

- Every change is numbered in the desk's events, so every open screen of the desk shows it within a moment. The
  event names the profile, never its name.
- A removed profile cannot be renamed or removed again; to the desk it is gone.
