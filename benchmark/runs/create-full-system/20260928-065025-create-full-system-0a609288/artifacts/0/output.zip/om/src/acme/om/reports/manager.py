"""The reports manager: the swimlane of private source communication, from the intake to the thread."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.opcontext import OpContext, RequestContext
from acme.om.reports.types.message import Message
from acme.om.reports.types.read_models import OpenedSubmission, Recipient, SourceThread
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission, SubmissionState


class ReportsManagerInterface(ABC):
    # --- the desk's inbox

    @abstractmethod
    async def get_submissions(
        self, ctx: OpContext, limit: int, state: SubmissionState | None = None, tag: str | None = None
    ) -> list[Submission]:
        """The desk's inbox, the newest first, filtered by the desk's state and tags."""
        ...

    @abstractmethod
    async def get_submission(self, ctx: OpContext, submission_id: UUID) -> Submission: ...

    @abstractmethod
    async def open_submission(self, ctx: OpContext, submission_id: UUID) -> OpenedSubmission:
        """The submission and its sealed report, for the member's device to open; every opening is audited."""
        ...

    @abstractmethod
    async def update_submission(self, ctx: OpContext, submission: Submission) -> Submission:
        """The desk's state and tags; everything the source sent stays as stored."""
        ...

    @abstractmethod
    async def get_messages(self, ctx: OpContext, submission_id: UUID, limit: int) -> list[Message]:
        """The whole thread, the desk's notes included, the oldest first."""
        ...

    @abstractmethod
    async def create_message(self, ctx: OpContext, message: Message) -> Message:
        """A reply to the source or an internal note; a rerun under the same id returns it as stored."""
        ...

    # --- a signed-in reader who sends a report under their name

    @abstractmethod
    async def submit_named_report(
        self,
        ctx: OpContext,
        report: SealedReport,
        recipients: tuple[Recipient, ...],
        reply_secret: str,
    ) -> list[Submission]:
        """The intake, with the sender taken from the context and shown to the recipient desks alone."""
        ...

    # --- the request stage: the desk's public intake and the source's side of the thread (ADR 0009)

    @abstractmethod
    async def submit_report(
        self,
        rctx: RequestContext,
        report: SealedReport,
        recipients: tuple[Recipient, ...],
        reply_secret: str,
    ) -> list[Submission]:
        """Stores the ciphertext once and one submission per recipient, each a published profile with a public key;
        a rerun under the same ids returns them as stored. Names no sender."""
        ...

    @abstractmethod
    async def get_source_thread(
        self, rctx: RequestContext, org_id: UUID, submission_id: UUID, reply_secret: str
    ) -> SourceThread:
        """What the source reads with its secret; NotFound for a wrong secret as for a missing submission."""
        ...

    @abstractmethod
    async def post_source_message(
        self, rctx: RequestContext, org_id: UUID, submission_id: UUID, reply_secret: str, message: Message
    ) -> Message:
        """The source's answer on the thread; a rerun under the same id returns it as stored."""
        ...
