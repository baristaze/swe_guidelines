# Outbox

**Nouns.** An **outbox row** is the note a change leaves behind, written together with the change itself: this thing
changed, or this work must now be done.

**What can happen.** Right after the change, the note is carried on: it becomes an event, and screens are told. If
carrying it fails, or the platform stops at the wrong moment, the note waits and is carried later. Once carried, it
is kept for a while, then cleared.

**Rules that hold.**

- A change and its note are saved together or not at all, so nothing a change sets off can be forgotten.
- Carrying a note twice has the same effect as carrying it once.
- A note names things by their ids only, never a person's details.
