"""The root of the object model: the root class, the mixins, and the helpers every constructor needs."""

import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from types import MappingProxyType
from typing import Annotated, Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, PlainSerializer, PlainValidator


def new_id() -> UUID:
    """A time-ordered UUID v7 as a standard-library UUID."""
    return uuid.uuid7()


def utcnow() -> datetime:
    return datetime.now(UTC)


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(k): _freeze(v) for k, v in value.items()})
    if isinstance(value, list | tuple):
        return tuple(_freeze(v) for v in value)
    return value


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {k: _thaw(v) for k, v in value.items()}
    if isinstance(value, tuple | list):
        return [_thaw(v) for v in value]
    return value


def _validate_mapping(value: Any) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError("a mapping is required")
    return _freeze(value)


# A mapping field: a read-only proxy that descends into nested mappings and lists, dumped as a plain dict.
FrozenMapping = Annotated[
    Mapping[str, Any],
    PlainValidator(_validate_mapping),
    PlainSerializer(_thaw),
]


class Platform(BaseModel):
    """Root of the object model. Holds no fields."""

    model_config = ConfigDict(frozen=True, extra="forbid")


class Identifiable(Platform):
    id: UUID  # uuid_v7, from new_id()


class Named(Platform):
    name: str


class Created(Platform):
    created_at: datetime


class Trackable(Created):
    updated_at: datetime
    created_by: UUID  # id of the user who created it
    updated_by: UUID  # id of the user who last changed it


class SoftDeletable(Platform):
    deleted_at: datetime | None = None
    deleted_by: UUID | None = None


PROVENANCE_FIELDS = frozenset({"created_at", "created_by", "deleted_at", "deleted_by"})  # stay as stored on update
# Beside it, each entity declares MANAGER_OWNED_FIELDS: the fields its manager sets and a caller never writes.

EMPTY_UUID = UUID(int=0)
