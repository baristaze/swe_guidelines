"""The audit manager impl."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.audit.manager import AuditManagerInterface
from acme.om.audit.storage import AuditStorageInterface
from acme.om.audit.types import AuditEntry
from acme.om.base import FrozenMapping, new_id
from acme.om.opcontext import OpContext, OperatorContext, OperatorPermission, Permission


@dataclass(frozen=True)
class AuditOptions:
    page_size: int


class AuditManagerImpl(AuditManagerInterface):
    def __init__(self, storage: AuditStorageInterface, options: AuditOptions) -> None:
        self._storage = storage
        self._options = options

    async def record(self, ctx: OpContext, kind: str, target_id: UUID, payload: FrozenMapping) -> AuditEntry:
        ctx.require(Permission.READ)  # every member's own action is recorded, a viewer's reads included
        entry = AuditEntry(
            id=new_id(),
            seq=0,
            kind=kind,
            target_id=target_id,
            actor_id=ctx.user_id,
            payload=payload,
            request_id=ctx.request_id,
            app=ctx.app,
        )
        return await self._storage.append_audit_entry(ctx.org_id, entry)

    async def record_for_operator(
        self, octx: OperatorContext, org_id: UUID, kind: str, target_id: UUID, payload: FrozenMapping
    ) -> AuditEntry:
        octx.require(OperatorPermission.READ)
        entry = AuditEntry(
            id=new_id(),
            seq=0,
            kind=kind,
            target_id=target_id,
            actor_id=octx.identity_id,
            payload={**payload, "operator": True},
            request_id=octx.request_id,
            app=octx.app,
        )
        return await self._storage.append_audit_entry(org_id, entry)

    async def get_audit_entries(self, ctx: OpContext, after_seq: int, limit: int) -> list[AuditEntry]:
        ctx.require(Permission.READ_AUDIT)
        return await self._storage.read_after(ctx.org_id, after_seq, max(1, min(limit, self._options.page_size)))
