"""The work queue in memory: the same contract over a dict and the loop's atomicity."""

from datetime import datetime
from uuid import UUID

from acme.om.base import EMPTY_UUID
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase
from acme.om.storage.root import InsertOutcome
from acme.om.work.storage import WorkStorageInterface
from acme.om.work.types.receipt import WorkReceipt
from acme.om.work.types.work_item import WorkGauges, WorkItem, WorkKind, WorkStatus


class WorkStorageMemoryImpl(MemoryStorageBase, WorkStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._items: dict[UUID, tuple[UUID, WorkItem]] = {}
        self._receipts: dict[UUID, tuple[UUID, WorkReceipt]] = {}

    async def create_item(self, org_id: UUID, item: WorkItem) -> InsertOutcome:
        """The insert that reports which key collided; nothing changes on a collision."""
        if item.id in self._items:
            return InsertOutcome.ID_EXISTS
        if any(o == org_id and i.idempotency_key == item.idempotency_key for o, i in self._items.values()):
            return InsertOutcome.KEY_EXISTS
        self._items[item.id] = (org_id, item)
        return InsertOutcome.INSERTED

    async def read_item(self, org_id: UUID, item_id: UUID) -> WorkItem | None:
        found = self._items.get(item_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def read_item_by_key(self, org_id: UUID, idempotency_key: UUID) -> WorkItem | None:
        return next((i for o, i in self._items.values() if o == org_id and i.idempotency_key == idempotency_key), None)

    async def write_item(self, org_id: UUID, item: WorkItem, claim_token: UUID) -> bool:
        """Writes only while the row still carries `claim_token`; False means another holder has it now."""
        found = self._items.get(item.id)
        if found is None or found[0] != org_id or found[1].claim_token != claim_token:
            return False
        self._items[item.id] = (org_id, item)
        return True

    async def requeue_stale(self, org_id: UUID, before: datetime, limit: int, now: datetime) -> int:
        """Hands back the tenant's claimed items whose lease passed before `before`, at most `limit`."""
        stale = [
            i
            for o, i in self._items.values()
            if o == org_id
            and i.status == WorkStatus.CLAIMED
            and i.lease_expires_at is not None
            and i.lease_expires_at < before
        ][:limit]
        for item in stale:
            self._items[item.id] = (
                org_id,
                item.model_copy(
                    update={
                        "status": WorkStatus.QUEUED,
                        "claimed_by": None,
                        "claim_token": None,
                        "lease_expires_at": None,
                        "available_at": now,
                        "updated_at": now,
                        "updated_by": EMPTY_UUID,
                    }
                ),
            )
        return len(stale)

    async def claim_next(
        self,
        lane: str,
        kinds: tuple[WorkKind, ...],
        worker_id: str,
        claim_token: UUID,
        lease_until: datetime,
        now: datetime,
    ) -> tuple[UUID, WorkItem] | None:
        """Tenant-less, named atomic: the oldest available item of the lane across tenants, locked past the others,
        stamped with the claim and the lease in the same statement; the tenant travels back beside the row."""
        ready = [
            (o, i)
            for o, i in self._items.values()
            if i.lane == lane and i.status == WorkStatus.QUEUED and i.available_at <= now and i.kind in kinds
        ]
        if not ready:
            return None
        org_id, item = min(ready, key=lambda pair: (pair[1].available_at, pair[1].id.int))
        claimed = item.model_copy(
            update={
                "status": WorkStatus.CLAIMED,
                "claimed_by": worker_id,
                "claim_token": claim_token,
                "lease_expires_at": lease_until,
                "updated_at": now,
                "updated_by": EMPTY_UUID,
            }
        )
        self._items[item.id] = (org_id, claimed)
        return org_id, claimed

    async def fail_orphaned(self, item_id: UUID, claim_token: UUID, error: str, now: datetime) -> bool:
        """Tenant-less: fails an item whose tenant is gone, conditional on the token, needing no stage."""
        found = self._items.get(item_id)
        if found is None or found[1].claim_token != claim_token:
            return False
        failed = found[1].model_copy(
            update={"status": WorkStatus.FAILED, "last_error": error[:500], "updated_at": now, "updated_by": EMPTY_UUID}
        )
        self._items[item_id] = (found[0], failed)
        return True

    async def read_gauges(self) -> WorkGauges:
        """Tenant-less: the oldest waiting item and the count of failed items, across tenants."""
        waiting = [i.available_at for _, i in self._items.values() if i.status == WorkStatus.QUEUED]
        failed = sum(1 for _, i in self._items.values() if i.status == WorkStatus.FAILED)
        return WorkGauges(oldest_waiting_at=min(waiting, default=None), failed=failed)

    async def purge_items(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges done and failed items last touched before `before`, across tenants, at most `limit`."""
        doomed = [
            i.id
            for _, i in self._items.values()
            if i.status in (WorkStatus.DONE, WorkStatus.FAILED) and i.updated_at < before
        ][:limit]
        for item_id in doomed:
            del self._items[item_id]
        return len(doomed)

    async def create_receipt(self, org_id: UUID, receipt: WorkReceipt) -> bool:
        if receipt.id in self._receipts:
            return False
        self._receipts[receipt.id] = (org_id, receipt)
        return True

    async def read_receipt(self, org_id: UUID, receipt_id: UUID) -> WorkReceipt | None:
        found = self._receipts.get(receipt_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def purge_receipts(self, before: datetime, limit: int) -> int:
        doomed = [r.id for _, r in self._receipts.values() if r.created_at < before][:limit]
        for receipt_id in doomed:
            del self._receipts[receipt_id]
        return len(doomed)
