-- The core role's first migration: its schema, the two logins' grants, the tenancy tables,
-- the outbox, and the idempotency marker, each tenant table with its policy.

CREATE SCHEMA IF NOT EXISTS core;
GRANT USAGE ON SCHEMA core TO acme_runtime, acme_system;
ALTER DEFAULT PRIVILEGES IN SCHEMA core GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO acme_runtime, acme_system;

-- api_keys: org scope
CREATE TABLE core.api_keys (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    issued_by UUID NOT NULL,
    digest VARCHAR NOT NULL,
    role VARCHAR NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    revoked_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_api_keys PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_api_keys_digest ON core.api_keys (digest);
CREATE INDEX ix_api_keys_org_id_issued_by ON core.api_keys (org_id, issued_by);
CREATE POLICY tenant_fence ON core.api_keys
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.api_keys ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.api_keys FORCE ROW LEVEL SECURITY;

-- idempotency_markers: org scope
CREATE TABLE core.idempotency_markers (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    user_id UUID NOT NULL,
    key VARCHAR NOT NULL,
    request_digest VARCHAR NOT NULL,
    target_id UUID NOT NULL,
    attempt_token UUID,
    status INTEGER,
    body VARCHAR,
    CONSTRAINT pk_idempotency_markers PRIMARY KEY (id)
);
CREATE INDEX ix_idempotency_markers_created_at ON core.idempotency_markers (created_at);
CREATE UNIQUE INDEX ix_idempotency_markers_org_id_user_id_key ON core.idempotency_markers (org_id, user_id, key);
CREATE POLICY tenant_fence ON core.idempotency_markers
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.idempotency_markers ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.idempotency_markers FORCE ROW LEVEL SECURITY;

-- identities: identity scope
CREATE TABLE core.identities (
    id UUID NOT NULL,
    identity_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    email VARCHAR NOT NULL,
    email_digest VARCHAR NOT NULL,
    display_name VARCHAR NOT NULL,
    password_hash VARCHAR,
    totp_secret VARCHAR,
    totp_confirmed_at TIMESTAMP WITH TIME ZONE,
    totp_last_step INTEGER,
    issuer VARCHAR,
    subject VARCHAR,
    CONSTRAINT pk_identities PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_identities_email_digest ON core.identities (email_digest);
CREATE INDEX ix_identities_identity_id ON core.identities (identity_id);
CREATE UNIQUE INDEX ix_identities_issuer_subject ON core.identities (issuer, subject);
CREATE POLICY tenant_fence ON core.identities
    FOR ALL
    USING (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.identities ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.identities FORCE ROW LEVEL SECURITY;

-- identity_memberships: identity scope
CREATE TABLE core.identity_memberships (
    id UUID NOT NULL,
    identity_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    tenant_id UUID NOT NULL,
    user_id UUID NOT NULL,
    role VARCHAR NOT NULL,
    CONSTRAINT pk_identity_memberships PRIMARY KEY (id)
);
CREATE INDEX ix_identity_memberships_identity_id ON core.identity_memberships (identity_id);
CREATE UNIQUE INDEX ix_identity_memberships_identity_id_org_id ON core.identity_memberships (identity_id, tenant_id);
CREATE POLICY tenant_fence ON core.identity_memberships
    FOR ALL
    USING (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.identity_memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.identity_memberships FORCE ROW LEVEL SECURITY;

-- memberships: org scope
CREATE TABLE core.memberships (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    user_id UUID NOT NULL,
    role VARCHAR NOT NULL,
    CONSTRAINT pk_memberships PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_memberships_org_id_user_id ON core.memberships (org_id, user_id);
CREATE POLICY tenant_fence ON core.memberships
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.memberships FORCE ROW LEVEL SECURITY;

-- operators: system scope
CREATE TABLE core.operators (
    id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    identity_id UUID NOT NULL,
    permission VARCHAR NOT NULL,
    disabled_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_operators PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_operators_identity_id ON core.operators (identity_id);

-- orgs: system scope
CREATE TABLE core.orgs (
    id UUID NOT NULL,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE,
    deleted_by UUID,
    slug VARCHAR NOT NULL,
    provisioned_by UUID,
    CONSTRAINT pk_orgs PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_orgs_slug ON core.orgs (slug) WHERE deleted_at IS NULL;

-- outbox: org scope
CREATE TABLE core.outbox (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    kind VARCHAR NOT NULL,
    target_id UUID NOT NULL,
    payload JSONB NOT NULL,
    actor_id UUID NOT NULL,
    request_id UUID NOT NULL,
    traceparent VARCHAR,
    app JSONB NOT NULL,
    done_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_outbox PRIMARY KEY (id)
);
CREATE INDEX ix_outbox_org_id ON core.outbox (org_id);
CREATE INDEX ix_outbox_pending ON core.outbox (created_at) WHERE done_at IS NULL;
CREATE POLICY tenant_fence ON core.outbox
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.outbox FORCE ROW LEVEL SECURITY;

-- sessions: identity scope
CREATE TABLE core.sessions (
    id UUID NOT NULL,
    identity_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    kind VARCHAR NOT NULL,
    tenant_id UUID NOT NULL,
    user_id UUID,
    permission VARCHAR,
    digest VARCHAR NOT NULL,
    second_factor BOOLEAN NOT NULL,
    last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ended_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_sessions PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_sessions_digest ON core.sessions (digest);
CREATE INDEX ix_sessions_expires_at ON core.sessions (expires_at);
CREATE INDEX ix_sessions_identity_id ON core.sessions (identity_id);
CREATE POLICY tenant_fence ON core.sessions
    FOR ALL
    USING (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.sessions FORCE ROW LEVEL SECURITY;

-- sign_in_failures: system scope
CREATE TABLE core.sign_in_failures (
    id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    email_digest VARCHAR NOT NULL,
    failures INTEGER NOT NULL,
    retry_at TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT pk_sign_in_failures PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_sign_in_failures_email_digest ON core.sign_in_failures (email_digest);

-- socket_tickets: identity scope
CREATE TABLE core.socket_tickets (
    id UUID NOT NULL,
    identity_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    tenant_id UUID NOT NULL,
    user_id UUID NOT NULL,
    credential_kind VARCHAR NOT NULL,
    credential_id UUID NOT NULL,
    digest VARCHAR NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    redeemed_at TIMESTAMP WITH TIME ZONE,
    CONSTRAINT pk_socket_tickets PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_socket_tickets_digest ON core.socket_tickets (digest);
CREATE INDEX ix_socket_tickets_expires_at ON core.socket_tickets (expires_at);
CREATE INDEX ix_socket_tickets_identity_id ON core.socket_tickets (identity_id);
CREATE POLICY tenant_fence ON core.socket_tickets
    FOR ALL
    USING (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (identity_id = NULLIF(current_setting('app.identity_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.socket_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.socket_tickets FORCE ROW LEVEL SECURITY;

-- users: org scope
CREATE TABLE core.users (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    name VARCHAR NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    identity_id UUID NOT NULL,
    CONSTRAINT pk_users PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_users_org_id_identity_id ON core.users (org_id, identity_id);
CREATE POLICY tenant_fence ON core.users
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.users FORCE ROW LEVEL SECURITY;
