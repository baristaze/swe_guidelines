"""The storage contract cases: plain modules both suites run, over memory and over Postgres."""
