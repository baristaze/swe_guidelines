"""The journalists manager impl."""
