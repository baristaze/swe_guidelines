"""The relay impl: dispatches on the row's kind and marks the row done only when its side effect happened."""

import logging
from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from uuid import UUID

from acme.infra.topics import EntityChangedPayload, Topics, TopicsInterface
from acme.om.base import new_id, utcnow
from acme.om.events.manager import EventsManagerInterface
from acme.om.opcontext import RequestContext
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.storage import OutboxStorageInterface
from acme.om.outbox.types import WORK_KIND_PREFIX, OutboxRow
from acme.om.work.manager import WorkManagerInterface

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class OutboxOptions:
    retention: timedelta  # a done row is kept past the backup schedule of the roles it feeds
    purge_batch: int


class OutboxRelayImpl(OutboxRelayInterface):
    def __init__(
        self,
        storage: OutboxStorageInterface,
        events: EventsManagerInterface,
        topics: TopicsInterface,
        options: OutboxOptions,
        work: Callable[[], WorkManagerInterface],
    ) -> None:
        self._work = work
        self._storage = storage
        self._events = events
        self._topics = topics
        self._options = options

    async def relay(self, org_id: UUID, row: OutboxRow) -> bool:
        try:
            if row.kind.startswith(WORK_KIND_PREFIX):
                # A work row is done once its item is queued; the WORK_AVAILABLE wake-up is only a hint.
                await self._work().enqueue_relayed(org_id, row)
                await self._storage.mark_done(org_id, row.id, utcnow())
                return True
            event = await self._events.append_relayed(org_id, row)
            taken = await self._topics.publish(
                Topics.ENTITY_CHANGED,
                EntityChangedPayload(
                    idempotency_key=new_id(),
                    produced_at=utcnow(),
                    org_id=org_id,
                    kind=event.kind,
                    target_id=event.target_id,
                    seq=event.seq,
                    actor_id=event.actor_id,
                    version=event.version,
                ),
            )
            if not taken:
                logger.info(
                    "the bus refused a publish; the row stays pending for the sweep", extra={"row_id": str(row.id)}
                )
                return False
            await self._storage.mark_done(org_id, row.id, utcnow())
            return True
        except Exception:
            # The write committed before the relay ran; a failure is left to the sweep and never raised.
            logger.exception("relay failed; the sweep will relay the row", extra={"row_id": str(row.id)})
            return False

    async def relay_pending(self, rctx: RequestContext, limit: int) -> int:
        relayed = 0
        for row in await self._storage.read_pending(limit):
            if await self.relay(row.org_id, row):
                relayed += 1
        return relayed

    async def purge_done(self, rctx: RequestContext) -> int:
        return await self._storage.purge_done(utcnow() - self._options.retention, self._options.purge_batch)

    async def read_lag(self, rctx: RequestContext) -> timedelta:
        oldest = await self._storage.read_oldest_pending()
        return timedelta(0) if oldest is None else max(timedelta(0), utcnow() - oldest)
