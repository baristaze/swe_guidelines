"""The follows manager: the swimlane of the journalists a reader follows from their own account."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.follows.types.follow import Follow
from acme.om.opcontext import OpContext


class FollowsManagerInterface(ABC):
    @abstractmethod
    async def get_follows(self, ctx: OpContext, limit: int) -> list[Follow]: ...

    @abstractmethod
    async def get_follow(self, ctx: OpContext, follow_id: UUID) -> Follow:
        """Raises NotFound for an id the account does not hold, or an ended follow."""
        ...

    @abstractmethod
    async def create_follow(self, ctx: OpContext, follow: Follow) -> Follow:
        """Follows a published journalist; a rerun under the same id, or a second follow of the same journalist,
        returns the follow as stored. NotFound when the journalist is not published."""
        ...

    @abstractmethod
    async def delete_follow(self, ctx: OpContext, follow_id: UUID) -> None:
        """Unfollows: a soft delete; the follow leaves every list, and a later follow is a new one."""
        ...
