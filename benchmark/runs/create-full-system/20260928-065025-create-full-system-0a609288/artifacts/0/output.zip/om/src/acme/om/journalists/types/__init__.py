"""One module per entity of the journalists namespace."""
