-- Each recipient desk's submissions, org scope (the desk's tenant).

-- submissions: org scope
CREATE TABLE core.submissions (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_by UUID NOT NULL,
    updated_by UUID NOT NULL,
    report_id UUID NOT NULL,
    journalist_id UUID NOT NULL,
    wrapped_key VARCHAR NOT NULL,
    source_public_key VARCHAR NOT NULL,
    reply_digest VARCHAR NOT NULL,
    sender_user_id UUID,
    sender_org_id UUID,
    sender_name VARCHAR,
    contact_email VARCHAR,
    state VARCHAR NOT NULL,
    tags VARCHAR[] NOT NULL,
    CONSTRAINT pk_submissions PRIMARY KEY (id)
);
CREATE INDEX ix_submissions_org_id_id ON core.submissions (org_id, id);
CREATE POLICY tenant_fence ON core.submissions
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.submissions FORCE ROW LEVEL SECURITY;
