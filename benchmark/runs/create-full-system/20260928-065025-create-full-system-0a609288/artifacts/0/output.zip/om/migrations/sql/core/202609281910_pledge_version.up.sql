-- The pledge's compare-and-set version: every transition writes only while the row carries the version it read.

ALTER TABLE core.pledges ADD COLUMN version INTEGER NOT NULL DEFAULT 1;
ALTER TABLE core.pledges ALTER COLUMN version DROP DEFAULT;
