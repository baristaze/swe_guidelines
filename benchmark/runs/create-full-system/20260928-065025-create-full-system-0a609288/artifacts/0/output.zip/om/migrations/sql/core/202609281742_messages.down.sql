-- Reverses 202609281742_messages.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.messages;
DROP TABLE IF EXISTS core.messages;
