# Follows

A reader keeps up with journalists by **following** them. This page says what a follow is and what can happen to
it. It sits one level below [the object model](../../../../README.md).

## A follow

A **follow** is a reader's account following one journalist of one desk. It is free, and it is the reader's own:
it belongs to the reader's account, never to the desk.

- A reader follows only a journalist the desk has published.
- An account follows a journalist once; following again while the follow stands changes nothing.

## What can happen to it

- **Listed**: the account sees the journalists it follows, and the updates they publish.
- **Added**: anyone on the account who can write follows a published journalist.
- **Ended**: the reader unfollows. The follow leaves every list at once; following again later starts a new one.

## Rules that hold

- Following needs no payment, and supporting a journalist or sending them information never needs a follow.
- Every change is numbered in the account's events. The event names the follow, never the journalist's name.
