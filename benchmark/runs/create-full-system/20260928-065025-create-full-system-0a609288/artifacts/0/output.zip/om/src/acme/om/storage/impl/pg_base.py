"""The Postgres base every namespace storage shares: one session funnel and the two write primitives.

`_session_for` routes a statement to its role, picks the system login's engine for the system scope
and the runtime login's otherwise, and sets the scope with `set_config(..., true)` so it dies with the
transaction. Nothing below assumes the database policy is there: every query carries its own predicate.
"""

from collections.abc import AsyncIterator, Sequence
from contextlib import asynccontextmanager
from typing import Any, TypeVar, cast
from uuid import UUID

from pydantic import BaseModel
from sqlalchemy import Table, insert, select, text
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.sql import Executable

from acme.om.base import EMPTY_UUID
from acme.om.exceptions import Conflict
from acme.om.outbox.storage.tables.outbox import Outbox
from acme.om.outbox.types import OutboxRow
from acme.om.storage.roles import DatabaseRole
from acme.om.storage.root import InsertOutcome
from acme.om.storage.settings import StorageSettings
from acme.om.storage.tables.base import Base
from acme.om.storage.utils.translation import apply_row, to_model, to_row, to_values

M = TypeVar("M", bound=BaseModel)


def async_url(url: str) -> str:
    """The runtime driver's spelling of a plain `postgresql://` URL."""
    return url.replace("postgresql://", "postgresql+asyncpg://", 1) if url.startswith("postgresql://") else url


class PgSessions:
    """One engine and pool per distinct URL, runtime and system login per role, each bounded from settings."""

    def __init__(self, settings: StorageSettings) -> None:
        self._settings = settings
        self._engines: dict[str, AsyncEngine] = {}
        self._makers: dict[tuple[DatabaseRole, bool], async_sessionmaker[AsyncSession]] = {}
        for role in DatabaseRole:
            for system in (False, True):
                url = settings.system_url(role) if system else settings.runtime_url(role)
                if url not in self._engines:
                    self._engines[url] = create_async_engine(
                        async_url(url),
                        pool_size=settings.pool_size(role),
                        pool_timeout=settings.pool_checkout_timeout(role),
                        pool_pre_ping=True,
                    )
                self._makers[(role, system)] = async_sessionmaker(self._engines[url], expire_on_commit=False)

    def maker(self, role: DatabaseRole, system: bool) -> async_sessionmaker[AsyncSession]:
        return self._makers[(role, system)]

    def statement_timeout_ms(self, role: DatabaseRole) -> int:
        return int(self._settings.statement_timeout(role) * 1000)

    def engines(self) -> list[AsyncEngine]:
        return list(self._engines.values())

    async def dispose(self) -> None:
        for engine in self._engines.values():
            await engine.dispose()


def _schemas(target: Any) -> set[str]:
    if isinstance(target, type) and issubclass(target, Base):
        return {target.__table__.schema or ""}
    if isinstance(target, Table):
        return {target.schema or ""}
    table = getattr(target, "table", None)
    if isinstance(table, Table):
        return {table.schema or ""}
    froms = target.get_final_froms() if hasattr(target, "get_final_froms") else []
    found: set[str] = set()
    for f in froms:
        for t in getattr(f, "_from_objects", [f]):
            schema = getattr(t, "schema", None)
            if schema:
                found.add(schema)
    return found


class PgStorageBase:
    def __init__(self, sessions: PgSessions) -> None:
        self._sessions = sessions

    @staticmethod
    def _role_of(stmt: Any) -> DatabaseRole:
        schemas = _schemas(stmt)
        if len(schemas) != 1:
            raise ValueError(f"a statement touches exactly one role; this one touches {sorted(schemas)}")
        return DatabaseRole(schemas.pop())

    @asynccontextmanager
    async def _session_for(
        self,
        stmt: Executable | type[Base],
        *,
        org_id: UUID | None = None,
        user_id: UUID | None = None,
        identity_id: UUID | None = None,
    ) -> AsyncIterator[AsyncSession]:
        role = self._role_of(stmt)
        maker = self._sessions.maker(role, system=org_id == EMPTY_UUID)
        async with maker() as session, session.begin():
            settings = {"statement_timeout": str(self._sessions.statement_timeout_ms(role))}
            if org_id is not None:
                settings["app.org_id"] = str(org_id)
            if user_id is not None:
                settings["app.user_id"] = str(user_id)
            if identity_id is not None:
                settings["app.identity_id"] = str(identity_id)
            for name, value in settings.items():
                await session.execute(text("SELECT set_config(:name, :value, true)"), {"name": name, "value": value})
            yield session

    async def _read_one(
        self,
        stmt: Any,
        model: type[M],
        *,
        org_id: UUID | None = None,
        user_id: UUID | None = None,
        identity_id: UUID | None = None,
    ) -> M | None:
        async with self._session_for(stmt, org_id=org_id, user_id=user_id, identity_id=identity_id) as session:
            row = (await session.execute(stmt)).scalars().first()
            return None if row is None else to_model(row, model)

    async def _read_all(
        self,
        stmt: Any,
        model: type[M],
        *,
        org_id: UUID | None = None,
        user_id: UUID | None = None,
        identity_id: UUID | None = None,
    ) -> list[M]:
        async with self._session_for(stmt, org_id=org_id, user_id=user_id, identity_id=identity_id) as session:
            return [to_model(r, model) for r in (await session.execute(stmt)).scalars()]

    async def _returned(
        self,
        stmt: Any,
        *,
        org_id: UUID | None = None,
        user_id: UUID | None = None,
        identity_id: UUID | None = None,
    ) -> int:
        """Runs a statement with a RETURNING clause and answers how many rows it touched."""
        async with self._session_for(stmt, org_id=org_id, user_id=user_id, identity_id=identity_id) as session:
            return len((await session.execute(stmt)).all())

    @staticmethod
    async def _land(session: AsyncSession, outbox_rows: Sequence[OutboxRow]) -> None:
        if outbox_rows:
            await session.execute(insert(Outbox), [to_values(r, Outbox) for r in outbox_rows])

    @staticmethod
    def _tenant_predicates(table: type[Base], org_id: UUID | None, identity_id: UUID | None) -> list[Any]:
        columns = table.__table__.columns
        out: list[Any] = []
        if org_id is not None and org_id != EMPTY_UUID and "org_id" in columns:
            out.append(columns["org_id"] == org_id)
        if identity_id is not None and "identity_id" in columns:
            out.append(columns["identity_id"] == identity_id)
        return out

    async def _insert(
        self,
        table: type[Base],
        entity: BaseModel,
        outbox_rows: Sequence[OutboxRow] = (),
        *,
        org_id: UUID | None = None,
        user_id: UUID | None = None,
        identity_id: UUID | None = None,
        extra: dict[str, Any] | None = None,
    ) -> InsertOutcome:
        """Insert unless the id or a unique key is held; the outbox rows land only when the insert won."""
        values = to_values(entity, table, **_scope_columns(table, org_id, identity_id, extra))
        stmt = pg_insert(table).values(**values).on_conflict_do_nothing().returning(table.__table__.c.id)
        async with self._session_for(stmt, org_id=org_id, user_id=user_id, identity_id=identity_id) as session:
            inserted = (await session.execute(stmt)).scalar_one_or_none()
            if inserted is not None:
                await self._land(session, outbox_rows)
                return InsertOutcome.INSERTED
            found = await session.execute(select(table.__table__.c.id).where(table.__table__.c.id == values["id"]))
            if found.scalar_one_or_none() is not None:
                return InsertOutcome.ID_EXISTS
            has_other_keys = any(ix.unique for ix in cast(Table, table.__table__).indexes)
            return InsertOutcome.KEY_EXISTS if has_other_keys else InsertOutcome.ID_EXISTS

    async def _upsert(
        self,
        table: type[Base],
        entity: BaseModel,
        outbox_rows: Sequence[OutboxRow] = (),
        *,
        org_id: UUID | None = None,
        user_id: UUID | None = None,
        identity_id: UUID | None = None,
        extra: dict[str, Any] | None = None,
    ) -> None:
        """Apply the entity onto its row under the call's tenant, or insert it; another tenant's id is a Conflict."""
        entity_id = cast(Any, entity).id
        stmt = select(table).where(
            table.__table__.c.id == entity_id, *self._tenant_predicates(table, org_id, identity_id)
        )
        try:
            async with self._session_for(stmt, org_id=org_id, user_id=user_id, identity_id=identity_id) as session:
                row = (await session.execute(stmt)).scalar_one_or_none()
                if row is None:
                    session.add(to_row(entity, table, **_scope_columns(table, org_id, identity_id, extra)))
                else:
                    apply_row(row, entity)
                    for name, value in (extra or {}).items():
                        setattr(row, name, value)
                await session.flush()
                await self._land(session, outbox_rows)
        except IntegrityError as exc:
            raise Conflict("the row is held under another key") from exc


def _scope_columns(
    table: type[Base], org_id: UUID | None, identity_id: UUID | None, extra: dict[str, Any] | None
) -> dict[str, Any]:
    columns = table.__table__.columns
    out: dict[str, Any] = dict(extra or {})
    if org_id is not None and "org_id" in columns and "org_id" not in out:
        out["org_id"] = org_id
    if identity_id is not None and "identity_id" in columns and "identity_id" not in out:
        out["identity_id"] = identity_id
    return out
