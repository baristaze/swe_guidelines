"""The work queue: durable background work as rows, claimed by workers and fenced by a claim token."""

from acme.om.work.manager import WorkManagerInterface

__all__ = ["WorkManagerInterface"]
