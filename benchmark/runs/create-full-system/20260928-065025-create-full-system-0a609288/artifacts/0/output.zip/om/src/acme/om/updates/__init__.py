"""The updates swimlane: the short updates a desk publishes to the readers who follow its journalists."""

from acme.om.updates.manager import UpdatesManagerInterface

__all__ = ["UpdatesManagerInterface"]
