"""The transactional outbox: the row that announces a write, and the relay that carries it on."""

from acme.om.outbox.manager import OutboxRelayInterface

__all__ = ["OutboxRelayInterface"]
