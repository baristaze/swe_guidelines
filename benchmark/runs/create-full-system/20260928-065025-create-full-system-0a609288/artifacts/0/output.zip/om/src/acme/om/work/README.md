# Work

**Nouns.** A **work item** is a piece of background work the platform owes: what to do (its **kind**), for which
record, asked for by whom, under which request. Its **status** is `queued`, `claimed`, `done`, or `failed`. There are
three kinds: `NOOP`, which the maintenance worker handles by doing nothing; `APPEND_CONTRIBUTION`, which the
maintenance worker handles by recording a settled pledge's contribution at its desk; and `SEND_NOTIFICATION`, which
the notifier worker handles by sending the one message a change owes someone (a desk told a report arrived or a source
answered, a source told a journalist replied, a supporter sent a receipt), never with a report's content. A
**receipt** records that one outside effect of an item happened (one message sent to one address), so a replayed item
skips what it already did.

**What can happen.** An item is **enqueued**, by a person's request or as the second note a change leaves; a worker
**claims** it and holds it for a while (its **lease**), renewing the lease while it works; it **completes** it, or
**defers** it for later, or **releases** it untouched, or it fails, and the item is **requeued** after a growing
wait, until its last attempt fails for good and it becomes a **dead letter**, recorded in the audit trail.

**Rules that hold.**

- One holder per claim. A worker whose hold has passed to another cannot complete, fail, or renew the item.
- Asking twice for the same work (the same key) creates one item.
- A failure at the last attempt is final, recorded, and counted.
- The work runs on the platform's authority and in the name of the person who asked for it.
