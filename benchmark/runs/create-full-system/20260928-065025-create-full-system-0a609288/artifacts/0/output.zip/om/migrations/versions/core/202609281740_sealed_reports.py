"""The sealed reports: the one ciphertext of each report, system scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281740"
down_revision = "202609281730"


def upgrade() -> None:
    run_sql("core", "202609281740_sealed_reports.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281740_sealed_reports.down.sql")
