-- The contributions a desk received, append-only, org scope (the desk's tenant).

-- contributions: org scope
CREATE TABLE activity.contributions (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    journalist_id UUID NOT NULL,
    pledge_id UUID NOT NULL,
    supporter_org_id UUID NOT NULL,
    supporter_name VARCHAR NOT NULL,
    amount_minor INTEGER NOT NULL,
    currency VARCHAR NOT NULL,
    mode VARCHAR NOT NULL,
    platform_fee_minor INTEGER NOT NULL,
    received_at TIMESTAMP WITH TIME ZONE NOT NULL,
    CONSTRAINT pk_contributions PRIMARY KEY (id)
);
CREATE INDEX ix_contributions_org_id_id ON activity.contributions (org_id, id);
CREATE POLICY tenant_fence ON activity.contributions
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE activity.contributions ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity.contributions FORCE ROW LEVEL SECURITY;
