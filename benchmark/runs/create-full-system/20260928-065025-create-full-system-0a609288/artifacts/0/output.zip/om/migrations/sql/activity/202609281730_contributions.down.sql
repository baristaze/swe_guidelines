-- Reverses 202609281730_contributions.up.sql.

DROP POLICY IF EXISTS tenant_fence ON activity.contributions;
DROP TABLE IF EXISTS activity.contributions;
