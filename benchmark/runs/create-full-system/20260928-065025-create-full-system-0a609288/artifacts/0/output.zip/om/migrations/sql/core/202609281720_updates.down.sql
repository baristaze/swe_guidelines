-- Reverses 202609281720_updates.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.updates;
DROP TABLE IF EXISTS core.updates;
