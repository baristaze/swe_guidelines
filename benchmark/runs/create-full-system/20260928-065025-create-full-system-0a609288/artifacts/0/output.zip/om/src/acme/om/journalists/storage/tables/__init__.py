"""One module per table of the journalists namespace."""
