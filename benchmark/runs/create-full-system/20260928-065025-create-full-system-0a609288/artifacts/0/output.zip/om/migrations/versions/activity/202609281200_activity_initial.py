"""The activity role's first migration: its schema, the two logins' grants, the event stream."""

from acme.om.storage.migrate import run_sql

revision = "202609281200"
down_revision = None


def upgrade() -> None:
    run_sql("activity", "202609281200_activity_initial.up.sql")


def downgrade() -> None:
    run_sql("activity", "202609281200_activity_initial.down.sql")
