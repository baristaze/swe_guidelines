"""The storage root over Postgres: one engine per distinct URL, every namespace storage built whole at construction."""

from sqlalchemy import text

from acme.om.audit.storage import AuditStorageInterface
from acme.om.audit.storage.impl.postgres import AuditStoragePostgresImpl
from acme.om.events.storage import EventsStorageInterface
from acme.om.events.storage.impl.postgres import EventsStoragePostgresImpl
from acme.om.follows.storage import FollowsStorageInterface
from acme.om.follows.storage.impl.postgres import FollowsStoragePostgresImpl
from acme.om.idempotency.storage import IdempotencyStorageInterface
from acme.om.idempotency.storage.impl.postgres import IdempotencyStoragePostgresImpl
from acme.om.journalists.storage import JournalistsStorageInterface
from acme.om.journalists.storage.impl.postgres import JournalistsStoragePostgresImpl
from acme.om.outbox.storage import OutboxStorageInterface
from acme.om.outbox.storage.impl.postgres import OutboxStoragePostgresImpl
from acme.om.reports.storage import ReportsStorageInterface
from acme.om.reports.storage.impl.postgres import ReportsStoragePostgresImpl
from acme.om.storage.impl.pg_base import PgSessions
from acme.om.storage.root import StorageInterface
from acme.om.storage.settings import StorageSettings
from acme.om.support.storage import SupportStorageInterface
from acme.om.support.storage.impl.postgres import SupportStoragePostgresImpl
from acme.om.tenancy.storage import TenancyStorageInterface
from acme.om.tenancy.storage.impl.postgres import TenancyStoragePostgresImpl
from acme.om.updates.storage import UpdatesStorageInterface
from acme.om.updates.storage.impl.postgres import UpdatesStoragePostgresImpl
from acme.om.work.storage import WorkStorageInterface
from acme.om.work.storage.impl.postgres import WorkStoragePostgresImpl


class StoragePostgresImpl(StorageInterface):
    def __init__(self, settings: StorageSettings) -> None:
        self._sessions = PgSessions(settings)
        self._tenancy: TenancyStorageInterface = TenancyStoragePostgresImpl(self._sessions)
        self._events: EventsStorageInterface = EventsStoragePostgresImpl(self._sessions)
        self._audit: AuditStorageInterface = AuditStoragePostgresImpl(self._sessions)
        self._outbox: OutboxStorageInterface = OutboxStoragePostgresImpl(self._sessions)
        self._work: WorkStorageInterface = WorkStoragePostgresImpl(self._sessions)
        self._journalists: JournalistsStorageInterface = JournalistsStoragePostgresImpl(self._sessions)
        self._follows: FollowsStorageInterface = FollowsStoragePostgresImpl(self._sessions)
        self._updates: UpdatesStorageInterface = UpdatesStoragePostgresImpl(self._sessions)
        self._support: SupportStorageInterface = SupportStoragePostgresImpl(self._sessions)
        self._reports: ReportsStorageInterface = ReportsStoragePostgresImpl(self._sessions)
        self._idempotency: IdempotencyStorageInterface = IdempotencyStoragePostgresImpl(self._sessions)

    def get_tenancy_storage(self) -> TenancyStorageInterface:
        return self._tenancy

    def get_events_storage(self) -> EventsStorageInterface:
        return self._events

    def get_audit_storage(self) -> AuditStorageInterface:
        return self._audit

    def get_outbox_storage(self) -> OutboxStorageInterface:
        return self._outbox

    def get_idempotency_storage(self) -> IdempotencyStorageInterface:
        return self._idempotency

    def get_work_storage(self) -> WorkStorageInterface:
        return self._work

    def get_journalist_storage(self) -> JournalistsStorageInterface:
        return self._journalists

    def get_follow_storage(self) -> FollowsStorageInterface:
        return self._follows

    def get_update_storage(self) -> UpdatesStorageInterface:
        return self._updates

    def get_support_storage(self) -> SupportStorageInterface:
        return self._support

    def get_report_storage(self) -> ReportsStorageInterface:
        return self._reports

    def describe(self) -> str:
        return f"storage: postgres, {len(self._sessions.engines())} engine(s)"

    async def healthcheck(self) -> bool:
        async def ping() -> None:
            for engine in self._sessions.engines():
                async with engine.connect() as conn:
                    await conn.execute(text("SELECT 1"))

        try:
            await ping()
        except Exception:  # a health check answers, it never raises
            return False
        return True

    async def close(self) -> None:
        await self._sessions.dispose()
