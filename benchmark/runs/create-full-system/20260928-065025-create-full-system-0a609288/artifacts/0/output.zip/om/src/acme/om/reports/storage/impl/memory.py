"""The reports storage in memory: the same filters, order, tenancy rule, and refusals as the engine."""

from uuid import UUID

from acme.om.exceptions import Conflict
from acme.om.outbox.types import OutboxRow
from acme.om.reports.storage import ReportsStorageInterface
from acme.om.reports.types.message import Message, MessageDirection
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission, SubmissionState
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase, by_uuid


class ReportsStorageMemoryImpl(MemoryStorageBase, ReportsStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._reports: dict[UUID, SealedReport] = {}
        self._submissions: dict[UUID, tuple[UUID, Submission]] = {}
        self._messages: dict[UUID, tuple[UUID, Message]] = {}

    async def create_sealed_report(self, report: SealedReport) -> bool:
        if report.id in self._reports:
            return False
        self._reports[report.id] = report
        return True

    async def read_sealed_report(self, report_id: UUID) -> SealedReport | None:
        return self._reports.get(report_id)

    async def read_submissions(
        self, org_id: UUID, limit: int, state: SubmissionState | None = None, tag: str | None = None
    ) -> list[Submission]:
        found = [
            s
            for o, s in self._submissions.values()
            if o == org_id and (state is None or s.state == state) and (tag is None or tag in s.tags)
        ]
        return list(reversed(by_uuid(found)))[:limit]

    async def read_submission(self, org_id: UUID, submission_id: UUID) -> Submission | None:
        found = self._submissions.get(submission_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def create_submission(self, org_id: UUID, submission: Submission, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        if submission.id in self._submissions:
            return False
        self._land(org_id, outbox_rows)
        self._submissions[submission.id] = (org_id, submission)
        return True

    async def write_submission(self, org_id: UUID, submission: Submission, outbox_rows: tuple[OutboxRow, ...]) -> None:
        found = self._submissions.get(submission.id)
        if found is not None and found[0] != org_id:
            raise Conflict("the row is held under another key")
        self._land(org_id, outbox_rows)
        self._submissions[submission.id] = (org_id, submission)

    async def read_messages(
        self, org_id: UUID, submission_id: UUID, limit: int, *, without_notes: bool = False
    ) -> list[Message]:
        found = [
            m
            for o, m in self._messages.values()
            if o == org_id
            and m.submission_id == submission_id
            and not (without_notes and m.direction == MessageDirection.NOTE)
        ]
        return by_uuid(found)[:limit]

    async def read_message(self, org_id: UUID, message_id: UUID) -> Message | None:
        found = self._messages.get(message_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def create_message(self, org_id: UUID, message: Message, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        if message.id in self._messages:
            return False
        self._land(org_id, outbox_rows)
        self._messages[message.id] = (org_id, message)
        return True
