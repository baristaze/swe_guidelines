"""The desk's journalist profiles: the first product entity, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281630"
down_revision = "202609281200"


def upgrade() -> None:
    run_sql("core", "202609281630_journalists.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281630_journalists.down.sql")
