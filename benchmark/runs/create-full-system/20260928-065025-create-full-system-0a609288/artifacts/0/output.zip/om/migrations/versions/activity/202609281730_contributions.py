"""The contributions a desk received, append-only, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281730"
down_revision = "202609281200"


def upgrade() -> None:
    run_sql("activity", "202609281730_contributions.up.sql")


def downgrade() -> None:
    run_sql("activity", "202609281730_contributions.down.sql")
