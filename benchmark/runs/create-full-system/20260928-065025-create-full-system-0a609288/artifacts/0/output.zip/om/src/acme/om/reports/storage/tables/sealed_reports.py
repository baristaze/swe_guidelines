"""The sealed reports, in the core role, in no tenant: ciphertext only (ADR 0009)."""

from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, CreatedMixin, GlobalIdentifiableMixin


class SealedReports(GlobalIdentifiableMixin, CreatedMixin, Base):
    __tablename__ = "sealed_reports"

    ciphertext: Mapped[str]
    algorithm: Mapped[str]
