"""The journalists a reader's account follows, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281710"
down_revision = "202609281700"


def upgrade() -> None:
    run_sql("core", "202609281710_follows.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281710_follows.down.sql")
