"""The storage root: one getter per namespace storage, a health check, and a close."""

from abc import ABC, abstractmethod
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from acme.om.audit.storage import AuditStorageInterface
    from acme.om.events.storage import EventsStorageInterface
    from acme.om.follows.storage import FollowsStorageInterface
    from acme.om.idempotency.storage import IdempotencyStorageInterface
    from acme.om.journalists.storage import JournalistsStorageInterface
    from acme.om.outbox.storage import OutboxStorageInterface
    from acme.om.reports.storage import ReportsStorageInterface
    from acme.om.support.storage import SupportStorageInterface
    from acme.om.tenancy.storage import TenancyStorageInterface
    from acme.om.updates.storage import UpdatesStorageInterface
    from acme.om.work.storage import WorkStorageInterface


class InsertOutcome(StrEnum):
    INSERTED = "inserted"
    ID_EXISTS = "id_exists"  # the id is already written; nothing changes
    KEY_EXISTS = "key_exists"  # another unique key is held, under another id


class StorageInterface(ABC):
    @abstractmethod
    def get_tenancy_storage(self) -> TenancyStorageInterface: ...

    @abstractmethod
    def get_events_storage(self) -> EventsStorageInterface: ...

    @abstractmethod
    def get_audit_storage(self) -> AuditStorageInterface: ...

    @abstractmethod
    def get_outbox_storage(self) -> OutboxStorageInterface: ...

    @abstractmethod
    def get_idempotency_storage(self) -> IdempotencyStorageInterface: ...

    @abstractmethod
    def get_work_storage(self) -> WorkStorageInterface: ...

    @abstractmethod
    def get_journalist_storage(self) -> JournalistsStorageInterface: ...

    @abstractmethod
    def get_follow_storage(self) -> FollowsStorageInterface: ...

    @abstractmethod
    def get_update_storage(self) -> UpdatesStorageInterface: ...

    @abstractmethod
    def get_support_storage(self) -> SupportStorageInterface: ...

    @abstractmethod
    def get_report_storage(self) -> ReportsStorageInterface: ...

    @abstractmethod
    def describe(self) -> str: ...

    @abstractmethod
    async def healthcheck(self) -> bool: ...

    @abstractmethod
    async def close(self) -> None: ...
