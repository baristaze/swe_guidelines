"""The outbox over Postgres. The three sweeps run in the system scope, on the system login."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import delete, func, select, update

from acme.om.base import EMPTY_UUID
from acme.om.outbox.storage import OutboxStorageInterface
from acme.om.outbox.storage.tables.outbox import Outbox
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.utils.translation import to_model


class OutboxStoragePostgresImpl(PgStorageBase, OutboxStorageInterface):
    async def read_row(self, org_id: UUID, row_id: UUID) -> OutboxRow | None:
        stmt = select(Outbox).where(Outbox.org_id == org_id, Outbox.id == row_id)
        async with self._session_for(stmt, org_id=org_id) as session:
            row = (await session.execute(stmt)).scalar_one_or_none()
            return None if row is None else to_model(row, OutboxRow)

    async def mark_done(self, org_id: UUID, row_id: UUID, done_at: datetime) -> bool:
        stmt = (
            update(Outbox)
            .where(Outbox.org_id == org_id, Outbox.id == row_id, Outbox.done_at.is_(None))
            .values(done_at=done_at)
            .returning(Outbox.id)
        )
        async with self._session_for(stmt, org_id=org_id) as session:
            return (await session.execute(stmt)).scalar_one_or_none() is not None

    async def read_pending(self, limit: int) -> list[OutboxRow]:
        """Tenant-less: a cross-tenant sweep in the system scope; each row names its own tenant."""
        stmt = select(Outbox).where(Outbox.done_at.is_(None)).order_by(Outbox.created_at, Outbox.id).limit(limit)
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            return [to_model(r, OutboxRow) for r in (await session.execute(stmt)).scalars()]

    async def read_oldest_pending(self) -> datetime | None:
        """Tenant-less: the creation time of the oldest pending row across tenants, for the lag gauge."""
        stmt = select(func.min(Outbox.created_at)).where(Outbox.done_at.is_(None))
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            return (await session.execute(stmt)).scalar_one_or_none()

    async def purge_done(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges up to `limit` rows done before `before`, across tenants, in the system scope."""
        doomed = select(Outbox.id).where(Outbox.done_at.is_not(None), Outbox.done_at < before).limit(limit)
        stmt = delete(Outbox).where(Outbox.id.in_(doomed.scalar_subquery())).returning(Outbox.id)
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            return len((await session.execute(stmt)).scalars().all())
