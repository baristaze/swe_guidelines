-- Reverses 202609281200_queue_initial.up.sql.

DROP POLICY IF EXISTS tenant_fence ON queue.work_items;
DROP TABLE IF EXISTS queue.work_items;
ALTER DEFAULT PRIVILEGES IN SCHEMA queue REVOKE SELECT, INSERT, UPDATE, DELETE ON TABLES FROM acme_runtime, acme_system;
REVOKE USAGE ON SCHEMA queue FROM acme_runtime, acme_system;
