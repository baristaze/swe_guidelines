"""One module per entity of the reports namespace, and the read models its manager answers."""
