"""The contributions a desk received, in the activity role (append-only), fenced by the desk's tenant."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, FeedIdentifiableMixin


class Contributions(FeedIdentifiableMixin, Base):
    __tablename__ = "contributions"
    __table_args__ = (Index("ix_contributions_org_id_id", "org_id", "id"),)

    journalist_id: Mapped[UUID]
    pledge_id: Mapped[UUID]
    supporter_org_id: Mapped[UUID]
    supporter_name: Mapped[str]
    amount_minor: Mapped[int]
    currency: Mapped[str]
    mode: Mapped[str]
    platform_fee_minor: Mapped[int]
    received_at: Mapped[datetime]
