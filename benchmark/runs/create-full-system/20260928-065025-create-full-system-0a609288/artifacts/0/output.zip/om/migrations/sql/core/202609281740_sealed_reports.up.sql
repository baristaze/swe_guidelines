-- The sealed reports: the one ciphertext of each report, system scope (ADR 0009).

-- sealed_reports: system scope
CREATE TABLE core.sealed_reports (
    id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ciphertext VARCHAR NOT NULL,
    algorithm VARCHAR NOT NULL,
    CONSTRAINT pk_sealed_reports PRIMARY KEY (id)
);
