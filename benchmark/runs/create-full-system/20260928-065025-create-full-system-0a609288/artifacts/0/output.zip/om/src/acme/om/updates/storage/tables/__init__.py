"""One module per table of the updates namespace."""
