"""The updates manager: the swimlane of the short updates a desk publishes to its readers."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.opcontext import OpContext, RequestContext
from acme.om.updates.types.update import Update


class UpdatesManagerInterface(ABC):
    @abstractmethod
    async def get_updates(self, ctx: OpContext, limit: int) -> list[Update]:
        """The desk's updates, the newest first."""
        ...

    @abstractmethod
    async def get_update(self, ctx: OpContext, update_id: UUID) -> Update: ...

    @abstractmethod
    async def create_update(self, ctx: OpContext, update: Update) -> Update:
        """Publishes under one of the desk's living profiles; a rerun under the same id returns it as stored."""
        ...

    # --- the request stage: published community activity, read by anyone who holds the desk's link

    @abstractmethod
    async def get_published_updates(
        self, rctx: RequestContext, org_id: UUID, journalist_id: UUID, limit: int
    ) -> list[Update]:
        """A published profile's updates, the newest first, read under the desk's tenant; NotFound for a profile that
        is not published."""
        ...
