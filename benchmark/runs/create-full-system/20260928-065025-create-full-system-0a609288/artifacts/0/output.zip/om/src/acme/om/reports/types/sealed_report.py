"""A sealed report: the one ciphertext of a source's report, encrypted on the sender's device under a fresh key."""

from typing import ClassVar

from acme.om.base import Created, Identifiable


class SealedReport(Identifiable, Created):
    """The platform's row, in no tenant: the ciphertext is of no use without a recipient's wrapped key (ADR 0004)."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    ciphertext: str  # base64 of the whole report (subject, description, tags, location, attachments), sealed once
    algorithm: str  # the device's scheme, named so a client knows how to open it; the platform never does
