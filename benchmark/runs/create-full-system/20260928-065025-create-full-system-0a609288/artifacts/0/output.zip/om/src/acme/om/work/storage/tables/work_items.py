"""The work queue, in the queue role: unique per tenant on the producer's key, indexed for the claim and the sweep."""

from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from acme.om.storage.tables.base import Base, FeedIdentifiableMixin, TrackableMixin


class WorkItems(FeedIdentifiableMixin, TrackableMixin, Base):
    __tablename__ = "work_items"
    __table_args__ = (
        Index("ix_work_items_org_id_idempotency_key", "org_id", "idempotency_key", unique=True),
        Index("ix_work_items_lane_status_available_at", "lane", "status", "available_at"),
        Index("ix_work_items_status_lease_expires_at", "status", "lease_expires_at"),
    )

    kind: Mapped[str]
    target_id: Mapped[UUID]
    idempotency_key: Mapped[UUID]
    request_id: Mapped[UUID]
    traceparent: Mapped[str | None]
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    lane: Mapped[str]
    status: Mapped[str]
    available_at: Mapped[datetime]
    claimed_by: Mapped[str | None]
    claim_token: Mapped[UUID | None]
    lease_expires_at: Mapped[datetime | None]
    attempts: Mapped[int]
    max_attempts: Mapped[int]
    last_error: Mapped[str | None]
