-- The activity role's first migration: its schema, the two logins' grants, the event stream
-- and the audit trail with their per-tenant cursors, each with its policy.

CREATE SCHEMA IF NOT EXISTS activity;
GRANT USAGE ON SCHEMA activity TO acme_runtime, acme_system;
ALTER DEFAULT PRIVILEGES IN SCHEMA activity GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO acme_runtime, acme_system;

-- audit_cursors: org scope
CREATE TABLE activity.audit_cursors (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    head INTEGER NOT NULL,
    CONSTRAINT pk_audit_cursors PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_audit_cursors_org_id ON activity.audit_cursors (org_id);
CREATE POLICY tenant_fence ON activity.audit_cursors
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE activity.audit_cursors ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity.audit_cursors FORCE ROW LEVEL SECURITY;

-- audit_entries: org scope
CREATE TABLE activity.audit_entries (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    seq INTEGER NOT NULL,
    kind VARCHAR NOT NULL,
    target_id UUID NOT NULL,
    actor_id UUID NOT NULL,
    payload JSONB NOT NULL,
    request_id UUID NOT NULL,
    app JSONB NOT NULL,
    CONSTRAINT pk_audit_entries PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_audit_entries_org_id_seq ON activity.audit_entries (org_id, seq);
CREATE POLICY tenant_fence ON activity.audit_entries
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE activity.audit_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity.audit_entries FORCE ROW LEVEL SECURITY;

-- event_cursors: org scope
CREATE TABLE activity.event_cursors (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    head INTEGER NOT NULL,
    CONSTRAINT pk_event_cursors PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_event_cursors_org_id ON activity.event_cursors (org_id);
CREATE POLICY tenant_fence ON activity.event_cursors
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE activity.event_cursors ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity.event_cursors FORCE ROW LEVEL SECURITY;

-- events: org scope
CREATE TABLE activity.events (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    seq INTEGER NOT NULL,
    kind VARCHAR NOT NULL,
    target_id UUID NOT NULL,
    actor_id UUID NOT NULL,
    payload JSONB NOT NULL,
    version INTEGER,
    request_id UUID NOT NULL,
    app JSONB NOT NULL,
    CONSTRAINT pk_events PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_events_org_id_seq ON activity.events (org_id, seq);
CREATE POLICY tenant_fence ON activity.events
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE activity.events ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity.events FORCE ROW LEVEL SECURITY;
