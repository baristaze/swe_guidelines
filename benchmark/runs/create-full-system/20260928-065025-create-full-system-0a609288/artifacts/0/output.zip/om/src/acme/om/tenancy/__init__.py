"""Tenancy: organizations, identities, users, memberships, credentials, and the operator allowlist."""

from acme.om.tenancy.manager import TenancyManagerInterface

__all__ = ["TenancyManagerInterface"]
