# Updates

A desk keeps its readers informed with short **updates**. This page says what an update is and what can happen to
it. It sits one level below [the object model](../../../../README.md).

## An update

An **update** is a short text a desk publishes under one of its journalist profiles. It is published community
activity: anyone who has the journalist's link can read it, and readers who follow the journalist see it in their
feed.

## What can happen to it

- **Published**: a member, an admin, or the owner of the desk publishes an update under one of the desk's living
  profiles. Publishing the same update twice, as a repeated request does, publishes it once.
- **Listed**: the desk sees its updates, the newest first; anyone sees the updates of a published profile.

## Rules that hold

- An update never changes once published, and it never carries anything from a source's private report.
- Only a profile the desk has published shows its updates outside the desk.
