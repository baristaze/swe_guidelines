"""The updates a desk publishes, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281720"
down_revision = "202609281710"


def upgrade() -> None:
    run_sql("core", "202609281720_updates.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281720_updates.down.sql")
