-- The journalist profile gains what readers and sources reach: the bio, the public key, whether it is published,
-- and the connected account payouts go to.

ALTER TABLE core.journalists ADD COLUMN bio VARCHAR DEFAULT '' NOT NULL;
ALTER TABLE core.journalists ADD COLUMN public_key VARCHAR;
ALTER TABLE core.journalists ADD COLUMN published BOOLEAN DEFAULT false NOT NULL;
ALTER TABLE core.journalists ADD COLUMN payout_account_id VARCHAR;
