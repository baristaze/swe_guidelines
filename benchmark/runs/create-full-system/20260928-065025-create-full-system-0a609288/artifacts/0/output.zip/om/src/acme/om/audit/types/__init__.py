"""The audit entry: who did what, when, under which request, and from which app."""

from typing import ClassVar
from uuid import UUID

from pydantic import Field

from acme.om.base import FrozenMapping, Identifiable
from acme.om.opcontext import AppContext


class AuditEntry(Identifiable):
    """Append-only; a tenant entity read under a context, so its org_id is a storage column and not a field.
    Its payload may carry values; erasing a person redacts those in place, the one write it ever takes."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    seq: int
    kind: str
    target_id: UUID
    actor_id: UUID
    payload: FrozenMapping = Field(default_factory=dict, validate_default=True)
    request_id: UUID
    app: AppContext
