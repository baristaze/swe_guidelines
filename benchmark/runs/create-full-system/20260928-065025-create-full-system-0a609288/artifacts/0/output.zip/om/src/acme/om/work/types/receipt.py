"""A work receipt: that one outside effect of a work item happened, recorded after the provider took it."""

from typing import ClassVar
from uuid import UUID

from acme.om.base import Created, Identifiable


class WorkReceipt(Identifiable, Created):
    """Its id is `rules.receipt_id(item key, effect)`, so an effect of one item is recorded once and a replay of the
    item finds it. It names neither the effect nor its recipient: the effect is only inside the id's digest."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    item_id: UUID  # the item whose effect it records
