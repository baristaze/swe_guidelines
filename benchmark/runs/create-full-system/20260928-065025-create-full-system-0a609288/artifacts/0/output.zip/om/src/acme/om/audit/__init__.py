"""The audit trail: who did what, when, and from which app."""

from acme.om.audit.manager import AuditManagerInterface

__all__ = ["AuditManagerInterface"]
