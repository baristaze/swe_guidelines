"""The storage root, at `acme.om.storage`, and the shared building blocks every namespace storage uses."""

from acme.om.storage.root import InsertOutcome, StorageInterface

__all__ = ["InsertOutcome", "StorageInterface"]
