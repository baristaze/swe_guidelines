"""The work storage. The claim, the orphan failure, the gauge read, and the purge read or write across tenants in
the system scope and return the tenant beside each row; every other method runs under the caller's tenant."""

from abc import ABC, abstractmethod
from datetime import datetime
from uuid import UUID

from acme.om.storage.root import InsertOutcome
from acme.om.work.types.receipt import WorkReceipt
from acme.om.work.types.work_item import WorkGauges, WorkItem, WorkKind


class WorkStorageInterface(ABC):
    @abstractmethod
    async def create_item(self, org_id: UUID, item: WorkItem) -> InsertOutcome:
        """The insert that reports which key collided; nothing changes on a collision."""
        ...

    @abstractmethod
    async def read_item(self, org_id: UUID, item_id: UUID) -> WorkItem | None: ...

    @abstractmethod
    async def read_item_by_key(self, org_id: UUID, idempotency_key: UUID) -> WorkItem | None: ...

    @abstractmethod
    async def write_item(self, org_id: UUID, item: WorkItem, claim_token: UUID) -> bool:
        """Writes only while the row still carries `claim_token`; False means another holder has it now."""
        ...

    @abstractmethod
    async def requeue_stale(self, org_id: UUID, before: datetime, limit: int, now: datetime) -> int:
        """Hands back the tenant's claimed items whose lease passed before `before`, at most `limit`."""
        ...

    @abstractmethod
    async def claim_next(
        self,
        lane: str,
        kinds: tuple[WorkKind, ...],
        worker_id: str,
        claim_token: UUID,
        lease_until: datetime,
        now: datetime,
    ) -> tuple[UUID, WorkItem] | None:
        """Tenant-less, named atomic: the oldest available item of the lane across tenants, locked past the others,
        stamped with the claim and the lease in the same statement; the tenant travels back beside the row."""
        ...

    @abstractmethod
    async def fail_orphaned(self, item_id: UUID, claim_token: UUID, error: str, now: datetime) -> bool:
        """Tenant-less: fails an item whose tenant is gone, conditional on the token, needing no stage."""
        ...

    @abstractmethod
    async def read_gauges(self) -> WorkGauges:
        """Tenant-less: the oldest waiting item and the count of failed items, across tenants."""
        ...

    @abstractmethod
    async def purge_items(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges done and failed items last touched before `before`, across tenants, at most `limit`."""
        ...

    @abstractmethod
    async def create_receipt(self, org_id: UUID, receipt: WorkReceipt) -> bool:
        """Records once: False when the id is already written, under any tenant; nothing changes then."""
        ...

    @abstractmethod
    async def read_receipt(self, org_id: UUID, receipt_id: UUID) -> WorkReceipt | None: ...

    @abstractmethod
    async def purge_receipts(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges receipts written before `before`, across tenants, at most `limit`."""
        ...
