"""The edge idempotency marker: one per tenant, principal, and key, owning the retry of a creating request."""

from datetime import UTC, datetime
from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from acme.om.base import Created, Identifiable, Platform


class IdempotencyMarker(Identifiable, Created):  # one per tenant, principal, and key
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    user_id: UUID
    key: str
    request_digest: str  # another digest under the same key is refused
    target_id: UUID  # the id the create uses, minted before the marker
    attempt_token: UUID | None  # the attempt that holds it; cleared by a release
    status: int | None = None  # the outcome, None while the request runs
    body: str | None = None


class BeginOutcome(StrEnum):
    STARTED = "started"  # this attempt holds the marker and runs the request on its target id
    REPLAY = "replay"  # the stored outcome answers
    RUNNING = "running"  # another attempt holds a live lease
    MISMATCH = "mismatch"  # the key was presented with another request


class MarkerOutcome(Platform):
    outcome: BeginOutcome
    marker: IdempotencyMarker


def attempt_started_at(token: UUID) -> datetime:
    """An attempt token is a uuid_v7, so it carries the millisecond its attempt began."""
    return datetime.fromtimestamp((token.int >> 80) / 1000, tz=UTC)
