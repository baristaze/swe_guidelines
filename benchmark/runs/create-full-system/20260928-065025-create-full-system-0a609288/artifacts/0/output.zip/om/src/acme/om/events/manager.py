"""The events manager: records one event per write the relay hands it, and reads the stream back."""

from abc import ABC, abstractmethod
from datetime import datetime
from uuid import UUID

from acme.om.events.types import Event
from acme.om.opcontext import OpContext, OperatorContext
from acme.om.outbox.types import OutboxRow


class EventsManagerInterface(ABC):
    @abstractmethod
    async def append_relayed(self, org_id: UUID, row: OutboxRow) -> Event:
        """A handoff by tenant id: the event of the write the row announces, under the row's id."""
        ...

    @abstractmethod
    async def get_events(self, ctx: OpContext, after_seq: int, limit: int) -> list[Event]: ...

    @abstractmethod
    async def get_head(self, ctx: OpContext) -> int: ...

    @abstractmethod
    async def count_events_for_operator(
        self, octx: OperatorContext, since: datetime, excluded: tuple[UUID, ...]
    ) -> int: ...

    @abstractmethod
    async def get_events_for_operator(
        self, octx: OperatorContext, org_id: UUID, after_seq: int, limit: int
    ) -> list[Event]: ...
