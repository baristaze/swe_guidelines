"""The audit manager: records who did what, and reads a tenant's trail back to those allowed to see it."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.audit.types import AuditEntry
from acme.om.base import FrozenMapping
from acme.om.opcontext import OpContext, OperatorContext


class AuditManagerInterface(ABC):
    @abstractmethod
    async def record(self, ctx: OpContext, kind: str, target_id: UUID, payload: FrozenMapping) -> AuditEntry: ...

    @abstractmethod
    async def record_for_operator(
        self, octx: OperatorContext, org_id: UUID, kind: str, target_id: UUID, payload: FrozenMapping
    ) -> AuditEntry:
        """The trail of the operator plane inside a tenant: support access is recorded with the operator."""
        ...

    @abstractmethod
    async def get_audit_entries(self, ctx: OpContext, after_seq: int, limit: int) -> list[AuditEntry]: ...
