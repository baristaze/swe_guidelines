"""The outbox in memory, over the ledger every memory write lands its rows in."""

from datetime import datetime
from uuid import UUID

from acme.om.outbox.storage import OutboxStorageInterface
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.memory_base import MemoryStorageBase


class OutboxStorageMemoryImpl(MemoryStorageBase, OutboxStorageInterface):
    async def read_row(self, org_id: UUID, row_id: UUID) -> OutboxRow | None:
        row = self._ledger.rows.get(row_id)
        return row if row is not None and row.org_id == org_id else None

    async def mark_done(self, org_id: UUID, row_id: UUID, done_at: datetime) -> bool:
        row = self._ledger.rows.get(row_id)
        if row is None or row.org_id != org_id or row.done_at is not None:
            return False
        self._ledger.rows[row_id] = row.model_copy(update={"done_at": done_at})
        return True

    async def read_pending(self, limit: int) -> list[OutboxRow]:
        """Tenant-less: a cross-tenant sweep in the system scope; each row names its own tenant."""
        pending = [r for r in self._ledger.rows.values() if r.done_at is None]
        return sorted(pending, key=lambda r: (r.created_at, r.id.int))[:limit]

    async def read_oldest_pending(self) -> datetime | None:
        """Tenant-less: the creation time of the oldest pending row across tenants, for the lag gauge."""
        return min((r.created_at for r in self._ledger.rows.values() if r.done_at is None), default=None)

    async def purge_done(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges up to `limit` rows done before `before`, across tenants, in the system scope."""
        doomed = [r.id for r in self._ledger.rows.values() if r.done_at is not None and r.done_at < before][:limit]
        for row_id in doomed:
            del self._ledger.rows[row_id]
        return len(doomed)
