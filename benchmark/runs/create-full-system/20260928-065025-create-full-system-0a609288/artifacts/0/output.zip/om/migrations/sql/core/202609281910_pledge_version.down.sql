-- Reverses 202609281910_pledge_version.up.sql.

ALTER TABLE core.pledges DROP COLUMN IF EXISTS version;
