"""A follow: a reader's account following one journalist of one desk, for free."""

from typing import ClassVar
from uuid import UUID

from acme.om.base import Created, Identifiable, SoftDeletable


class Follow(Identifiable, Created, SoftDeletable):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    desk_id: UUID  # the desk (tenant) that presents the journalist
    journalist_id: UUID  # the followed profile; one living follow per journalist per account
