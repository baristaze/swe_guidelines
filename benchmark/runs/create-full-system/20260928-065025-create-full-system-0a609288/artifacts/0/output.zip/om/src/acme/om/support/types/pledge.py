"""A pledge: a reader's account supporting one journalist with money, once or every month."""

from datetime import datetime
from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from acme.om.base import Identifiable, Trackable


class SupportMode(StrEnum):
    ONE_TIME = "one_time"
    MONTHLY = "monthly"


class PledgeStatus(StrEnum):
    PENDING = "pending"  # the checkout is open; nothing is paid
    PAID = "paid"  # a one-time pledge the payment processor settled
    ACTIVE = "active"  # a monthly pledge the payment processor settled: the reader is a patron while it lasts
    CANCELLED = "cancelled"  # a monthly pledge the reader ended, or a pending one they abandoned


class Pledge(Identifiable, Trackable):
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = (
        "status",
        "platform_fee_minor",
        "checkout_session_id",
        "subscription_id",
        "settled_at",
        "version",
    )

    desk_id: UUID  # the desk (tenant) that presents the journalist
    journalist_id: UUID
    amount_minor: int  # in the currency's minor unit
    currency: str  # ISO 4217, lower case
    mode: SupportMode
    supporter_name: str  # the name the reader shows the desk; a personal field, never on an event
    status: PledgeStatus = PledgeStatus.PENDING
    platform_fee_minor: int = 0  # the platform's share, from its configured rate, apart from the processor's fees
    checkout_session_id: str | None = None
    subscription_id: str | None = None  # the processor's subscription behind a monthly pledge
    settled_at: datetime | None = None
    version: int = 1  # compare-and-set: a transition writes only while the row still carries the version it read
