"""The reports storage. The sealed report is the platform's row, in no tenant; every other method runs under the
desk's tenant it names."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.outbox.types import OutboxRow
from acme.om.reports.types.message import Message
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission, SubmissionState


class ReportsStorageInterface(ABC):
    @abstractmethod
    async def create_sealed_report(self, report: SealedReport) -> bool:
        """System scope, so no tenant: the one ciphertext of a report serves every recipient desk, and it is of no
        use without a wrapped key. False when the id is already written; nothing changes then."""
        ...

    @abstractmethod
    async def read_sealed_report(self, report_id: UUID) -> SealedReport | None:
        """System scope, so no tenant: read only after the caller found a submission that names the report."""
        ...

    @abstractmethod
    async def read_submissions(
        self, org_id: UUID, limit: int, state: SubmissionState | None = None, tag: str | None = None
    ) -> list[Submission]:
        """The desk's submissions, the newest first (by id, descending), filtered by state and tag when named."""
        ...

    @abstractmethod
    async def read_submission(self, org_id: UUID, submission_id: UUID) -> Submission | None: ...

    @abstractmethod
    async def create_submission(self, org_id: UUID, submission: Submission, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        """False when the id is already written, under any tenant; nothing changes then."""
        ...

    @abstractmethod
    async def write_submission(self, org_id: UUID, submission: Submission, outbox_rows: tuple[OutboxRow, ...]) -> None:
        """Writes the submission onto its row under the tenant; an id another tenant holds is a Conflict."""
        ...

    @abstractmethod
    async def read_messages(
        self, org_id: UUID, submission_id: UUID, limit: int, *, without_notes: bool = False
    ) -> list[Message]:
        """One submission's thread, the oldest first (by id), the desk's notes left out when asked."""
        ...

    @abstractmethod
    async def read_message(self, org_id: UUID, message_id: UUID) -> Message | None: ...

    @abstractmethod
    async def create_message(self, org_id: UUID, message: Message, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        """False when the id is already written, under any tenant; nothing changes then."""
        ...
