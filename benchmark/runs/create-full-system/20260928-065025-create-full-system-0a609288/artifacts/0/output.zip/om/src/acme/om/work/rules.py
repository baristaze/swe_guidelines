"""The work queue's arithmetic: the retry delay, exhaustion, and the stale cut-off. Plain functions over values."""

import uuid
from datetime import datetime, timedelta
from uuid import UUID


def retry_delay(attempts: int, base: timedelta, cap: timedelta) -> timedelta:
    """A growing delay before a failed item is claimable again: base, twice base, four times, up to the cap."""
    return min(cap, base * (2 ** max(0, attempts - 1)))


def is_exhausted(attempts: int, max_attempts: int) -> bool:
    """A failure at max_attempts is final: the item is a dead letter."""
    return attempts >= max_attempts


def stale_before(now: datetime) -> datetime:
    """A claimed item whose lease expired before this instant is stale. `requeue_stale`'s statement spells the same
    rule once more (`lease_expires_at < :before`), and the contract case holds the two together."""
    return now


def receipt_id(idempotency_key: UUID, effect: str) -> UUID:
    """The id of the receipt of one outside effect of an item (`"email:<address>"`): a UUID v5 over the item's key and
    the effect, the same on every run of the item, so a replay finds what an earlier run already did."""
    return uuid.uuid5(idempotency_key, effect)
