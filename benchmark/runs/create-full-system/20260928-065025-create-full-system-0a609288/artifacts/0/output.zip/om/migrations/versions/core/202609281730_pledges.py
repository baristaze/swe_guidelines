"""A reader's pledges, org scope."""

from acme.om.storage.migrate import run_sql

revision = "202609281730"
down_revision = "202609281720"


def upgrade() -> None:
    run_sql("core", "202609281730_pledges.up.sql")


def downgrade() -> None:
    run_sql("core", "202609281730_pledges.down.sql")
