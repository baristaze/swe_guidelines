"""One module per table of the reports namespace."""
