"""The read models the reports manager answers: a recipient, an opened submission, and a source's thread."""

from uuid import UUID

from acme.om.base import Platform
from acme.om.reports.types.message import Message
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission


class Recipient(Platform):
    """One recipient of a report: the desk (tenant) and the submission that lands in it."""

    desk_id: UUID
    submission: Submission


class OpenedSubmission(Platform):
    """What a desk opens: its submission and the sealed report its wrapped key opens."""

    submission: Submission
    report: SealedReport


class SourceThread(Platform):
    """What the source reads with its reply secret: the submission's state and every message but the notes."""

    submission: Submission
    report: SealedReport
    messages: tuple[Message, ...]
