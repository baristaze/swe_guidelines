-- The receipts of work items' outside effects, org scope: one row per effect a provider took (ASY-24).

-- work_receipts: org scope
CREATE TABLE queue.work_receipts (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    item_id UUID NOT NULL,
    CONSTRAINT pk_work_receipts PRIMARY KEY (id)
);
CREATE INDEX ix_work_receipts_org_id ON queue.work_receipts (org_id);
CREATE INDEX ix_work_receipts_created_at ON queue.work_receipts (created_at);
CREATE POLICY tenant_fence ON queue.work_receipts
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE queue.work_receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE queue.work_receipts FORCE ROW LEVEL SECURITY;
