"""The relay: carries each outbox row to its destination, at once or from the sweep, and marks it done."""

from abc import ABC, abstractmethod
from datetime import timedelta
from uuid import UUID

from acme.om.opcontext import RequestContext
from acme.om.outbox.types import OutboxRow


class OutboxRelayInterface(ABC):
    @abstractmethod
    async def relay(self, org_id: UUID, row: OutboxRow) -> bool:
        """A handoff by tenant id: the row carries its actor and request. Never raises; False leaves it pending."""
        ...

    @abstractmethod
    async def relay_pending(self, rctx: RequestContext, limit: int) -> int:
        """Bookkeeping with no principal: relays what a crash or a dropped publish left pending."""
        ...

    @abstractmethod
    async def purge_done(self, rctx: RequestContext) -> int: ...

    @abstractmethod
    async def read_lag(self, rctx: RequestContext) -> timedelta: ...
