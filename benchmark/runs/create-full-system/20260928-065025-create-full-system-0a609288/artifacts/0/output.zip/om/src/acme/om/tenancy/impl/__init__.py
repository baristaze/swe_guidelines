"""The implementations of the tenancy interfaces."""
