"""The implementations of the storage interfaces."""
