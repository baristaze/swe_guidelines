"""The journalists storage impls, Postgres and memory."""
