-- Reverses 202609281630_journalists.up.sql.

DROP POLICY IF EXISTS tenant_fence ON core.journalists;
DROP TABLE IF EXISTS core.journalists;
