"""The object model of the Free Journalism platform."""
