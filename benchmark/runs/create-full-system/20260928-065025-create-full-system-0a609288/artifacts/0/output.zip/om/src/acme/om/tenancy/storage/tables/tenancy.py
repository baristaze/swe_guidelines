"""The tenancy tables, all in the core role. Their scopes are declared in the scope map beside the role map."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import Index, text
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import (
    Base,
    CreatedMixin,
    FeedIdentifiableMixin,
    GlobalIdentifiableMixin,
    IdentityScopedMixin,
    NamedMixin,
    SoftDeletableMixin,
    TrackableMixin,
)


class Orgs(GlobalIdentifiableMixin, NamedMixin, TrackableMixin, SoftDeletableMixin, Base):
    """The platform's global list of tenants: a system table with no policy."""

    __tablename__ = "orgs"
    __table_args__ = (Index("ix_orgs_slug", "slug", unique=True, postgresql_where=text("deleted_at IS NULL")),)

    slug: Mapped[str]
    provisioned_by: Mapped[UUID | None]


class Identities(IdentityScopedMixin, TrackableMixin, Base):
    """One row per person; `identity_id` equals `id`, the column the identity policy rests on."""

    __tablename__ = "identities"
    __table_args__ = (
        Index("ix_identities_email_digest", "email_digest", unique=True),
        Index("ix_identities_issuer_subject", "issuer", "subject", unique=True),
    )

    email: Mapped[str]
    email_digest: Mapped[str]
    display_name: Mapped[str]
    password_hash: Mapped[str | None]
    totp_secret: Mapped[str | None]
    totp_confirmed_at: Mapped[datetime | None]
    totp_last_step: Mapped[int | None]
    issuer: Mapped[str | None]
    subject: Mapped[str | None]


class Users(FeedIdentifiableMixin, NamedMixin, TrackableMixin, Base):
    __tablename__ = "users"
    __table_args__ = (Index("ix_users_org_id_identity_id", "org_id", "identity_id", unique=True),)

    identity_id: Mapped[UUID]


class Memberships(FeedIdentifiableMixin, TrackableMixin, Base):
    __tablename__ = "memberships"
    __table_args__ = (Index("ix_memberships_org_id_user_id", "org_id", "user_id", unique=True),)

    user_id: Mapped[UUID]
    role: Mapped[str]


class IdentityMemberships(IdentityScopedMixin, CreatedMixin, Base):
    """The identity's copy of each membership, written in the same transaction as the membership."""

    __tablename__ = "identity_memberships"
    __table_args__ = (Index("ix_identity_memberships_identity_id_org_id", "identity_id", "tenant_id", unique=True),)

    tenant_id: Mapped[UUID]
    user_id: Mapped[UUID]
    role: Mapped[str]


class Sessions(IdentityScopedMixin, CreatedMixin, Base):
    __tablename__ = "sessions"
    __table_args__ = (
        Index("ix_sessions_digest", "digest", unique=True),
        Index("ix_sessions_expires_at", "expires_at"),
    )

    kind: Mapped[str]
    tenant_id: Mapped[UUID]
    user_id: Mapped[UUID | None]
    permission: Mapped[str | None]
    digest: Mapped[str]
    second_factor: Mapped[bool]
    last_seen_at: Mapped[datetime]
    expires_at: Mapped[datetime]
    ended_at: Mapped[datetime | None]


class ApiKeys(FeedIdentifiableMixin, NamedMixin, CreatedMixin, Base):
    __tablename__ = "api_keys"
    __table_args__ = (
        Index("ix_api_keys_digest", "digest", unique=True),
        Index("ix_api_keys_org_id_issued_by", "org_id", "issued_by"),
    )

    issued_by: Mapped[UUID]
    digest: Mapped[str]
    role: Mapped[str]
    expires_at: Mapped[datetime]
    revoked_at: Mapped[datetime | None]


class SocketTickets(IdentityScopedMixin, CreatedMixin, Base):
    __tablename__ = "socket_tickets"
    __table_args__ = (
        Index("ix_socket_tickets_digest", "digest", unique=True),
        Index("ix_socket_tickets_expires_at", "expires_at"),
    )

    tenant_id: Mapped[UUID]
    user_id: Mapped[UUID]
    credential_kind: Mapped[str]
    credential_id: Mapped[UUID]
    digest: Mapped[str]
    expires_at: Mapped[datetime]
    redeemed_at: Mapped[datetime | None]


class SignInFailures(GlobalIdentifiableMixin, CreatedMixin, Base):
    """Failed sign-ins per email digest: the defense that does not fail open, a system table."""

    __tablename__ = "sign_in_failures"
    __table_args__ = (Index("ix_sign_in_failures_email_digest", "email_digest", unique=True),)

    email_digest: Mapped[str]
    failures: Mapped[int]
    retry_at: Mapped[datetime]


class Operators(GlobalIdentifiableMixin, TrackableMixin, Base):
    """The operator allowlist: a system table the operator plane and the grant job read."""

    __tablename__ = "operators"
    __table_args__ = (Index("ix_operators_identity_id", "identity_id", unique=True),)

    identity_id: Mapped[UUID]
    permission: Mapped[str]
    disabled_at: Mapped[datetime | None]
