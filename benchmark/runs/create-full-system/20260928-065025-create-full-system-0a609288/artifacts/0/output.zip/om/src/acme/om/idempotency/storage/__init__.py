"""The marker's storage: every move one conditional write whose guard is in the statement."""

from abc import ABC, abstractmethod
from datetime import datetime
from uuid import UUID

from acme.om.idempotency.types import IdempotencyMarker, MarkerOutcome


class IdempotencyStorageInterface(ABC):
    @abstractmethod
    async def begin(self, org_id: UUID, marker: IdempotencyMarker, stale_before: datetime) -> MarkerOutcome:
        """Named atomic: writes the marker pending, or takes over a released one or one whose attempt began
        before `stale_before`, keeping its digest and target id; exactly one of two racing callers starts."""
        ...

    @abstractmethod
    async def finish(
        self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID, status: int, body: str
    ) -> bool: ...  # False: the attempt no longer holds the marker

    @abstractmethod
    async def release(self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID) -> bool: ...

    @abstractmethod
    async def holds_attempt(self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID) -> bool:
        """Whether the marker is still pending under this attempt: the guard a rerun's re-mint reads."""
        ...

    @abstractmethod
    async def read_marker(self, org_id: UUID, user_id: UUID, key: str) -> IdempotencyMarker | None: ...

    @abstractmethod
    async def purge_markers(self, before: datetime, limit: int) -> int:
        """Tenant-less: the sweep's purge of markers created before `before`, across tenants, in the system scope."""
        ...
