"""The work item: durable background work as a row, carrying the producer's key and recording its own claim."""

from datetime import datetime
from enum import StrEnum
from typing import ClassVar
from uuid import UUID

from pydantic import Field

from acme.om.base import FrozenMapping, Identifiable, Platform, Trackable


class WorkKind(StrEnum):
    NOOP = "NOOP"  # the maintenance worker's placeholder kind; its handler does nothing, idempotently
    SEND_NOTIFICATION = "SEND_NOTIFICATION"  # the notifier's: one message a write owes someone (ADR 0009)
    APPEND_CONTRIBUTION = "APPEND_CONTRIBUTION"  # the maintenance worker's: a settled pledge's record at its desk


class WorkStatus(StrEnum):
    QUEUED = "queued"
    CLAIMED = "claimed"
    DONE = "done"
    FAILED = "failed"


class WorkItem(Identifiable, Trackable):
    """`created_by` is the person who asked for the work; `updated_by` is the machinery that ran it (EMPTY_UUID)."""

    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = (
        "status",
        "available_at",
        "claimed_by",
        "claim_token",
        "lease_expires_at",
        "attempts",
        "last_error",
    )

    kind: WorkKind  # what to do
    target_id: UUID  # the record it advances
    idempotency_key: UUID  # unique per tenant
    request_id: UUID  # the request that caused the work
    traceparent: str | None = None  # the trace context of that request, for a link
    payload: FrozenMapping = Field(default_factory=dict, validate_default=True)
    lane: str = "default"  # routing: "default", "region:<id>", ...
    status: WorkStatus = WorkStatus.QUEUED
    available_at: datetime  # not before
    claimed_by: str | None = None  # the worker's name, for an operator; never a fence
    claim_token: UUID | None = None  # the fence every write to the row conditions on
    lease_expires_at: datetime | None = None
    attempts: int = 0
    max_attempts: int = 3
    last_error: str | None = None


class NoopPayload(Platform):
    """The NOOP kind carries nothing."""


class NotificationTopic(StrEnum):
    """What a notification says; the handler finds the recipients and the words from the topic and the target."""

    SUBMISSION_RECEIVED = "submission_received"  # to the desk's members: a new report arrived (never its content)
    SOURCE_REPLIED = "source_replied"  # to the desk's members: a source answered on a submission
    DESK_REPLIED = "desk_replied"  # to the source's contact address, when one was given
    SUPPORT_RECEIPT = "support_receipt"  # to the supporter's account: a pledge settled


class SendNotificationPayload(Platform):
    """The SEND_NOTIFICATION kind names its topic; the item's target is the record the notice is about."""

    topic: NotificationTopic


SEND_NOTIFICATION_ROW = "work.send_notification"  # the outbox row kind that asks for one


class AppendContributionPayload(Platform):
    """The APPEND_CONTRIBUTION kind names the contribution's id, the payment delivery's key, so a replay appends
    nothing; the item's target is the settled pledge, in the supporter's account the item was queued in."""

    contribution_id: UUID


APPEND_CONTRIBUTION_ROW = "work.append_contribution"  # the outbox row kind a settlement lands beside the pledge


WORK_PAYLOADS: dict[WorkKind, type[Platform]] = {
    WorkKind.NOOP: NoopPayload,
    WorkKind.SEND_NOTIFICATION: SendNotificationPayload,
    WorkKind.APPEND_CONTRIBUTION: AppendContributionPayload,
}


class WorkGauges(Platform):
    oldest_waiting_at: datetime | None
    failed: int
