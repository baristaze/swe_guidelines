# Audit

**Nouns.** An **audit entry** records who did what, to which thing, when, under which request, and from which app.

**What can happen.** Entries are only ever added. Opening a sensitive report, an operator looking inside a desk, and
work that failed for good each leave one. A desk's owner and admins read their desk's trail.

**Rules that hold.**

- An entry is never changed, with one exception: when a person is erased, the personal details in their entries are
  blanked out.
- Entries are numbered per desk, in order.
- Every look an operator takes inside a desk is recorded with that operator.
