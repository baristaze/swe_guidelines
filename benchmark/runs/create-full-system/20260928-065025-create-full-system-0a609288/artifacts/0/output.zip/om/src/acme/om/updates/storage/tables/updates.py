"""The updates a desk publishes, in the core role, fenced by the desk's tenant."""

from uuid import UUID

from sqlalchemy import Index
from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, CreatedMixin, FeedIdentifiableMixin


class Updates(FeedIdentifiableMixin, CreatedMixin, Base):
    __tablename__ = "updates"
    __table_args__ = (
        Index("ix_updates_org_id_id", "org_id", "id"),
        Index("ix_updates_org_id_journalist_id_id", "org_id", "journalist_id", "id"),
    )

    journalist_id: Mapped[UUID]
    body: Mapped[str]
