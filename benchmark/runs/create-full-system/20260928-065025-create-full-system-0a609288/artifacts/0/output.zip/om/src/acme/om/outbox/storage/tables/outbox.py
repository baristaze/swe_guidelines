"""The outbox table, in the core role beside the rows it announces."""

from datetime import datetime
from typing import Any
from uuid import UUID

from sqlalchemy import Index, text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from acme.om.storage.tables.base import Base, CreatedMixin, IdentifiableMixin


class Outbox(IdentifiableMixin, CreatedMixin, Base):
    __tablename__ = "outbox"
    __table_args__ = (Index("ix_outbox_pending", "created_at", postgresql_where=text("done_at IS NULL")),)

    kind: Mapped[str]
    target_id: Mapped[UUID]
    payload: Mapped[dict[str, Any]] = mapped_column(JSONB)
    actor_id: Mapped[UUID]
    request_id: Mapped[UUID]
    traceparent: Mapped[str | None]
    app: Mapped[dict[str, Any]] = mapped_column(JSONB)
    done_at: Mapped[datetime | None]
