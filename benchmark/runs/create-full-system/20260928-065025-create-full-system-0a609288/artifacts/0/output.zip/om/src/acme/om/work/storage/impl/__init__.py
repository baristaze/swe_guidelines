"""The implementations of the work storage."""
