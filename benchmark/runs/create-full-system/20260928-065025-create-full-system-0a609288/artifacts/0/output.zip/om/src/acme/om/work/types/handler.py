"""The one handler interface for background work; each kind's impl is `<Kind>HandlerImpl`."""

from abc import ABC, abstractmethod

from acme.om.opcontext import OpContext
from acme.om.work.types.work_item import WorkItem


class WorkHandlerInterface(ABC):
    @abstractmethod
    async def handle(self, ctx: OpContext, item: WorkItem) -> None:
        """Idempotent on the item's key: a replay or an at-least-once delivery leaves one effect."""
        ...
