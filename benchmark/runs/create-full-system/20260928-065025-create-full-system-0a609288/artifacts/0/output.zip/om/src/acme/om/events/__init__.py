"""The event stream: every push is also a record, numbered per tenant."""

from acme.om.events.manager import EventsManagerInterface

__all__ = ["EventsManagerInterface"]
