-- The journalists a reader's account follows, org scope (the reader's own account).

-- follows: org scope
CREATE TABLE core.follows (
    id UUID NOT NULL,
    org_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE,
    deleted_by UUID,
    desk_id UUID NOT NULL,
    journalist_id UUID NOT NULL,
    CONSTRAINT pk_follows PRIMARY KEY (id)
);
CREATE UNIQUE INDEX ix_follows_org_id_journalist_id ON core.follows (org_id, journalist_id) WHERE deleted_at IS NULL;
CREATE POLICY tenant_fence ON core.follows
    FOR ALL
    USING (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'))
    WITH CHECK (org_id = NULLIF(current_setting('app.org_id', true), '')::uuid
       OR (current_setting('app.org_id', true) = '00000000-0000-0000-0000-000000000000'
          AND current_user = 'acme_system'));
ALTER TABLE core.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.follows FORCE ROW LEVEL SECURITY;
