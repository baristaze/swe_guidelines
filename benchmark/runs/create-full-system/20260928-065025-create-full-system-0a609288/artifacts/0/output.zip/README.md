# Free Journalism

A platform for directly supporting independent journalists, and a safe channel for communities to bring them
information that might otherwise go unreported. Readers follow journalists, support them financially, and send
tips and evidence, which are encrypted on the sender's device and readable only by the journalists they chose.

What the system is made of: [`docs/architecture.md`](docs/architecture.md). How it is built:
[`specs/architecture.md`](specs/architecture.md). The nouns: [`om/README.md`](om/README.md). How it runs:
[`deployment/README.md`](deployment/README.md). How it is operated: [`ops/README.md`](ops/README.md).

## Setup

Needs `uv`, `pnpm`, Node 24 (see `.nvmrc`), and Docker. Python (3.14, see `.python-version`) is installed by `uv`.

```bash
make setup      # installs the Python and TypeScript workspaces
make check      # the fast gate: lint, format, types, arch-check, unit tests
```

## Quick start

```bash
make up         # dependencies and dashboards in containers, the application on the host; migrates, seeds, prints URLs
make down       # stops the containers and the host processes; the data stays
make reset      # wipes every local container and volume, then `make up` again
make urls       # prints every local URL
```

`make up` wraps steps that also run one at a time, which is what a gate and a scaffold take:

```bash
make setup
make infra-up        # the dependencies alone (make devx-up adds the dashboards)
make migrate
make seed
scripts/dev.sh start # the application on the host
```

## Seeded sign-in (local only)

`make seed` creates a development desk and its owner, read from `.env`:

| Desk | Owner email | Password |
|------|-------------|----------|
| Local Desk (`local-desk`) | `owner@acme.example` | `pswd_1234` |

These exist on your machine only. A deployed environment has no seed: it is entered through sign-up.

## Local URLs

| What | URL |
|------|-----|
| Portal | http://localhost:5173 |
| API interactive docs | http://localhost:8000/docs |
| pgweb (Postgres) | http://localhost:58081 |
| Valkey Admin (cache) | http://localhost:58082 |
| Object store console | http://localhost:59333 |
| Queue console | http://localhost:59325 |
| Jaeger (traces) | http://localhost:56686 |
| GlitchTip (errors) | http://localhost:58000 |
| Prometheus | http://localhost:59090 |
| Grafana (metrics view) | http://localhost:53000 |
