# 0003. How the journalism product maps onto tenants, identities, and namespaces

Date: 2026-09-28

Status: accepted

## Context

The product (see the product description the run was given) centers on a **Journalist** and their **Community**. A
community member can follow, become a **Patron** by paying, or privately act as a **Source**; the three roles are
independent, a source need not reveal a public identity, and an anonymous source submits without an account. The
guideline's multi-tenant shape needs a tenant, and nobody was available to ask which noun it is.

## Decision

- **The tenant (org) is a journalist's desk.** A desk is the journalist and anyone they work with later (an editor, a
  researcher). The journalist's inbox, notes, investigations, and received reports are the desk's rows, fenced by
  `org_id` and by the database policy. Newsroom organizations are out of the first release, and a desk grows into
  one without a change of shape.
- **The first namespace is `journalists`, its entity `Journalist`** (the desk's public profile: display name first;
  bio, coverage areas, topics, links, and the verification badge follow as fields). Its table is `org`-scoped.
- **Readers, patrons, and sources are identities, not members.** A reader who follows journalists is one identity
  across desks; their follows, their patronage, and their notification preferences are identity-scoped rows
  (the `identity` scope of the Second Fence), never a membership in each desk.
- **An anonymous source has no identity.** A report arrives through a desk's public intake, found by an intake token
  the way the guideline finds the integration behind an inbound webhook token: an operation without a principal,
  rate-limited by client address and by token, which writes ciphertext only (ADR 0004). A follow-up channel is a
  per-report reply token the source keeps; it is a credential of its own kind and names no identity.
- **Published community activity and private source communication are separate namespaces.** A report is private
  to its recipient desks and never becomes public without an explicit editorial action by the desk.
- **Roles inside a desk** keep the guideline's ladder: owner (the journalist), admin, member, viewer.
- **The MVP proves three loops** (follow and support; send information; inbox and reply). Public discussions,
  comments, collaborations between desks, newsroom organizations, recommendation feeds, story publishing, and
  mobile apps are out of the first release.

## Consequences

- The namespaces that follow the first one are, in order: `follows` (identity-scoped), `support` (patronage,
  payments through the payment processor's connected accounts, the platform fee a modelled setting), `reports`
  (the encrypted intake, per-recipient wrapped keys, journalist-side states `new`, `reviewing`, `follow-up`,
  `useful`, `archived`, notes, links to investigations), `notifications` (email, opt-in SMS, the in-app center, each
  a work item), `verification`, and `safety` (abuse reports, blocks, retention). Each arrives through the namespace
  and entity scaffolds, with its own ADR where it decides something.
- The public profile read is served to anonymous readers; it is a read of the `journalists` namespace by slug under
  a public route, a decision recorded when that route is added.
