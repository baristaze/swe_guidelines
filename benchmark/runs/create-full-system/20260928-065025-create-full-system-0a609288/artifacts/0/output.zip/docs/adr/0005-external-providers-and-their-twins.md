# 0005. External providers sit behind interfaces with twins; no live account exists yet

Date: 2026-09-28

Status: accepted

## Context

The product names WorkOS AuthKit for registered sign-in (email code, Google, Apple, GitHub, Microsoft), Stripe
Checkout and Connect for support and payouts, Postmark or Resend for transactional email, Twilio for opted-in SMS,
and a malware scanner. The guideline puts every hosted service behind one interface with a real client and a
deterministic twin. There are no accounts and no keys for any of them at the time of writing.

## Decision

- The `integrations/` distribution holds one interface per provider (`IdentityProviderInterface`,
  `PaymentsInterface`, `EmailInterface`, `SmsInterface`, `MalwareScannerInterface`), a real client each
  (`IdentityProviderWorkOSImpl`, `PaymentsStripeImpl`, `EmailPostmarkImpl` and `EmailResendImpl`, `SmsTwilioImpl`,
  `MalwareScannerVirusTotalImpl`), and a twin each. Postmark is the configured email provider in the cloud; Resend is
  a one-setting switch.
- The malware scanner is VirusTotal, used by file hash only (ADR 0004).
- Every twin refuses to run outside `local`, and every record it produces names its provenance (`"twin"`).
- The real clients are proven against recorded response fixtures (`integrations/tests/fixtures/`); a sandbox run
  against each provider belongs to a separate, non-gating workflow, added once accounts exist.
- WorkOS is one more credential kind at the gateway: the provider's token is verified against its published keys and
  the tenancy manager's `sign_in_external` finds or creates the identity by issuer and subject. An address already
  held by a password identity is refused, never linked silently.
- Provider credentials are process credentials, injected from the secret store at start. Terraform creates each
  secret empty, with no version, so no key enters state; a person fills them outside Terraform.
- `deployment/cloud/environments.json` names placeholder account ids and the `free-journalism.example` domain.

## Consequences

- Until a person fills the provider secrets, a deployed API task cannot start (ECS refuses a secret with no value):
  the first staging deploy migrates, then its rollout fails and rolls back. `scripts/cloud_create.sh` prints the
  secret names and the fill command; the next deploy succeeds.
- Replacing a provider is a new impl behind the same interface and a settings value, never a change to a manager.
