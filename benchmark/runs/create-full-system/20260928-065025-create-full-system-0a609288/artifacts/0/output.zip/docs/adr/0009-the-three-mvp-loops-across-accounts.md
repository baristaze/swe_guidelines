# 0009. The three MVP loops: every account is a tenant, and the loops cross accounts in named ways

Date: 2026-09-28

Status: accepted (refines 0003)

## Context

The Initial MVP proves three loops: a reader follows and supports a journalist; a source sends a tip, anonymous or
not, encrypted on the sender's device for each recipient; a journalist works the inbox and replies. ADR 0003 made
the tenant a journalist's desk and put a reader's follows and patronage in identity-scoped rows. The guideline gives
the identity stage three operations only (the memberships read, the exchange, the sign-out), so an identity-scoped
follow would need a fourth operation on that stage for every reader action. Every loop also crosses from one party
to another: a reader to a desk, a source with no account to one or more desks, a desk back to a source.

## Decision

- **Every account is a tenant.** Sign-up already creates an org and its owner; a reader's account is that org, and
  a journalist's desk is an account whose org presents a journalist profile. A reader's follows and pledges are
  `org`-scoped rows of the reader's own account, written under the reader's `OpContext`. This replaces the
  identity-scoped rows of ADR 0003; the rest of 0003 stands.
- **Published community activity is read by anyone, by desk id.** A journalist profile the desk marks `published`,
  and the updates it publishes, are read by the request stage under the desk's own tenant (the runtime login, the
  desk id from the path): `JournalistsManagerImpl.get_published_journalist` and
  `UpdatesManagerImpl.get_published_updates`. Nothing reads across tenants; a profile that is not published, or
  deleted, answers `NotFound`. There is no directory: a reader reaches a journalist by the link the journalist
  shares.
- **Private source communication enters a desk through the desk's public intake.** The intake takes the request
  stage and names each recipient by desk and journalist: `ReportsManagerImpl.submit_report`. The report is
  encrypted once on the sender's device under a fresh key; the platform stores that ciphertext once, in the
  `system`-scoped table `sealed_reports` (ciphertext alone, of no use without a wrapped key), and one `submissions`
  row per recipient desk, `org`-scoped, holding that recipient's wrapped key and the journalist-side state. The
  server never sees a key or a plaintext; it checks only that each recipient is a published profile carrying a
  public key.
- **The source's follow-up is authenticated by a reply secret, not an account.** The sender's device mints a secret
  and a key pair of its own; the submission stores the secret's SHA-256 digest and the source's public key. The
  source reads the thread and answers through two request-stage operations that name the desk and the submission
  and present the secret (`get_source_thread`, `post_source_message`), compared in constant time. A journalist's
  reply is sealed on the journalist's device to the source's public key; an internal note is sealed to the desk's
  own key and never shown to the source.
- **Anonymous or not.** An anonymous tip names no one. A signed-in reader may send it under their name instead:
  the submission then carries `sender_user_id`, `sender_org_id`, and `sender_name`, taken from the verified context
  and never from the body, seen by the recipient desks alone. A contact address for reply notices is a separate,
  optional field either way, since identity and contact method are separate concepts in the product.
- **A public create carries its ids from the device.** The gateway's `Idempotency-Key` marker is keyed by a
  principal, and the intake has none; the device mints the report id and each submission id (UUID v7) and a retry
  under the same ids returns the rows as stored, as every create does. The source's answers on the thread carry a
  device-minted id the same way. These routes live apart, in `routers/intake.py`, and `arch-check` NET-09 (a
  creating POST takes the gateway's idempotency dependency) is excepted for that file alone, in `pyproject.toml`.
  The named intake of a signed-in reader takes the dependency like every other creating route.
- **The reply secret is a credential of its own kind**, read by the gateway (`gateway/auth.py`, `x-reply-secret`)
  and compared by the reports manager; the payment processor's delivery is verified by the gateway
  (`gateway/webhooks.py`) before its route runs.
- **Outbox rows of a request-stage write** are stamped by `platform_outbox_row(rctx, org_id, ...)`, the actor
  `EMPTY_UUID` (the platform), the request id and trace of the intake; never a personal field.
- **Notifications ride one work kind**, `SEND_NOTIFICATION`, handled by the `notifier` worker under the tenant the
  item was enqueued in: a new submission or a source's answer notifies the desk's members, a journalist's reply
  notifies the source's contact address when one was given, a settled pledge sends the reader a receipt. No
  notification carries a report's content, which the server cannot read.
- The new request-stage operations are listed in the request-stage test; the `sealed_reports` storage methods are
  listed under `[tool.arch-check.options.CTX-12] tenantless`.

## Consequences

- A reader who later becomes a journalist presents a profile from the same account; nothing moves.
- Follower counts, update fan-out by email, a public directory, verification, retention purges, attachments in the
  bucket, and refunds are outside the first release; each arrives as its own change.
- A desk that loses its private key cannot read its past submissions (ADR 0004).
