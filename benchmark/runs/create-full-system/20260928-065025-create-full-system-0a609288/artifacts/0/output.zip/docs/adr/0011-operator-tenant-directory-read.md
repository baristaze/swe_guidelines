# 0011. The operator plane lists the live tenants, logged with the operator

Date: 2026-09-28

Status: accepted (a deviation)

## Context

OPS-05 (Operations, Operator Roles; Operational Skills) states:

> The supporter is the investigator plus one thing: a read of a named tenant's rows through the platform's operator
> plane, never a database login. The tenant is a parameter of every read. The credential is an identity on the
> operator allowlist whose entry says read. Every such read is logged with the tenant and the operator.

and names as a violation "an operator read with no tenant parameter, or one that reads across tenants; a tenant read
that leaves no line naming the tenant and the operator."

`GET /v1/admin/orgs` (`TenancyManagerImpl.get_orgs`) takes no tenant: it answers a page of the live tenants. Every
other operator read (`/v1/admin/orgs/{org_id}`, `.../members`, `.../events`) names its tenant in the path and logs a
line with the tenant and the operator (`_log_read`). The supporter's skill (`ops-root-cause`) starts from an org id,
and an operator who is handed a tenant by name or slug has no other way to find that id without a database login.
The DB-calls audit (`ops/audit/dbcalls_flows.py`) and the generated clients call the route too.

## Decision

- `GET /v1/admin/orgs` stays as the one operator read across tenants. It is a directory: each live tenant's id,
  name, slug, and timestamps (`AdminOrgView`), clamped to the page size. It reads no tenant's rows: no member, no
  event, no entity of the product.
- It requires the `read` operator permission, like every operator read.
- Each call logs one line, `operator listed the tenants`, with `operator_identity_id` and `tenant_count`. There is no
  single tenant to name, so the line names the operator and how many tenants it was shown.
- The route (`services/api/src/acme/services/api/routers/admin.py`) and the manager operation
  (`om/src/acme/om/tenancy/impl/manager.py`) cite this record.

## Consequences

- Reading anything inside a tenant still takes that tenant as a path parameter and leaves a line naming the tenant
  and the operator; this record covers the directory alone.
- A field added to `AdminOrgView` beyond the tenant's identity (a count of its rows, a member's name) would make the
  directory a read of tenant rows, and needs a new record or a per-tenant route.
- If a search by slug replaces the listing (`/v1/admin/orgs?slug=...` answering one tenant), this record is
  superseded and the route takes a tenant key again.
