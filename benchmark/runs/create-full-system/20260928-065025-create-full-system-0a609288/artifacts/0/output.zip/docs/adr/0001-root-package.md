# 0001. The root package is `acme`

Date: 2026-09-28

Status: accepted

## Context

Every Python distribution of the monorepo uses the `src/<root>/...` layout, and every workspace member shares one
import root, so the object model, infra, the integrations, the services, the workers, the clients, and the ops tool
all read as one namespace. The root must not shadow a standard-library module (`platform` would), and it spells the
settings prefix (`ACME_`), the database logins (`acme_migration`, `acme_runtime`, `acme_system`), and, as its kebab
slug, every cloud resource name (`acme-state-<account id>`, `acme-<env>-alarms`).

The product is the Free Journalism platform (`free-journalism/`). The scaffold was run as
`arch-scaffold-new free-journalism acme`, so the root package is the short, product-neutral `acme`, and the product's
own name appears in documents, the portal, and the public domain, not in import paths.

## Decision

The root package is `acme`. Its slug is `acme`. Distributions are `acme-om`, `acme-infra`, `acme-integrations`,
`acme-api`, `acme-maintenance`, `acme-client`, and `acme-ops`, each with the `src/acme/...` layout and a
`tests/` sibling. `acme` is a namespace package: no distribution ships `acme/__init__.py`.

## Consequences

- The root `pyproject.toml` lists every member, and `[tool.arch-check] package = "acme"`.
- Renaming the root later touches every import, every setting, every login, and every cloud resource name; it is a
  migration of its own, not a search and replace.
