# 0002. The stack as adopted, and its substitutions

Date: 2026-09-28

Status: accepted

## Context

The guideline (pinned in `specs/architecture.md`) names its technologies as defaults and asks a project to record,
once, every substitution with the rules the substitute must still satisfy, and to hold every dependency at its
latest stable release, a patch release behind it, the active LTS line where one exists.

## Decision

Adopted as the guideline names them: Python 3.14 on Pydantic; FastAPI on uvicorn, httpx as the HTTP client; Typer
for a Python CLI; SQLAlchemy and Alembic (as a runner of hand-written SQL) over Postgres 18; Valkey as the cache; an
S3-shaped object store; SQS as the hosted queue; React and TypeScript on Vite with TanStack Query and Zustand; uv
and pnpm workspaces; Docker Compose locally; AWS through Terraform, ECS Fargate, S3 and CloudFront; OpenTelemetry
traces, Prometheus metrics, the Sentry SDK for errors; Node 24 (active LTS).

| Named by the guideline | Substitute | Reason | Rules it must still satisfy |
|------------------------|------------|--------|-----------------------------|
| the object store's local image | SeaweedFS (`chrislusf/seaweedfs`) with its S3 gateway | MinIO no longer publishes community images; SeaweedFS speaks the S3 API and ships a console | keys prefixed by tenant; presigned POST bounded by type and size in the cloud; the local filesystem impl stays the unit-test twin |
| the queue's local image | ElasticMQ (`softwaremill/elasticmq`) | a wire-compatible SQS stand-in with a console, no account | at-least-once, no deduplication, visibility timeouts, a dead-letter queue after the last receive |
| the topic bus | Postgres `LISTEN/NOTIFY` on the queue role's database | no broker to run; the guideline names it as satisfying the contract | best effort, at most once, reaches every subscribed process; payloads trimmed past 8 KB and marked `truncated` |
| the metrics view of the `devx` profile | Prometheus with Grafana, dashboard provisioned from a file | the panel titles are held equal to the cloud dashboard's by a test | the same panels as `deployment/terraform/modules/observability/panels.json` |
| the error tracker locally | GlitchTip (Sentry protocol) | the guideline names it | seeded project key, so the local DSN works without a visit to its UI |
| DNS delegation at the domain's host | Cloudflare's API in `scripts/cloud_create.sh` | one host had to be chosen; another host gets its NS records printed as a manual step | the delegation is written once by the create run; a deploy never writes the domain's zone |

Versions held back, each named with its reason:

- **TypeScript 6.0.3**, not 7.0.2: `typescript-eslint` 8.70, the lint every browser app runs, supports
  TypeScript below 6.1 only. The bump follows the linter's.
- **Valkey 9.0.6**, not 9.2: 9.2 is still a release candidate on the registry.
- **boto3 at the 1.40 line** in `ops/`: `aioboto3` (infra) pins its `aiobotocore`, which pins boto3; one workspace
  resolves one boto3.

## Consequences

- Reviews treat each substitute as the named technology wherever a rule mentions it.
- `arch-upgrade-deps` bumps every pin at the next scheduled bump; the two held-back versions move when their reason
  ends.
