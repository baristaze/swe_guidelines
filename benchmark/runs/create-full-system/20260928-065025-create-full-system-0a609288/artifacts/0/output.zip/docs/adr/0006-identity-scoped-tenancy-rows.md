# 0006. The identity's own copy of each membership, and `tenant_id` on identity-scoped tables

Date: 2026-09-28

Status: accepted

## Context

The identity stage lists a person's memberships across tenants, and a session or a socket ticket names the tenant it
serves. Under the Second Fence, `memberships` is `org`-scoped: a transaction that names only an identity reads
nothing from it, and the listed system-scope methods do not include the memberships read. `arch-check` (STO-11) also
refuses an `org_id` column on a table that composes `IdentityScopedMixin`.

## Decision

- A membership is written together with its identity-scoped copy, `core.identity_memberships` (`identity_id`,
  `tenant_id`, `user_id`, `role`), in the same named atomic storage method, under a transaction that sets both
  `app.org_id` and `app.identity_id`. The memberships read under the identity stage reads the copy; a role change and
  a removal move both rows together.
- On identity-scoped tables (`sessions`, `socket_tickets`, `identity_memberships`) the tenant column is named
  `tenant_id`; `EMPTY_UUID` there means a sign-in or an operator token, which names no tenant.

## Consequences

- One more row per membership, and one more statement in each membership write, inside the same transaction.
- The copy is never read as the truth of a membership inside a tenant; `authenticate` reads `memberships` itself.
