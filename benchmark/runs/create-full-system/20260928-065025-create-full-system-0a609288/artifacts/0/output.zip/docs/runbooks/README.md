# Runbooks

One runbook per operational procedure a person follows by hand, in the language of the platform: what it is for,
when to run it, the steps, and how to tell it worked. An operational task an agent runs is a skill under
`.claude/skills/`, not a runbook; a runbook is what a person reads when no skill covers the case.

| Runbook | For |
|---------|-----|
| [tenant-isolation.md](tenant-isolation.md) | the negative control of the isolation suite, and the record of its last run |
