# 0007. The work item's idempotency key is unique per tenant; arch-check ASY-16 is excepted for that table

Date: 2026-09-28

Status: accepted

## Context

The guideline's The Work Queue states: "The unique index leads with the tenant, `(org_id, idempotency_key)`, as every
index on a tenant table does. So a key collides only within its tenant, and the read-back under that tenant always
finds the row that holds it." The scaffold reference says the same, and asks for a contract case where the same key
under another tenant is inserted.

`arch-check` v0.37.0's ASY-16 accepts only a unique index on `idempotency_key` alone (or a unique column), so it
reports `core.work_items`'s tenant-leading unique index as missing. A global unique index would make the contract
case fail, and would let one tenant learn, by a conflict, that another tenant holds a key.

## Decision

`queue.work_items` keeps the unique index the guideline prescribes, `ix_work_items_org_id_idempotency_key` on
`(org_id, idempotency_key)`. ASY-16 is excepted for `om/src/acme/om/work/storage/tables/work_items.py` in the root
`pyproject.toml`, naming this record. This is a deviation from the checker, not from the guideline.

## Consequences

- The exception is reported as unused, and must be removed, once the checker accepts a tenant-leading unique index.
- The defect is worth reporting to the guideline's maintainers with this record attached.
