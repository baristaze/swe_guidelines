# 0012. Replay keys are derived by UUID v5; arch-check OM-12 is excepted for two rules modules

Date: 2026-09-28

Status: accepted

## Context

OM-12 states: "Every id is a time-ordered `uuid_v7` produced by `new_id()` by whoever constructs the entity, always
above the storage layer." `arch-check` v0.37.0 decides it by refusing any `uuid5` under `acme.om`.

Two rows are not entities a caller constructs once; they are the keys of an effect that must collide when the same
input is replayed:

- `support.rules.delivery_row_id`: the outbox rows a payment delivery lands with its settlement (the receipt and the
  contribution). A redelivery must land the same row ids, so the relay queues the work once (ASY-14, STO-22).
- `work.rules.receipt_id`: the receipt of one outside effect of a work item (one email address). A replay of the item
  must find the receipt an earlier run wrote, so no address is sent to twice (ASY-24).

A `new_id()` would differ on every run, which is exactly the defect those findings describe. The delivery's own key
is already a UUID v5 minted in `integrations/payments` (`WebhookDelivery.key`); these ids are derived from it, and
from the work item's idempotency key, in the pure rules of the namespace that owns the row.

## Decision

The two functions derive their ids with `uuid.uuid5(<replay key>, <name>)`, each documented at the function. OM-12 is
excepted for `om/src/acme/om/support/rules.py` and `om/src/acme/om/work/rules.py` in the root `pyproject.toml`,
naming this record. Every entity id is still minted by `new_id()`.

## Consequences

- A replay of the same delivery or work item lands the same rows, and the storage's insert-once write makes the
  replay a no-op.
- The exception is scoped to the two rules modules; a `uuid5` anywhere else above storage is still refused.
