# 0008. The journalist profile: the first product entity, and its shape

Date: 2026-09-28

Status: accepted

## Context

The scaffold was asked for a first namespace, `journalists`, with one entity, `Journalist display_name:str`. The
entity skill asks, of the person running it, which mixins the entity composes, whether concurrent edits matter,
and which fields the manager owns. Nobody answers questions in this run, so each is decided here from the product
specification: a desk presents a journalist's public profile (name, bio, coverage areas, topics, links, the
verification badge), and the name is the first of those fields.

## Decision

- `Journalist` composes `Identifiable`, `Trackable`, and `SoftDeletable`, in the core role and the org scope. A
  profile is renamed (an update exercises `Trackable`) and removed (a delete exercises `SoftDeletable`); the purge
  of a removed profile is the sweep's, never a route's.
- Not `Named`: the field the product names is `display_name`, the name readers see, and `Named`'s `name` would be
  a second name with no reader.
- Not versioned: one desk's few members rename a profile rarely, and the last rename winning is what a person
  expects there. A version, with `If-Match` on the `PATCH`, arrives with the fields where a lost edit costs work
  (the bio), as a migration and a new required header in one change.
- `MANAGER_OWNED_FIELDS` is empty: the verification badge, when it arrives, is the first field the manager owns,
  since only an operator's review sets it.
- No unique key besides the id: a desk may present several profiles (a small team publishing together), so the
  create reports only whether the id was already written.
- The display name is a personal field: the events, outbox rows, and socket frames of a change carry the
  profile's id, never the name.

## Consequences

- Readers, following, and the public directory read profiles across desks; that read is a later operation of its
  own, over published profiles only, and never a relaxation of the org-scoped list.
