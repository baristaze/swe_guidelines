# Tenant isolation: the negative control

The isolation suite (every storage method's case that presents another tenant's id) is only worth what it catches.
So it is verified against a deliberate breach, run twice before the breach is undone.

## How it is run

1. Take the tenant predicate out of one query of a storage impl over Postgres (the first entity's list, else a
   tenancy list). Leave the table's policy in place.
2. **Run one**: `make test-integration`. It stays green: the database policy (the second fence) still holds the query
   whose predicate went missing.
3. **Run two**: turn the policy off for that table, as the migration login (only the owner alters a table):
   `ALTER TABLE <role>.<table> NO FORCE ROW LEVEL SECURITY; ALTER TABLE <role>.<table> DISABLE ROW LEVEL SECURITY;`
   and run `make test-integration` again. It fails, and its failures name the cross-tenant case of that method and
   the policy check.
4. **Run three**: put the predicate back, turn the policy on again (`ENABLE` and `FORCE ROW LEVEL SECURITY`), and
   run `make test-integration` green.

The suite runs as the runtime login in every run. A run two that stays green is a defect of the suite.

## Record of the last run

2026-09-28, against the local compose stack, by the scaffold's own run.

- **Query**: `JournalistsStoragePostgresImpl.read_journalists`
  (`om/src/acme/om/journalists/storage/impl/postgres.py`), with `Journalists.org_id == org_id` taken out of its
  `WHERE` clause, leaving `deleted_at IS NULL`.
- **Table**: `core.journalists`, org scope, policy `tenant_fence`.
- **Run one** (policy in place): `make test-integration`, 79 passed. The policy held the list to the tenant the
  transaction named.
- **Run two** (`NO FORCE` and `DISABLE ROW LEVEL SECURITY` on `core.journalists`, as `acme_migration`):
  `make test-integration`, 7 failed, 72 passed. The failures:
  - `test_journalist_storage_postgres.py::test_contract[list_under_another_tenant_finds_nothing]`, the cross-tenant
    case of the method;
  - `test_database_fence.py::test_every_table_carries_the_policy_its_scope_declares`, the policy check;
  - besides those two, every other case that lists a tenant's profiles and saw other tenants' rows in the list:
    `create_then_read_and_list`, `list_pages_in_id_order`, `the_list_leaves_out_the_deleted`,
    `write_under_another_tenant_is_refused_and_changes_nothing` (its list under the other tenant), and
    `a_create_race_has_one_winner` (its list after the race).
- **Run three** (predicate back, `ENABLE` and `FORCE ROW LEVEL SECURITY`): `make test-integration`, 79 passed.
