# 0010. A payment delivery settles in the webhook request, not through the inbound queue

Date: 2026-09-28

Status: accepted (a deviation), amended 2026-09-28

## Context

The guideline (Infrastructure, Queues) sends an inbound webhook, once its signature and timestamp verify, to the
inbound queue, and a consumer works it. The rule it deviates from is ASY-12 (`lenses/async.md`), quoted:

> **ASY-12 Queues absorb outside producers; the consumer owns exactly-once**
>
> **Principle.** Work whose producer is outside the platform and cannot wait goes on a queue with the shape of a
> hosted queue service. The queue delivers at least once and does not deduplicate; the consumer dedupes. Dead
> letters are visible: an audit entry names them and a metric counts them.
>
> **Violation.** A consumer that relies on the queue to deduplicate; a message that fails its last attempt and
> disappears without an audit entry or a metric; an in-process impl that lacks visibility timeouts or a dead-letter
> path; an outside producer wired directly into a request handler that does the whole job inline.

The MVP's one delivery is the payment processor's `checkout.session.completed`: it settles a pledge in the reader's
account, owes the reader a receipt, and records a contribution at the desk. No consumer of `Queues.WEBHOOKS` exists
yet.

## Decision

- The webhook route (`services/api/.../routers/support.py`, `POST /webhooks/payments`) is wired to the request
  handler, not to `Queues.WEBHOOKS`: it verifies the delivery's signature and replay window first, then calls
  `SupportManagerImpl.settle_checkout(rctx, ...)`, a request-stage operation whose authority is the verified
  delivery. This is the deviation from ASY-12; the route cites this record.
- The request does one write, not the whole job. `settle_checkout` writes the pledge's settlement in the reader's
  account by compare-and-set on the pledge's `version`, and lands with it, in the same transaction, the outbox rows
  of the change, of the receipt (`SEND_NOTIFICATION`, the notifier's), and of the desk's record
  (`APPEND_CONTRIBUTION`, the maintenance worker's). The contribution is appended by that work item, off the request
  path, never by a second statement after the settlement (STO-20).
- The key is the delivery's UUID v5 over the provider's name and its delivery id (ASY-14). Every outbox row's id is a
  UUID v5 over that key and the row's kind, and the contribution's id is the key itself, so a redelivery, concurrent
  or late, finds the pledge settled (or loses the compare-and-set) and lands nothing; were it to land, its rows and its
  work items would collide with the first delivery's.
- The provider's redelivery on any non-2xx answer is the retry, and the provider's own dashboard is the dead-letter
  view of a delivery that never succeeded; the work the settlement queued has the work queue's dead letters (audited
  and counted).

## Consequences

- A delivery that needs slow work (a renewal cascade, a dispute) moves to the inbound queue with a consumer, and
  this decision is superseded then.
- A delivery whose pledge cannot be found is answered `2xx` and logged, so the provider does not retry it forever.
- The desk sees a contribution moments after the settlement, once the maintenance worker has run its item, not in
  the same instant.
