# 0004. Reports are encrypted on the sender's device; the platform holds ciphertext and wrapped keys

Date: 2026-09-28

Status: accepted

## Context

The product requires client-side envelope encryption with per-recipient key wrapping: every submission gets a fresh
symmetric key; the whole report (subject, description, attachments) is encrypted once on the sender's device; the
report key is wrapped separately for each chosen journalist's public key; the platform stores one ciphertext and one
wrapped key per recipient, and never holds a private key or a plaintext. It also asks for attachment malware
scanning, stripping of photo metadata, minimal logging of anonymous activity, and configurable retention.

## Decision

- **Cryptography lives in the clients.** Each journalist's key pair is generated in their browser; the private key
  never leaves it (it is stored encrypted under a passphrase the platform never sees). The platform stores the
  public key on the journalist's profile. The server holds a report as an opaque ciphertext in the
  `report-attachments` bucket (ciphertext only, keyed by tenant) plus one wrapped key per recipient desk.
- **Search and filtering run on what is not encrypted by design**: the journalist-side state, tags a journalist
  adds after decrypting, dates, and the recipient desk. A sender's own tags and location are inside the ciphertext.
- **Malware scanning is by hash, on the recipient's client**: after decrypting an attachment, the journalist's
  client computes its SHA-256 and asks the platform, which asks the scanner (`MalwareScannerInterface`, VirusTotal
  in the cloud, a twin locally) for a verdict on the hash. No plaintext leaves the recipient's device; an unknown
  file is shown with a warning and never opened automatically.
- **Metadata stripping happens on the sender's device**, before encryption (EXIF removed from images by the
  submission page); the server cannot strip what it cannot read.
- **Minimal logging of anonymous activity**: the intake route logs the request id, the desk, and the outcome, never
  the client address beyond the rate limiter's short-lived digest, and never a body.
- **Retention**: a desk sets how long reports it archived are kept; the maintenance sweep purges past that
  period, the purge being the one hard delete.

## Consequences

- A journalist who loses their private key loses access to past reports; key backup is a product feature of its
  own, designed with the same constraint.
- Server-side features that need plaintext (full-text search of report bodies, server-side previews) are ruled out
  by this decision, not deferred.
