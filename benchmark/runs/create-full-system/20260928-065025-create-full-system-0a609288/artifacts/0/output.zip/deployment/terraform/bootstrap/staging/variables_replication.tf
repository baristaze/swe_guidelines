variable "replicate_to_production" {
  description = "Replicate the registry and the bundles into production's account. scripts/cloud_create.sh turns it on in staging's second run, once production's artifacts bucket exists."
  type        = bool
  default     = false
}
