# One SQS queue per Queues member under the prefix, each with its dead-letter
# queue, <prefix>-<name>-dlq, after max_receives deliveries (the same number
# the process reads as ACME_QUEUE_MAX_RECEIVES). Encrypted at rest.

variable "prefix" {
  description = "acme-<env>, ACME_QUEUES_PREFIX."
  type        = string
}

variable "names" {
  type    = list(string)
  default = ["webhooks"]
}

variable "max_receives" {
  type = number
}

variable "visibility_timeout_seconds" {
  type    = number
  default = 60
}

variable "retention_seconds" {
  type    = number
  default = 345600
}

resource "aws_sqs_queue" "dlq" {
  for_each                  = toset(var.names)
  name                      = "${var.prefix}-${each.key}-dlq"
  message_retention_seconds = 1209600
  sqs_managed_sse_enabled   = true
}

resource "aws_sqs_queue" "this" {
  for_each                   = toset(var.names)
  name                       = "${var.prefix}-${each.key}"
  visibility_timeout_seconds = var.visibility_timeout_seconds
  message_retention_seconds  = var.retention_seconds
  receive_wait_time_seconds  = 20
  sqs_managed_sse_enabled    = true

  redrive_policy = jsonencode({
    deadLetterTargetArn = aws_sqs_queue.dlq[each.key].arn
    maxReceiveCount     = var.max_receives
  })
}

resource "aws_sqs_queue_redrive_allow_policy" "dlq" {
  for_each  = toset(var.names)
  queue_url = aws_sqs_queue.dlq[each.key].id

  redrive_allow_policy = jsonencode({
    redrivePermission = "byQueue"
    sourceQueueArns   = [aws_sqs_queue.this[each.key].arn]
  })
}

output "queue_arns" {
  value = concat([for q in aws_sqs_queue.this : q.arn], [for q in aws_sqs_queue.dlq : q.arn])
}

output "queue_names" {
  value = { for k, q in aws_sqs_queue.this : k => q.name }
}

output "dlq_names" {
  value = { for k, q in aws_sqs_queue.dlq : k => q.name }
}
