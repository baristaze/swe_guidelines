# The container runtime every service, worker, and one-off task runs on, the one
# security group the tasks share (the database and the cache admit it), and the
# log group the collectors write their embedded metrics to.

variable "name" {
  description = "acme-<env>: the cluster's name."
  type        = string
}

variable "environment" {
  type = string
}

variable "product" {
  type    = string
  default = "acme"
}

variable "vpc_id" {
  type = string
}

variable "log_retention_days" {
  type = number
}

resource "aws_ecs_cluster" "this" {
  name = var.name

  # Container insights feed "running tasks below desired" and the "Processes up" panel.
  setting {
    name  = "containerInsights"
    value = "enabled"
  }
}

resource "aws_ecs_cluster_capacity_providers" "this" {
  cluster_name       = aws_ecs_cluster.this.name
  capacity_providers = ["FARGATE"]

  default_capacity_provider_strategy {
    capacity_provider = "FARGATE"
    weight            = 1
  }
}

resource "aws_security_group" "tasks" {
  name        = "${var.name}-tasks"
  description = "Every task of ${var.name}; ingress only from the load balancer, added by the load balancer module."
  vpc_id      = var.vpc_id

  egress {
    description = "The registry, the secret store, the logs, the object store, the queue, and outside providers, through the NAT gateway."
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "aws_cloudwatch_log_group" "metrics" {
  name              = "/${var.product}/${var.environment}/metrics"
  retention_in_days = var.log_retention_days
}

output "cluster_name" {
  value = aws_ecs_cluster.this.name
}

output "cluster_arn" {
  value = aws_ecs_cluster.this.arn
}

output "tasks_security_group_id" {
  value = aws_security_group.tasks.id
}

output "metrics_log_group" {
  value = aws_cloudwatch_log_group.metrics.name
}
