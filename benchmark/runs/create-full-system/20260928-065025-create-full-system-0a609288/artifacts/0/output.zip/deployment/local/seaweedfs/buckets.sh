#!/bin/sh
# Creates the local buckets the settings name, idempotently: one per Buckets member under the local prefix.
set -e
for bucket in acme-local-report-attachments acme-local-profile-media; do
  echo "s3.bucket.create -name ${bucket}" | weed shell -master=objectstore:9333 || true
done
