terraform {
  required_version = ">= 1.16.3, < 2.0.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.65.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.9.0"
    }
  }

  # Partial configuration: the pipeline passes -backend-config=bucket=$TF_STATE_BUCKET
  # (acme-state-<account id>, made by bootstrap/prod).
  backend "s3" {
    key          = "environments/prod/terraform.tfstate"
    region       = "eu-central-1"
    encrypt      = true
    use_lockfile = true
  }
}
