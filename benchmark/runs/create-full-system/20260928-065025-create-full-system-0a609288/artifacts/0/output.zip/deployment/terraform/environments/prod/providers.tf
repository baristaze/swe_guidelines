provider "aws" {
  region              = local.region
  allowed_account_ids = [local.account_id]

  default_tags {
    tags = {
      environment = var.environment
      product     = local.product
      managed_by  = "terraform"
    }
  }
}

# CloudFront reads certificates (and its web firewall) from us-east-1 alone.
provider "aws" {
  alias               = "us_east_1"
  region              = "us-east-1"
  allowed_account_ids = [local.account_id]

  default_tags {
    tags = {
      environment = var.environment
      product     = local.product
      managed_by  = "terraform"
    }
  }
}
