terraform {
  required_version = ">= 1.16.3, < 2.0.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.65.0"
    }
  }

  # Partial configuration: scripts/cloud_create.sh applies this root first with
  # local state (a backend_override.tf it writes and removes), then moves the
  # state here with -backend-config=bucket=acme-state-<account id>. No pipeline
  # role may write this key.
  backend "s3" {
    key          = "bootstrap/prod/terraform.tfstate"
    region       = "eu-central-1"
    encrypt      = true
    use_lockfile = true
  }
}
