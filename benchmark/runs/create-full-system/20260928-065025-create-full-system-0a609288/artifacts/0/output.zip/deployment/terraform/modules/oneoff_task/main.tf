# A one-off task on a service's image: the migration, run inside the apply before
# the rollout (the services depend on this module), or the grant-operator
# subcommand, which grant-operator.yml runs on dispatch.
#
# With run_on_apply, the task runs whenever its definition changes (a new image
# or new settings), and the apply waits for it to stop: a non-zero exit ends the
# apply with the old tasks still serving.

variable "name_prefix" {
  type = string
}

variable "product" {
  type    = string
  default = "acme"
}

variable "environment" {
  type = string
}

variable "process" {
  description = "migrate or grant-operator: the family is <name_prefix>-<process>."
  type        = string
}

variable "region" {
  type = string
}

variable "image" {
  type = string
}

variable "command" {
  type = list(string)
}

variable "cpu" {
  type    = number
  default = 512
}

variable "memory" {
  type    = number
  default = 1024
}

variable "environment_variables" {
  type = map(string)
}

variable "secrets" {
  type = map(string)
}

variable "labels" {
  type    = map(string)
  default = {}
}

variable "task_role_statements" {
  type = list(object({
    sid       = string
    actions   = list(string)
    resources = list(string)
  }))
  default = []
}

variable "permissions_boundary_arn" {
  type = string
}

variable "log_retention_days" {
  type = number
}

variable "metrics_log_group" {
  type = string
}

variable "collector_image" {
  type = string
}

variable "run_on_apply" {
  type    = bool
  default = false
}

variable "run_triggers" {
  description = "Anything else whose change re-runs the task."
  type        = list(string)
  default     = []
}

variable "run_after" {
  description = "Values the run waits for (the URL secrets' versions)."
  type        = list(string)
  default     = []
}

variable "cluster_name" {
  type = string
}

variable "subnet_ids" {
  type = list(string)
}

variable "security_group_ids" {
  type = list(string)
}

variable "timeout_seconds" {
  type    = number
  default = 1800
}

module "task" {
  source = "../task"

  family                   = "${var.name_prefix}-${var.process}"
  product                  = var.product
  environment              = var.environment
  process                  = var.process
  region                   = var.region
  image                    = var.image
  command                  = var.command
  container_port           = null
  cpu                      = var.cpu
  memory                   = var.memory
  environment_variables    = var.environment_variables
  secrets                  = var.secrets
  labels                   = var.labels
  task_role_statements     = var.task_role_statements
  permissions_boundary_arn = var.permissions_boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = var.metrics_log_group
  collector_image          = var.collector_image
}

resource "terraform_data" "run" {
  count = var.run_on_apply ? 1 : 0

  triggers_replace = concat([module.task.arn], var.run_triggers)
  input            = var.run_after

  provisioner "local-exec" {
    interpreter = ["bash"]
    command     = "${path.module}/run_task.sh"
    environment = {
      CLUSTER         = var.cluster_name
      TASK_DEFINITION = module.task.arn
      CONTAINER       = var.process
      SUBNETS         = join(",", var.subnet_ids)
      SECURITY_GROUPS = join(",", var.security_group_ids)
      REGION          = var.region
      TIMEOUT_SECONDS = tostring(var.timeout_seconds)
    }
  }
}

output "task_definition_arn" {
  value = module.task.arn
}

output "task_definition_family" {
  value = module.task.family
}

output "container_name" {
  value = module.task.container_name
}

output "task_role_name" {
  value = module.task.task_role_name
}

output "task_role_arn" {
  value = module.task.task_role_arn
}

output "log_group" {
  value = module.task.log_group
}

output "completed" {
  description = "Known once the run finished (or immediately without run_on_apply); the rollout depends on it."
  value       = var.run_on_apply ? terraform_data.run[0].id : module.task.arn
}
