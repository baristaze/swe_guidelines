# The platform's own secrets beside the database URLs.
#
# - The API's TOTP encryption key: a Fernet key (32 random bytes, url-safe
#   base64) from an ephemeral generator, its version written write-only.
# - The API's internal signing key (HMAC), generated the same way.
# - The provider keys and the error-tracking DSN: created empty, with no
#   version. A person puts each value outside Terraform (aws secretsmanager
#   put-secret-value), so no key enters state; the task definitions reference
#   them by ARN.
# - The two operator-token secrets, provisioner and smoke: created empty. The
#   grant task writes a token into one; nothing else may write them, and only
#   the person's identity-center role (both) and the smoke role (smoke) may
#   read them. The deploy role only starts the grant task; the smoke job reads
#   the token under the smoke role, which holds nothing that applies.

variable "prefix" {
  description = "acme-<env>."
  type        = string
}

variable "account_id" {
  type = string
}

variable "environment" {
  type = string
}

variable "product" {
  type    = string
  default = "acme"
}

variable "recovery_window_days" {
  description = "0 outside production, so a create that follows a nuke finds the names free."
  type        = number
}

variable "totp_key_version" {
  description = "Bump to rotate the TOTP encryption key (every enrolled factor must then be re-enrolled)."
  type        = number
  default     = 1
}

variable "internal_signing_key_version" {
  description = "Bump to rotate the API's internal signing key (the environment keeps the previous version verifying under its key id)."
  type        = number
  default     = 1
}

variable "provider_secrets" {
  description = "Secrets created empty, filled by a person: short name => description."
  type        = map(string)
  default = {
    "error-tracking-dsn"    = "ACME_ERROR_TRACKING_DSN (may be the empty string)"
    "workos-api-key"        = "ACME_INTEGRATIONS_WORKOS_API_KEY"
    "stripe-secret-key"     = "ACME_INTEGRATIONS_STRIPE_SECRET_KEY"
    "stripe-webhook-secret" = "ACME_INTEGRATIONS_STRIPE_WEBHOOK_SECRET"
    "postmark-server-token" = "ACME_INTEGRATIONS_POSTMARK_SERVER_TOKEN"
    "twilio-auth-token"     = "ACME_INTEGRATIONS_TWILIO_AUTH_TOKEN"
    "virustotal-api-key"    = "ACME_INTEGRATIONS_VIRUSTOTAL_API_KEY"
  }
}

variable "grant_task_role_name" {
  description = "The grant-operator task's role, the one writer of the token secrets."
  type        = string
}

variable "everyday_permission_set" {
  description = "The identity center's everyday permission set, whose role reads the token secrets."
  type        = string
}

locals {
  grant_role_arn        = "arn:aws:iam::${var.account_id}:role/${var.grant_task_role_name}"
  smoke_role_arn        = "arn:aws:iam::${var.account_id}:role/${var.product}-smoke-${var.environment}"
  everyday_role_pattern = "arn:aws:iam::${var.account_id}:role/aws-reserved/sso.amazonaws.com/*AWSReservedSSO_${var.everyday_permission_set}_*"
  token_readers = {
    provisioner = [local.everyday_role_pattern]
    smoke       = [local.everyday_role_pattern, local.smoke_role_arn]
  }
}

ephemeral "random_bytes" "totp_key" {
  length = 32
}

resource "aws_secretsmanager_secret" "totp_key" {
  name                    = "${var.prefix}-totp-encryption-key"
  description             = "ACME_API_TOTP_ENCRYPTION_KEY: a Fernet key, the API's alone."
  recovery_window_in_days = var.recovery_window_days
}

resource "aws_secretsmanager_secret_version" "totp_key" {
  secret_id                = aws_secretsmanager_secret.totp_key.id
  secret_string_wo         = replace(replace(ephemeral.random_bytes.totp_key.base64, "+", "-"), "/", "_")
  secret_string_wo_version = var.totp_key_version
}

# The API's internal signing key: the HMAC key a peer service's internal
# credential is signed and verified with. 32 random bytes, url-safe base64,
# generated and written exactly like the TOTP key: no value in state or a plan.
ephemeral "random_bytes" "internal_signing_key" {
  length = 32
}

resource "aws_secretsmanager_secret" "internal_signing_key" {
  name                    = "${var.prefix}-internal-signing-key"
  description             = "ACME_API_INTERNAL_SIGNING_KEY: the HMAC key of peer services' internal credentials, the API's alone."
  recovery_window_in_days = var.recovery_window_days
}

resource "aws_secretsmanager_secret_version" "internal_signing_key" {
  secret_id                = aws_secretsmanager_secret.internal_signing_key.id
  secret_string_wo         = replace(replace(ephemeral.random_bytes.internal_signing_key.base64, "+", "-"), "/", "_")
  secret_string_wo_version = var.internal_signing_key_version
}

resource "aws_secretsmanager_secret" "provider" {
  for_each                = var.provider_secrets
  name                    = "${var.prefix}-${each.key}"
  description             = "${each.value}. Created empty; a person puts the value outside Terraform."
  recovery_window_in_days = var.recovery_window_days
}

resource "aws_secretsmanager_secret" "token" {
  for_each                = local.token_readers
  name                    = "${var.prefix}-${each.key}-token"
  description             = "The ${each.key} identity's operator token, written by the grant task alone. Created empty."
  recovery_window_in_days = var.recovery_window_days
}

data "aws_iam_policy_document" "token" {
  for_each = local.token_readers

  statement {
    sid       = "OnlyTheGrantTaskWrites"
    effect    = "Deny"
    actions   = ["secretsmanager:PutSecretValue"]
    resources = ["*"]
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    condition {
      test     = "ArnNotLike"
      variable = "aws:PrincipalArn"
      values   = [local.grant_role_arn]
    }
  }

  statement {
    sid       = "OnlyNamedReaders"
    effect    = "Deny"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = ["*"]
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    condition {
      test     = "ArnNotLike"
      variable = "aws:PrincipalArn"
      values   = each.value
    }
  }
}

resource "aws_secretsmanager_secret_policy" "token" {
  for_each   = local.token_readers
  secret_arn = aws_secretsmanager_secret.token[each.key].arn
  policy     = data.aws_iam_policy_document.token[each.key].json
}

output "totp_key_secret_arn" {
  value = aws_secretsmanager_secret.totp_key.arn
}

output "internal_signing_key_secret_arn" {
  value = aws_secretsmanager_secret.internal_signing_key.arn
}

output "provider_secret_arns" {
  description = "short name => ARN"
  value       = { for k, s in aws_secretsmanager_secret.provider : k => s.arn }
}

output "token_secret_arns" {
  value = { for k, s in aws_secretsmanager_secret.token : k => s.arn }
}

output "token_secret_names" {
  value = { for k, s in aws_secretsmanager_secret.token : k => s.name }
}
