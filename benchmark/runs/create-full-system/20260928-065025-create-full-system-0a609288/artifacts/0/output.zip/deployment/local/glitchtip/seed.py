# Seeds the local GlitchTip so the error tracker works with no visit to its UI: one user, the organization
# "acme", the project "acme-api" with the fixed key the local DSN in .env.example names, and an API token
# (ACME_LOCAL_GLITCHTIP_TOKEN) the telemetry round trip reads events with. Local only; run by the
# `glitchtip-seed` service through `./manage.py shell`, so it is idempotent: every run converges on the same rows.
import os
import uuid

from apps.api_tokens.models import APIToken
from apps.organizations_ext.constants import OrganizationUserRole
from apps.organizations_ext.models import Organization, OrganizationUser
from apps.projects.models import Project, ProjectKey
from apps.users.models import User

EMAIL = "devx@acme.example"
PASSWORD = os.environ.get("ACME_LOCAL_GLITCHTIP_PASSWORD", "glitchtip_local_pswd")
TOKEN = os.environ["ACME_LOCAL_GLITCHTIP_TOKEN"]
PUBLIC_KEY = uuid.UUID(os.environ.get("ACME_LOCAL_GLITCHTIP_DSN_KEY", "6f3b8f2fd2a54a0f9c7e3c1a8b9d0e11"))

user = User.objects.filter(email=EMAIL).first()
if user is None:
    user = User.objects.create_superuser(email=EMAIL, password=PASSWORD)

org = Organization.objects.filter(slug="acme").first()
if org is None:
    org = Organization.objects.create(name="acme", slug="acme")
OrganizationUser.objects.get_or_create(organization=org, user=user, defaults={"role": OrganizationUserRole.OWNER})

project = Project.objects.filter(organization=org, slug="acme-api").first()
if project is None:
    project = Project.objects.create(organization=org, name="acme-api", slug="acme-api", platform="python")

if not ProjectKey.objects.filter(public_key=PUBLIC_KEY).exists():
    key = ProjectKey.objects.filter(project=project).first()
    if key is None:
        ProjectKey.objects.create(project=project, public_key=PUBLIC_KEY)
    else:
        ProjectKey.objects.filter(pk=key.pk).update(public_key=PUBLIC_KEY)

token = APIToken.objects.filter(token=TOKEN).first()
if token is None:
    token = APIToken.objects.create(user=user, label="acme local telemetry round trip", token=TOKEN)
token.add_permissions(["project:read", "event:read", "org:read", "team:read", "member:read"])

print(f"glitchtip seeded: org acme, project acme-api (id {project.id}), key {PUBLIC_KEY.hex}")
