variable "product" {
  description = "The kebab slug every resource name starts with."
  type        = string
  default     = "acme"
}

variable "environment" {
  description = "The environment this account holds: staging or production."
  type        = string

  validation {
    condition     = contains(["staging", "production"], var.environment)
    error_message = "environment is staging or production."
  }
}

variable "other_environment" {
  description = "The other environment's name, which every fence here denies by tag."
  type        = string
}

variable "account_id" {
  description = "This account's id, from deployment/cloud/environments.json."
  type        = string
}

variable "region" {
  description = "The region, from deployment/cloud/environments.json."
  type        = string
}

variable "public_names" {
  description = "The public names this environment serves; one hosted zone each."
  type        = list(string)
}

variable "github_repository" {
  description = "owner/name of the repository whose workflows assume the pipeline roles (informational; the trust uses the ids)."
  type        = string
}

variable "github_repository_id" {
  description = "The repository's immutable numeric id (gh api repos/<owner>/<name> --jq .id)."
  type        = string
}

variable "github_repository_owner_id" {
  description = "The repository owner's immutable numeric id (gh api repos/<owner>/<name> --jq .owner.id)."
  type        = string
}

variable "pipeline_roles" {
  description = <<-EOT
    The roles the repository host's identity federation assumes, keyed by verb (build, deploy, plan, smoke).
    Each names the repository-host environment and the branch its trust admits, and its kind:
    "build" pushes images and bundles only, "plan" reads and writes the plan and the lock, "deploy" applies,
    "smoke" reads the smoke token and the signals. No two roles may share a repository-host environment:
    the environment is what tells the roles apart in the trust, so a job holds exactly its own.
  EOT
  type = map(object({
    github_environment = string
    branch             = string
    kind               = string
  }))

  validation {
    condition     = alltrue([for r in values(var.pipeline_roles) : contains(["build", "plan", "deploy", "smoke"], r.kind)])
    error_message = "kind is build, plan, deploy, or smoke."
  }

  validation {
    condition     = length(distinct([for r in values(var.pipeline_roles) : r.github_environment])) == length(var.pipeline_roles)
    error_message = "Each pipeline role names its own repository-host environment; two roles on one environment are one credential."
  }
}

variable "ecr_repositories" {
  description = "One image repository per process image."
  type        = list(string)
  default     = ["acme-api", "acme-maintenance", "acme-notifier"]
}

variable "ecr_keep_images" {
  description = "How many images each repository keeps, beyond every image tagged prod-."
  type        = number
  default     = 100
}

variable "bundle_prefix" {
  description = "The prefix of the artifacts bucket the bundles live under, kept by commit."
  type        = string
  default     = "bundles/"
}

variable "artifacts_retention_days" {
  description = "How long a bundle is kept; outlasts the last few releases."
  type        = number
  default     = 180
}

variable "bundle_object_lock" {
  description = "Production: object lock on the artifacts bucket and a refusal of a second write to a bundle key."
  type        = bool
  default     = false
}

variable "bundle_object_lock_days" {
  description = "How long each bundle version is locked (governance mode)."
  type        = number
  default     = 90
}

variable "replicate_to_production" {
  description = "Staging only: replicate the registry and the bundles into production's account. Turned on once production's bucket exists."
  type        = bool
  default     = false
}

variable "production_account_id" {
  description = "Staging only: production's account id, the one replication target."
  type        = string
  default     = ""
}

variable "staging_account_id" {
  description = "Production only: staging's account id, the one replication source this account grants."
  type        = string
  default     = ""
}

variable "grant_replication_from_staging" {
  description = "Production only: grant staging's replication its two writes (images into these repositories, bundles under the bundle prefix)."
  type        = bool
  default     = false
}

variable "everyday_permission_set" {
  description = "The identity center's everyday permission set; its role (AWSReservedSSO_<name>_<suffix>) is trusted by the investigate role by pattern."
  type        = string
  default     = "Everyday"
}

variable "trail_retention_days" {
  description = "How long the trail's objects are kept."
  type        = number
  default     = 365
}

variable "monthly_budget_usd" {
  description = "The account's monthly budget in US dollars."
  type        = number
}

variable "owner_email" {
  description = "Who the budget and the anomaly monitor alert."
  type        = string
}

variable "anomaly_threshold_usd" {
  description = "The absolute impact of a cost anomaly that is reported."
  type        = number
  default     = 20
}
