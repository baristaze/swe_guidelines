# The API image: two stages, the workspace's locked dependencies of one package, a non-root user,
# and a healthcheck on /healthz (never /readyz). Built from the repository root as the context.

FROM python:3.14.7-slim-trixie AS build
COPY --from=ghcr.io/astral-sh/uv:0.12.17 /uv /bin/uv
ENV UV_COMPILE_BYTECODE=1 UV_LINK_MODE=copy UV_PYTHON_DOWNLOADS=never
WORKDIR /app
COPY pyproject.toml uv.lock ./
COPY om om
COPY infra infra
COPY integrations integrations
COPY services/api services/api
RUN uv sync --frozen --no-dev --no-editable --package acme-api

FROM python:3.14.7-slim-trixie AS runtime
RUN groupadd --system acme && useradd --system --gid acme --home /app acme
WORKDIR /app
COPY --from=build /app/.venv /app/.venv
COPY om/migrations /app/om/migrations
COPY deployment/docker/entrypoint.sh /usr/local/bin/entrypoint.sh
ENV PATH="/app/.venv/bin:$PATH" \
    ACME_DATABASE_MIGRATIONS_DIR=/app/om/migrations \
    ACME_API_HOST=0.0.0.0 \
    ACME_API_PORT=8000
USER acme
EXPOSE 8000
HEALTHCHECK --interval=10s --timeout=3s --start-period=20s --retries=3 \
  CMD ["python", "-c", "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:8000/healthz', timeout=2).status == 200 else 1)"]
ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]
CMD ["acme-api", "serve"]
