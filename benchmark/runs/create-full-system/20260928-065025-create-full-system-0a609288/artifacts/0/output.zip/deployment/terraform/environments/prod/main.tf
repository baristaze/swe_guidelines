# The environment root. Every environment root is this same module graph; what
# differs is terraform.tfvars and the backend key. The pipeline applies it on
# every deploy: the migration runs as a one-off task on the new image inside
# the apply, before the rollout, and the rollout depends on it.

locals {
  layout        = jsondecode(file("${path.module}/../../../cloud/environments.json"))
  env           = local.layout.environments[var.environment]
  product       = local.layout.product
  region        = local.layout.region
  account_id    = local.env.account_id
  is_production = var.environment == "production"

  # acme-<env>: the cluster, the alarm topic's and dashboard's stem, and the
  # prefix of every bucket, queue, and secret the settings read.
  name   = "${local.product}-${var.environment}"
  prefix = local.name

  base_domain     = local.env.base_domain
  api_domain      = "api.${local.base_domain}"
  app_domain      = "app.${local.base_domain}"
  admin_domain    = "admin.${local.base_domain}"
  api_origin      = "https://${local.api_domain}"
  allowed_origins = ["https://${local.app_domain}", "https://${local.admin_domain}"]

  boundary_arn          = "arn:aws:iam::${local.account_id}:policy/${local.product}-boundary-${var.environment}"
  secret_recovery_days  = local.is_production ? 30 : 0
  grant_task_role_name  = "${local.name}-grant-operator-task"
  api_port              = 8000
  worker_port           = 9100
  worker_process        = "maintenance"
  notifier_port         = 9101
  notifier_process      = "notifier"
  migrations_dir        = "/app/om/migrations"
  otel_exporter         = "http://localhost:4318"
  secrets_version_label = "${local.product}.secrets-version"
}

check "public_names" {
  assert {
    condition     = alltrue([for n in [local.api_domain, local.app_domain, local.admin_domain] : contains(local.env.public_names, n)])
    error_message = "deployment/cloud/environments.json must list api., app., and admin. under the base domain as this environment's public names."
  }
}

# ---------------------------------------------------------------------------
# The stores.
# ---------------------------------------------------------------------------

module "network" {
  source = "../../modules/network"

  name              = local.name
  cidr              = var.vpc_cidr
  egress            = var.egress
  nat_gateway_count = var.nat_gateway_count
}

module "cluster" {
  source = "../../modules/cluster"

  name               = local.name
  product            = local.product
  environment        = var.environment
  vpc_id             = module.network.vpc_id
  log_retention_days = var.log_retention_days
}

module "database" {
  source = "../../modules/database"

  name                        = local.name
  product                     = local.product
  environment                 = var.environment
  vpc_id                      = module.network.vpc_id
  subnet_ids                  = module.network.private_subnet_ids
  client_security_group_ids   = [module.cluster.tasks_security_group_id]
  engine_version              = var.database_engine_version
  parameter_group_family      = var.database_parameter_group_family
  instance_class              = var.database_instance_class
  allocated_storage           = var.database_allocated_storage
  max_allocated_storage       = var.database_max_allocated_storage
  multi_az                    = var.database_multi_az
  backup_retention_days       = var.database_backup_retention_days
  deletion_protection         = var.database_deletion_protection
  destroyable                 = var.destroyable
  password_version            = var.database_password_version
  secret_recovery_window_days = local.secret_recovery_days
}

module "cache" {
  source = "../../modules/cache"

  name                      = local.name
  vpc_id                    = module.network.vpc_id
  subnet_ids                = module.network.private_subnet_ids
  client_security_group_ids = [module.cluster.tasks_security_group_id]
  engine_version            = var.cache_engine_version
  node_type                 = var.cache_node_type
  num_nodes                 = var.cache_num_nodes
}

module "queue" {
  source = "../../modules/queue"

  prefix       = local.prefix
  names        = ["webhooks"]
  max_receives = var.queue_max_receives
}

module "buckets" {
  source = "../../modules/buckets"

  prefix          = local.prefix
  names           = ["report-attachments", "profile-media"]
  allowed_origins = local.allowed_origins
  destroyable     = var.destroyable
}

module "secrets" {
  source = "../../modules/secrets"

  prefix                       = local.prefix
  account_id                   = local.account_id
  environment                  = var.environment
  product                      = local.product
  recovery_window_days         = local.secret_recovery_days
  totp_key_version             = var.totp_key_version
  internal_signing_key_version = var.internal_signing_key_version
  grant_task_role_name         = local.grant_task_role_name
  everyday_permission_set      = var.everyday_permission_set
}

# ---------------------------------------------------------------------------
# The process environment. Every name the settings read, and every secret by ARN.
# ---------------------------------------------------------------------------

locals {
  shared_environment = {
    ACME_ENVIRONMENT                    = var.environment
    ACME_RELEASE                        = var.release
    ACME_CACHE_BACKEND                  = "valkey"
    ACME_CACHE_URL                      = module.cache.url
    ACME_CACHE_TIMEOUT_MS               = tostring(var.cache_timeout_ms)
    ACME_BUCKETS_BACKEND                = "s3"
    ACME_BUCKETS_PREFIX                 = local.prefix
    ACME_S3_ENDPOINT_URL                = ""
    ACME_TOPICS_BACKEND                 = "postgres"
    ACME_QUEUES_BACKEND                 = "sqs"
    ACME_QUEUES_PREFIX                  = local.prefix
    ACME_SQS_ENDPOINT_URL               = ""
    ACME_QUEUE_MAX_RECEIVES             = tostring(var.queue_max_receives)
    ACME_SECRETS_BACKEND                = "aws"
    ACME_SECRETS_PREFIX                 = local.prefix
    ACME_AWS_REGION                     = local.region
    ACME_CALL_TIMEOUT_SECONDS           = tostring(var.call_timeout_seconds)
    ACME_LOG_JSON                       = "true"
    ACME_LOG_LEVEL                      = var.log_level
    ACME_OTEL_EXPORTER_ENDPOINT         = local.otel_exporter
    ACME_DATABASE_POOL_SIZE             = tostring(var.database_pool_size)
    ACME_DATABASE_POOL_CHECKOUT_TIMEOUT = tostring(var.database_pool_checkout_timeout)
    ACME_DATABASE_STATEMENT_TIMEOUT     = tostring(var.database_statement_timeout)
    ACME_DATABASE_MIGRATIONS_DIR        = local.migrations_dir
  }

  # The services and workers hold the runtime and the system logins' URLs, never the migration login's or the master's.
  shared_secrets = {
    ACME_DATABASE_URL        = module.database.runtime_url_secret_arn
    ACME_DATABASE_SYSTEM_URL = module.database.system_url_secret_arn
    ACME_TOPICS_URL          = module.database.runtime_url_secret_arn
    ACME_ERROR_TRACKING_DSN  = module.secrets.provider_secret_arns["error-tracking-dsn"]
  }

  api_environment = merge(local.shared_environment, {
    ACME_SERVICE_NAME                    = "${local.product}-api"
    ACME_API_PORT                        = tostring(local.api_port)
    ACME_API_ALLOWED_ORIGINS             = jsonencode(local.allowed_origins)
    ACME_API_SIGNUP_ENABLED              = "true"
    ACME_API_PUBLIC_URL                  = local.api_origin
    ACME_INTEGRATIONS_IDENTITY_PROVIDER  = "workos"
    ACME_INTEGRATIONS_WORKOS_CLIENT_ID   = var.workos_client_id
    ACME_INTEGRATIONS_PAYMENTS           = "stripe"
    ACME_INTEGRATIONS_EMAIL              = "postmark"
    ACME_INTEGRATIONS_EMAIL_FROM         = var.email_from
    ACME_INTEGRATIONS_SMS                = "twilio"
    ACME_INTEGRATIONS_TWILIO_ACCOUNT_SID = var.twilio_account_sid
    ACME_INTEGRATIONS_SMS_FROM           = var.sms_from
    ACME_INTEGRATIONS_MALWARE_SCANNER    = "virustotal"
    ACME_INTEGRATIONS_TIMEOUT_SECONDS    = tostring(var.integrations_timeout_seconds)
    ACME_API_INTERNAL_SIGNING_KEY_ID     = "v${var.internal_signing_key_version}"
    }, var.internal_signing_key_version > 1 ? {
    # after a rotation the previous key still verifies under its own id, so no credential in flight is refused
    ACME_API_INTERNAL_PREVIOUS_SIGNING_KEY_ID = "v${var.internal_signing_key_version - 1}"
  } : {})

  api_secrets = merge(local.shared_secrets, {
    ACME_API_TOTP_ENCRYPTION_KEY            = module.secrets.totp_key_secret_arn
    ACME_API_INTERNAL_SIGNING_KEY           = module.secrets.internal_signing_key_secret_arn
    ACME_INTEGRATIONS_WORKOS_API_KEY        = module.secrets.provider_secret_arns["workos-api-key"]
    ACME_INTEGRATIONS_STRIPE_SECRET_KEY     = module.secrets.provider_secret_arns["stripe-secret-key"]
    ACME_INTEGRATIONS_STRIPE_WEBHOOK_SECRET = module.secrets.provider_secret_arns["stripe-webhook-secret"]
    ACME_INTEGRATIONS_POSTMARK_SERVER_TOKEN = module.secrets.provider_secret_arns["postmark-server-token"]
    ACME_INTEGRATIONS_TWILIO_AUTH_TOKEN     = module.secrets.provider_secret_arns["twilio-auth-token"]
    ACME_INTEGRATIONS_VIRUSTOTAL_API_KEY    = module.secrets.provider_secret_arns["virustotal-api-key"]
    }, var.internal_signing_key_version > 1 ? {
    # the secret's previous version: Secrets Manager moves AWSPREVIOUS onto it when the rotation writes the new one
    ACME_API_INTERNAL_PREVIOUS_SIGNING_KEY = "${module.secrets.internal_signing_key_secret_arn}::AWSPREVIOUS:"
  } : {})

  worker_environment = merge(local.shared_environment, {
    ACME_SERVICE_NAME                  = "${local.product}-${local.worker_process}"
    ACME_WORKER_NAME                   = local.worker_process
    ACME_WORKER_PORT                   = tostring(local.worker_port)
    ACME_WORKER_CAPACITY               = tostring(var.worker_capacity)
    ACME_WORKER_POLL_INTERVAL_SECONDS  = tostring(var.worker_poll_interval_seconds)
    ACME_WORKER_LEASE_SECONDS          = tostring(var.worker_lease_seconds)
    ACME_WORKER_SWEEP_INTERVAL_SECONDS = tostring(var.worker_sweep_interval_seconds)
    ACME_WORKER_LANE                   = "default"
  })

  notifier_environment = merge(local.shared_environment, {
    ACME_SERVICE_NAME                   = "${local.product}-${local.notifier_process}"
    ACME_NOTIFIER_NAME                  = local.notifier_process
    ACME_NOTIFIER_PORT                  = tostring(local.notifier_port)
    ACME_NOTIFIER_CAPACITY              = tostring(var.notifier_capacity)
    ACME_NOTIFIER_POLL_INTERVAL_SECONDS = tostring(var.worker_poll_interval_seconds)
    ACME_NOTIFIER_LEASE_SECONDS         = tostring(var.worker_lease_seconds)
    ACME_NOTIFIER_LANE                  = "default"
  })

  # The one-off migration task alone holds the migration login's URL and the master's.
  migration_secrets = merge(local.shared_secrets, {
    ACME_DATABASE_MIGRATION_URL = module.database.migration_url_secret_arn
    ACME_DATABASE_MASTER_URL    = module.database.master_url_secret_arn
  })

  # The grant task holds the runtime and the system logins' URLs, never the migration login's or the master's.
  grant_secrets = merge(local.shared_secrets, {
    ACME_API_TOTP_ENCRYPTION_KEY = module.secrets.totp_key_secret_arn
  })

  # A rotation bumps a version and the task definitions carry it, so the services roll.
  version_labels = {
    (local.secrets_version_label) = "db${var.database_password_version}-totp${var.totp_key_version}-signing${var.internal_signing_key_version}"
  }

  app_statements = [
    {
      sid       = "DataBucketObjects"
      actions   = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject"]
      resources = [for arn in module.buckets.bucket_arns : "${arn}/*"]
    },
    {
      sid       = "DataBucketList"
      actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
      resources = module.buckets.bucket_arns
    },
    {
      sid       = "Queues"
      actions   = ["sqs:SendMessage", "sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:ChangeMessageVisibility", "sqs:GetQueueUrl", "sqs:GetQueueAttributes"]
      resources = module.queue.queue_arns
    },
    {
      sid       = "TenantSecrets"
      actions   = ["secretsmanager:GetSecretValue", "secretsmanager:PutSecretValue", "secretsmanager:CreateSecret", "secretsmanager:DeleteSecret", "secretsmanager:DescribeSecret", "secretsmanager:TagResource"]
      resources = ["arn:aws:secretsmanager:${local.region}:${local.account_id}:secret:${local.prefix}/*"]
    },
  ]
}

# ---------------------------------------------------------------------------
# The edge.
# ---------------------------------------------------------------------------

module "load_balancer" {
  source = "../../modules/load_balancer"

  name                    = local.name
  domain_name             = local.api_domain
  vpc_id                  = module.network.vpc_id
  public_subnet_ids       = module.network.public_subnet_ids
  tasks_security_group_id = module.cluster.tasks_security_group_id
  container_port          = local.api_port
  health_check_path       = "/healthz"
  idle_timeout_seconds    = jsondecode(file("${path.root}/../../../realtime-timeouts.json")).idle_timeout_seconds
  waf_enabled             = var.waf_enabled
  destroyable             = var.destroyable
}

# ---------------------------------------------------------------------------
# The migration: a one-off task on the new API image, inside the apply, before
# the rollout. ensure-logins (the only use of the master URL) creates the three
# logins by their fixed names and sets their passwords from their URLs'
# secrets; then upgrade --all runs every role's migrations as the migration login.
# ---------------------------------------------------------------------------

module "migration" {
  source = "../../modules/oneoff_task"

  name_prefix              = local.name
  product                  = local.product
  environment              = var.environment
  process                  = "migrate"
  region                   = local.region
  image                    = var.api_image
  command                  = ["sh", "-c", "acme-api migrate ensure-logins && exec acme-api migrate upgrade --all"]
  environment_variables    = merge(local.api_environment, { ACME_SERVICE_NAME = "${local.product}-api" })
  secrets                  = local.migration_secrets
  labels                   = local.version_labels
  permissions_boundary_arn = local.boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = module.cluster.metrics_log_group
  collector_image          = var.collector_image

  run_on_apply       = true
  run_triggers       = [tostring(var.database_password_version)]
  run_after          = module.database.url_secrets_ready
  cluster_name       = module.cluster.cluster_name
  subnet_ids         = module.network.private_subnet_ids
  security_group_ids = [module.cluster.tasks_security_group_id]
}

# ---------------------------------------------------------------------------
# The processes. Both roll out only after the migration succeeded: each task
# definition carries the migration run's id, so the new definition, and with
# it the rollout, waits for the run to finish, and a failed run ends the apply
# before any service changes. (A data dependency, rather than a module-wide
# depends_on, which would defer every policy document to the apply.)
# ---------------------------------------------------------------------------

locals {
  after_migration = { "${local.product}.migration-run" = module.migration.completed }
}

module "api" {
  source = "../../modules/service"

  name_prefix              = local.name
  product                  = local.product
  environment              = var.environment
  process                  = "api"
  region                   = local.region
  image                    = var.api_image
  command                  = ["acme-api", "serve"]
  container_port           = local.api_port
  cpu                      = var.api_cpu
  memory                   = var.api_memory
  desired_count            = var.api_desired_count
  worker                   = false
  cluster_arn              = module.cluster.cluster_arn
  subnet_ids               = module.network.private_subnet_ids
  security_group_ids       = [module.cluster.tasks_security_group_id]
  target_group_arn         = module.load_balancer.target_group_arn
  environment_variables    = local.api_environment
  secrets                  = local.api_secrets
  labels                   = merge(local.version_labels, local.after_migration)
  task_role_statements     = local.app_statements
  permissions_boundary_arn = local.boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = module.cluster.metrics_log_group
  collector_image          = var.collector_image
}

module "worker" {
  source = "../../modules/service"

  name_prefix              = local.name
  product                  = local.product
  environment              = var.environment
  process                  = local.worker_process
  region                   = local.region
  image                    = var.worker_image
  command                  = null
  container_port           = local.worker_port
  cpu                      = var.worker_cpu
  memory                   = var.worker_memory
  desired_count            = var.worker_desired_count
  worker                   = true
  cluster_arn              = module.cluster.cluster_arn
  subnet_ids               = module.network.private_subnet_ids
  security_group_ids       = [module.cluster.tasks_security_group_id]
  target_group_arn         = null
  environment_variables    = local.worker_environment
  secrets                  = local.shared_secrets
  labels                   = merge(local.version_labels, local.after_migration)
  task_role_statements     = local.app_statements
  permissions_boundary_arn = local.boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = module.cluster.metrics_log_group
  collector_image          = var.collector_image
}

# The notifier: SEND_NOTIFICATION off the request path; no load balancer route, no sweep of its own.
module "notifier" {
  source = "../../modules/service"

  name_prefix              = local.name
  product                  = local.product
  environment              = var.environment
  process                  = local.notifier_process
  region                   = local.region
  image                    = var.notifier_image
  command                  = null
  container_port           = local.notifier_port
  cpu                      = var.worker_cpu
  memory                   = var.worker_memory
  desired_count            = var.notifier_desired_count
  worker                   = true
  cluster_arn              = module.cluster.cluster_arn
  subnet_ids               = module.network.private_subnet_ids
  security_group_ids       = [module.cluster.tasks_security_group_id]
  target_group_arn         = null
  environment_variables    = local.notifier_environment
  secrets                  = local.api_secrets
  labels                   = merge(local.version_labels, local.after_migration)
  task_role_statements     = local.app_statements
  permissions_boundary_arn = local.boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = module.cluster.metrics_log_group
  collector_image          = var.collector_image
}

module "notifier_autoscaling" {
  source = "../../modules/autoscaling"

  root_enabled  = var.autoscaling_enabled
  scaling       = var.worker_scaling
  cluster_name  = module.cluster.cluster_name
  service_name  = module.notifier.service_name
  desired_count = var.notifier_desired_count
}

module "api_autoscaling" {
  source = "../../modules/autoscaling"

  root_enabled  = var.autoscaling_enabled
  scaling       = var.api_scaling
  cluster_name  = module.cluster.cluster_name
  service_name  = module.api.service_name
  desired_count = var.api_desired_count
}

module "worker_autoscaling" {
  source = "../../modules/autoscaling"

  root_enabled  = var.autoscaling_enabled
  scaling       = var.worker_scaling
  cluster_name  = module.cluster.cluster_name
  service_name  = module.worker.service_name
  desired_count = var.worker_desired_count
}

# ---------------------------------------------------------------------------
# The grant: a second one-off task definition on the API image, run by
# grant-operator.yml and the deploy workflows' smoke job, never by the apply.
# Its role may write the two operator-token secrets and no other secret value.
# ---------------------------------------------------------------------------

module "grant_operator" {
  source = "../../modules/oneoff_task"

  name_prefix              = local.name
  product                  = local.product
  environment              = var.environment
  process                  = "grant-operator"
  region                   = local.region
  image                    = var.api_image
  command                  = ["acme-api", "grant-operator", "--help"]
  environment_variables    = local.api_environment
  secrets                  = local.grant_secrets
  labels                   = local.version_labels
  permissions_boundary_arn = local.boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = module.cluster.metrics_log_group
  collector_image          = var.collector_image

  task_role_statements = [
    {
      sid       = "WriteOperatorTokens"
      actions   = ["secretsmanager:PutSecretValue", "secretsmanager:DescribeSecret"]
      resources = values(module.secrets.token_secret_arns)
    },
  ]

  run_on_apply       = false
  cluster_name       = module.cluster.cluster_name
  subnet_ids         = module.network.private_subnet_ids
  security_group_ids = [module.cluster.tasks_security_group_id]
}

# ---------------------------------------------------------------------------
# The portal: app.<base_domain>, served from a private bucket through CloudFront.
# ---------------------------------------------------------------------------

module "portal" {
  source = "../../modules/static_site"

  providers = {
    aws           = aws
    aws.us_east_1 = aws.us_east_1
  }

  name              = "${local.prefix}-portal"
  domain_name       = local.app_domain
  api_origin        = local.api_origin
  extra_connect_src = var.error_tracker_origin == "" ? [] : [var.error_tracker_origin]
  waf_enabled       = var.waf_enabled
  destroyable       = var.destroyable
}

# ---------------------------------------------------------------------------
# The operator's view.
# ---------------------------------------------------------------------------

module "observability" {
  source = "../../modules/observability"

  name                       = local.name
  environment                = var.environment
  region                     = local.region
  alarm_email                = var.alarm_email
  cluster_name               = module.cluster.cluster_name
  api_service_name           = module.api.service_name
  worker_service_name        = module.worker.service_name
  notifier_service_name      = module.notifier.service_name
  worker_process             = local.worker_process
  alb_arn_suffix             = module.load_balancer.alb_arn_suffix
  target_group_arn_suffix    = module.load_balancer.target_group_arn_suffix
  db_identifier              = module.database.identifier
  cache_replication_group_id = module.cache.replication_group_id
  queue_names                = concat(values(module.queue.queue_names), values(module.queue.dlq_names))
  thresholds                 = var.alarm_thresholds
}
