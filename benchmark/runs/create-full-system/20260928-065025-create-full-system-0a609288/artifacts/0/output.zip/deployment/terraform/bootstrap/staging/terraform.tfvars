# Staging's bootstrap. The account id, the region, and the public names come
# from deployment/cloud/environments.json. OWNER_EMAIL and the repository's ids
# are passed by scripts/cloud_create.sh.
monthly_budget_usd = 300
