output "state_bucket" {
  value = module.account.state_bucket
}

output "artifacts_bucket" {
  value = module.account.artifacts_bucket
}

output "ecr_registry" {
  value = module.account.ecr_registry
}

output "ecr_repository_urls" {
  value = module.account.ecr_repository_urls
}

output "pipeline_role_arns" {
  value = module.account.pipeline_role_arns
}

output "investigate_role_arn" {
  value = module.account.investigate_role_arn
}

output "permissions_boundary_arn" {
  value = module.account.permissions_boundary_arn
}

output "zone_name_servers" {
  value = module.account.zone_name_servers
}
