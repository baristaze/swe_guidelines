# Postgres, and the four connection URLs as secrets: the master's and the
# migration login's (held by the one-off migration task alone), the runtime
# login's and the system login's (held by the services and workers).
#
# No secret value lands in state or a plan: every password comes from an
# ephemeral generator, the master's reaches the database through the write-only
# `password_wo`, and each URL's secret version is written through the write-only
# `secret_string_wo`. Nothing computes a URL as an output. `migrate
# ensure-logins` creates the three logins by their fixed names and sets each
# password from its URL's secret. A rotation bumps `password_version`.

variable "name" {
  description = "acme-<env>: the instance identifier and the secrets' prefix."
  type        = string
}

variable "environment" {
  type = string
}

variable "product" {
  description = "The root package; the logins are <product>_migration, <product>_runtime, <product>_system."
  type        = string
  default     = "acme"
}

variable "vpc_id" {
  type = string
}

variable "subnet_ids" {
  type = list(string)
}

variable "client_security_group_ids" {
  description = "Security groups admitted on 5432."
  type        = list(string)
}

variable "engine_version" {
  description = "Postgres major version; RDS picks the latest minor of it and minor upgrades apply on their own."
  type        = string
  default     = "18"
}

variable "parameter_group_family" {
  type    = string
  default = "postgres18"
}

variable "instance_class" {
  type = string
}

variable "allocated_storage" {
  type = number
}

variable "max_allocated_storage" {
  description = "Storage grows on its own up to this many GiB."
  type        = number
}

variable "multi_az" {
  description = "Two zones, once customers depend on it."
  type        = bool
}

variable "backup_retention_days" {
  description = "Point-in-time recovery window."
  type        = number
}

variable "deletion_protection" {
  type = bool
}

variable "destroyable" {
  description = "Outside production, skip the final snapshot on delete. Production always leaves one."
  type        = bool
}

variable "password_version" {
  description = "Bump to rotate every generated password (the master's and the three logins')."
  type        = number
  default     = 1
}

variable "secret_recovery_window_days" {
  type = number
}

locals {
  is_production = var.environment == "production"
  db_name       = var.product
  logins        = ["migration", "runtime", "system"]
}

resource "aws_security_group" "db" {
  name        = "${var.name}-db"
  description = "Postgres for ${var.name}, reachable from its tasks alone."
  vpc_id      = var.vpc_id

  ingress {
    description     = "Postgres from the tasks"
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = var.client_security_group_ids
  }
}

resource "aws_db_subnet_group" "this" {
  name       = var.name
  subnet_ids = var.subnet_ids
}

resource "aws_db_parameter_group" "this" {
  name   = "${var.name}-pg"
  family = var.parameter_group_family

  # The database refuses a connection that does not use TLS.
  parameter {
    name  = "rds.force_ssl"
    value = "1"
  }

  parameter {
    name  = "log_min_duration_statement"
    value = "1000"
  }
}

ephemeral "random_password" "master" {
  length  = 40
  special = false
}

ephemeral "random_password" "login" {
  for_each = toset(local.logins)
  length   = 40
  special  = false
}

resource "aws_db_instance" "this" {
  identifier     = var.name
  engine         = "postgres"
  engine_version = var.engine_version
  instance_class = var.instance_class
  db_name        = local.db_name

  username            = "${var.product}_master"
  password_wo         = ephemeral.random_password.master.result
  password_wo_version = var.password_version

  allocated_storage     = var.allocated_storage
  max_allocated_storage = var.max_allocated_storage
  storage_type          = "gp3"
  storage_encrypted     = true

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.db.id]
  parameter_group_name   = aws_db_parameter_group.this.name
  publicly_accessible    = false
  multi_az               = var.multi_az

  backup_retention_period  = var.backup_retention_days
  delete_automated_backups = !local.is_production
  copy_tags_to_snapshot    = true
  deletion_protection      = var.deletion_protection

  skip_final_snapshot       = local.is_production ? false : var.destroyable
  final_snapshot_identifier = "${var.name}-final"

  auto_minor_version_upgrade   = true
  allow_major_version_upgrade  = false
  apply_immediately            = !local.is_production
  performance_insights_enabled = true

  enabled_cloudwatch_logs_exports = ["postgresql"]
}

# ---------------------------------------------------------------------------
# The URL secrets. Each version is written write-only, with the password in it.
# Plain postgresql:// URLs (the processes add their driver); the server's
# rds.force_ssl refuses a connection without TLS.
# ---------------------------------------------------------------------------

resource "aws_secretsmanager_secret" "master_url" {
  name                    = "${var.name}-database-master-url"
  description             = "ACME_DATABASE_MASTER_URL: held by the one-off migration task alone, for migrate ensure-logins."
  recovery_window_in_days = var.secret_recovery_window_days
}

resource "aws_secretsmanager_secret_version" "master_url" {
  secret_id                = aws_secretsmanager_secret.master_url.id
  secret_string_wo         = "postgresql://${aws_db_instance.this.username}:${ephemeral.random_password.master.result}@${aws_db_instance.this.address}:${aws_db_instance.this.port}/${local.db_name}"
  secret_string_wo_version = var.password_version
}

resource "aws_secretsmanager_secret" "login_url" {
  for_each                = toset(local.logins)
  name                    = "${var.name}-database-${each.key}-url"
  description             = "The ${var.product}_${each.key} login's URL."
  recovery_window_in_days = var.secret_recovery_window_days
}

resource "aws_secretsmanager_secret_version" "login_url" {
  for_each                 = toset(local.logins)
  secret_id                = aws_secretsmanager_secret.login_url[each.key].id
  secret_string_wo         = "postgresql://${var.product}_${each.key}:${ephemeral.random_password.login[each.key].result}@${aws_db_instance.this.address}:${aws_db_instance.this.port}/${local.db_name}"
  secret_string_wo_version = var.password_version
}

output "identifier" {
  value = aws_db_instance.this.identifier
}

output "address" {
  value = aws_db_instance.this.address
}

output "master_url_secret_arn" {
  value = aws_secretsmanager_secret.master_url.arn
}

output "migration_url_secret_arn" {
  value = aws_secretsmanager_secret.login_url["migration"].arn
}

output "runtime_url_secret_arn" {
  value = aws_secretsmanager_secret.login_url["runtime"].arn
}

output "system_url_secret_arn" {
  value = aws_secretsmanager_secret.login_url["system"].arn
}

output "password_version" {
  description = "Put into the task definitions, so a rotation rolls the services."
  value       = var.password_version
}

output "url_secrets_ready" {
  description = "Depends on every URL version, so the migration waits for them."
  value       = concat([aws_secretsmanager_secret_version.master_url.id], [for v in aws_secretsmanager_secret_version.login_url : v.id])
}
