-- The three logins every environment uses, under their fixed names, with the local passwords .env.example names.
-- The migration login owns the role schemas it creates; the runtime and system logins own nothing.
-- The grants on each schema are the migrations' own, so the cloud and a role that arrives later get the same.
-- None of the three is a superuser or carries BYPASSRLS.
CREATE ROLE acme_migration LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD 'migration_pswd';
CREATE ROLE acme_runtime LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD 'runtime_pswd';
CREATE ROLE acme_system LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD 'system_pswd';
GRANT CREATE ON DATABASE acme TO acme_migration;

-- The local error tracker's own database, for the devx profile.
CREATE ROLE acme_glitchtip LOGIN NOSUPERUSER PASSWORD 'glitchtip_pswd';
CREATE DATABASE glitchtip OWNER acme_glitchtip;
