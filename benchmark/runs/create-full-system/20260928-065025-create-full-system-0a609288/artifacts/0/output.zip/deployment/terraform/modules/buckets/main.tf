# One private bucket per Buckets member, named <prefix>-<name> (ACME_BUCKETS_PREFIX).
# Encrypted at rest, public access blocked, TLS only, versioned. The browser
# posts to a presigned form, so the app origins are admitted by CORS.

variable "prefix" {
  description = "acme-<env>, ACME_BUCKETS_PREFIX."
  type        = string
}

variable "names" {
  type    = list(string)
  default = ["report-attachments", "profile-media"]
}

variable "allowed_origins" {
  description = "Browser origins that post presigned uploads and read presigned downloads."
  type        = list(string)
}

variable "destroyable" {
  description = "force_destroy on every bucket."
  type        = bool
}

variable "noncurrent_version_days" {
  type    = number
  default = 30
}

resource "aws_s3_bucket" "this" {
  for_each      = toset(var.names)
  bucket        = "${var.prefix}-${each.key}"
  force_destroy = var.destroyable
}

resource "aws_s3_bucket_versioning" "this" {
  for_each = aws_s3_bucket.this
  bucket   = each.value.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "this" {
  for_each = aws_s3_bucket.this
  bucket   = each.value.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "this" {
  for_each                = aws_s3_bucket.this
  bucket                  = each.value.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_ownership_controls" "this" {
  for_each = aws_s3_bucket.this
  bucket   = each.value.id
  rule {
    object_ownership = "BucketOwnerEnforced"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "this" {
  for_each = aws_s3_bucket.this
  bucket   = each.value.id

  rule {
    id     = "noncurrent-versions"
    status = "Enabled"
    filter {}
    noncurrent_version_expiration {
      noncurrent_days = var.noncurrent_version_days
    }
    abort_incomplete_multipart_upload {
      days_after_initiation = 1
    }
  }
}

resource "aws_s3_bucket_cors_configuration" "this" {
  for_each = aws_s3_bucket.this
  bucket   = each.value.id

  cors_rule {
    allowed_methods = ["GET", "POST", "PUT", "HEAD"]
    allowed_origins = var.allowed_origins
    allowed_headers = ["*"]
    expose_headers  = ["ETag"]
    max_age_seconds = 3000
  }
}

data "aws_iam_policy_document" "tls_only" {
  for_each = aws_s3_bucket.this
  statement {
    sid       = "TlsOnly"
    effect    = "Deny"
    actions   = ["s3:*"]
    resources = [each.value.arn, "${each.value.arn}/*"]
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

resource "aws_s3_bucket_policy" "this" {
  for_each   = aws_s3_bucket.this
  bucket     = each.value.id
  policy     = data.aws_iam_policy_document.tls_only[each.key].json
  depends_on = [aws_s3_bucket_public_access_block.this]
}

output "bucket_arns" {
  value = [for b in aws_s3_bucket.this : b.arn]
}

output "bucket_names" {
  value = [for b in aws_s3_bucket.this : b.id]
}
