locals {
  layout      = jsondecode(file("${path.module}/../../../cloud/environments.json"))
  environment = "production"
  other       = "staging"
  env         = local.layout.environments[local.environment]
  region      = local.layout.region
}

provider "aws" {
  region              = local.region
  allowed_account_ids = [local.env.account_id]

  default_tags {
    tags = {
      environment = local.environment
      product     = local.layout.product
      managed_by  = "terraform"
      root        = "bootstrap/prod"
    }
  }
}
