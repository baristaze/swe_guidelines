# Production's account: the same as staging's but for three things. Its
# pipeline roles plan and apply (with the smoke role beside them), not build,
# so the approval gates the one that writes. The artifacts bucket locks every bundle version and refuses a
# second write to a key. And it grants staging's replication two writes, images
# into these repositories and bundles under the bundle prefix, and nothing else.
module "account" {
  source = "../../modules/account"

  environment       = local.environment
  other_environment = local.other
  account_id        = local.env.account_id
  region            = local.region
  public_names      = local.env.public_names

  github_repository          = var.github_repository
  github_repository_id       = var.github_repository_id
  github_repository_owner_id = var.github_repository_owner_id

  pipeline_roles = {
    plan   = { github_environment = "production-plan", branch = local.env.branch, kind = "plan" }
    deploy = { github_environment = "production", branch = local.env.branch, kind = "deploy" }
    smoke  = { github_environment = "production-smoke", branch = local.env.branch, kind = "smoke" }
  }

  ecr_repositories               = ["acme-api", "acme-maintenance", "acme-notifier"]
  bundle_object_lock             = true
  grant_replication_from_staging = true
  staging_account_id             = local.layout.environments.staging.account_id

  everyday_permission_set = var.everyday_permission_set
  monthly_budget_usd      = var.monthly_budget_usd
  owner_email             = var.owner_email
}
