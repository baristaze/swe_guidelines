locals {
  # The folder under deployment/terraform/ spells production `prod`; every name spells it `production`.
  state_dir     = local.is_production ? "prod" : var.environment
  boundary_name = "${var.product}-boundary-${var.environment}"
  boundary_arn  = "arn:aws:iam::${var.account_id}:policy/${local.boundary_name}"

  bootstrap_role_arns = [
    "arn:aws:iam::${var.account_id}:role/${var.product}-deploy-*",
    "arn:aws:iam::${var.account_id}:role/${var.product}-plan-*",
    "arn:aws:iam::${var.account_id}:role/${var.product}-build-*",
    "arn:aws:iam::${var.account_id}:role/${var.product}-smoke-*",
    "arn:aws:iam::${var.account_id}:role/${var.product}-investigate-*",
    "arn:aws:iam::${var.account_id}:role/${var.product}-replication-*",
  ]

  bootstrap_bucket_arns = [
    aws_s3_bucket.state.arn,
    aws_s3_bucket.artifacts.arn,
    aws_s3_bucket.trail.arn,
  ]

  # The identity center's everyday role carries a generated suffix, so it is matched by pattern.
  everyday_role_pattern = "arn:aws:iam::${var.account_id}:role/aws-reserved/sso.amazonaws.com/*AWSReservedSSO_${var.everyday_permission_set}_*"
}

# ---------------------------------------------------------------------------
# The repository host's identity federation. No cloud user and no access key.
# ---------------------------------------------------------------------------

resource "aws_iam_openid_connect_provider" "github" {
  url            = "https://token.actions.githubusercontent.com"
  client_id_list = ["sts.amazonaws.com"]
}

# The subject is the repository host's customized subject template, set by
# scripts/cloud_create.sh (include_claim_keys: repository_owner_id,
# repository_id, environment, ref), so the trust conditions on the immutable ids,
# the environment, and the ref, built from the same ids it conditions on.
data "aws_iam_policy_document" "pipeline_trust" {
  for_each = var.pipeline_roles

  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]
    principals {
      type        = "Federated"
      identifiers = [aws_iam_openid_connect_provider.github.arn]
    }
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = ["sts.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:sub"
      values = [
        "repository_owner_id:${var.github_repository_owner_id}:repository_id:${var.github_repository_id}:environment:${each.value.github_environment}:ref:refs/heads/${each.value.branch}",
      ]
    }
  }
}

# ---------------------------------------------------------------------------
# The permissions boundary every role a pipeline role creates must carry: the
# widest role a deploy can mint. It reaches what the tasks use, and never IAM.
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "boundary" {
  statement {
    sid    = "WhatTasksUse"
    effect = "Allow"
    actions = [
      "ecr:GetAuthorizationToken",
      "ecr:BatchGetImage",
      "ecr:BatchCheckLayerAvailability",
      "ecr:GetDownloadUrlForLayer",
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams",
      "logs:PutLogEvents",
      "logs:PutRetentionPolicy",
      "xray:PutTraceSegments",
      "xray:PutTelemetryRecords",
      "xray:GetSamplingRules",
      "xray:GetSamplingTargets",
      "xray:GetSamplingStatisticSummaries",
      "cloudwatch:PutMetricData",
      "s3:GetObject",
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:ListBucket",
      "s3:GetBucketLocation",
      "s3:GetReplicationConfiguration",
      "s3:GetObjectVersionForReplication",
      "s3:GetObjectVersionAcl",
      "s3:GetObjectVersionTagging",
      "s3:GetObjectRetention",
      "s3:GetObjectLegalHold",
      "s3:ReplicateObject",
      "s3:ReplicateTags",
      "s3:ObjectOwnerOverrideToBucketOwner",
      "sqs:SendMessage",
      "sqs:ReceiveMessage",
      "sqs:DeleteMessage",
      "sqs:ChangeMessageVisibility",
      "sqs:GetQueueUrl",
      "sqs:GetQueueAttributes",
      "secretsmanager:GetSecretValue",
      "secretsmanager:PutSecretValue",
      "secretsmanager:CreateSecret",
      "secretsmanager:DeleteSecret",
      "secretsmanager:DescribeSecret",
      "secretsmanager:TagResource",
      "kms:Decrypt",
      "kms:GenerateDataKey",
      "ssmmessages:CreateControlChannel",
      "ssmmessages:CreateDataChannel",
      "ssmmessages:OpenControlChannel",
      "ssmmessages:OpenDataChannel",
    ]
    resources = ["*"]
  }

  statement {
    sid       = "NeverIdentityOrAccount"
    effect    = "Deny"
    actions   = ["iam:*", "sts:AssumeRole", "organizations:*", "account:*"]
    resources = ["*"]
  }

  statement {
    sid       = "NeverTheOtherEnvironment"
    effect    = "Deny"
    actions   = ["*"]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "aws:ResourceTag/environment"
      values   = [var.other_environment]
    }
  }
}

resource "aws_iam_policy" "boundary" {
  name        = local.boundary_name
  description = "The permissions boundary every role a ${var.environment} pipeline role creates must carry."
  policy      = data.aws_iam_policy_document.boundary.json
}

# ---------------------------------------------------------------------------
# The fence every pipeline role carries: a role or a user only with the
# boundary, no access key, no change to the boundary, to the bootstrap's roles
# and trust, to its buckets and state key, to the trail, or to the other
# environment's tagged resources.
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "fence" {
  statement {
    sid       = "DenyRoleWithoutBoundary"
    effect    = "Deny"
    actions   = ["iam:CreateRole", "iam:PutRolePermissionsBoundary"]
    resources = ["*"]
    condition {
      test     = "StringNotEquals"
      variable = "iam:PermissionsBoundary"
      values   = [local.boundary_arn]
    }
  }

  statement {
    sid       = "DenyUserWithoutBoundary"
    effect    = "Deny"
    actions   = ["iam:CreateUser", "iam:PutUserPermissionsBoundary"]
    resources = ["*"]
    condition {
      test     = "StringNotEquals"
      variable = "iam:PermissionsBoundary"
      values   = [local.boundary_arn]
    }
  }

  statement {
    sid       = "DenyBoundaryRemoval"
    effect    = "Deny"
    actions   = ["iam:DeleteRolePermissionsBoundary", "iam:DeleteUserPermissionsBoundary"]
    resources = ["*"]
  }

  statement {
    sid    = "DenyLongLivedCredentials"
    effect = "Deny"
    actions = [
      "iam:CreateAccessKey",
      "iam:UpdateAccessKey",
      "iam:CreateLoginProfile",
      "iam:UpdateLoginProfile",
      "iam:CreateServiceSpecificCredential",
      "iam:UploadSSHPublicKey",
    ]
    resources = ["*"]
  }

  statement {
    sid    = "DenyBoundaryChange"
    effect = "Deny"
    actions = [
      "iam:CreatePolicyVersion",
      "iam:DeletePolicy",
      "iam:DeletePolicyVersion",
      "iam:SetDefaultPolicyVersion",
      "iam:TagPolicy",
      "iam:UntagPolicy",
    ]
    resources = [local.boundary_arn]
  }

  statement {
    sid    = "DenyBootstrapRoleChange"
    effect = "Deny"
    actions = [
      "iam:AttachRolePolicy",
      "iam:DetachRolePolicy",
      "iam:PutRolePolicy",
      "iam:DeleteRolePolicy",
      "iam:UpdateAssumeRolePolicy",
      "iam:UpdateRole",
      "iam:UpdateRoleDescription",
      "iam:DeleteRole",
      "iam:TagRole",
      "iam:UntagRole",
      "iam:PutRolePermissionsBoundary",
      "iam:DeleteRolePermissionsBoundary",
    ]
    resources = local.bootstrap_role_arns
  }

  statement {
    sid    = "DenyTrustChange"
    effect = "Deny"
    actions = [
      "iam:CreateOpenIDConnectProvider",
      "iam:DeleteOpenIDConnectProvider",
      "iam:UpdateOpenIDConnectProviderThumbprint",
      "iam:AddClientIDToOpenIDConnectProvider",
      "iam:RemoveClientIDFromOpenIDConnectProvider",
      "iam:TagOpenIDConnectProvider",
      "iam:UntagOpenIDConnectProvider",
      "iam:CreateSAMLProvider",
      "iam:UpdateSAMLProvider",
      "iam:DeleteSAMLProvider",
    ]
    resources = ["*"]
  }

  statement {
    sid       = "DenyBootstrapStateKey"
    effect    = "Deny"
    actions   = ["s3:PutObject", "s3:DeleteObject", "s3:DeleteObjectVersion", "s3:PutObjectAcl"]
    resources = ["${aws_s3_bucket.state.arn}/bootstrap/*"]
  }

  statement {
    sid    = "DenyBootstrapBucketChange"
    effect = "Deny"
    actions = [
      "s3:DeleteBucket",
      "s3:PutBucketPolicy",
      "s3:DeleteBucketPolicy",
      "s3:PutBucketVersioning",
      "s3:PutLifecycleConfiguration",
      "s3:PutEncryptionConfiguration",
      "s3:PutBucketPublicAccessBlock",
      "s3:PutReplicationConfiguration",
      "s3:PutBucketObjectLockConfiguration",
      "s3:PutBucketOwnershipControls",
    ]
    resources = local.bootstrap_bucket_arns
  }

  statement {
    sid    = "DenyTrailChange"
    effect = "Deny"
    actions = [
      "cloudtrail:StopLogging",
      "cloudtrail:DeleteTrail",
      "cloudtrail:UpdateTrail",
      "cloudtrail:PutEventSelectors",
    ]
    resources = [aws_cloudtrail.this.arn]
  }

  statement {
    sid    = "DenyRegistryAndBudgetChange"
    effect = "Deny"
    actions = [
      "ecr:DeleteRepository",
      "ecr:PutLifecyclePolicy",
      "ecr:DeleteLifecyclePolicy",
      "ecr:PutImageTagMutability",
      "ecr:PutImageScanningConfiguration",
      "ecr:SetRepositoryPolicy",
      "ecr:PutReplicationConfiguration",
      "ecr:PutRegistryPolicy",
      "ecr:DeleteRegistryPolicy",
      "budgets:ModifyBudget",
      "ce:DeleteAnomalyMonitor",
      "ce:UpdateAnomalyMonitor",
      "ce:DeleteAnomalySubscription",
      "ce:UpdateAnomalySubscription",
      "route53:DeleteHostedZone",
    ]
    resources = ["*"]
  }

  statement {
    sid       = "DenyTheOtherEnvironment"
    effect    = "Deny"
    actions   = ["*"]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "aws:ResourceTag/environment"
      values   = [var.other_environment]
    }
  }
}

# ---------------------------------------------------------------------------
# The pipeline roles: staging's push-only build role and its deploy role;
# production's plan role and its deploy role; and each environment's smoke
# role, which reads the smoke token and the signals and nothing else, so the
# job that installs the test's dependencies never holds the deploy role.
# ---------------------------------------------------------------------------

resource "aws_iam_role" "pipeline" {
  for_each = var.pipeline_roles

  name                 = "${var.product}-${each.key}-${var.environment}"
  description          = "Assumed by the ${each.value.github_environment} environment of ${var.github_repository} on ${each.value.branch}."
  assume_role_policy   = data.aws_iam_policy_document.pipeline_trust[each.key].json
  max_session_duration = 3600
}

resource "aws_iam_role_policy" "fence" {
  for_each = aws_iam_role.pipeline
  name     = "fence"
  role     = each.value.id
  policy   = data.aws_iam_policy_document.fence.json
}

resource "aws_iam_role_policy_attachment" "deploy_admin" {
  for_each   = { for k, r in var.pipeline_roles : k => r if r.kind == "deploy" }
  role       = aws_iam_role.pipeline[each.key].name
  policy_arn = "arn:aws:iam::aws:policy/AdministratorAccess"
}

resource "aws_iam_role_policy_attachment" "plan_readonly" {
  for_each   = { for k, r in var.pipeline_roles : k => r if r.kind == "plan" }
  role       = aws_iam_role.pipeline[each.key].name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

data "aws_iam_policy_document" "plan" {
  statement {
    sid       = "StateLockAndSavedPlan"
    actions   = ["s3:PutObject", "s3:DeleteObject"]
    resources = ["${aws_s3_bucket.state.arn}/environments/${local.state_dir}/*.tflock", "${aws_s3_bucket.state.arn}/plans/*"]
  }

  # A refresh reads each secret's current version; only the plan role may.
  statement {
    sid       = "RefreshSecretVersions"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = ["arn:aws:secretsmanager:${var.region}:${var.account_id}:secret:${var.product}-${var.environment}-*"]
  }
}

resource "aws_iam_role_policy" "plan" {
  for_each = { for k, r in var.pipeline_roles : k => r if r.kind == "plan" }
  name     = "plan"
  role     = aws_iam_role.pipeline[each.key].id
  policy   = data.aws_iam_policy_document.plan.json
}

data "aws_iam_policy_document" "build" {
  statement {
    sid       = "RegistryLogin"
    actions   = ["ecr:GetAuthorizationToken"]
    resources = ["*"]
  }

  statement {
    sid = "PushImages"
    actions = [
      "ecr:BatchCheckLayerAvailability",
      "ecr:BatchGetImage",
      "ecr:InitiateLayerUpload",
      "ecr:UploadLayerPart",
      "ecr:CompleteLayerUpload",
      "ecr:PutImage",
      "ecr:DescribeImages",
    ]
    resources = [for r in aws_ecr_repository.this : r.arn]
  }

  statement {
    sid       = "WriteBundles"
    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.artifacts.arn}/${var.bundle_prefix}*"]
  }

  statement {
    sid       = "ListBundles"
    actions   = ["s3:ListBucket"]
    resources = [aws_s3_bucket.artifacts.arn]
    condition {
      test     = "StringLike"
      variable = "s3:prefix"
      values   = ["${var.bundle_prefix}*"]
    }
  }
}

resource "aws_iam_role_policy" "build" {
  for_each = { for k, r in var.pipeline_roles : k => r if r.kind == "build" }
  name     = "build"
  role     = aws_iam_role.pipeline[each.key].id
  policy   = data.aws_iam_policy_document.build.json
}

# The smoke role: the smoke identity's token (the deploy role's one-off grant
# task writes it) and the three signal reads the telemetry round trip makes.
data "aws_iam_policy_document" "smoke" {
  statement {
    sid       = "ReadTheSmokeToken"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = ["arn:aws:secretsmanager:${var.region}:${var.account_id}:secret:${var.product}-${var.environment}-smoke-token-*"]
  }

  statement {
    sid       = "QueryTheLogs"
    actions   = ["logs:StartQuery"]
    resources = ["arn:aws:logs:${var.region}:${var.account_id}:log-group:/${var.product}/${var.environment}/*"]
  }

  statement {
    sid       = "ReadSignals"
    actions   = ["logs:GetQueryResults", "logs:StopQuery", "cloudwatch:GetMetricData", "xray:GetTraceSummaries", "xray:BatchGetTraces"]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "smoke" {
  for_each = { for k, r in var.pipeline_roles : k => r if r.kind == "smoke" }
  name     = "smoke"
  role     = aws_iam_role.pipeline[each.key].id
  policy   = data.aws_iam_policy_document.smoke.json
}

# ---------------------------------------------------------------------------
# The investigate role: reads every signal and every resource description, the
# state prefix (for plan -lock=false -refresh=false), and nothing that holds data.
# ---------------------------------------------------------------------------

data "aws_iam_policy_document" "investigate_trust" {
  statement {
    actions = ["sts:AssumeRole", "sts:SetSourceIdentity"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${var.account_id}:root"]
    }
    condition {
      test     = "ArnLike"
      variable = "aws:PrincipalArn"
      values   = [local.everyday_role_pattern]
    }
  }
}

resource "aws_iam_role" "investigate" {
  name                 = "${var.product}-investigate-${var.environment}"
  description          = "Read-only: every signal and resource description of ${var.environment}; never a secret, a data object, or a row."
  assume_role_policy   = data.aws_iam_policy_document.investigate_trust.json
  max_session_duration = 3600
}

resource "aws_iam_role_policy_attachment" "investigate_readonly" {
  role       = aws_iam_role.investigate.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

data "aws_iam_policy_document" "investigate_fence" {
  statement {
    sid    = "DenySecretValues"
    effect = "Deny"
    actions = [
      "secretsmanager:GetSecretValue",
      "secretsmanager:BatchGetSecretValue",
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:GetParametersByPath",
      "kms:Decrypt",
    ]
    resources = ["*"]
  }

  statement {
    sid     = "DenyDataObjects"
    effect  = "Deny"
    actions = ["s3:GetObject", "s3:GetObjectVersion", "s3:GetObjectAttributes", "s3:GetObjectTorrent"]
    resources = [
      "arn:aws:s3:::${var.product}-${var.environment}-*/*",
      "${aws_s3_bucket.state.arn}/plans/*",
    ]
  }

  statement {
    sid    = "DenyRows"
    effect = "Deny"
    actions = [
      "rds-db:connect",
      "rds-data:*",
      "sqs:ReceiveMessage",
      "elasticache:Connect",
      "ecs:ExecuteCommand",
    ]
    resources = ["*"]
  }

  statement {
    sid       = "DenyOtherRoles"
    effect    = "Deny"
    actions   = ["sts:AssumeRole", "sts:AssumeRoleWithWebIdentity", "sts:AssumeRoleWithSAML", "sts:GetFederationToken"]
    resources = ["*"]
  }

  statement {
    sid       = "DenyTheOtherEnvironment"
    effect    = "Deny"
    actions   = ["*"]
    resources = ["*"]
    condition {
      test     = "StringEquals"
      variable = "aws:ResourceTag/environment"
      values   = [var.other_environment]
    }
  }
}

resource "aws_iam_role_policy" "investigate_fence" {
  name   = "fence"
  role   = aws_iam_role.investigate.id
  policy = data.aws_iam_policy_document.investigate_fence.json
}
