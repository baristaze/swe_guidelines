# Target-tracking autoscaling for one service. The scalable target always
# exists and owns the service's desired count (the service ignores its own):
# its floor is the desired count, so turning autoscaling on changes nothing
# until load does. The root switch `autoscaling_enabled` (off by default) and
# the service's own lever (`enabled`, declared on) both must be on for the
# ceiling to rise above the floor and the policy to exist; so one flip at the
# root scales the whole environment.

variable "root_enabled" {
  description = "The root switch autoscaling_enabled."
  type        = bool
}

variable "scaling" {
  description = "The service's lever: { enabled, max, target_cpu }."
  type = object({
    enabled    = bool
    max        = number
    target_cpu = number
  })
}

variable "cluster_name" {
  type = string
}

variable "service_name" {
  type = string
}

variable "desired_count" {
  type = number
}

locals {
  on = var.root_enabled && var.scaling.enabled
}

resource "aws_appautoscaling_target" "this" {
  service_namespace  = "ecs"
  scalable_dimension = "ecs:service:DesiredCount"
  resource_id        = "service/${var.cluster_name}/${var.service_name}"
  min_capacity       = var.desired_count
  max_capacity       = local.on ? max(var.scaling.max, var.desired_count) : var.desired_count
}

resource "aws_appautoscaling_policy" "cpu" {
  count              = local.on ? 1 : 0
  name               = "${var.service_name}-cpu"
  policy_type        = "TargetTrackingScaling"
  service_namespace  = aws_appautoscaling_target.this.service_namespace
  scalable_dimension = aws_appautoscaling_target.this.scalable_dimension
  resource_id        = aws_appautoscaling_target.this.resource_id

  target_tracking_scaling_policy_configuration {
    target_value       = var.scaling.target_cpu
    scale_in_cooldown  = 300
    scale_out_cooldown = 60

    predefined_metric_specification {
      predefined_metric_type = "ECSServiceAverageCPUUtilization"
    }
  }
}

output "enabled" {
  value = local.on
}
