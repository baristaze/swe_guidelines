# One Fargate task definition: the process's container and, beside it, a
# non-essential OpenTelemetry collector. The collector scrapes the process's
# /metrics on localhost, receives its spans over OTLP on localhost:4318, and
# forwards both to CloudWatch (embedded metrics, namespace Acme) and X-Ray. It
# adds `service` (the process) and `environment` as dimensions and no other
# beyond a metric's own bounded labels, and sets the trace's service name to
# <product>-<process>, the name X-Ray shows. Its failure never stops the process.
#
# The container's own health check probes /healthz, never /readyz.

variable "family" {
  description = "The task definition family, acme-<env>-<process>."
  type        = string
}

variable "product" {
  type    = string
  default = "acme"
}

variable "environment" {
  type = string
}

variable "process" {
  description = "The process name: api, maintenance, migrate, grant-operator."
  type        = string
}

variable "region" {
  type = string
}

variable "image" {
  type = string
}

variable "command" {
  type    = list(string)
  default = null
}

variable "container_port" {
  description = "The port the process serves /healthz and /metrics on; null for a one-off task."
  type        = number
  default     = null
}

variable "health_check_path" {
  type    = string
  default = "/healthz"

  validation {
    condition     = var.health_check_path == "/healthz"
    error_message = "A task's health check probes /healthz; /readyz is read by the deploy and an operator, never by a check that replaces a task."
  }
}

variable "cpu" {
  type = number
}

variable "memory" {
  type = number
}

variable "environment_variables" {
  description = "Plain settings: name => value."
  type        = map(string)
}

variable "secrets" {
  description = "Secret settings: name => secret ARN."
  type        = map(string)
}

variable "labels" {
  description = "Docker labels; a change rolls the service (the password and key versions ride here)."
  type        = map(string)
  default     = {}
}

variable "task_role_statements" {
  description = "What the process itself may do."
  type = list(object({
    sid       = string
    actions   = list(string)
    resources = list(string)
  }))
  default = []
}

variable "permissions_boundary_arn" {
  description = "acme-boundary-<env>: every role this root creates carries it."
  type        = string
}

variable "log_retention_days" {
  type = number
}

variable "metrics_log_group" {
  description = "The log group the collector writes embedded metrics to."
  type        = string
}

variable "collector_image" {
  type = string
}

variable "metrics_namespace" {
  type    = string
  default = "Acme"
}

locals {
  log_group     = "/${var.product}/${var.environment}/${var.process}"
  trace_service = "${var.product}-${var.process}"
  scrape        = var.container_port != null

  collector_config = templatefile("${path.module}/collector.yaml.tftpl", {
    process           = var.process
    environment       = var.environment
    trace_service     = local.trace_service
    region            = var.region
    namespace         = var.metrics_namespace
    metrics_log_group = var.metrics_log_group
    scrape            = local.scrape
    port              = coalesce(var.container_port, 0)
  })

  app_container = merge(
    {
      name        = var.process
      image       = var.image
      essential   = true
      stopTimeout = 30
      environment = [for k in sort(keys(var.environment_variables)) : { name = k, value = var.environment_variables[k] }]
      secrets     = [for k in sort(keys(var.secrets)) : { name = k, valueFrom = var.secrets[k] }]
      dockerLabels = merge(var.labels, {
        "${var.product}.process"     = var.process
        "${var.product}.environment" = var.environment
      })
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          awslogs-group         = local.log_group
          awslogs-region        = var.region
          awslogs-stream-prefix = var.process
        }
      }
    },
    # Optional keys are built as JSON so both branches have one type.
    jsondecode(var.command == null ? "{}" : jsonencode({ command = var.command })),
    jsondecode(var.container_port == null ? "{}" : jsonencode({
      portMappings = [{ containerPort = var.container_port, protocol = "tcp" }]
      healthCheck = {
        command     = ["CMD-SHELL", "python -c \"import urllib.request; urllib.request.urlopen('http://localhost:${coalesce(var.container_port, 0)}${var.health_check_path}', timeout=3)\" || exit 1"]
        interval    = 15
        timeout     = 5
        retries     = 3
        startPeriod = 30
      }
    })),
  )

  collector_container = {
    name              = "otel-collector"
    image             = var.collector_image
    essential         = false
    memoryReservation = 128
    environment       = [{ name = "AOT_CONFIG_CONTENT", value = local.collector_config }]
    logConfiguration = {
      logDriver = "awslogs"
      options = {
        awslogs-group         = local.log_group
        awslogs-region        = var.region
        awslogs-stream-prefix = "otel-collector"
      }
    }
  }
}

resource "aws_cloudwatch_log_group" "this" {
  name              = local.log_group
  retention_in_days = var.log_retention_days
}

data "aws_iam_policy_document" "ecs_trust" {
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

# The execution role pulls the image, writes the logs, and resolves the secrets
# the definition names, and nothing else.
resource "aws_iam_role" "execution" {
  name                 = "${var.family}-execution"
  assume_role_policy   = data.aws_iam_policy_document.ecs_trust.json
  permissions_boundary = var.permissions_boundary_arn
}

data "aws_iam_policy_document" "execution" {
  statement {
    sid       = "PullImage"
    actions   = ["ecr:GetAuthorizationToken", "ecr:BatchCheckLayerAvailability", "ecr:GetDownloadUrlForLayer", "ecr:BatchGetImage"]
    resources = ["*"]
  }

  statement {
    sid       = "WriteLogs"
    actions   = ["logs:CreateLogStream", "logs:PutLogEvents"]
    resources = ["${aws_cloudwatch_log_group.this.arn}:*"]
  }

  dynamic "statement" {
    for_each = length(var.secrets) > 0 ? [1] : []
    content {
      sid       = "ResolveSecrets"
      actions   = ["secretsmanager:GetSecretValue"]
      resources = distinct(values(var.secrets))
    }
  }
}

resource "aws_iam_role_policy" "execution" {
  name   = "execution"
  role   = aws_iam_role.execution.id
  policy = data.aws_iam_policy_document.execution.json
}

# The task role: what the process may do, plus what its collector writes.
resource "aws_iam_role" "task" {
  name                 = "${var.family}-task"
  assume_role_policy   = data.aws_iam_policy_document.ecs_trust.json
  permissions_boundary = var.permissions_boundary_arn
}

data "aws_iam_policy_document" "task" {
  statement {
    sid       = "CollectorMetrics"
    actions   = ["logs:CreateLogStream", "logs:PutLogEvents", "logs:DescribeLogStreams", "logs:DescribeLogGroups"]
    resources = ["*"]
  }

  statement {
    sid       = "CollectorTraces"
    actions   = ["xray:PutTraceSegments", "xray:PutTelemetryRecords", "xray:GetSamplingRules", "xray:GetSamplingTargets", "xray:GetSamplingStatisticSummaries"]
    resources = ["*"]
  }

  dynamic "statement" {
    for_each = var.task_role_statements
    content {
      sid       = statement.value.sid
      actions   = statement.value.actions
      resources = statement.value.resources
    }
  }
}

resource "aws_iam_role_policy" "task" {
  name   = "task"
  role   = aws_iam_role.task.id
  policy = data.aws_iam_policy_document.task.json
}

resource "aws_ecs_task_definition" "this" {
  family                   = var.family
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.cpu
  memory                   = var.memory
  execution_role_arn       = aws_iam_role.execution.arn
  task_role_arn            = aws_iam_role.task.arn

  runtime_platform {
    operating_system_family = "LINUX"
    cpu_architecture        = "X86_64"
  }

  container_definitions = jsonencode([local.app_container, local.collector_container])
}

output "arn" {
  value = aws_ecs_task_definition.this.arn
}

output "family" {
  value = aws_ecs_task_definition.this.family
}

output "container_name" {
  value = var.process
}

output "task_role_arn" {
  value = aws_iam_role.task.arn
}

output "task_role_name" {
  value = aws_iam_role.task.name
}

output "log_group" {
  value = aws_cloudwatch_log_group.this.name
}
