# The notifier worker's image: the same shape as a service image, the metrics port its only exposed port,
# and a healthcheck on /healthz. Built from the repository root as the context.

FROM python:3.14.7-slim-trixie AS build
COPY --from=ghcr.io/astral-sh/uv:0.12.17 /uv /bin/uv
ENV UV_COMPILE_BYTECODE=1 UV_LINK_MODE=copy UV_PYTHON_DOWNLOADS=never
WORKDIR /app
COPY pyproject.toml uv.lock ./
COPY om om
COPY infra infra
COPY integrations integrations
COPY workers/notifier workers/notifier
RUN uv sync --frozen --no-dev --no-editable --package acme-worker-notifier

FROM python:3.14.7-slim-trixie AS runtime
RUN groupadd --system acme && useradd --system --gid acme --home /app acme
WORKDIR /app
COPY --from=build /app/.venv /app/.venv
COPY deployment/docker/entrypoint.sh /usr/local/bin/entrypoint.sh
ENV PATH="/app/.venv/bin:$PATH" \
    ACME_NOTIFIER_HOST=0.0.0.0 \
    ACME_NOTIFIER_PORT=9101
USER acme
EXPOSE 9101
HEALTHCHECK --interval=10s --timeout=3s --start-period=20s --retries=3 \
  CMD ["python", "-c", "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://127.0.0.1:9101/healthz', timeout=2).status == 200 else 1)"]
ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]
CMD ["acme-notifier", "serve"]
