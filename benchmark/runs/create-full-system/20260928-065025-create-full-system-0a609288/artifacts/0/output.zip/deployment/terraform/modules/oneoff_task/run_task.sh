#!/usr/bin/env bash
# Runs one one-off task on Fargate and waits for it to stop; exits non-zero
# unless the named container exited 0. Used by the apply (the migration, from
# modules/oneoff_task) and by grant-operator.yml and the deploy workflows' smoke
# job (the grant task, with OVERRIDES carrying the command).
#
# Environment: CLUSTER, TASK_DEFINITION, CONTAINER, SUBNETS (comma-separated),
# SECURITY_GROUPS (comma-separated), REGION, and optionally TIMEOUT_SECONDS
# (default 1800) and OVERRIDES (a JSON task override).
set -euo pipefail

: "${CLUSTER:?}" "${TASK_DEFINITION:?}" "${CONTAINER:?}" "${SUBNETS:?}" "${SECURITY_GROUPS:?}" "${REGION:?}"
timeout_seconds="${TIMEOUT_SECONDS:-1800}"

args=(
  ecs run-task
  --region "$REGION"
  --cluster "$CLUSTER"
  --task-definition "$TASK_DEFINITION"
  --launch-type FARGATE
  --started-by "oneoff-${CONTAINER}"
  --network-configuration "awsvpcConfiguration={subnets=[${SUBNETS}],securityGroups=[${SECURITY_GROUPS}],assignPublicIp=DISABLED}"
  --query 'tasks[0].taskArn'
  --output text
)
if [ -n "${OVERRIDES:-}" ]; then
  args+=(--overrides "$OVERRIDES")
fi

task_arn="$(aws "${args[@]}")"
if [ -z "$task_arn" ] || [ "$task_arn" = "None" ]; then
  echo "run-task started no task for ${TASK_DEFINITION}" >&2
  exit 1
fi
echo "one-off task ${CONTAINER} started: ${task_arn}"

deadline=$(($(date +%s) + timeout_seconds))
while :; do
  status="$(aws ecs describe-tasks --region "$REGION" --cluster "$CLUSTER" --tasks "$task_arn" \
    --query 'tasks[0].lastStatus' --output text)"
  if [ "$status" = "STOPPED" ]; then
    break
  fi
  if [ "$(date +%s)" -ge "$deadline" ]; then
    echo "one-off task ${CONTAINER} did not stop within ${timeout_seconds}s; stopping it" >&2
    aws ecs stop-task --region "$REGION" --cluster "$CLUSTER" --task "$task_arn" \
      --reason "timed out in the apply" >/dev/null
    exit 1
  fi
  sleep 10
done

exit_code="$(aws ecs describe-tasks --region "$REGION" --cluster "$CLUSTER" --tasks "$task_arn" \
  --query "tasks[0].containers[?name=='${CONTAINER}'].exitCode | [0]" --output text)"
reason="$(aws ecs describe-tasks --region "$REGION" --cluster "$CLUSTER" --tasks "$task_arn" \
  --query 'tasks[0].stoppedReason' --output text)"

if [ "$exit_code" != "0" ]; then
  echo "one-off task ${CONTAINER} failed: exit ${exit_code}, ${reason}; its log is in the task's log group" >&2
  exit 1
fi
echo "one-off task ${CONTAINER} succeeded"
