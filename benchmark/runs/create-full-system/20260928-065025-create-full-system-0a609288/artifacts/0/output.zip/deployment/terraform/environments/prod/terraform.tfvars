# Production: a push to release plans this, and it applies behind the
# production environment's approval. The account, the region, and the base
# domain come from deployment/cloud/environments.json; the images, the release,
# and the alarm address are passed by the pipeline.
environment = "production"

autoscaling_enabled          = false
destroyable                  = false
database_deletion_protection = true
waf_enabled                  = true

database_instance_class        = "db.t4g.small"
database_multi_az              = true
database_backup_retention_days = 14
database_max_allocated_storage = 500

cache_node_type = "cache.t4g.small"
cache_num_nodes = 2

nat_gateway_count = 2

api_desired_count    = 2
worker_desired_count = 1

log_retention_days = 90

workos_client_id   = ""
email_from         = "no-reply@free-journalism.example"
twilio_account_sid = ""
sms_from           = ""
