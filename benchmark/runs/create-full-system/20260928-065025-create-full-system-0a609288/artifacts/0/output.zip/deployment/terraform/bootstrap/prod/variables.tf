variable "github_repository" {
  description = "owner/name of the repository (scripts/cloud_create.sh passes it from gh repo view)."
  type        = string
}

variable "github_repository_id" {
  description = "The repository's immutable id, which the pipeline roles' trust names."
  type        = string
}

variable "github_repository_owner_id" {
  description = "The repository owner's immutable id, which the pipeline roles' trust names."
  type        = string
}

variable "owner_email" {
  description = "Who the budget and the anomaly monitor alert (OWNER_EMAIL)."
  type        = string
}

variable "monthly_budget_usd" {
  description = "The account's monthly budget in US dollars."
  type        = number
}

variable "everyday_permission_set" {
  description = "The identity center's everyday permission set name, whose role the investigate role trusts by pattern."
  type        = string
  default     = "Everyday"
}
