# One long-running process on the container runtime, reused for the API and
# every worker: its task definition (with the collector beside it), its log
# group /acme/<env>/<process> with retention, and its ECS service.
#
# Every service: the deployment circuit breaker with rollback, and the apply
# waits for the steady state, so a rollout the breaker rolled back fails the
# apply. A worker's rollout never exceeds its desired count (maximum 100%,
# minimum healthy 0%): the old task stops before the new one claims work.
# desired_count is owned by the autoscaling target (modules/autoscaling), which
# always exists with the desired count as its floor, so the apply never resets a
# scaled-out service.

variable "name_prefix" {
  description = "acme-<env>."
  type        = string
}

variable "product" {
  type    = string
  default = "acme"
}

variable "environment" {
  type = string
}

variable "process" {
  type = string
}

variable "region" {
  type = string
}

variable "image" {
  type = string
}

variable "command" {
  type    = list(string)
  default = null
}

variable "container_port" {
  type = number
}

variable "cpu" {
  type = number
}

variable "memory" {
  type = number
}

variable "desired_count" {
  type = number
}

variable "worker" {
  description = "A worker: no load balancer, and a rollout that never exceeds the desired count."
  type        = bool
  default     = false
}

variable "cluster_arn" {
  type = string
}

variable "subnet_ids" {
  type = list(string)
}

variable "security_group_ids" {
  type = list(string)
}

variable "target_group_arn" {
  description = "The load balancer's target group, or null for a worker."
  type        = string
  default     = null
}

variable "health_check_grace_period_seconds" {
  type    = number
  default = 60
}

variable "environment_variables" {
  type = map(string)
}

variable "secrets" {
  type = map(string)
}

variable "labels" {
  type    = map(string)
  default = {}
}

variable "task_role_statements" {
  type = list(object({
    sid       = string
    actions   = list(string)
    resources = list(string)
  }))
  default = []
}

variable "permissions_boundary_arn" {
  type = string
}

variable "log_retention_days" {
  type = number
}

variable "metrics_log_group" {
  type = string
}

variable "collector_image" {
  type = string
}

module "task" {
  source = "../task"

  family                   = "${var.name_prefix}-${var.process}"
  product                  = var.product
  environment              = var.environment
  process                  = var.process
  region                   = var.region
  image                    = var.image
  command                  = var.command
  container_port           = var.container_port
  cpu                      = var.cpu
  memory                   = var.memory
  environment_variables    = var.environment_variables
  secrets                  = var.secrets
  labels                   = var.labels
  task_role_statements     = var.task_role_statements
  permissions_boundary_arn = var.permissions_boundary_arn
  log_retention_days       = var.log_retention_days
  metrics_log_group        = var.metrics_log_group
  collector_image          = var.collector_image
}

resource "aws_ecs_service" "this" {
  name             = "${var.name_prefix}-${var.process}"
  cluster          = var.cluster_arn
  task_definition  = module.task.arn
  desired_count    = var.desired_count
  launch_type      = "FARGATE"
  platform_version = "LATEST"
  propagate_tags   = "SERVICE"

  deployment_maximum_percent         = var.worker ? 100 : 200
  deployment_minimum_healthy_percent = var.worker ? 0 : 100

  deployment_circuit_breaker {
    enable   = true
    rollback = true
  }

  wait_for_steady_state = true

  health_check_grace_period_seconds = var.target_group_arn == null ? null : var.health_check_grace_period_seconds

  network_configuration {
    subnets          = var.subnet_ids
    security_groups  = var.security_group_ids
    assign_public_ip = false
  }

  dynamic "load_balancer" {
    for_each = var.target_group_arn == null ? [] : [var.target_group_arn]
    content {
      target_group_arn = load_balancer.value
      container_name   = var.process
      container_port   = var.container_port
    }
  }

  lifecycle {
    # The autoscaling target owns the count; see modules/autoscaling.
    ignore_changes = [desired_count]

    precondition {
      condition     = var.worker == (var.target_group_arn == null)
      error_message = "A worker has no load balancer; every other service has one."
    }
  }
}

output "service_name" {
  value = aws_ecs_service.this.name
}

output "task_definition_arn" {
  value = module.task.arn
}

output "task_definition_family" {
  value = module.task.family
}

output "log_group" {
  value = module.task.log_group
}

output "desired_count" {
  value = var.desired_count
}
