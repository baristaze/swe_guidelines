# Staging: every bundle kept under the bundle prefix replicates into production's
# artifacts bucket. Production's bucket policy (buckets.tf, grant_replication_from_staging)
# admits this role's writes under the prefix and nothing else.

locals {
  production_artifacts_bucket = "${var.product}-artifacts-${var.production_account_id}"
}

data "aws_iam_policy_document" "replication_trust" {
  count = var.replicate_to_production ? 1 : 0
  statement {
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["s3.amazonaws.com"]
    }
    condition {
      test     = "StringEquals"
      variable = "aws:SourceAccount"
      values   = [var.account_id]
    }
  }
}

resource "aws_iam_role" "replication" {
  count                = var.replicate_to_production ? 1 : 0
  name                 = "${var.product}-replication-staging"
  assume_role_policy   = data.aws_iam_policy_document.replication_trust[0].json
  permissions_boundary = aws_iam_policy.boundary.arn
}

data "aws_iam_policy_document" "replication" {
  count = var.replicate_to_production ? 1 : 0

  statement {
    actions   = ["s3:GetReplicationConfiguration", "s3:ListBucket"]
    resources = [aws_s3_bucket.artifacts.arn]
  }

  statement {
    actions = [
      "s3:GetObjectVersionForReplication",
      "s3:GetObjectVersionAcl",
      "s3:GetObjectVersionTagging",
      "s3:GetObjectRetention",
      "s3:GetObjectLegalHold",
    ]
    resources = ["${aws_s3_bucket.artifacts.arn}/${var.bundle_prefix}*"]
  }

  statement {
    actions = [
      "s3:ReplicateObject",
      "s3:ReplicateTags",
      "s3:ObjectOwnerOverrideToBucketOwner",
    ]
    resources = ["arn:aws:s3:::${local.production_artifacts_bucket}/${var.bundle_prefix}*"]
  }
}

resource "aws_iam_role_policy" "replication" {
  count  = var.replicate_to_production ? 1 : 0
  name   = "replicate-bundles"
  role   = aws_iam_role.replication[0].id
  policy = data.aws_iam_policy_document.replication[0].json
}

resource "aws_s3_bucket_replication_configuration" "to_production" {
  count  = var.replicate_to_production ? 1 : 0
  bucket = aws_s3_bucket.artifacts.id
  role   = aws_iam_role.replication[0].arn

  rule {
    id     = "bundles-to-production"
    status = "Enabled"

    filter {
      prefix = var.bundle_prefix
    }

    delete_marker_replication {
      status = "Disabled"
    }

    destination {
      bucket  = "arn:aws:s3:::${local.production_artifacts_bucket}"
      account = var.production_account_id

      access_control_translation {
        owner = "Destination"
      }
    }
  }

  depends_on = [aws_s3_bucket_versioning.artifacts]
}
