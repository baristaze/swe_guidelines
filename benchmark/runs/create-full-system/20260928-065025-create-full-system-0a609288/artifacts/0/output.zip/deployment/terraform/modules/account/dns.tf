# One hosted zone per public name (api., app., admin. under the base domain),
# its records at the zone's apex. The domain's own zone delegates each name here
# with NS records, written once by scripts/cloud_create.sh.

resource "aws_route53_zone" "public" {
  for_each = toset(var.public_names)
  name     = each.value
  comment  = "${var.environment}: ${each.value}"
}
