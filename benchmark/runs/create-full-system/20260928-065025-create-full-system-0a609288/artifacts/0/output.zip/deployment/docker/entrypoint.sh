#!/bin/sh
# The shared entrypoint of every image: the process's console script and its subcommand arrive as arguments,
# so `acme-api serve`, `acme-api migrate upgrade --all`, and a worker's default command all start the same way.
set -eu
if [ "$#" -eq 0 ]; then
  echo "entrypoint: no command given" >&2
  exit 64
fi
exec "$@"
