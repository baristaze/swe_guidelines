# Staging: a merge to main applies this. The account, the region, and the base
# domain come from deployment/cloud/environments.json; the images, the release,
# and the alarm address are passed by the pipeline.
environment = "staging"

autoscaling_enabled          = false
destroyable                  = false
database_deletion_protection = false
waf_enabled                  = false

database_instance_class        = "db.t4g.micro"
database_multi_az              = false
database_backup_retention_days = 7
database_max_allocated_storage = 100

cache_node_type = "cache.t4g.micro"
cache_num_nodes = 1

api_desired_count    = 1
worker_desired_count = 1

log_retention_days = 30

workos_client_id   = ""
email_from         = "no-reply@staging.free-journalism.example"
twilio_account_sid = ""
sms_from           = ""
