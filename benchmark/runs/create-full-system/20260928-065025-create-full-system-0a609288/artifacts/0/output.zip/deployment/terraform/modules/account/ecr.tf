# One repository per process image: tags never overwritten, every push scanned,
# a bounded number of images kept, and never one tagged prod- (the production
# deploy adds prod-<commit> to each digest it promotes).

resource "aws_ecr_repository" "this" {
  for_each = toset(var.ecr_repositories)

  name                 = each.value
  image_tag_mutability = "IMMUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  encryption_configuration {
    encryption_type = "AES256"
  }
}

resource "aws_ecr_lifecycle_policy" "this" {
  for_each   = aws_ecr_repository.this
  repository = each.value.name

  # An image a higher-priority rule matches is never expired by a lower one, so
  # rule 1 holds every prod- image for good.
  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Never expire an image production runs or ran"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["prod-"]
          countType     = "imageCountMoreThan"
          countNumber   = 9999
        }
        action = { type = "expire" }
      },
      {
        rulePriority = 2
        description  = "Keep a bounded number of every other image"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = var.ecr_keep_images
        }
        action = { type = "expire" }
      },
    ]
  })
}

# Staging: every image pushed replicates into production's registry, digest for
# digest. Replication never creates a repository there.
resource "aws_ecr_replication_configuration" "to_production" {
  count = var.replicate_to_production ? 1 : 0

  replication_configuration {
    rule {
      destination {
        region      = var.region
        registry_id = var.production_account_id
      }
      repository_filter {
        filter      = "${var.product}-"
        filter_type = "PREFIX_MATCH"
      }
    }
  }
}

# Production: staging may replicate into these repositories, and nothing else.
data "aws_iam_policy_document" "registry" {
  count = var.grant_replication_from_staging ? 1 : 0

  statement {
    sid       = "StagingReplicatesImages"
    actions   = ["ecr:ReplicateImage"]
    resources = [for r in aws_ecr_repository.this : r.arn]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${var.staging_account_id}:root"]
    }
  }
}

resource "aws_ecr_registry_policy" "this" {
  count  = var.grant_replication_from_staging ? 1 : 0
  policy = data.aws_iam_policy_document.registry[0].json
}
