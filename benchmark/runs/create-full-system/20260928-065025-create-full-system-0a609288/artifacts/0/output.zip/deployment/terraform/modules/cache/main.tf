# Valkey on ElastiCache: encrypted at rest and in transit. The client connects
# over TLS, so ACME_CACHE_URL is a rediss:// URL. No auth token: the security
# group admits the tasks alone, so the URL holds no secret and is passed plain.

variable "name" {
  type = string
}

variable "vpc_id" {
  type = string
}

variable "subnet_ids" {
  type = list(string)
}

variable "client_security_group_ids" {
  type = list(string)
}

variable "engine_version" {
  type    = string
  default = "8.1"
}

variable "node_type" {
  type = string
}

variable "num_nodes" {
  description = "1 is a single primary; 2 or more adds replicas with automatic failover."
  type        = number
}

resource "aws_security_group" "cache" {
  name        = "${var.name}-cache"
  description = "Valkey for ${var.name}, reachable from its tasks alone."
  vpc_id      = var.vpc_id

  ingress {
    description     = "Valkey over TLS from the tasks"
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = var.client_security_group_ids
  }
}

resource "aws_elasticache_subnet_group" "this" {
  name       = var.name
  subnet_ids = var.subnet_ids
}

resource "aws_elasticache_replication_group" "this" {
  replication_group_id = var.name
  description          = "The cache of ${var.name}"
  engine               = "valkey"
  engine_version       = var.engine_version
  node_type            = var.node_type
  num_cache_clusters   = var.num_nodes
  port                 = 6379

  subnet_group_name  = aws_elasticache_subnet_group.this.name
  security_group_ids = [aws_security_group.cache.id]

  at_rest_encryption_enabled = true
  transit_encryption_enabled = true
  transit_encryption_mode    = "required"

  automatic_failover_enabled = var.num_nodes > 1
  multi_az_enabled           = var.num_nodes > 1
  auto_minor_version_upgrade = true
  apply_immediately          = true
}

output "url" {
  description = "rediss:// URL of the primary endpoint."
  value       = "rediss://${aws_elasticache_replication_group.this.primary_endpoint_address}:6379"
}

output "replication_group_id" {
  value = aws_elasticache_replication_group.this.id
}
