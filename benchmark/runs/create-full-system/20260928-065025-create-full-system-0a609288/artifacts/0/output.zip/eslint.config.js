// The one lint configuration every browser app extends.
import js from "@eslint/js";
import tseslint from "typescript-eslint";

export default tseslint.config(
  { ignores: ["**/dist/**", "**/node_modules/**", "**/src/api/schema.d.ts"] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    rules: {
      // Feature code never calls fetch; the one transport client does.
      "no-restricted-globals": ["error", { name: "fetch", message: "use the API client in src/api/client.ts" }],
      "no-restricted-syntax": [
        "error",
        { selector: "MemberExpression[object.name='localStorage']", message: "the bearer never lives in local storage" },
      ],
    },
  },
);
