"""The one outbound call shape every real client uses: a timeout on every call, failures mapped to one family."""

from typing import Any

import httpx

from acme.integrations.exceptions import IntegrationException, IntegrationRefused, IntegrationUnavailable


async def call(client: httpx.AsyncClient, method: str, url: str, **kwargs: Any) -> httpx.Response:
    try:
        response = await client.request(method, url, **kwargs)
    except httpx.TimeoutException as exc:
        raise IntegrationUnavailable(f"{method} {url} timed out") from exc
    except httpx.TransportError as exc:
        raise IntegrationUnavailable(f"{method} {url} could not connect") from exc
    if response.status_code >= 500 or response.status_code == 429:
        raise IntegrationUnavailable(f"{method} {url} answered {response.status_code}")
    if response.status_code in (401, 403):
        raise IntegrationRefused(f"{method} {url} refused the credential ({response.status_code})")
    if response.status_code >= 400 and response.status_code != 404:
        raise IntegrationException(f"{method} {url} answered {response.status_code}")
    return response
