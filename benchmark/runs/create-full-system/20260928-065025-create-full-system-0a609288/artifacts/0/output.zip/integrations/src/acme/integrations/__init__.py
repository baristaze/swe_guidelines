"""Third-party providers: each an interface, a real client, and a twin that refuses to run outside local."""
