"""The integrations' exceptions, rooted at InfraException: a boundary presents them by their status and code."""

from acme.infra.exceptions import InfraException


class IntegrationException(InfraException):
    http_status: int = 502
    code: str = "provider_failed"


class IntegrationUnavailable(IntegrationException):
    """The provider could not be reached or answered with a failure a retry may change."""

    http_status = 503
    code = "provider_unavailable"


class IntegrationRefused(IntegrationException):
    """The provider, or the twin, refused the call as shaped: a bad signature, a twin outside local."""

    http_status = 422
    code = "provider_refused"
