"""The identity provider's twin: deterministic codes and tokens it signs itself. Refuses to run outside local."""

import time
from urllib.parse import urlencode

import jwt

from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.identity import ExternalIdentity, IdentityProviderInterface
from acme.integrations.twin import TWIN_PROVENANCE, refuse_outside_local

TWIN_ISSUER = "https://identity.twin.local"


class IdentityProviderTwinImpl(IdentityProviderInterface):
    def __init__(self, environment: str, signing_secret: str) -> None:
        refuse_outside_local(environment, "identity provider")
        self._secret = signing_secret

    def issue_token(self, email: str, display_name: str, ttl_seconds: int = 3600) -> str:
        """What the provider's hosted page would hand back: a token naming the person by a stable subject."""
        now = int(time.time())
        claims = {"iss": TWIN_ISSUER, "sub": f"twin|{email.lower()}", "email": email, "name": display_name}
        return jwt.encode({**claims, "iat": now, "exp": now + ttl_seconds}, self._secret, algorithm="HS256")

    def authorization_url(self, redirect_uri: str, state: str, connection: str | None = None) -> str:
        # The twin has no hosted page: it redirects straight back with a code the exchange understands.
        code = f"twin:{connection or 'email'}:developer@acme.example"
        return f"{redirect_uri}?{urlencode({'code': code, 'state': state})}"

    async def exchange_code(self, code: str, redirect_uri: str) -> ExternalIdentity:
        parts = code.split(":", 2)
        if len(parts) != 3 or parts[0] != "twin" or "@" not in parts[2]:
            raise IntegrationRefused("the twin does not know that code")
        email = parts[2]
        return await self.verify_token(self.issue_token(email, email.split("@")[0]))

    async def verify_token(self, token: str) -> ExternalIdentity:
        try:
            claims = jwt.decode(token, self._secret, algorithms=["HS256"], issuer=TWIN_ISSUER)
        except jwt.PyJWTError as exc:
            raise IntegrationRefused("the twin token does not verify") from exc
        return ExternalIdentity(
            issuer=TWIN_ISSUER,
            subject=str(claims["sub"]),
            email=str(claims["email"]),
            display_name=str(claims["name"]),
            provenance=TWIN_PROVENANCE,
        )

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return "identity provider: twin"
