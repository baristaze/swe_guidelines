"""The integrations settings: which provider backs each integration, real or twin, and its credentials."""

from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class IntegrationsSettings(BaseSettings):
    """Every provider credential is a process credential injected at start, never a tenant secret."""

    model_config = SettingsConfigDict(
        env_prefix="ACME_INTEGRATIONS_", env_file=".env", extra="ignore", env_ignore_empty=True
    )

    environment: Literal["local", "staging", "production"] = "local"
    timeout_seconds: float = 10.0
    twin_signing_secret: str = "local-twin-signing-secret-of-32-bytes"  # the twins sign their own synthetic deliveries

    identity_provider: Literal["twin", "workos"] = "twin"
    workos_client_id: str = ""
    workos_api_key: str = ""
    workos_api_base: str = "https://api.workos.com"

    payments: Literal["twin", "stripe"] = "twin"
    stripe_secret_key: str = ""
    stripe_webhook_secret: str = ""
    stripe_api_base: str = "https://api.stripe.com"

    email: Literal["twin", "postmark", "resend"] = "twin"
    email_from: str = "Free Journalism <notifications@free-journalism.example>"
    postmark_server_token: str = ""
    resend_api_key: str = ""

    sms: Literal["twin", "twilio"] = "twin"
    sms_from: str = ""
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""

    malware_scanner: Literal["twin", "virustotal"] = "twin"
    virustotal_api_key: str = ""
