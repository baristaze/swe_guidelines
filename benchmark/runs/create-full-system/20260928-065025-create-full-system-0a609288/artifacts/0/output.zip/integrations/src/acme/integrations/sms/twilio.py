"""Twilio's Messages API."""

import httpx

from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.http import call
from acme.integrations.sms import OutboundSms, SmsDelivery, SmsInterface

TWILIO_API = "https://api.twilio.com"


class SmsTwilioImpl(SmsInterface):
    def __init__(
        self,
        account_sid: str,
        auth_token: str,
        sender: str,
        timeout_seconds: float,
        api_base: str = TWILIO_API,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._sid = account_sid
        self._token = auth_token
        self._sender = sender
        self._timeout = timeout_seconds
        self._base = api_base.rstrip("/")
        self._transport = transport  # a recorded-fixture test hands one in; None is the network
        self._http: httpx.AsyncClient | None = None

    async def start(self) -> None:
        self._http = httpx.AsyncClient(transport=self._transport, timeout=self._timeout, auth=(self._sid, self._token))

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def send(self, message: OutboundSms) -> SmsDelivery:
        if self._http is None:
            raise IntegrationRefused("the sms client is not started")
        response = await call(
            self._http,
            "POST",
            f"{self._base}/2010-04-01/Accounts/{self._sid}/Messages.json",
            data={"To": message.to, "From": self._sender, "Body": message.body},
        )
        return SmsDelivery(message_id=str(response.json()["sid"]), provenance="twilio")

    def describe(self) -> str:
        return "sms: twilio"
