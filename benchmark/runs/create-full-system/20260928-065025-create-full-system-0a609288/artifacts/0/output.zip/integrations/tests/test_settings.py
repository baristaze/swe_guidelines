"""Every integrations knob is documented in .env.example under its prefix."""

from pathlib import Path

from acme.integrations.settings import IntegrationsSettings

ENV_EXAMPLE = Path(__file__).resolve().parents[2] / ".env.example"


def test_every_field_is_in_env_example() -> None:
    lines = ENV_EXAMPLE.read_text().splitlines()
    documented = {line.split("=", 1)[0] for line in lines if "=" in line and not line.startswith("#")}
    missing = {f"ACME_INTEGRATIONS_{name.upper()}" for name in IntegrationsSettings.model_fields} - documented
    assert not missing, f"undocumented integrations settings: {sorted(missing)}"
