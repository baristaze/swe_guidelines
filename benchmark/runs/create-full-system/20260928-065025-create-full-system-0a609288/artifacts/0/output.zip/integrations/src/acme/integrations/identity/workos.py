"""WorkOS AuthKit: the hosted sign-in, the code exchange, and access tokens verified against its JWKS."""

from typing import Any
from urllib.parse import urlencode

import httpx
import jwt

from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.http import call
from acme.integrations.identity import ExternalIdentity, IdentityProviderInterface


class IdentityProviderWorkOSImpl(IdentityProviderInterface):
    def __init__(
        self,
        client_id: str,
        api_key: str,
        api_base: str,
        timeout_seconds: float,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._client_id = client_id
        self._api_key = api_key
        self._base = api_base.rstrip("/")
        self._timeout = timeout_seconds
        self._transport = transport  # a recorded-fixture test hands one in; None is the network
        self._http: httpx.AsyncClient | None = None
        self._keys: dict[str, Any] = {}

    @property
    def issuer(self) -> str:
        return f"{self._base}/user_management/{self._client_id}"

    async def start(self) -> None:
        self._http = httpx.AsyncClient(transport=self._transport, timeout=self._timeout)

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    def _client(self) -> httpx.AsyncClient:
        if self._http is None:
            raise IntegrationRefused("the identity provider client is not started")
        return self._http

    def authorization_url(self, redirect_uri: str, state: str, connection: str | None = None) -> str:
        query = {
            "client_id": self._client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "state": state,
            "provider": connection or "authkit",
        }
        return f"{self._base}/user_management/authorize?{urlencode(query)}"

    async def exchange_code(self, code: str, redirect_uri: str) -> ExternalIdentity:
        response = await call(
            self._client(),
            "POST",
            f"{self._base}/user_management/authenticate",
            json={
                "client_id": self._client_id,
                "client_secret": self._api_key,
                "grant_type": "authorization_code",
                "code": code,
            },
        )
        if response.status_code == 404:
            raise IntegrationRefused("the provider does not know that code")
        body = response.json()
        user = body.get("user") or {}
        verified = await self.verify_token(body["access_token"])
        name = " ".join(p for p in (user.get("first_name"), user.get("last_name")) if p) or verified.display_name
        return verified.model_copy(update={"email": user.get("email", verified.email), "display_name": name})

    async def _key(self, kid: str) -> Any:
        if kid not in self._keys:
            response = await call(self._client(), "GET", f"{self._base}/sso/jwks/{self._client_id}")
            for jwk in response.json().get("keys", []):
                self._keys[jwk["kid"]] = jwt.PyJWK(jwk).key
        if kid not in self._keys:
            raise IntegrationRefused("the token names a key the provider does not publish")
        return self._keys[kid]

    async def verify_token(self, token: str) -> ExternalIdentity:
        try:
            header = jwt.get_unverified_header(token)
            claims = jwt.decode(
                token,
                await self._key(str(header.get("kid"))),
                algorithms=["RS256"],
                options={"require": ["exp", "sub", "iss"], "verify_aud": False},
            )
        except jwt.PyJWTError as exc:
            raise IntegrationRefused("the provider token does not verify") from exc
        if not str(claims["iss"]).startswith(self._base):
            raise IntegrationRefused("the provider token names another issuer")
        return ExternalIdentity(
            issuer=self.issuer,
            subject=str(claims["sub"]),
            email=str(claims.get("email", "")),
            display_name=str(claims.get("name") or claims.get("email") or claims["sub"]),
            provenance="workos",
        )

    def describe(self) -> str:
        return f"identity provider: workos at {self._base}"
