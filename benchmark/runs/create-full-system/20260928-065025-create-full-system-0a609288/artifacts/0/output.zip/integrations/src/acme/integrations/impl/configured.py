"""Builds the integrations from settings: each provider real or twin; a twin refuses outside local."""

from acme.integrations.email import EmailInterface
from acme.integrations.email.postmark import EmailPostmarkImpl
from acme.integrations.email.resend import EmailResendImpl
from acme.integrations.email.twin import EmailTwinImpl
from acme.integrations.identity import IdentityProviderInterface
from acme.integrations.identity.twin import IdentityProviderTwinImpl
from acme.integrations.identity.workos import IdentityProviderWorkOSImpl
from acme.integrations.malware import MalwareScannerInterface
from acme.integrations.malware.twin import MalwareScannerTwinImpl
from acme.integrations.malware.virustotal import MalwareScannerVirusTotalImpl
from acme.integrations.payments import PaymentsInterface
from acme.integrations.payments.stripe import PaymentsStripeImpl
from acme.integrations.payments.twin import PaymentsTwinImpl
from acme.integrations.root import Integrations
from acme.integrations.settings import IntegrationsSettings
from acme.integrations.sms import SmsInterface
from acme.integrations.sms.twilio import SmsTwilioImpl
from acme.integrations.sms.twin import SmsTwinImpl

TEST_SIGNING_SECRET = "test-twin-signing-secret-of-32-bytes"


def build_integrations(settings: IntegrationsSettings) -> Integrations:
    env, timeout, secret = settings.environment, settings.timeout_seconds, settings.twin_signing_secret
    identity: IdentityProviderInterface = (
        IdentityProviderWorkOSImpl(
            settings.workos_client_id, settings.workos_api_key, settings.workos_api_base, timeout
        )
        if settings.identity_provider == "workos"
        else IdentityProviderTwinImpl(env, secret)
    )
    payments: PaymentsInterface = (
        PaymentsStripeImpl(
            settings.stripe_secret_key, settings.stripe_webhook_secret, settings.stripe_api_base, timeout
        )
        if settings.payments == "stripe"
        else PaymentsTwinImpl(env, secret)
    )
    if settings.email == "postmark":
        email: EmailInterface = EmailPostmarkImpl(settings.postmark_server_token, settings.email_from, timeout)
    elif settings.email == "resend":
        email = EmailResendImpl(settings.resend_api_key, settings.email_from, timeout)
    else:
        email = EmailTwinImpl(env)
    sms: SmsInterface = (
        SmsTwilioImpl(settings.twilio_account_sid, settings.twilio_auth_token, settings.sms_from, timeout)
        if settings.sms == "twilio"
        else SmsTwinImpl(env)
    )
    scanner: MalwareScannerInterface = (
        MalwareScannerVirusTotalImpl(settings.virustotal_api_key, timeout)
        if settings.malware_scanner == "virustotal"
        else MalwareScannerTwinImpl(env)
    )
    return Integrations(identity_provider=identity, payments=payments, email=email, sms=sms, malware_scanner=scanner)


def build_twins(signing_secret: str = TEST_SIGNING_SECRET) -> Integrations:
    """Every provider its twin, for tests and the fast gate."""
    return Integrations(
        identity_provider=IdentityProviderTwinImpl("local", signing_secret),
        payments=PaymentsTwinImpl("local", signing_secret),
        email=EmailTwinImpl("local"),
        sms=SmsTwinImpl("local"),
        malware_scanner=MalwareScannerTwinImpl("local"),
    )
