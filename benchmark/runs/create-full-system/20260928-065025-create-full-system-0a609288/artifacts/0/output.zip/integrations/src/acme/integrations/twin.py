"""What every twin shares: it refuses to run outside local, and every record it produces names its provenance."""

from acme.integrations.exceptions import IntegrationRefused

TWIN_PROVENANCE = "twin"


def refuse_outside_local(environment: str, integration: str) -> None:
    if environment != "local":
        raise IntegrationRefused(f"the {integration} twin is refused outside local (environment={environment})")
