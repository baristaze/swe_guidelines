"""SMS for explicitly opted-in, high-priority notifications only."""

from abc import ABC, abstractmethod

from pydantic import BaseModel, ConfigDict


class OutboundSms(BaseModel):
    model_config = ConfigDict(frozen=True)

    to: str  # E.164
    body: str
    idempotency_key: str


class SmsDelivery(BaseModel):
    model_config = ConfigDict(frozen=True)

    message_id: str
    provenance: str


class SmsInterface(ABC):
    @abstractmethod
    async def send(self, message: OutboundSms) -> SmsDelivery: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...
