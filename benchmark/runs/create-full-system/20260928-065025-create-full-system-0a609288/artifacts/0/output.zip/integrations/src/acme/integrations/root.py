"""The integrations root: one frozen object holding every provider by interface, built once per process."""

from dataclasses import dataclass

from acme.integrations.email import EmailInterface
from acme.integrations.identity import IdentityProviderInterface
from acme.integrations.malware import MalwareScannerInterface
from acme.integrations.payments import PaymentsInterface
from acme.integrations.sms import SmsInterface


@dataclass(frozen=True)
class Integrations:
    identity_provider: IdentityProviderInterface
    payments: PaymentsInterface
    email: EmailInterface
    sms: SmsInterface
    malware_scanner: MalwareScannerInterface

    def _all(
        self,
    ) -> tuple[
        IdentityProviderInterface | PaymentsInterface | EmailInterface | SmsInterface | MalwareScannerInterface, ...
    ]:
        return (self.identity_provider, self.payments, self.email, self.sms, self.malware_scanner)

    def describe(self) -> list[str]:
        return [p.describe() for p in self._all()]

    async def start(self) -> None:
        for provider in self._all():
            await provider.start()

    async def close(self) -> None:
        for provider in reversed(self._all()):
            await provider.close()
