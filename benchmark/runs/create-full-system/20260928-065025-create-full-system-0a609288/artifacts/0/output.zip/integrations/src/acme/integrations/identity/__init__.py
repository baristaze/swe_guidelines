"""The external identity provider: hosted sign-in (email code, Google, Apple, GitHub, Microsoft) for registered users.

The gateway's dependency hands the provider's token here; what comes back is an issuer and a subject, which the
tenancy manager's transition finds or creates an identity for. Nothing below the gateway knows which provider spoke.
"""

from abc import ABC, abstractmethod

from pydantic import BaseModel, ConfigDict


class ExternalIdentity(BaseModel):
    model_config = ConfigDict(frozen=True)

    issuer: str
    subject: str
    email: str
    display_name: str
    provenance: str  # "workos", or "twin" for a record the twin produced


class IdentityProviderInterface(ABC):
    @abstractmethod
    def authorization_url(self, redirect_uri: str, state: str, connection: str | None = None) -> str:
        """Where the browser goes to sign in; `connection` names a social provider, None for the hosted page."""
        ...

    @abstractmethod
    async def exchange_code(self, code: str, redirect_uri: str) -> ExternalIdentity:
        """Trades the code the provider redirected back with for the verified identity it names."""
        ...

    @abstractmethod
    async def verify_token(self, token: str) -> ExternalIdentity:
        """Verifies a provider access token against the provider's published keys."""
        ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...
