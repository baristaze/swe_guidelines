"""Resend, the alternative transactional provider; it dedupes on the Idempotency-Key header itself."""

import httpx

from acme.integrations.email import Delivery, EmailInterface, OutboundEmail
from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.http import call

RESEND_API = "https://api.resend.com"


class EmailResendImpl(EmailInterface):
    def __init__(
        self,
        api_key: str,
        sender: str,
        timeout_seconds: float,
        api_base: str = RESEND_API,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._key = api_key
        self._sender = sender
        self._timeout = timeout_seconds
        self._base = api_base.rstrip("/")
        self._transport = transport  # a recorded-fixture test hands one in; None is the network
        self._http: httpx.AsyncClient | None = None

    async def start(self) -> None:
        self._http = httpx.AsyncClient(
            transport=self._transport, timeout=self._timeout, headers={"Authorization": f"Bearer {self._key}"}
        )

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def send(self, message: OutboundEmail) -> Delivery:
        if self._http is None:
            raise IntegrationRefused("the email client is not started")
        response = await call(
            self._http,
            "POST",
            f"{self._base}/emails",
            json={
                "from": self._sender,
                "to": [message.to],
                "subject": message.subject,
                "text": message.text,
                "tags": [{"name": "kind", "value": message.tag}],
            },
            headers={"Idempotency-Key": message.idempotency_key},
        )
        return Delivery(message_id=str(response.json()["id"]), provenance="resend")

    def describe(self) -> str:
        return "email: resend"
