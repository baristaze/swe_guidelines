"""Stripe: Checkout Sessions with destination charges, Connect Express accounts, refunds, and signed webhooks."""

import json

import httpx

from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.http import call
from acme.integrations.payments import (
    Checkout,
    ConnectedAccount,
    PaymentsInterface,
    Refund,
    SupportMode,
    WebhookDelivery,
    verify_signature,
)


class PaymentsStripeImpl(PaymentsInterface):
    def __init__(
        self,
        secret_key: str,
        webhook_secret: str,
        api_base: str,
        timeout_seconds: float,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._key = secret_key
        self._webhook_secret = webhook_secret
        self._base = api_base.rstrip("/")
        self._timeout = timeout_seconds
        self._transport = transport  # a recorded-fixture test hands one in; None is the network
        self._http: httpx.AsyncClient | None = None

    async def start(self) -> None:
        self._http = httpx.AsyncClient(transport=self._transport, timeout=self._timeout, auth=(self._key, ""))

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def _post(self, path: str, form: dict[str, str], idempotency_key: str) -> dict[str, object]:
        if self._http is None:
            raise IntegrationRefused("the payments client is not started")
        response = await call(
            self._http, "POST", f"{self._base}{path}", data=form, headers={"Idempotency-Key": idempotency_key}
        )
        return response.json()

    async def create_checkout(
        self,
        *,
        connected_account_id: str,
        amount_minor: int,
        currency: str,
        mode: SupportMode,
        platform_fee_minor: int,
        success_url: str,
        cancel_url: str,
        reference: str,
        idempotency_key: str,
    ) -> Checkout:
        form = {
            "mode": mode.value,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "client_reference_id": reference,
            "line_items[0][quantity]": "1",
            "line_items[0][price_data][currency]": currency,
            "line_items[0][price_data][unit_amount]": str(amount_minor),
            "line_items[0][price_data][product_data][name]": "Support",
        }
        if mode == SupportMode.MONTHLY:
            form["line_items[0][price_data][recurring][interval]"] = "month"
            form["subscription_data[transfer_data][destination]"] = connected_account_id
            form["subscription_data[application_fee_percent]"] = str(round(100 * platform_fee_minor / amount_minor, 2))
        else:
            form["payment_intent_data[transfer_data][destination]"] = connected_account_id
            form["payment_intent_data[application_fee_amount]"] = str(platform_fee_minor)
        body = await self._post("/v1/checkout/sessions", form, idempotency_key)
        return Checkout(session_id=str(body["id"]), url=str(body["url"]), provenance="stripe")

    async def create_connected_account(self, *, email: str, country: str, idempotency_key: str) -> ConnectedAccount:
        body = await self._post(
            "/v1/accounts",
            {"type": "express", "email": email, "country": country, "capabilities[transfers][requested]": "true"},
            idempotency_key,
        )
        return ConnectedAccount(account_id=str(body["id"]), provenance="stripe")

    async def onboarding_link(self, account_id: str, refresh_url: str, return_url: str) -> str:
        body = await self._post(
            "/v1/account_links",
            {"account": account_id, "refresh_url": refresh_url, "return_url": return_url, "type": "account_onboarding"},
            f"link-{account_id}-{return_url}",
        )
        return str(body["url"])

    async def cancel_subscription(self, subscription_id: str, *, idempotency_key: str) -> str:
        body = await self._post(
            f"/v1/subscriptions/{subscription_id}", {"cancel_at_period_end": "true"}, idempotency_key
        )
        return str(body["status"])

    async def refund(self, *, payment_intent_id: str, amount_minor: int | None, idempotency_key: str) -> Refund:
        form = {"payment_intent": payment_intent_id}
        if amount_minor is not None:
            form["amount"] = str(amount_minor)
        body = await self._post("/v1/refunds", form, idempotency_key)
        return Refund(refund_id=str(body["id"]), status=str(body["status"]), provenance="stripe")

    def verify_webhook(self, payload: bytes, signature_header: str) -> WebhookDelivery:
        verify_signature(payload, signature_header, self._webhook_secret)
        event = json.loads(payload)
        return WebhookDelivery(delivery_id=str(event["id"]), type=str(event["type"]), data=dict(event.get("data", {})))

    def describe(self) -> str:
        return f"payments: stripe at {self._base}"
