"""The payment processor's twin: the same shapes, keyed deterministically, signing its own synthetic deliveries."""

import hashlib
import json
import time

from acme.integrations.payments import (
    Checkout,
    ConnectedAccount,
    PaymentsInterface,
    Refund,
    SupportMode,
    WebhookDelivery,
    sign,
    verify_signature,
)
from acme.integrations.twin import TWIN_PROVENANCE, refuse_outside_local


def _id(prefix: str, key: str) -> str:
    return f"{prefix}_twin_{hashlib.sha256(key.encode()).hexdigest()[:24]}"


class PaymentsTwinImpl(PaymentsInterface):
    def __init__(self, environment: str, signing_secret: str) -> None:
        refuse_outside_local(environment, "payments")
        self._secret = signing_secret
        self.checkouts: dict[str, dict[str, object]] = {}
        self.cancelled: set[str] = set()

    async def create_checkout(
        self,
        *,
        connected_account_id: str,
        amount_minor: int,
        currency: str,
        mode: SupportMode,
        platform_fee_minor: int,
        success_url: str,
        cancel_url: str,
        reference: str,
        idempotency_key: str,
    ) -> Checkout:
        session_id = _id("cs", idempotency_key)  # the same key answers the same session, as the provider does
        self.checkouts.setdefault(
            session_id,
            {"account": connected_account_id, "amount": amount_minor, "fee": platform_fee_minor, "mode": mode.value},
        )
        return Checkout(session_id=session_id, url=f"{success_url}?session_id={session_id}", provenance=TWIN_PROVENANCE)

    async def create_connected_account(self, *, email: str, country: str, idempotency_key: str) -> ConnectedAccount:
        return ConnectedAccount(account_id=_id("acct", idempotency_key), provenance=TWIN_PROVENANCE)

    async def onboarding_link(self, account_id: str, refresh_url: str, return_url: str) -> str:
        return f"{return_url}?account={account_id}&twin=1"

    async def cancel_subscription(self, subscription_id: str, *, idempotency_key: str) -> str:
        self.cancelled.add(subscription_id)
        return "active"  # the provider keeps it active until the period already paid ends

    async def refund(self, *, payment_intent_id: str, amount_minor: int | None, idempotency_key: str) -> Refund:
        return Refund(refund_id=_id("re", idempotency_key), status="succeeded", provenance=TWIN_PROVENANCE)

    def synthetic_delivery(self, event_type: str, data: dict[str, object]) -> tuple[bytes, str]:
        """A delivery as the provider would send it: the body and its signature header."""
        body = json.dumps(
            {"id": _id("evt", json.dumps([event_type, data], sort_keys=True)), "type": event_type, "data": data}
        )
        payload = body.encode()
        return payload, sign(payload, self._secret, int(time.time()))

    def verify_webhook(self, payload: bytes, signature_header: str) -> WebhookDelivery:
        verify_signature(payload, signature_header, self._secret)
        event = json.loads(payload)
        return WebhookDelivery(delivery_id=str(event["id"]), type=str(event["type"]), data=dict(event.get("data", {})))

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return "payments: twin"
