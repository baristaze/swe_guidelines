"""The SMS twin: messages kept in memory, one per idempotency key."""

import hashlib

from acme.integrations.sms import OutboundSms, SmsDelivery, SmsInterface
from acme.integrations.twin import TWIN_PROVENANCE, refuse_outside_local


class SmsTwinImpl(SmsInterface):
    def __init__(self, environment: str) -> None:
        refuse_outside_local(environment, "sms")
        self.sent: dict[str, OutboundSms] = {}

    async def send(self, message: OutboundSms) -> SmsDelivery:
        self.sent.setdefault(message.idempotency_key, message)
        return SmsDelivery(
            message_id="SMtwin" + hashlib.sha256(message.idempotency_key.encode()).hexdigest()[:26],
            provenance=TWIN_PROVENANCE,
        )

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return "sms: twin"
