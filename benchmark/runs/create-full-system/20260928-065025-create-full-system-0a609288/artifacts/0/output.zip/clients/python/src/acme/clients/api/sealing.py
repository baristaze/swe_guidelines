"""The device's side of the envelope: what a source's and a journalist's client do so the platform never sees a key
or a plaintext (ADR 0004).

A report is sealed once under a fresh 256-bit key (AES-256-GCM); that key is wrapped separately for each recipient's
public key (ECDH on P-256, an ephemeral key per wrap, HKDF-SHA256, AES-256-GCM). Every value on the wire is base64.
The same scheme runs in a browser under WebCrypto, which offers each of these primitives.
"""

import base64
import contextlib
import json
import os
from dataclasses import dataclass

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

ALGORITHM = "p256-hkdf-sha256-aesgcm-v1"
_WRAP_INFO = b"free-journalism key wrap v1"
_NONCE = 12
_POINT = 65  # an uncompressed P-256 point, as WebCrypto exports a raw public key


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def _unb64(text: str) -> bytes:
    return base64.b64decode(text.encode())


@dataclass(frozen=True)
class KeyPair:
    """A device's key pair. The private half never leaves the device; `public_key` is what the platform stores."""

    private_key: ec.EllipticCurvePrivateKey

    @property
    def public_key(self) -> str:
        raw = self.private_key.public_key().public_bytes(
            serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint
        )
        return _b64(raw)


def generate_key_pair() -> KeyPair:
    return KeyPair(ec.generate_private_key(ec.SECP256R1()))


def new_reply_secret() -> str:
    """The secret a source's device keeps to follow up; the platform stores only its digest."""
    return base64.urlsafe_b64encode(os.urandom(32)).decode().rstrip("=")


def _derive(shared: bytes) -> bytes:
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=_WRAP_INFO).derive(shared)


def wrap_key(key: bytes, recipient_public_key: str) -> str:
    """The report's key, readable only with the recipient's private key."""
    recipient = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), _unb64(recipient_public_key))
    ephemeral = ec.generate_private_key(ec.SECP256R1())
    kek = _derive(ephemeral.exchange(ec.ECDH(), recipient))
    nonce = os.urandom(_NONCE)
    point = ephemeral.public_key().public_bytes(
        serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint
    )
    return _b64(point + nonce + AESGCM(kek).encrypt(nonce, key, None))


def unwrap_key(wrapped: str, keys: KeyPair) -> bytes:
    """Raises InvalidTag when the key was wrapped for someone else."""
    raw = _unb64(wrapped)
    point, nonce, sealed = raw[:_POINT], raw[_POINT : _POINT + _NONCE], raw[_POINT + _NONCE :]
    ephemeral = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(), point)
    kek = _derive(keys.private_key.exchange(ec.ECDH(), ephemeral))
    return AESGCM(kek).decrypt(nonce, sealed, None)


def seal(plaintext: bytes, key: bytes) -> str:
    nonce = os.urandom(_NONCE)
    return _b64(nonce + AESGCM(key).encrypt(nonce, plaintext, None))


def open_sealed(ciphertext: str, key: bytes) -> bytes:
    raw = _unb64(ciphertext)
    return AESGCM(key).decrypt(raw[:_NONCE], raw[_NONCE:], None)


@dataclass(frozen=True)
class SealedReport:
    """One ciphertext for every recipient, and one wrapped key per recipient public key, in the order given."""

    ciphertext: str
    wrapped_keys: tuple[str, ...]
    algorithm: str = ALGORITHM


def seal_report(report: dict[str, object], recipient_public_keys: list[str]) -> SealedReport:
    """The whole report (subject, description, tags, place, time, attachments) sealed once under a fresh key."""
    key = AESGCM.generate_key(bit_length=256)
    ciphertext = seal(json.dumps(report).encode(), key)
    return SealedReport(ciphertext=ciphertext, wrapped_keys=tuple(wrap_key(key, pk) for pk in recipient_public_keys))


def open_report(ciphertext: str, wrapped_key: str, keys: KeyPair) -> dict[str, object]:
    return json.loads(open_sealed(ciphertext, unwrap_key(wrapped_key, keys)))


def seal_message(text: str, recipient_public_keys: list[str]) -> str:
    """A thread message: sealed under its own key, wrapped for each reader (the other party, and the writer's own
    side so it can read back what it wrote)."""
    key = AESGCM.generate_key(bit_length=256)
    body = {"c": seal(text.encode(), key), "k": [wrap_key(key, pk) for pk in recipient_public_keys]}
    return _b64(json.dumps(body).encode())


def open_message(sealed_body: str, keys: KeyPair) -> str:
    """Tries each wrapped key; raises ValueError when none is this reader's."""
    body = json.loads(_unb64(sealed_body))
    for wrapped in body["k"]:
        with contextlib.suppress(InvalidTag):  # this wrap is someone else's
            return open_sealed(body["c"], unwrap_key(wrapped, keys)).decode()
    raise ValueError("this message was not sealed for these keys")
