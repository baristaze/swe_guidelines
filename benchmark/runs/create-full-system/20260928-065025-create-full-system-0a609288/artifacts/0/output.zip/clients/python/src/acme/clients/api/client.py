"""The client: every operation of the API over one transport, built from constructor arguments alone."""

from dataclasses import dataclass

import httpx

from acme.clients.api.generated.operations import Operations
from acme.clients.api.transport import RetryPolicy, Transport


@dataclass(frozen=True)
class ClientConfig:
    """Everything a client needs, handed in by its caller; nothing is read from the environment."""

    base_url: str
    timeout: float
    app_type: str = "cli"
    app_version: str = "client@0.1.0"
    retry: RetryPolicy = RetryPolicy()  # noqa: RUF009 - a frozen value


class ApiClient(Operations):
    def __init__(
        self, config: ClientConfig, credential: str | None = None, transport: httpx.AsyncBaseTransport | None = None
    ) -> None:
        self.config = config
        self._mock = transport
        super().__init__(
            Transport(
                config.base_url,
                credential,
                config.timeout,
                app_type=config.app_type,
                app_version=config.app_version,
                retry=config.retry,
                transport=transport,
            )
        )

    def with_bearer(self, credential: str) -> ApiClient:
        """A client with the same settings and another credential (the session a sign-in was exchanged for)."""
        return ApiClient(self.config, credential, self._mock)

    async def aclose(self) -> None:
        await self._transport.aclose()

    async def __aenter__(self) -> ApiClient:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()
