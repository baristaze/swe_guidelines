"""Generated from the OpenAPI document by clients/python/generate.py. Do not edit."""
