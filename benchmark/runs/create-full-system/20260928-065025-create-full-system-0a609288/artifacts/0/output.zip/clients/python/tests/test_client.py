"""The client over a stubbed transport: the headers it sends, the error it raises, and the retry it owns."""

import json

import httpx
import pytest

from acme.clients.api import ApiClient, ApiError, ClientConfig, RetryPolicy, models

CONFIG = ClientConfig(base_url="http://api.test", timeout=5.0, retry=RetryPolicy(attempts=3, base_delay=0.0))


async def test_a_creating_call_sends_one_idempotency_key_across_its_retries() -> None:
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        if len(seen) == 1:
            return httpx.Response(503, json={"error": {"code": "unavailable", "message": "busy", "request_id": "r1"}})
        return httpx.Response(
            201,
            json={
                "id": "0199f2d1-8a8b-7c1e-9b5a-2f6f1c1e4a10",
                "name": "ci",
                "role": "member",
                "expires_at": "2026-10-01T00:00:00Z",
            },
        )

    client = ApiClient(CONFIG, "fjs_token", httpx.MockTransport(handler))
    key = await client.tenancy_create_api_key(models.AddApiKeyRequest(name="ci", role="member"))
    await client.aclose()
    assert key.name == "ci" and len(seen) == 2
    assert seen[0].headers["idempotency-key"] == seen[1].headers["idempotency-key"]
    assert seen[0].headers["authorization"] == "Bearer fjs_token" and seen[0].headers["x-app-type"] == "cli"
    assert json.loads(seen[0].content) == {"name": "ci", "role": "member"}


async def test_a_refusal_raises_the_envelope_with_its_request_id() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, json={"error": {"code": "not_authorized", "message": "no", "request_id": "r2"}})

    client = ApiClient(CONFIG, "fjs_token", httpx.MockTransport(handler))
    with pytest.raises(ApiError) as refused:
        await client.tenancy_get_org()
    await client.aclose()
    assert (refused.value.status, refused.value.code, refused.value.request_id) == (403, "not_authorized", "r2")


async def test_a_refusal_is_never_retried() -> None:
    calls: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(1)
        return httpx.Response(409, json={"error": {"code": "conflict", "message": "taken", "request_id": "r3"}})

    client = ApiClient(CONFIG, None, httpx.MockTransport(handler))
    with pytest.raises(ApiError):
        await client.tenancy_sign_up(
            models.SignUpRequest(
                email="a@acme.example", password="pswd_1234", display_name="A", org_name="D", org_slug="dd"
            )
        )
    await client.aclose()
    assert len(calls) == 1
