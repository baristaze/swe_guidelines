"""Generates the typed client from the committed OpenAPI document: the models and one method per operation.

    uv run python clients/python/generate.py services/api/openapi.json

The output lives under src/acme/clients/api/generated/ and is never edited by hand.
"""

import json
import keyword
import re
import sys
from pathlib import Path
from typing import Any

OUT = Path(__file__).parent / "src" / "acme" / "clients" / "api" / "generated"
HEADER = '"""Generated from the OpenAPI document by clients/python/generate.py. Do not edit."""\n\n'


def ref_name(ref: str) -> str:
    return ref.rsplit("/", 1)[1]


def py_type(schema: dict[str, Any]) -> str:
    if "$ref" in schema:
        return ref_name(schema["$ref"])
    if "anyOf" in schema:
        parts = [py_type(s) for s in schema["anyOf"]]
        return " | ".join(dict.fromkeys(parts))
    if "enum" in schema:
        return "Literal[" + ", ".join(json.dumps(v) for v in schema["enum"]) + "]"
    kind = schema.get("type")
    if kind == "string":
        return {"uuid": "UUID", "date-time": "datetime"}.get(schema.get("format", ""), "str")
    if kind == "integer":
        return "int"
    if kind == "number":
        return "float"
    if kind == "boolean":
        return "bool"
    if kind == "null":
        return "None"
    if kind == "array":
        return f"list[{py_type(schema.get('items', {}))}]"
    return "Any"


def field_name(name: str) -> str:
    return f"{name}_" if keyword.iskeyword(name) else name


def models(schemas: dict[str, Any]) -> str:
    out = [
        HEADER,
        "from datetime import datetime\nfrom typing import Any, Literal\nfrom uuid import UUID\n\n",
        "from pydantic import BaseModel, ConfigDict\n\n",
    ]
    for name, schema in sorted(schemas.items()):
        if "enum" in schema:
            out.append(f"\n{name} = {py_type(schema)}\n")
            continue
        out.append(f'\n\nclass {name}(BaseModel):\n    model_config = ConfigDict(extra="ignore")\n\n')
        required = set(schema.get("required", []))
        props = schema.get("properties", {})
        if not props:
            out.append("    pass\n")
        for prop, sub in props.items():
            annotation = py_type(sub)
            if prop in required:
                out.append(f"    {field_name(prop)}: {annotation}\n")
            else:
                optional = annotation if "None" in annotation else f"{annotation} | None"
                out.append(f"    {field_name(prop)}: {optional} = None\n")
    return "".join(out)


def snake(name: str) -> str:
    return re.sub(r"[^0-9a-zA-Z_]", "_", name)


def response_type(operation: dict[str, Any]) -> tuple[str, str | None]:
    for status in ("200", "201"):
        content = operation.get("responses", {}).get(status, {}).get("content", {})
        schema = content.get("application/json", {}).get("schema")
        if schema is not None:
            if schema.get("type") == "array":
                return f"list[{py_type(schema['items'])}]", py_type(schema["items"])
            return py_type(schema), None
    return "None", None


def qualified(annotation: str, names: set[str]) -> str:
    """Model names in an operation's signature are read from the models module."""
    return re.sub(
        r"\b([A-Za-z_][A-Za-z0-9_]*)\b", lambda x: f"m.{x.group(1)}" if x.group(1) in names else x.group(1), annotation
    )


def operations(document: dict[str, Any]) -> str:
    names = set(document["components"]["schemas"])
    out = [
        HEADER,
        "from uuid import UUID\n\n",
        "from acme.clients.api.generated import models as m\n",
        "from acme.clients.api.transport import Transport\n\n\nclass Operations:\n",
        '    """One method per operation of the API, named by its operation id."""\n\n',
        "    def __init__(self, transport: Transport) -> None:\n        self._transport = transport\n",
    ]
    for path, item in sorted(document["paths"].items()):
        for method, operation in sorted(item.items()):
            name = snake(operation["operationId"])
            args: list[str] = ["self"]
            params: list[str] = []
            path_expr = path
            for p in operation.get("parameters", []):
                pname = field_name(p["name"])
                annotation = qualified(py_type(p.get("schema", {})), names)
                if p["in"] == "path":
                    args.append(f"{pname}: {annotation}")
                    path_expr = path_expr.replace("{" + p["name"] + "}", "{" + pname + "}")
                elif p["in"] == "query":
                    default = p.get("schema", {}).get("default")
                    params.append(f'"{p["name"]}": {pname}')
                    args.append(f"{pname}: {annotation} | None = {default!r}")
            body = operation.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema")
            if body is not None:
                args.insert(1 + sum(1 for a in args[1:] if "=" not in a), f"body: {qualified(py_type(body), names)}")
            creating = method == "post" and "201" in operation.get("responses", {})
            if creating:
                args.append("idempotency_key: str | None = None")
            returns, item_type = response_type(operation)
            returns = qualified(returns, names)
            item_type = None if item_type is None else qualified(item_type, names)
            ordered = [a for a in args if "=" not in a] + [a for a in args if "=" in a]
            out.append(f"\n    async def {name}({', '.join(ordered)}) -> {returns}:\n")
            summary = (operation.get("summary") or name).replace('"', "'")
            out.append(f'        """{method.upper()} {path}: {summary}."""\n')
            call = [f'"{method.upper()}"', f'f"{path_expr}"']
            if params:
                call.append("params={" + ", ".join(params) + "}")
            if body is not None:
                call.append('body=body.model_dump(mode="json", exclude_unset=True)')
            if creating:
                call.append("creating=True")
                call.append("idempotency_key=idempotency_key")
            out.append(f"        answer = await self._transport.request({', '.join(call)})\n")
            if returns == "None":
                out.append("        del answer\n")
            elif item_type is not None:
                out.append(f"        return [{item_type}.model_validate(x) for x in answer]\n")
            else:
                out.append(f"        return {returns}.model_validate(answer)\n")
    return "".join(out)


def main() -> int:
    document = json.loads(Path(sys.argv[1]).read_text())
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "__init__.py").write_text(HEADER.strip() + "\n")
    (OUT / "models.py").write_text(models(document["components"]["schemas"]))
    (OUT / "operations.py").write_text(operations(document))
    print(f"generated the client from {sys.argv[1]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
