"""The device's envelope: one ciphertext opens for each recipient, and for nobody else."""

import pytest
from cryptography.exceptions import InvalidTag

from acme.clients.api import sealing


def test_each_recipient_opens_the_one_ciphertext_with_their_own_key() -> None:
    a, b, stranger = sealing.generate_key_pair(), sealing.generate_key_pair(), sealing.generate_key_pair()
    report = {"subject": "Water", "description": "The river turned brown", "tags": ["water"]}
    sealed = sealing.seal_report(report, [a.public_key, b.public_key])
    assert sealed.algorithm == sealing.ALGORITHM and len(sealed.wrapped_keys) == 2
    assert "river" not in sealed.ciphertext
    assert sealing.open_report(sealed.ciphertext, sealed.wrapped_keys[0], a) == report
    assert sealing.open_report(sealed.ciphertext, sealed.wrapped_keys[1], b) == report
    with pytest.raises(InvalidTag):  # one journalist's key never opens another's wrap
        sealing.open_report(sealed.ciphertext, sealed.wrapped_keys[1], a)
    with pytest.raises(InvalidTag):
        sealing.open_report(sealed.ciphertext, sealed.wrapped_keys[0], stranger)


def test_a_message_opens_for_each_party_it_was_sealed_for() -> None:
    source, desk, stranger = sealing.generate_key_pair(), sealing.generate_key_pair(), sealing.generate_key_pair()
    body = sealing.seal_message("Can you send the photo?", [source.public_key, desk.public_key])
    assert sealing.open_message(body, source) == sealing.open_message(body, desk) == "Can you send the photo?"
    with pytest.raises(ValueError, match="not sealed for these keys"):
        sealing.open_message(body, stranger)


def test_a_reply_secret_is_long_and_fresh() -> None:
    first, second = sealing.new_reply_secret(), sealing.new_reply_secret()
    assert len(first) >= 43 and first != second
