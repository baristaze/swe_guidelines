"""The one transport: the credential, the app header, the timeout on every call, the error envelope as a typed
error carrying the request id, an Idempotency-Key on every creating call, and the one retry of the call chain."""

import asyncio
import random
import ssl
import uuid
from dataclasses import dataclass
from typing import Any

import httpx
import truststore

RETRIED_STATUSES = frozenset({502, 503, 504})


class ApiError(Exception):
    """A refusal or a failure the API answered with its error envelope."""

    def __init__(self, status: int, code: str, message: str, request_id: str | None) -> None:
        super().__init__(f"{status} {code}: {message} (request {request_id})")
        self.status = status
        self.code = code
        self.message = message
        self.request_id = request_id


@dataclass(frozen=True)
class RetryPolicy:
    """Only a failure that can differ on a second attempt is retried: a timeout, a refused connection, an
    unavailable answer. Bounded in count, spaced by a delay that grows and carries jitter."""

    attempts: int = 3
    base_delay: float = 0.2
    max_delay: float = 2.0


class Transport:
    def __init__(
        self,
        base_url: str,
        credential: str | None,
        timeout: float,
        *,
        app_type: str = "cli",
        app_version: str = "client@0.1.0",
        retry: RetryPolicy = RetryPolicy(),
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._retry = retry
        headers = {"x-app-type": app_type, "x-app-version": app_version}
        if credential:
            headers["authorization"] = f"Bearer {credential}"
        self._http = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            headers=headers,
            transport=transport,
            verify=truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT),
        )

    async def aclose(self) -> None:
        await self._http.aclose()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        body: Any = None,
        creating: bool = False,
        idempotency_key: str | None = None,
    ) -> Any:
        headers: dict[str, str] = {}
        if creating:
            # Minted once per create and sent unchanged on each retry, so a retried create is stored once.
            headers["idempotency-key"] = idempotency_key or str(uuid.uuid4())
        query = {k: v for k, v in (params or {}).items() if v is not None}
        attempt = 0
        while True:
            attempt += 1
            try:
                response = await self._http.request(method, path, params=query, json=body, headers=headers)
            except httpx.TimeoutException, httpx.ConnectError:
                if attempt >= self._retry.attempts:
                    raise
                await self._pause(attempt)
                continue
            if response.status_code in RETRIED_STATUSES and attempt < self._retry.attempts:
                await self._pause(attempt)
                continue
            return self._answer(response)

    async def _pause(self, attempt: int) -> None:
        delay = min(self._retry.max_delay, self._retry.base_delay * 2 ** (attempt - 1))
        await asyncio.sleep(delay * (0.5 + random.random() / 2))

    @staticmethod
    def _answer(response: httpx.Response) -> Any:
        if response.status_code >= 400:
            try:
                error = response.json()["error"]
            except ValueError, KeyError, TypeError:
                raise ApiError(response.status_code, "http_error", response.text[:200], None) from None
            raise ApiError(response.status_code, error["code"], error["message"], error.get("request_id"))
        if response.status_code == 204 or not response.content:
            return None
        return response.json()
