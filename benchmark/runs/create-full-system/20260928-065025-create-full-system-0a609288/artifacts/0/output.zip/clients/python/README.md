# The Python client

`acme-client`, the one typed client of the API for every Python consumer (the ops tool, a remote service impl).
It is generated from the API's committed OpenAPI document (`services/api/openapi.json`) by `generate.py`, which
`make openapi` runs; `src/acme/clients/api/generated/` is never edited by hand. The transport around it is
hand-written: the credential, the app header, a timeout on every call, the error envelope as `ApiError` with the
request id, an `Idempotency-Key` on every creating call, and the one retry of the call chain.
