"""Generated from the OpenAPI document by clients/python/generate.py. Do not edit."""

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict



class AddApiKeyRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_in: int | None = None
    name: str
    role: Role


class AddFollowRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    desk_id: UUID
    journalist_id: UUID


class AddJournalistRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    bio: str | None = None
    display_name: str
    public_key: str | None = None
    published: bool | None = None


class AddMemberRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    display_name: str
    email: str
    password: str | None = None
    role: Role


class AddMessageRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    direction: MessageDirection
    sealed_body: str


class AddOperatorTokenRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_in: int | None = None
    permission: OperatorPermission


class AddOrgRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    slug: str


class AddPledgeRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    amount_minor: int
    currency: str
    desk_id: UUID
    journalist_id: UUID
    mode: SupportMode
    supporter_name: str | None = None


class AddUpdateRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    body: str
    journalist_id: UUID


class AdminEventView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    actor_id: UUID
    app_type: AppType
    app_version: str
    kind: str
    request_id: UUID
    seq: int
    target_id: UUID


class AdminMemberView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    identity_id: UUID
    name: str
    role: Role
    user_id: UUID


class AdminOrgView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    deleted_at: datetime | None = None
    id: UUID
    name: str
    slug: str


class ApiKeyView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    expires_at: datetime
    id: UUID
    name: str
    revoked_at: datetime | None = None
    role: Role

AppType = Literal["portal", "admin", "cli", "api", "worker", "ops", "bootstrap"]


class ConfirmTotpRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    totp_code: str


class ContributionView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    amount_minor: int
    currency: str
    id: UUID
    journalist_id: UUID
    mode: SupportMode
    platform_fee_minor: int
    pledge_id: UUID
    received_at: datetime
    supporter_name: str


class DeliveryReceivedView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    received: bool


class ErrorBody(BaseModel):
    model_config = ConfigDict(extra="ignore")

    code: str
    message: str
    request_id: str


class ErrorResponse(BaseModel):
    model_config = ConfigDict(extra="ignore")

    error: ErrorBody


class EventView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    actor_id: UUID
    kind: str
    seq: int
    target_id: UUID
    version: int | None = None


class ExchangeRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    org_id: UUID


class ExternalSignInRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    code: str | None = None
    redirect_uri: str | None = None
    token: str | None = None


class FeedItemView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    body: str
    created_at: datetime
    desk_id: UUID
    id: UUID
    journalist_id: UUID
    journalist_name: str


class FollowView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    desk_id: UUID
    id: UUID
    journalist_id: UUID


class IssuedApiKeyView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    id: UUID
    name: str
    role: Role
    token: str | None = None


class IssuedOperatorTokenView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    id: UUID
    permission: OperatorPermission
    token: str | None = None


class IssuedSessionView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    token: str


class IssuedSignInView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    memberships: list[MembershipChoiceView]
    token: str


class JournalistView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    bio: str
    created_at: datetime
    display_name: str
    id: UUID
    payouts_ready: bool
    public_key: str | None
    published: bool
    updated_at: datetime


class MemberView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str
    role: Role
    user_id: UUID


class MembershipChoiceView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    org_id: UUID
    org_name: str
    org_slug: str
    role: Role


class MembershipView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    role: Role
    user_id: UUID

MessageDirection = Literal["to_source", "from_source", "note"]


class MessageView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    author_user_id: UUID | None
    created_at: datetime
    direction: MessageDirection
    id: UUID
    sealed_body: str
    submission_id: UUID


class OpenedSubmissionView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    algorithm: str
    ciphertext: str
    source_public_key: str
    submission: SubmissionView
    wrapped_key: str

OperatorPermission = Literal["read", "write", "enrol"]


class OperatorView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    email: str
    identity_id: UUID
    operator_role: OperatorPermission
    permissions: list[OperatorPermission]


class OrgView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    slug: str


class PayoutOnboardingView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    url: str

PledgeStatus = Literal["pending", "paid", "active", "cancelled"]


class PledgeView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    amount_minor: int
    created_at: datetime
    currency: str
    desk_id: UUID
    id: UUID
    journalist_id: UUID
    mode: SupportMode
    platform_fee_minor: int
    settled_at: datetime | None
    status: PledgeStatus
    supporter_name: str
    updated_at: datetime


class PublishedJournalistView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    accepts_support: bool
    bio: str
    desk_id: UUID
    display_name: str
    id: UUID
    public_key: str | None


class RealtimeTicketView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    expires_at: datetime
    ticket: str | None = None


class RecipientRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    desk_id: UUID
    journalist_id: UUID
    submission_id: UUID
    wrapped_key: str

Role = Literal["owner", "admin", "member", "viewer", "service"]


class SignInRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    email: str
    password: str
    totp_code: str | None = None


class SignUpRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    display_name: str
    email: str
    org_name: str
    org_slug: str
    password: str


class SizeView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    events_last_day: int
    tenants: int
    users: int


class SourceMessageRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    sealed_body: str


class SourceThreadView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    algorithm: str
    ciphertext: str
    messages: list[MessageView]
    state: SubmissionState
    submission_id: UUID


class StartPayoutsRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    country: str


class StartedPledgeView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    checkout_url: str
    pledge: PledgeView


class SubmissionReceiptView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    desk_id: UUID
    submission_id: UUID

SubmissionState = Literal["new", "reviewing", "follow-up", "useful", "archived"]


class SubmissionView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    created_at: datetime
    has_contact: bool
    id: UUID
    journalist_id: UUID
    report_id: UUID
    sender_name: str | None
    state: SubmissionState
    tags: list[str]
    updated_at: datetime


class SubmitReportRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    algorithm: str
    ciphertext: str
    contact_email: str | None = None
    recipients: list[RecipientRequest]
    reply_secret: str
    report_id: UUID
    source_public_key: str

SupportMode = Literal["one_time", "monthly"]


class TotpEnrolmentView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    otpauth_uri: str


class UpdateJournalistRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    bio: str | None = None
    display_name: str | None = None
    public_key: str | None = None
    published: bool | None = None


class UpdateMemberRoleRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    role: Role


class UpdateSubmissionRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    state: SubmissionState | None = None
    tags: list[str] | None = None


class UpdateUserRequest(BaseModel):
    model_config = ConfigDict(extra="ignore")

    name: str | None = None


class UpdateView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    body: str
    created_at: datetime
    id: UUID
    journalist_id: UUID


class UserView(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
