// The API keys domain.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, isApiError, type AddApiKeyRequest, type ApiKeyView } from "../api";
import { placeInLists } from "./cache";
import { keys, PAGE_SIZE } from "./keys";

export const apiKeysCache = {
  place(queryClient: QueryClient, view: ApiKeyView): void {
    placeInLists(queryClient, keys.apiKeys.lists(), view, () => true);
  },
  /** A revoke keeps the row, stamped, as the list answers it. */
  markRevoked(queryClient: QueryClient, id: string, at: string): void {
    queryClient.setQueriesData<ApiKeyView[]>({ queryKey: keys.apiKeys.lists() }, (page) =>
      page?.map((key) => (key.id === id && !key.revoked_at ? { ...key, revoked_at: at } : key)),
    );
  },
  /** There is no read of one key: a hint re-reads the loaded pages. */
  reread(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.apiKeys.all }).catch(() => {});
  },
};

export function useApiKeys(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.apiKeys.list(limit), queryFn: () => api.apiKeys.list(limit) });
}

export function useCreateApiKey() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: AddApiKeyRequest) => api.apiKeys.create(body),
    onSuccess: (issued) => {
      const { token: _token, ...row } = issued;
      void _token; // shown once by the screen, never cached
      apiKeysCache.place(queryClient, { ...row, created_at: new Date().toISOString(), revoked_at: null });
    },
  });
}

export function useRevokeApiKey() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      try {
        await api.apiKeys.revoke(id);
      } catch (error) {
        if (!(isApiError(error) && error.status === 404)) throw error;
      }
      return id;
    },
    onSuccess: (id) => apiKeysCache.markRevoked(queryClient, id, new Date().toISOString()),
  });
}
