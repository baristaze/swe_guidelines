import { describe, expect, it } from "vitest";
import { ApiError, type MembershipChoiceView } from "../../api";
import { canSubmit, EMPTY_FORM, nextStep, signInErrorText, slugFromName, toLoginRequest, toSignUpRequest } from "./signInModel";

const desk = (name: string): MembershipChoiceView => ({ org_id: `id-${name}`, org_name: name, org_slug: name.toLowerCase(), role: "owner" });

describe("sign-in model", () => {
  it("goes straight in with one desk, shows the picker with several, and says so with none", () => {
    expect(nextStep([])).toEqual({ kind: "none" });
    expect(nextStep([desk("Alpha")])).toEqual({ kind: "enter", membership: desk("Alpha") });
    expect(nextStep([desk("Zeta"), desk("Alpha")])).toEqual({ kind: "choose", memberships: [desk("Alpha"), desk("Zeta")] });
  });

  it("asks for every sign-up field before sending", () => {
    const login = { ...EMPTY_FORM, email: "a@b.c", password: "x" };
    expect(canSubmit("login", login)).toBe(true);
    expect(canSubmit("signup", login)).toBe(false);
    expect(canSubmit("signup", { ...login, displayName: "A", orgName: "Desk", orgSlug: "desk" })).toBe(true);
  });

  it("sends the TOTP code only when one was typed", () => {
    expect(toLoginRequest({ ...EMPTY_FORM, email: " a@b.c ", password: "p" })).toEqual({ email: "a@b.c", password: "p" });
    expect(toLoginRequest({ ...EMPTY_FORM, email: "a@b.c", password: "p", totpCode: "123456" })).toMatchObject({ totp_code: "123456" });
    expect(toSignUpRequest({ ...EMPTY_FORM, email: "a@b.c", password: "p", displayName: " Ada ", orgName: "Desk", orgSlug: "desk" })).toEqual({
      email: "a@b.c",
      password: "p",
      display_name: "Ada",
      org_name: "Desk",
      org_slug: "desk",
    });
  });

  it("suggests a desk address from its name", () => {
    expect(slugFromName("  Café Politique! ")).toBe("cafe-politique");
  });

  it("reads a throttle with its wait, and any other refusal with its request id", () => {
    expect(signInErrorText(new ApiError(429, "rate_limited", "slow down", "r1", 120))).toBe("Too many attempts. Try again in 2 min.");
    expect(signInErrorText(new ApiError(401, "invalid_credentials", "Wrong email or password", "r2", null))).toBe(
      "Wrong email or password (request r2)",
    );
  });
});
