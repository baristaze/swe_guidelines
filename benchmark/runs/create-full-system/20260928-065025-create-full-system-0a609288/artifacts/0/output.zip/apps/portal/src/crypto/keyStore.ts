// The keys this device holds, and only this device: a journalist's private key, keyed by the
// journalist's id, and a source's key pair and reply secret, keyed by the submission. They live in
// IndexedDB as CryptoKey objects whose private half is not extractable, so no script can read the
// key's bytes out, and they never go to the server. Pure code takes the `KeyStore` interface; the
// memory store stands in for tests and for a browser without IndexedDB (which then forgets on reload).

export interface SourceKeys {
  deskId: string;
  journalistId: string;
  privateKey: CryptoKey;
  publicKey: string;
  replySecret: string;
}

export interface KeyStore {
  journalistKey(journalistId: string): Promise<CryptoKey | null>;
  putJournalistKey(journalistId: string, privateKey: CryptoKey): Promise<void>;
  sourceKeys(submissionId: string): Promise<SourceKeys | null>;
  putSourceKeys(submissionId: string, keys: SourceKeys): Promise<void>;
}

export function createMemoryKeyStore(): KeyStore {
  const journalists = new Map<string, CryptoKey>();
  const sources = new Map<string, SourceKeys>();
  return {
    journalistKey: async (id) => journalists.get(id) ?? null,
    putJournalistKey: async (id, key) => void journalists.set(id, key),
    sourceKeys: async (id) => sources.get(id) ?? null,
    putSourceKeys: async (id, keys) => void sources.set(id, keys),
  };
}

const DB_NAME = "acme.portal.keys";
const JOURNALIST = "journalist";
const SOURCE = "source";

function done<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("the key store could not be read"));
  });
}

function openDb(factory: IDBFactory): Promise<IDBDatabase> {
  const request = factory.open(DB_NAME, 1);
  request.onupgradeneeded = () => {
    request.result.createObjectStore(JOURNALIST);
    request.result.createObjectStore(SOURCE);
  };
  return done(request);
}

export function createIndexedDbKeyStore(factory: IDBFactory): KeyStore {
  let db: Promise<IDBDatabase> | null = null;
  const database = () => (db ??= openDb(factory));

  async function get<T>(store: string, key: string): Promise<T | null> {
    const tx = (await database()).transaction(store, "readonly");
    return ((await done(tx.objectStore(store).get(key))) as T | undefined) ?? null;
  }

  async function put(store: string, key: string, value: unknown): Promise<void> {
    const tx = (await database()).transaction(store, "readwrite");
    await done(tx.objectStore(store).put(value, key));
  }

  return {
    journalistKey: (id) => get<CryptoKey>(JOURNALIST, id),
    putJournalistKey: (id, key) => put(JOURNALIST, id, key),
    sourceKeys: (id) => get<SourceKeys>(SOURCE, id),
    putSourceKeys: (id, keys) => put(SOURCE, id, keys),
  };
}

let current: KeyStore | null = null;

/** The device's key store: IndexedDB where the browser has it. */
export function keyStore(): KeyStore {
  current ??= typeof indexedDB === "undefined" ? createMemoryKeyStore() : createIndexedDbKeyStore(indexedDB);
  return current;
}
