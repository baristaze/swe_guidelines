import { describe, expect, it } from "vitest";
import { encodeFrame, parseFrame } from "./envelopes";

describe("parseFrame", () => {
  it("reads every frame the service sends", () => {
    expect(parseFrame('{"type":"hello","head_seq":4}')).toEqual({ type: "hello", head_seq: 4 });
    expect(parseFrame('{"type":"pong","head_seq":5}')).toEqual({ type: "pong", head_seq: 5 });
    expect(parseFrame('{"type":"subscribed","scope":"tenant"}')).toEqual({ type: "subscribed", scope: "tenant" });
    expect(parseFrame('{"type":"unsubscribed","scope":"tenant"}')).toEqual({ type: "unsubscribed", scope: "tenant" });
    expect(parseFrame('{"type":"error","code":"bad_frame","message":"no"}')).toEqual({ type: "error", code: "bad_frame", message: "no" });
    expect(
      parseFrame('{"type":"event","seq":7,"kind":"journalists.journalist.created","target_id":"t","actor_id":"a","version":null}'),
    ).toEqual({ type: "event", seq: 7, kind: "journalists.journalist.created", target_id: "t", actor_id: "a", version: null });
  });

  it("ignores what it does not know", () => {
    expect(parseFrame("not json")).toBeNull();
    expect(parseFrame('{"type":"surprise"}')).toBeNull();
    expect(parseFrame('{"type":"event","seq":"7"}')).toBeNull();
  });

  it("encodes the ping", () => {
    expect(encodeFrame({ type: "ping" })).toBe('{"type":"ping"}');
  });
});
