import { Banner, Button, Muted, Stack } from "../../design/kit";
import { color, font, radius, space } from "../../design/tokens";
import { useOrgChipVm } from "./useOrgChipVm";

export function OrgChip() {
  const vm = useOrgChipVm();
  return (
    <div style={{ position: "relative", display: "flex", alignItems: "center", gap: space.sm }}>
      <button
        type="button"
        onClick={vm.switchable ? vm.toggle : undefined}
        aria-expanded={vm.switchable ? vm.open : undefined}
        style={{
          display: "flex",
          alignItems: "center",
          gap: space.sm,
          padding: `${space.xs}px ${space.md}px ${space.xs}px ${space.xs}px`,
          borderRadius: radius.pill,
          border: `1px solid ${color.line}`,
          background: color.surface,
          fontFamily: font.ui,
          fontSize: font.size.md,
          cursor: vm.switchable ? "pointer" : "default",
        }}
      >
        <span
          aria-hidden
          style={{ width: 28, height: 28, borderRadius: radius.pill, background: color.accent, color: color.accentInk, display: "grid", placeItems: "center", fontSize: font.size.sm }}
        >
          {vm.badge}
        </span>
        {vm.name}
        {vm.switchable && <span aria-hidden>▾</span>}
      </button>
      <Button onClick={vm.signOut} disabled={vm.signingOut}>
        Sign out
      </Button>
      {vm.open && (
        <div
          role="menu"
          style={{ position: "absolute", top: "110%", right: 0, minWidth: 260, background: color.surface, border: `1px solid ${color.line}`, borderRadius: radius.md, padding: space.md, zIndex: 10 }}
        >
          <Stack gap={space.xs}>
            {vm.loading && <Muted>Loading your desks…</Muted>}
            {vm.rows.map((row) => (
              <Button key={row.orgId} role="menuitem" disabled={row.current || vm.switching} onClick={() => vm.switchTo(row.orgId)} style={{ textAlign: "left", border: "none" }}>
                {row.name} <Muted>· {row.role}{row.current ? " · current" : ""}</Muted>
              </Button>
            ))}
            {vm.error && <Banner tone="danger">{vm.error}</Banner>}
          </Stack>
        </div>
      )}
    </div>
  );
}
