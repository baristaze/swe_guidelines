import { describe, expect, it } from "vitest";
import { parseReportContent, parseTags } from "./reportContent";

describe("report content", () => {
  it("reads what a device sealed, whatever it left out", () => {
    expect(parseReportContent({ subject: "S", tags: ["a", 3], occurred_at: "" })).toEqual({
      subject: "S",
      description: "",
      tags: ["a"],
      place: "",
      occurred_at: null,
      attachments: [],
    });
    expect(parseReportContent(null).subject).toBe("");
  });

  it("parses tags as the server normalizes them", () => {
    expect(parseTags(" Water, tender,,water ")).toEqual(["water", "tender"]);
    expect(parseTags("")).toEqual([]);
  });
});
