// The public profile view-model, outside the sign-in gate: a published profile and its updates;
// for a signed-in reader, Follow and Support (which leaves for the processor's checkout); and for
// anyone, "Send information": the report is sealed in this browser for this journalist's public
// key, sent anonymously (or, when a signed-in reader chooses, under their name), and the source's
// own key pair and reply secret are kept on this device to follow up.
import { useState } from "react";
import { useParams } from "react-router";
import { errorText } from "../../app/errorText";
import { newId } from "../../crypto/ids";
import { exportPublicKey, generateKeyPair, newReplySecret, sealReport } from "../../crypto/sealing";
import { useKeepSourceKeys } from "../../queries/device";
import { useFollow, useFollows } from "../../queries/follows";
import { PAGE_SIZE } from "../../queries/keys";
import { usePublishedJournalist, usePublishedUpdates, useSubmitReport } from "../../queries/public";
import { usePledge } from "../../queries/support";
import { useSession } from "../../store/session";
import {
  canSendReport,
  canSupport,
  CURRENCY_OPTIONS,
  EMPTY_REPORT_FORM,
  EMPTY_SUPPORT_FORM,
  followOf,
  followUpLink,
  MODE_OPTIONS,
  publicUpdateRows,
  toAddPledgeRequest,
  toReportContent,
  toSubmitReportRequest,
  type ReportForm,
  type SupportForm,
} from "./publicProfileModel";

export function usePublicProfileVm() {
  const { deskId = "", journalistId = "" } = useParams();
  const signedIn = useSession((s) => s.stage === "tenant");
  const journalist = usePublishedJournalist(deskId, journalistId);
  const updates = usePublishedUpdates(deskId, journalistId);
  const follows = useFollows(PAGE_SIZE, signedIn);
  const follow = useFollow();
  const pledge = usePledge();
  const submit = useSubmitReport();
  const keepSourceKeys = useKeepSourceKeys();

  const [support, setSupport] = useState<SupportForm>(EMPTY_SUPPORT_FORM);
  const [report, setReport] = useState<ReportForm>(EMPTY_REPORT_FORM);
  const [sending, setSending] = useState(false);
  const [sentLink, setSentLink] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [reportError, setReportError] = useState<string | null>(null);
  const onError = (e: unknown) => setError(errorText(e));

  const profile = journalist.data;
  const publicKey = profile?.public_key ?? null;
  const following = followOf(follows.data ?? [], deskId, journalistId);

  const send = async () => {
    if (!publicKey) return;
    setReportError(null);
    setSending(true);
    try {
      const pair = await generateKeyPair();
      const sourcePublicKey = await exportPublicKey(pair.publicKey);
      const replySecret = newReplySecret();
      const sealed = await sealReport(toReportContent(report), [publicKey]);
      const submissionId = newId();
      // Kept before it is sent: a report that lands must never leave its source without the way back.
      await keepSourceKeys(submissionId, { deskId, journalistId, privateKey: pair.privateKey, publicKey: sourcePublicKey, replySecret });
      const body = toSubmitReportRequest({
        reportId: newId(),
        submissionId,
        deskId,
        journalistId,
        sealed,
        sourcePublicKey,
        replySecret,
        contactEmail: report.contactEmail,
      });
      await submit.mutateAsync({ body, named: signedIn && report.named });
      setReport(EMPTY_REPORT_FORM);
      setSentLink(followUpLink(window.location.origin, deskId, submissionId, replySecret));
    } catch (e) {
      setReportError(errorText(e));
    } finally {
      setSending(false);
    }
  };

  return {
    loading: journalist.isPending,
    loadError: journalist.error ? errorText(journalist.error) : null,
    profile: profile && { name: profile.display_name, bio: profile.bio, acceptsSupport: profile.accepts_support },
    updates: publicUpdateRows(updates.data ?? []),
    signedIn,
    error,

    following: following !== undefined,
    canFollow: signedIn && following === undefined && !follow.isPending && !follows.isPending,
    follow: () => {
      setError(null);
      follow.mutate({ desk_id: deskId, journalist_id: journalistId }, { onError });
    },

    currencyOptions: CURRENCY_OPTIONS,
    modeOptions: MODE_OPTIONS,
    support,
    setSupport: <K extends keyof SupportForm>(field: K, value: SupportForm[K]) => setSupport((f) => ({ ...f, [field]: value })),
    canSupport: canSupport(support) && !pledge.isPending,
    startSupport: () => {
      setError(null);
      pledge.mutate(toAddPledgeRequest(deskId, journalistId, support), {
        onSuccess: (started) => window.location.assign(started.checkout_url),
        onError,
      });
    },

    acceptsReports: publicKey !== null,
    report,
    setReport: <K extends keyof ReportForm>(field: K, value: ReportForm[K]) => setReport((f) => ({ ...f, [field]: value })),
    canSend: canSendReport(report) && publicKey !== null && !sending,
    send: () => void send(),
    sending,
    reportError,
    sentLink,
    dismissSent: () => setSentLink(null),
  };
}
