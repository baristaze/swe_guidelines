// The app's configuration, read once from /config.json before the first render. Every value
// that differs between environments lives there, written by scripts/dev.sh locally and by the
// deploy workflow next to the bundle; nothing environment-specific is read from import.meta.env.

export interface AppConfig {
  /** The API's origin, e.g. https://api.example.org; the socket runs on the same origin. */
  apiOrigin: string;
  /** Every call carries this timeout. */
  requestTimeoutMs: number;
  /** The error tracker's DSN; empty means no error tracking. */
  errorTrackingDsn: string | null;
  environment: string;
}

export const DEFAULT_REQUEST_TIMEOUT_MS = 15_000;

export class ConfigError extends Error {}

function str(raw: Record<string, unknown>, name: string): string | null {
  const value = raw[name];
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string") throw new ConfigError(`config.json: ${name} must be a string`);
  return value;
}

export function parseConfig(raw: unknown): AppConfig {
  if (typeof raw !== "object" || raw === null) throw new ConfigError("config.json must be an object");
  const record = raw as Record<string, unknown>;
  const apiOrigin = str(record, "apiOrigin");
  if (apiOrigin === null) throw new ConfigError("config.json: apiOrigin is required");
  const origin = new URL(apiOrigin).origin;
  const timeout = record.requestTimeoutMs;
  let requestTimeoutMs = DEFAULT_REQUEST_TIMEOUT_MS;
  if (timeout !== undefined && timeout !== null && timeout !== "") {
    requestTimeoutMs = Number(timeout);
    if (!Number.isFinite(requestTimeoutMs) || requestTimeoutMs <= 0) {
      throw new ConfigError("config.json: requestTimeoutMs must be a positive number");
    }
  }
  return {
    apiOrigin: origin,
    requestTimeoutMs,
    errorTrackingDsn: str(record, "errorTrackingDsn"),
    environment: str(record, "environment") ?? "unknown",
  };
}

let loaded: AppConfig | null = null;

/** Loads /config.json once; main.tsx awaits it before rendering. */
export async function loadConfig(): Promise<AppConfig> {
  if (loaded) return loaded;
  // The one read that precedes the transport: it is what tells the transport where the API is.
  const response = await fetch("/config.json", { cache: "no-store" });
  if (!response.ok) throw new ConfigError(`config.json: ${response.status}`);
  loaded = parseConfig(await response.json());
  return loaded;
}

export function getConfig(): AppConfig {
  if (!loaded) throw new ConfigError("the config is read before loadConfig");
  return loaded;
}
