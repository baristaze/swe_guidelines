// The socket's frames, a discriminated union on `type`, mirrored by hand from the service's
// services/api/src/acme/services/api/realtime/envelopes.py. Control frames report the socket
// itself; the one stream frame, `event`, is a hint: the identity of a change, never a field of
// the entity.

export interface HelloFrame {
  type: "hello";
  head_seq: number;
}

export interface PongFrame {
  type: "pong";
  head_seq: number;
}

export interface SubscribedFrame {
  type: "subscribed";
  scope: string;
}

export interface UnsubscribedFrame {
  type: "unsubscribed";
  scope: string;
}

export interface ErrorFrame {
  type: "error";
  code: string;
  message: string;
}

export interface EventFrame {
  type: "event";
  seq: number;
  kind: string;
  target_id: string;
  actor_id: string;
  version?: number | null;
}

export type ControlFrame = HelloFrame | PongFrame | SubscribedFrame | UnsubscribedFrame | ErrorFrame;
export type ServerFrame = ControlFrame | EventFrame;

export interface PingFrame {
  type: "ping";
}

/** Only meaningful when the product keeps more than one stream; the tenant stream needs none. */
export interface SubscribeFrame {
  type: "subscribe";
  scope: string;
}

export interface UnsubscribeFrame {
  type: "unsubscribe";
  scope: string;
}

export type ClientFrame = PingFrame | SubscribeFrame | UnsubscribeFrame;

const isInt = (v: unknown): v is number => typeof v === "number" && Number.isInteger(v);
const isStr = (v: unknown): v is string => typeof v === "string";

/** Parses one text frame; anything that is not a known frame is null and is ignored. */
export function parseFrame(data: string): ServerFrame | null {
  let raw: unknown;
  try {
    raw = JSON.parse(data);
  } catch {
    return null;
  }
  if (typeof raw !== "object" || raw === null) return null;
  const f = raw as Record<string, unknown>;
  switch (f.type) {
    case "hello":
    case "pong":
      return isInt(f.head_seq) ? { type: f.type, head_seq: f.head_seq } : null;
    case "subscribed":
    case "unsubscribed":
      return isStr(f.scope) ? { type: f.type, scope: f.scope } : null;
    case "error":
      return isStr(f.code) ? { type: "error", code: f.code, message: isStr(f.message) ? f.message : "" } : null;
    case "event":
      if (!isInt(f.seq) || !isStr(f.kind) || !isStr(f.target_id) || !isStr(f.actor_id)) return null;
      return {
        type: "event",
        seq: f.seq,
        kind: f.kind,
        target_id: f.target_id,
        actor_id: f.actor_id,
        version: isInt(f.version) ? f.version : null,
      };
    default:
      return null;
  }
}

export function encodeFrame(frame: ClientFrame): string {
  return JSON.stringify(frame);
}
