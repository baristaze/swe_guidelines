// The contributions view-model: what readers gave the desk. A settled payment arrives as a hint
// through the realtime router, which re-reads the loaded pages.
import { errorText } from "../../app/errorText";
import { useJournalists } from "../../queries/journalists";
import { useContributions } from "../../queries/support";
import { contributionCountText, contributionRows } from "./contributionsModel";

export function useContributionsVm() {
  const contributions = useContributions();
  const journalists = useJournalists();
  const rows = contributionRows(contributions.data ?? [], journalists.data ?? []);

  return {
    loading: contributions.isPending,
    loadError: contributions.error ? errorText(contributions.error) : null,
    rows,
    countText: contributionCountText(rows.length),
  };
}
