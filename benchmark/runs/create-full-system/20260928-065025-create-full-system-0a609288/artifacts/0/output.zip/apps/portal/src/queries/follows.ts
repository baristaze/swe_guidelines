// The follows domain: the journalists this reader follows, and the feed of their updates.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, isApiError, type AddFollowRequest, type FollowView } from "../api";
import { placeInLists, removeFromLists } from "./cache";
import { keys, PAGE_SIZE } from "./keys";

export const followsCache = {
  place(queryClient: QueryClient, view: FollowView): void {
    placeInLists(queryClient, keys.follows.lists(), view, () => true);
  },
  remove(queryClient: QueryClient, id: string): void {
    removeFromLists<FollowView>(queryClient, keys.follows.lists(), id);
  },
  /** A follow changes what the feed holds: the follows and the feed are read again. */
  reread(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.follows.all }).catch(() => {});
    queryClient.invalidateQueries({ queryKey: keys.feed.all }).catch(() => {});
  },
};

/** `enabled` is false where no reader is signed in, as on a public page. */
export function useFollows(limit = PAGE_SIZE, enabled = true) {
  return useQuery({ queryKey: keys.follows.list(limit), queryFn: () => api.follows.list(limit), enabled });
}

export function useFeed(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.feed.list(limit), queryFn: () => api.follows.feed(limit) });
}

export function useFollow() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: AddFollowRequest) => api.follows.create(body),
    onSuccess: (view) => {
      followsCache.place(queryClient, view);
      queryClient.invalidateQueries({ queryKey: keys.feed.all }).catch(() => {});
    },
  });
}

export function useUnfollow() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      try {
        await api.follows.remove(id);
      } catch (error) {
        // A retried delete whose first attempt landed answers 404: the follow is gone either way.
        if (!(isApiError(error) && error.status === 404)) throw error;
      }
      return id;
    },
    onSuccess: (id) => {
      followsCache.remove(queryClient, id);
      queryClient.invalidateQueries({ queryKey: keys.feed.all }).catch(() => {});
    },
  });
}
