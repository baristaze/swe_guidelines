// Shared cache writes over the key factory: one entity placed into, or removed from, every cached
// page of its collection.
import type { QueryClient, QueryKey } from "@tanstack/react-query";
import { limitOf } from "./keys";
import { place, removeFrom, type Identified } from "./placement";

export function placeInLists<T extends Identified>(
  queryClient: QueryClient,
  listsKey: QueryKey,
  item: T,
  isNewer: (incoming: T, cached: T) => boolean,
): void {
  for (const [queryKey, page] of queryClient.getQueriesData<T[]>({ queryKey: listsKey })) {
    if (!page) continue;
    const placed = place(page, item, limitOf(queryKey), isNewer);
    if (placed.kind === "page") queryClient.setQueryData(queryKey, placed.page);
    else queryClient.invalidateQueries({ queryKey, exact: true }).catch(() => {});
  }
}

export function removeFromLists<T extends Identified>(queryClient: QueryClient, listsKey: QueryKey, id: string): void {
  queryClient.setQueriesData<T[]>({ queryKey: listsKey }, (page) => (page ? removeFrom(page, id) : page));
}
