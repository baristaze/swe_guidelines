import { Link } from "react-router";
import { Banner, Button, Card, cellStyle, Muted, Stack, Table } from "../../design/kit";
import { color, font, space } from "../../design/tokens";
import { useFollowingVm } from "./useFollowingVm";

export function FollowingPage() {
  const vm = useFollowingVm();

  return (
    <Stack gap={24}>
      <Card title="Following" actions={<Muted>{vm.countText}</Muted>}>
        {vm.loading && <Muted>Loading…</Muted>}
        {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
        {!vm.loading && vm.rows.length === 0 && <Muted>Follow a journalist from the link they share.</Muted>}
        {vm.rows.length > 0 && (
          <Table head={["Journalist", "Since", ""]}>
            {vm.rows.map((row) => (
              <tr key={row.id}>
                <td style={cellStyle}>
                  <Link to={row.path}>{row.name}</Link>
                </td>
                <td style={cellStyle}>{row.since}</td>
                <td style={{ ...cellStyle, textAlign: "right" }}>
                  <Button variant="danger" disabled={vm.unfollowing} onClick={() => vm.unfollow(row.id)}>
                    Unfollow
                  </Button>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Card>

      <Card title="Feed">
        {!vm.loading && vm.feed.length === 0 && <Muted>No updates yet.</Muted>}
        {vm.feed.map((item) => (
          <article key={item.id} style={{ borderBottom: `1px solid ${color.line}`, paddingBottom: space.md }}>
            <Muted>
              <Link to={item.path}>{item.name}</Link> · {item.published}
            </Muted>
            <p style={{ margin: `${space.xs}px 0 0`, whiteSpace: "pre-wrap", fontFamily: font.body }}>{item.body}</p>
          </article>
        ))}
      </Card>
    </Stack>
  );
}
