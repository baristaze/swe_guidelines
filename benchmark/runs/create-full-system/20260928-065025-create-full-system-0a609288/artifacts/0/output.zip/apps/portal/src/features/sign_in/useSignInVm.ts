// The sign-in view-model: login or sign-up, then the membership choice, then the exchange for a
// desk's session, after which the sign-in bearer is gone and only the session is held.
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import type { IssuedSignInView, MembershipChoiceView } from "../../api";
import { errorText } from "../../app/errorText";
import { useExchange, useLogin, useSignUp } from "../../queries/auth";
import { useSession } from "../../store/session";
import { dropTenantState } from "../../store/tenant";
import {
  canSubmit,
  EMPTY_FORM,
  needsSecondFactor,
  nextStep,
  signInErrorText,
  slugFromName,
  toLoginRequest,
  toSignUpRequest,
  type Mode,
  type SignInForm,
} from "./signInModel";

export function useSignInVm() {
  const queryClient = useQueryClient();
  const stage = useSession((s) => s.stage);
  const memberships = useSession((s) => s.memberships);
  const signedIn = useSession((s) => s.signedIn);
  const enteredDesk = useSession((s) => s.enteredDesk);
  const clear = useSession((s) => s.clear);
  const login = useLogin();
  const signUp = useSignUp();
  const exchange = useExchange();

  const [mode, setMode] = useState<Mode>("login");
  const [form, setForm] = useState<SignInForm>(EMPTY_FORM);
  const [slugTouched, setSlugTouched] = useState(false);
  const [askTotp, setAskTotp] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const step = stage === "choosing" ? nextStep(memberships) : null;

  const enter = (membership: MembershipChoiceView) => {
    setError(null);
    exchange.mutate(membership.org_id, {
      onSuccess: (session) => {
        dropTenantState(queryClient);
        enteredDesk(session.token, membership);
      },
      onError: (e) => setError(errorText(e)),
    });
  };

  const afterSignIn = (answer: IssuedSignInView) => {
    signedIn(answer);
    setForm(EMPTY_FORM);
    const next = nextStep(answer.memberships);
    if (next.kind === "enter") enter(next.membership);
  };

  const update = (field: keyof SignInForm, value: string) => {
    if (field === "orgSlug") setSlugTouched(true);
    setForm((f) => {
      const changed = { ...f, [field]: value };
      if (field === "orgName" && !slugTouched) changed.orgSlug = slugFromName(value);
      return changed;
    });
  };

  const submit = () => {
    setError(null);
    if (mode === "login") {
      login.mutate(toLoginRequest(form), {
        onSuccess: afterSignIn,
        onError: (e) => {
          if (needsSecondFactor(e)) setAskTotp(true);
          setError(signInErrorText(e));
        },
      });
    } else {
      signUp.mutate(toSignUpRequest(form), { onSuccess: afterSignIn, onError: (e) => setError(signInErrorText(e)) });
    }
  };

  return {
    mode,
    switchMode: () => {
      setMode((m) => (m === "login" ? "signup" : "login"));
      setError(null);
    },
    form,
    update,
    askTotp,
    canSubmit: canSubmit(mode, form) && !login.isPending && !signUp.isPending,
    submit,
    pending: login.isPending || signUp.isPending || exchange.isPending,
    error,
    step,
    enter,
    startOver: () => {
      clear();
      setError(null);
    },
  };
}
