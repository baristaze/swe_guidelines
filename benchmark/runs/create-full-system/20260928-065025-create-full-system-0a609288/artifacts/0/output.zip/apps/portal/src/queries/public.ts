// What anyone reaches by a desk's link, signed in or not: a published profile and its updates, the
// intake a source sends a sealed report through, and the source's side of the thread. None of these
// carries a bearer (the anonymous intake must not name its sender); the named intake does.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api, type SourceMessageRequest, type SourceThreadView, type SubmitReportRequest } from "../api";
import { keys, PAGE_SIZE } from "./keys";

export function usePublishedJournalist(deskId: string, journalistId: string, enabled = true) {
  return useQuery({
    queryKey: keys.publishedJournalists.detail(deskId, journalistId),
    queryFn: () => api.public.journalist(deskId, journalistId),
    enabled,
  });
}

export function usePublishedUpdates(deskId: string, journalistId: string, limit = PAGE_SIZE) {
  return useQuery({
    queryKey: keys.publishedUpdates.list(deskId, journalistId, limit),
    queryFn: () => api.public.updates(deskId, journalistId, limit),
  });
}

/** Sends a sealed report: anonymously through the public intake, or under the reader's name. */
export function useSubmitReport() {
  return useMutation({
    mutationFn: ({ body, named }: { body: SubmitReportRequest; named: boolean }) =>
      named ? api.reports.submitNamed(body) : api.public.submit(body),
  });
}

export function useSourceThread(deskId: string, submissionId: string, replySecret: string | null) {
  return useQuery({
    queryKey: keys.sourceThreads.detail(deskId, submissionId),
    queryFn: () => api.public.thread(deskId, submissionId, replySecret ?? ""),
    enabled: replySecret !== null,
  });
}

export function useAnswerSource() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (args: { deskId: string; submissionId: string; replySecret: string; body: SourceMessageRequest }) =>
      api.public.answer(args.deskId, args.submissionId, args.replySecret, args.body),
    onSuccess: (message, args) =>
      queryClient.setQueryData<SourceThreadView>(keys.sourceThreads.detail(args.deskId, args.submissionId), (thread) =>
        thread && !thread.messages.some((m) => m.id === message.id) ? { ...thread, messages: [...thread.messages, message] } : thread,
      ),
  });
}
