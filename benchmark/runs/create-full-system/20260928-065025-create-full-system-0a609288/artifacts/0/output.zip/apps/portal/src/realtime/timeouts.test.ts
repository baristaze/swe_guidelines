import { describe, expect, it } from "vitest";
import shared from "../../../../deployment/realtime-timeouts.json";
import { PING_INTERVAL_SECONDS, reconnectDelay, RECONNECT_MAX_MS } from "./timeouts";

describe("the shared timeouts file", () => {
  it("is where the ping interval comes from", () => {
    expect(PING_INTERVAL_SECONDS).toBe(shared.ping_interval_seconds);
  });

  it("puts the ping inside the load balancer's idle timeout, with room for one lost ping", () => {
    expect(PING_INTERVAL_SECONDS).toBeGreaterThan(0);
    expect(PING_INTERVAL_SECONDS).toBeLessThan(shared.idle_timeout_seconds);
    expect(PING_INTERVAL_SECONDS * 2).toBeLessThanOrEqual(shared.idle_timeout_seconds);
  });
});

describe("reconnectDelay", () => {
  it("grows with each failed cycle, carries jitter, and is capped", () => {
    expect(reconnectDelay(1, () => 1)).toBeLessThan(reconnectDelay(3, () => 1));
    expect(reconnectDelay(3, () => 0)).toBeLessThan(reconnectDelay(3, () => 1));
    expect(reconnectDelay(50, () => 1)).toBe(RECONNECT_MAX_MS);
  });
});
