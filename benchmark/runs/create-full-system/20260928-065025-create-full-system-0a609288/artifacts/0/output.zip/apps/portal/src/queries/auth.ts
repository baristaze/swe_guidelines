// The sign-in domain: the calls before and between desks. None of them is cached; the session
// store holds what they answer.
import { useMutation } from "@tanstack/react-query";
import { api, type SignInRequest, type SignUpRequest } from "../api";

export function useLogin() {
  return useMutation({ mutationFn: (body: SignInRequest) => api.auth.login(body) });
}

export function useSignUp() {
  return useMutation({ mutationFn: (body: SignUpRequest) => api.auth.signUp(body) });
}

/** Trades the held bearer (the sign-in bearer, or the current session on a switch) for a desk's session. */
export function useExchange() {
  return useMutation({ mutationFn: (orgId: string) => api.auth.exchange(orgId) });
}

export function useLogout() {
  return useMutation({ mutationFn: () => api.auth.logout() });
}
