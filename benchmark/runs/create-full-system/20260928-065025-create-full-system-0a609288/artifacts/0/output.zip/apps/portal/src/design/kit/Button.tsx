import type { ButtonHTMLAttributes } from "react";
import { color, font, radius, space } from "../tokens";

type Variant = "primary" | "secondary" | "danger";

const palette: Record<Variant, { background: string; ink: string; border: string }> = {
  primary: { background: color.accent, ink: color.accentInk, border: color.accent },
  secondary: { background: color.surface, ink: color.ink, border: color.line },
  danger: { background: color.surface, ink: color.danger, border: color.danger },
};

export function Button({ variant = "secondary", style, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant }) {
  const p = palette[variant];
  return (
    <button
      type="button"
      {...rest}
      style={{
        fontFamily: font.ui,
        fontSize: font.size.md,
        padding: `${space.sm}px ${space.lg}px`,
        borderRadius: radius.sm,
        border: `1px solid ${p.border}`,
        background: p.background,
        color: p.ink,
        cursor: rest.disabled ? "not-allowed" : "pointer",
        opacity: rest.disabled ? 0.6 : 1,
        ...style,
      }}
    />
  );
}
