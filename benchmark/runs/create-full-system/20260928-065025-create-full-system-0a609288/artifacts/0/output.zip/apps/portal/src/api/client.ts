// The one transport client. Every call of the app goes out through `request`: the API origin
// and the timeout from the config, the bearer from the session store, the app header, the
// error envelope parsed into ApiError with its request id, 401 clearing authentication, the
// Idempotency-Key minted once per create and resent unchanged on each retry, the one retry, and
// each response's X-Request-Id handed to `onRequestId`, so an error event can name the request.
import { backoffDelay, retryAfterDelay, shouldRetry, type Outcome } from "./retry";
import type { ErrorResponse } from "./types";

export const APP_TYPE = "portal";
export const APP_VERSION = "portal@0.1.0";

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  readonly requestId: string | null;
  readonly retryAfterSeconds: number | null;

  constructor(status: number, code: string, message: string, requestId: string | null, retryAfterSeconds: number | null) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.code = code;
    this.requestId = requestId;
    this.retryAfterSeconds = retryAfterSeconds;
  }
}

export function isApiError(error: unknown): error is ApiError {
  return error instanceof ApiError;
}

export interface TransportOptions {
  apiOrigin: string;
  requestTimeoutMs: number;
  getToken: () => string | null;
  onUnauthorized: () => void;
  /** Called with each response's X-Request-Id (null when the response carries none), whatever its status. */
  onRequestId?: (requestId: string | null) => void;
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
  newKey?: () => string;
}

export type Query = Record<string, string | number | undefined>;

export interface RequestOptions {
  query?: Query;
  body?: unknown;
  /** A creating call: an Idempotency-Key is minted once for it and sent on every attempt. */
  creates?: boolean;
  /** The sign-in calls carry no bearer, and their 401 is an answer, not a lost session. */
  anonymous?: boolean;
  /** A create without a principal whose ids are minted on the device: a retry lands once, so it may repeat. */
  repeatable?: boolean;
  /** Extra headers of one call, such as the source's reply secret. */
  headers?: Record<string, string>;
}

export interface Transport {
  request<T>(method: string, path: string, options?: RequestOptions): Promise<T>;
  socketUrl(path: string, query: Query): string;
}

function buildUrl(origin: string, path: string, query: Query | undefined): string {
  const url = new URL(`/v1${path}`, origin);
  for (const [name, value] of Object.entries(query ?? {})) {
    if (value !== undefined) url.searchParams.set(name, String(value));
  }
  return url.toString();
}

async function parseError(response: Response): Promise<ApiError> {
  const headerId = response.headers.get("x-request-id");
  const retryAfter = response.headers.get("retry-after");
  const retryAfterSeconds = retryAfter !== null && Number.isFinite(Number(retryAfter)) ? Number(retryAfter) : null;
  try {
    const envelope = (await response.json()) as Partial<ErrorResponse>;
    if (envelope.error && typeof envelope.error.code === "string") {
      const { code, message, request_id } = envelope.error;
      return new ApiError(response.status, code, message, request_id ?? headerId, retryAfterSeconds);
    }
  } catch {
    // not an envelope: fall through to the status
  }
  return new ApiError(response.status, `http_${response.status}`, response.statusText || "request failed", headerId, retryAfterSeconds);
}

const defaultSleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export function createTransport(options: TransportOptions): Transport {
  const doFetch = options.fetchImpl ?? fetch.bind(globalThis);
  const sleep = options.sleep ?? defaultSleep;
  const newKey = options.newKey ?? (() => crypto.randomUUID());

  async function attemptOnce(method: string, url: string, headers: Headers, body: string | undefined): Promise<Response | Outcome> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), options.requestTimeoutMs);
    try {
      return await doFetch(url, { method, headers, body, signal: controller.signal });
    } catch {
      return controller.signal.aborted ? { kind: "timeout" } : { kind: "network" };
    } finally {
      clearTimeout(timer);
    }
  }

  async function request<T>(method: string, path: string, opts: RequestOptions = {}): Promise<T> {
    const url = buildUrl(options.apiOrigin, path, opts.query);
    const headers = new Headers({ accept: "application/json", "x-app-type": APP_TYPE, "x-app-version": APP_VERSION });
    const body = opts.body === undefined ? undefined : JSON.stringify(opts.body);
    if (body !== undefined) headers.set("content-type", "application/json");
    if (opts.creates) headers.set("idempotency-key", newKey());
    for (const [name, value] of Object.entries(opts.headers ?? {})) headers.set(name, value);

    for (let attempt = 1; ; attempt += 1) {
      const token = opts.anonymous ? null : options.getToken();
      if (token) headers.set("authorization", `Bearer ${token}`);
      else headers.delete("authorization");

      const result = await attemptOnce(method, url, headers, body);
      const outcome: Outcome = result instanceof Response ? { kind: "status", status: result.status } : result;
      if (result instanceof Response) options.onRequestId?.(result.headers.get("x-request-id"));

      if (result instanceof Response && result.ok) {
        if (result.status === 204) return undefined as T;
        const text = await result.text();
        return (text ? JSON.parse(text) : undefined) as T;
      }

      if (shouldRetry({ method, idempotencyKey: Boolean(opts.creates || opts.repeatable), outcome, attempt })) {
        const hinted = result instanceof Response ? retryAfterDelay(result.headers.get("retry-after")) : null;
        await sleep(hinted ?? backoffDelay(attempt));
        continue;
      }

      if (result instanceof Response) {
        const error = await parseError(result);
        if (result.status === 401 && !opts.anonymous) options.onUnauthorized();
        throw error;
      }
      throw outcome.kind === "timeout"
        ? new ApiError(0, "timeout", "the request took too long", null, null)
        : new ApiError(0, "network", "the service could not be reached", null, null);
    }
  }

  function socketUrl(path: string, query: Query): string {
    const url = new URL(buildUrl(options.apiOrigin, path, query));
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
    return url.toString();
  }

  return { request, socketUrl };
}
