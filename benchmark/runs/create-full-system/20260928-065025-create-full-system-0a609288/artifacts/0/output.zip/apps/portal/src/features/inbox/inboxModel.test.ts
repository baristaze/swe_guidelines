import { describe, expect, it } from "vitest";
import type { SubmissionView } from "../../api";
import { inboxCountText, STATE_FILTER_OPTIONS, submissionRows, toFilter } from "./inboxModel";

const s = (id: string, created_at: string, extra: Partial<SubmissionView> = {}): SubmissionView => ({
  id,
  report_id: "r",
  journalist_id: "j",
  state: "new",
  tags: [],
  sender_name: null,
  has_contact: false,
  created_at,
  updated_at: created_at,
  ...extra,
});

describe("inbox model", () => {
  it("lists submissions newest first, anonymous unless sent under a name", () => {
    const rows = submissionRows(
      [s("1", "2026-05-01T10:00:00Z"), s("2", "2026-05-02T10:00:00Z", { state: "follow-up", tags: ["water", "city"], sender_name: "Bo" })],
      [],
    );
    expect(rows.map((r) => [r.id, r.stateLabel, r.tags, r.sender])).toEqual([
      ["2", "Follow-up", "water, city", "Bo"],
      ["1", "New", "", "Anonymous"],
    ]);
  });

  it("filters by a known state and a trimmed tag only", () => {
    expect(toFilter("", "  ")).toEqual({});
    expect(toFilter("bogus", "")).toEqual({});
    expect(toFilter("useful", " Water ")).toEqual({ state: "useful", tag: "water" });
    expect(STATE_FILTER_OPTIONS[0]).toEqual({ value: "", label: "Any state" });
  });

  it("counts", () => {
    expect(inboxCountText(0, false)).toBe("The inbox is empty");
    expect(inboxCountText(0, true)).toBe("Nothing matches");
    expect(inboxCountText(2, true)).toBe("2 submissions");
  });
});
