import { Banner, Button, Card, cellStyle, Muted, Table } from "../../design/kit";
import { usePledgesVm } from "./usePledgesVm";

export function PledgesPage() {
  const vm = usePledgesVm();

  return (
    <Card title="Your pledges" actions={<Muted>{vm.countText}</Muted>}>
      {vm.loading && <Muted>Loading your pledges…</Muted>}
      {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
      {vm.error && <Banner tone="danger">{vm.error}</Banner>}
      {!vm.loading && vm.rows.length === 0 && <Muted>Support a journalist from their public page.</Muted>}
      {vm.rows.length > 0 && (
        <Table head={["Started", "Amount", "Kind", "Status", ""]}>
          {vm.rows.map((row) => (
            <tr key={row.id}>
              <td style={cellStyle}>{row.started}</td>
              <td style={cellStyle}>{row.amount}</td>
              <td style={cellStyle}>{row.mode}</td>
              <td style={cellStyle}>
                <Muted>{row.status}</Muted>
              </td>
              <td style={{ ...cellStyle, textAlign: "right" }}>
                {row.cancellable && (
                  <Button variant="danger" disabled={vm.cancelling} onClick={() => vm.cancel(row.id)}>
                    Cancel
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </Table>
      )}
    </Card>
  );
}
