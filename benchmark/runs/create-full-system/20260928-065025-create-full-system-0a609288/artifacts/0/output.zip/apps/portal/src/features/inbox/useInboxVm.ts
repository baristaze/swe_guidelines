// The inbox view-model: the desk's submissions, filtered by state and tag on the server. New
// submissions arrive through the realtime router, which re-reads the loaded pages.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { useJournalists } from "../../queries/journalists";
import { useSubmissions } from "../../queries/reports";
import { inboxCountText, STATE_FILTER_OPTIONS, submissionRows, toFilter } from "./inboxModel";

export function useInboxVm() {
  const [state, setState] = useState("");
  const [tag, setTag] = useState("");
  const filter = toFilter(state, tag);
  const submissions = useSubmissions(filter);
  const journalists = useJournalists();

  const rows = submissionRows(submissions.data ?? [], journalists.data ?? []);
  const filtered = filter.state !== undefined || filter.tag !== undefined;

  return {
    loading: submissions.isPending,
    loadError: submissions.error ? errorText(submissions.error) : null,
    rows,
    countText: inboxCountText(rows.length, filtered),
    stateOptions: STATE_FILTER_OPTIONS,
    state,
    setState,
    tag,
    setTag,
    clear: () => {
      setState("");
      setTag("");
    },
    filtered,
  };
}
