import { describe, expect, it } from "vitest";
import { parseSession, serializeSession, SIGNED_OUT, type PersistedSession } from "./sessionModel";

const tenant: PersistedSession = {
  token: "t",
  stage: "tenant",
  memberships: [{ org_id: "o", org_name: "Desk", org_slug: "desk", role: "owner" }],
  org: { id: "o", name: "Desk", slug: "desk" },
};

describe("session mirror", () => {
  it("survives a reload", () => {
    expect(parseSession(serializeSession(tenant))).toEqual(tenant);
  });

  it("writes nothing when signed out", () => {
    expect(serializeSession(SIGNED_OUT)).toBeNull();
  });

  it("starts signed out on anything unreadable", () => {
    expect(parseSession("{")).toEqual(SIGNED_OUT);
    expect(parseSession(JSON.stringify({ stage: "tenant" }))).toEqual(SIGNED_OUT);
    expect(parseSession(JSON.stringify({ token: "t", stage: "tenant", org: null }))).toEqual(SIGNED_OUT);
  });
});
