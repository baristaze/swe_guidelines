// The contributions screen's pure rules: what readers gave the desk's profiles, newest first, with
// the platform's fee and what the desk keeps.
import type { ContributionView, JournalistView } from "../../api";
import { formatAmount, MODE_LABELS } from "../pledges/pledgesModel";
import { formatDateTime, nameOf } from "../updates/updatesModel";

export interface ContributionRow {
  id: string;
  received: string;
  journalistName: string;
  supporter: string;
  amount: string;
  fee: string;
  net: string;
  mode: string;
}

export function contributionRows(contributions: readonly ContributionView[], journalists: readonly JournalistView[]): ContributionRow[] {
  return [...contributions]
    .sort((a, b) => Date.parse(b.received_at) - Date.parse(a.received_at) || (a.id < b.id ? 1 : -1))
    .map((c) => ({
      id: c.id,
      received: formatDateTime(c.received_at),
      journalistName: nameOf(journalists, c.journalist_id),
      supporter: c.supporter_name,
      amount: formatAmount(c.amount_minor, c.currency),
      fee: formatAmount(c.platform_fee_minor, c.currency),
      net: formatAmount(c.amount_minor - c.platform_fee_minor, c.currency),
      mode: MODE_LABELS[c.mode],
    }));
}

export function contributionCountText(count: number): string {
  return count === 0 ? "No contributions yet" : count === 1 ? "1 contribution" : `${count} contributions`;
}
