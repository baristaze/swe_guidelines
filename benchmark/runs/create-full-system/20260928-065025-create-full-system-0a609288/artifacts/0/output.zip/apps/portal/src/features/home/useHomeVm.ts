// The home screen's view-model: the desk, the signed-in person, and the members.
import { useState } from "react";
import type { Role } from "../../api";
import { errorText } from "../../app/errorText";
import { useChangeRole, useMe, useMembers, useOrg, useRemoveMember, useRenameMe } from "../../queries/tenancy";
import { memberCountText, memberRows, PERSON_ROLES } from "./homeModel";

export function useHomeVm() {
  const org = useOrg();
  const me = useMe();
  const members = useMembers();
  const rename = useRenameMe();
  const changeRole = useChangeRole();
  const remove = useRemoveMember();
  const [nameDraft, setNameDraft] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const rows = memberRows(members.data ?? [], me.data?.id);
  const onError = (e: unknown) => setError(errorText(e));

  return {
    loading: org.isPending || me.isPending || members.isPending,
    loadError: org.error ?? me.error ?? members.error ? errorText(org.error ?? me.error ?? members.error) : null,
    org: org.data,
    me: me.data,
    rows,
    countText: memberCountText(rows.length),
    roleOptions: PERSON_ROLES,
    error,
    nameDraft: nameDraft ?? me.data?.name ?? "",
    editName: (value: string) => setNameDraft(value),
    nameChanged: nameDraft !== null && nameDraft.trim() !== "" && nameDraft.trim() !== me.data?.name,
    saveName: () => {
      if (nameDraft === null) return;
      setError(null);
      rename.mutate(nameDraft.trim(), { onSuccess: () => setNameDraft(null), onError });
    },
    savingName: rename.isPending,
    changeRole: (userId: string, role: Role) => {
      setError(null);
      changeRole.mutate({ userId, role }, { onError });
    },
    removeMember: (userId: string) => {
      setError(null);
      remove.mutate(userId, { onError });
    },
    busy: changeRole.isPending || remove.isPending,
  };
}
