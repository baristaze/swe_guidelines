// The org chip's pure rules.
import type { MembershipChoiceView } from "../../api";
import type { CurrentOrg } from "../../store/sessionModel";

/** The chip opens a list only when there is somewhere else to go. */
export function canSwitch(memberships: readonly MembershipChoiceView[]): boolean {
  return memberships.length > 1;
}

export interface DeskRow {
  orgId: string;
  name: string;
  role: string;
  current: boolean;
}

export function deskRows(memberships: readonly MembershipChoiceView[], current: CurrentOrg | null): DeskRow[] {
  return [...memberships]
    .sort((a, b) => a.org_name.localeCompare(b.org_name))
    .map((m) => ({ orgId: m.org_id, name: m.org_name, role: m.role, current: m.org_id === current?.id }));
}

export function initials(name: string): string {
  const words = name.trim().split(/\s+/).filter(Boolean);
  return words
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
}
