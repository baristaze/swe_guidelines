// The journalists screen's pure rules: rows, the edit state, the profile's public side (bio,
// published, the device key, payouts, the shareable link), and the requests it sends. Whether a
// profile may be published or paid out is the server's decision; the screen shows its refusal.
import type { AddJournalistRequest, JournalistView, StartPayoutsRequest, UpdateJournalistRequest } from "../../api";
import { formatDate } from "../api_keys/apiKeysModel";

export interface JournalistRow {
  id: string;
  displayName: string;
  published: boolean;
  added: string;
  updated: string;
}

export function journalistRows(journalists: readonly JournalistView[]): JournalistRow[] {
  return [...journalists]
    .sort((a, b) => a.display_name.localeCompare(b.display_name) || (a.id < b.id ? -1 : 1))
    .map((j) => ({
      id: j.id,
      displayName: j.display_name,
      published: j.published,
      added: formatDate(j.created_at),
      updated: formatDate(j.updated_at),
    }));
}

export function canSave(draft: string, current?: string): boolean {
  const name = draft.trim();
  return name.length > 0 && name !== current;
}

/** A new profile starts unpublished, with no bio and no key: the desk sets those up next. */
export function toAddJournalistRequest(draft: string): AddJournalistRequest {
  return { display_name: draft.trim(), bio: "", published: false };
}

/** A partial update: only the field that changed is sent. */
export function toUpdateJournalistRequest(draft: string): UpdateJournalistRequest {
  return { display_name: draft.trim() };
}

export function countText(count: number): string {
  return count === 0 ? "No journalists yet" : count === 1 ? "1 journalist" : `${count} journalists`;
}

// --- the profile's public side

export function toBioRequest(draft: string): UpdateJournalistRequest {
  return { bio: draft.trim() };
}

export function bioChanged(draft: string, current: string): boolean {
  return draft.trim() !== current;
}

export function toPublishedRequest(published: boolean): UpdateJournalistRequest {
  return { published };
}

/**
 * Where the profile's key stands. `here`: this device holds the private key for it. `elsewhere`: a
 * key is on the profile but not on this device, which then cannot open the profile's reports.
 */
export type KeyStatus = "none" | "here" | "elsewhere";

export function keyStatus(publicKey: string | null, onThisDevice: boolean): KeyStatus {
  if (publicKey === null) return "none";
  return onThisDevice ? "here" : "elsewhere";
}

export const KEY_STATUS_TEXT: Record<KeyStatus, string> = {
  none: "No key yet: sources cannot send this profile a report until a key is generated.",
  here: "The private key is on this device. Reports to this profile open here.",
  elsewhere: "A key is on the profile, but its private half is not on this device, so reports cannot be opened here.",
};

/** A new key replaces the old one: reports sealed to the old key open only where that key is kept. */
export function keyActionText(status: KeyStatus): string {
  return status === "none" ? "Generate the key on this device" : "Replace the key with one generated on this device";
}

export function toPublicKeyRequest(publicKey: string): UpdateJournalistRequest {
  return { public_key: publicKey };
}

export function normalizedCountry(draft: string): string {
  return draft.trim().toUpperCase();
}

export function canStartPayouts(draft: string): boolean {
  return /^[A-Z]{2}$/.test(normalizedCountry(draft));
}

export function toStartPayoutsRequest(draft: string): StartPayoutsRequest {
  return { country: normalizedCountry(draft) };
}

/** The link the journalist shares; there is no directory (ADR 0009). */
export function publicLink(origin: string, deskId: string, journalistId: string): string {
  return `${origin}/p/${deskId}/${journalistId}`;
}
