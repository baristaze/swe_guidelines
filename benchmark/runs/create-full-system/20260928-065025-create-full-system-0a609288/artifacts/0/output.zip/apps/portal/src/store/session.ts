// The session store: one bearer and the current desk, never two sessions. The bearer is held in
// memory and mirrored to the tab's session storage, so a reload survives and a closed tab forgets;
// local storage is never touched.
import { create } from "zustand";
import type { IssuedSignInView, MembershipChoiceView } from "../api";
import { parseSession, serializeSession, SIGNED_OUT, type CurrentOrg, type PersistedSession } from "./sessionModel";

const STORAGE_KEY = "acme.portal.session";

function tabStorage(): Storage | null {
  return typeof sessionStorage === "undefined" ? null : sessionStorage;
}

interface SessionState extends PersistedSession {
  /** Bumped on every exchange, so the signed-in tree mounts afresh per tenant session. */
  epoch: number;
  /** The login or sign-up answered: hold its bearer and the desks it can enter. */
  signedIn: (answer: IssuedSignInView) => void;
  /** An exchange answered: its session replaces whatever bearer was held. */
  enteredDesk: (token: string, membership: MembershipChoiceView) => void;
  clear: () => void;
}

function orgOf(membership: MembershipChoiceView): CurrentOrg {
  return { id: membership.org_id, name: membership.org_name, slug: membership.org_slug };
}

export const useSession = create<SessionState>()((set) => ({
  ...parseSession(tabStorage()?.getItem(STORAGE_KEY) ?? null),
  epoch: 0,
  signedIn: (answer) => set({ token: answer.token, stage: "choosing", memberships: answer.memberships, org: null }),
  enteredDesk: (token, membership) =>
    set((state) => ({ token, stage: "tenant", org: orgOf(membership), epoch: state.epoch + 1 })),
  clear: () => set((state) => ({ ...SIGNED_OUT, epoch: state.epoch + 1 })),
}));

useSession.subscribe((state) => {
  const storage = tabStorage();
  if (!storage) return;
  const serialized = serializeSession({ token: state.token, stage: state.stage, memberships: state.memberships, org: state.org });
  if (serialized === null) storage.removeItem(STORAGE_KEY);
  else storage.setItem(STORAGE_KEY, serialized);
});

export const getToken = (): string | null => useSession.getState().token;
