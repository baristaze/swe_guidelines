import { Banner, Card, cellStyle, Muted, Table } from "../../design/kit";
import { useContributionsVm } from "./useContributionsVm";

export function ContributionsPage() {
  const vm = useContributionsVm();

  return (
    <Card title="Contributions" actions={<Muted>{vm.countText}</Muted>}>
      {vm.loading && <Muted>Loading contributions…</Muted>}
      {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
      {vm.rows.length > 0 && (
        <Table head={["Received", "For", "From", "Kind", "Amount", "Fee", "Kept"]}>
          {vm.rows.map((row) => (
            <tr key={row.id}>
              <td style={{ ...cellStyle, whiteSpace: "nowrap" }}>{row.received}</td>
              <td style={cellStyle}>{row.journalistName}</td>
              <td style={cellStyle}>{row.supporter}</td>
              <td style={cellStyle}>{row.mode}</td>
              <td style={cellStyle}>{row.amount}</td>
              <td style={cellStyle}>
                <Muted>{row.fee}</Muted>
              </td>
              <td style={cellStyle}>{row.net}</td>
            </tr>
          ))}
        </Table>
      )}
    </Card>
  );
}
