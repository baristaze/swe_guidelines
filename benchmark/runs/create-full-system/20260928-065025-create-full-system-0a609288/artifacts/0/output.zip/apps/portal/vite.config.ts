import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

// The build is a static bundle and nothing else. Nothing environment-specific is baked in:
// every value that differs between environments arrives in /config.json at load time.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, strictPort: true },
  preview: { port: 5173, strictPort: true },
  build: { outDir: "dist", sourcemap: "hidden" },
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
  },
});
