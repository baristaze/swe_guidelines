// The API keys view-model. A created key's token is shown once, held only in this hook's state
// until the person dismisses it; it is never cached or stored.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { useApiKeys, useCreateApiKey, useRevokeApiKey } from "../../queries/apiKeys";
import { canCreate, EMPTY_KEY_FORM, EXPIRY_CHOICES, KEY_ROLES, keyRows, toAddApiKeyRequest, type KeyForm } from "./apiKeysModel";

export function useApiKeysVm() {
  const keys = useApiKeys();
  const create = useCreateApiKey();
  const revoke = useRevokeApiKey();
  const [form, setForm] = useState<KeyForm>(EMPTY_KEY_FORM);
  const [issued, setIssued] = useState<{ name: string; token: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  return {
    loading: keys.isPending,
    loadError: keys.error ? errorText(keys.error) : null,
    rows: keyRows(keys.data ?? [], new Date()),
    form,
    update: <K extends keyof KeyForm>(field: K, value: KeyForm[K]) => setForm((f) => ({ ...f, [field]: value })),
    roleOptions: KEY_ROLES,
    expiryOptions: EXPIRY_CHOICES,
    canCreate: canCreate(form) && !create.isPending,
    create: () => {
      setError(null);
      create.mutate(toAddApiKeyRequest(form), {
        onSuccess: (answer) => {
          setForm(EMPTY_KEY_FORM);
          setIssued(answer.token ? { name: answer.name, token: answer.token } : null);
        },
        onError: (e) => setError(errorText(e)),
      });
    },
    issued,
    dismissIssued: () => setIssued(null),
    revoke: (id: string) => {
      setError(null);
      revoke.mutate(id, { onError: (e) => setError(errorText(e)) });
    },
    revoking: revoke.isPending,
    error,
  };
}
