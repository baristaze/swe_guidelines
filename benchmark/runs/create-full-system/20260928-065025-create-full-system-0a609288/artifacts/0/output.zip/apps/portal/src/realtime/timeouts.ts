// The client's half of the shared timeouts file: the ping interval is read from
// deployment/realtime-timeouts.json, the file the load balancer's idle timeout is set from, so
// the two cannot drift apart. timeouts.test.ts asserts the ping sits inside the idle timeout.
import shared from "../../../../deployment/realtime-timeouts.json";

export const PING_INTERVAL_SECONDS: number = shared.ping_interval_seconds;
export const PING_INTERVAL_MS = PING_INTERVAL_SECONDS * 1000;

/** How long the socket may go without a frame before the provider treats it as dead. */
export const SILENCE_LIMIT_MS = PING_INTERVAL_MS * 2;

/** The reconnect backoff and the degraded mode's polling cadence. */
export const RECONNECT_BASE_MS = 1_000;
export const RECONNECT_MAX_MS = 30_000;
export const DEGRADED_POLL_MS = 30_000;

export function reconnectDelay(failedCycles: number, random: () => number = Math.random): number {
  const ceiling = Math.min(RECONNECT_MAX_MS, RECONNECT_BASE_MS * 2 ** Math.max(0, failedCycles - 1));
  return Math.round(ceiling / 2 + (random() * ceiling) / 2);
}
