import { Banner, Button, Card, cellStyle, Muted, SelectField, Stack, Table, TextField } from "../../design/kit";
import type { Role } from "../../api";
import { useHomeVm } from "./useHomeVm";

export function HomePage() {
  const vm = useHomeVm();
  if (vm.loading) return <Muted>Loading your desk…</Muted>;
  if (vm.loadError) return <Banner tone="danger">{vm.loadError}</Banner>;

  return (
    <Stack gap={24}>
      <Card title={vm.org?.name ?? "Your desk"}>
        <Muted>Desk address: {vm.org?.slug}</Muted>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            vm.saveName();
          }}
        >
          <Stack row>
            <TextField label="Your name" value={vm.nameDraft} onChange={(e) => vm.editName(e.target.value)} />
            <Button type="submit" disabled={!vm.nameChanged || vm.savingName} style={{ alignSelf: "flex-end" }}>
              Save
            </Button>
          </Stack>
        </form>
      </Card>

      <Card title="Members" actions={<Muted>{vm.countText}</Muted>}>
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
        <Table head={["Name", "Role", ""]}>
          {vm.rows.map((row) => (
            <tr key={row.userId}>
              <td style={cellStyle}>
                {row.name} {row.isMe && <Muted>(you)</Muted>}
              </td>
              <td style={cellStyle}>
                <SelectField
                  label=""
                  aria-label={`Role of ${row.name}`}
                  value={row.role}
                  options={row.role === "service" ? [{ value: "service", label: row.roleLabel }] : vm.roleOptions}
                  disabled={vm.busy}
                  onChange={(e) => vm.changeRole(row.userId, e.target.value as Role)}
                />
              </td>
              <td style={{ ...cellStyle, textAlign: "right" }}>
                <Button variant="danger" disabled={vm.busy} onClick={() => vm.removeMember(row.userId)}>
                  Remove
                </Button>
              </td>
            </tr>
          ))}
        </Table>
      </Card>
    </Stack>
  );
}
