import { Link } from "react-router";
import { Banner, Button, Card, cellStyle, Muted, SelectField, Stack, Table, TextField } from "../../design/kit";
import { useInboxVm } from "./useInboxVm";

export function InboxPage() {
  const vm = useInboxVm();

  return (
    <Card title="Inbox" actions={<Muted>{vm.countText}</Muted>}>
      <Stack row>
        <SelectField label="State" value={vm.state} options={vm.stateOptions} onChange={(e) => vm.setState(e.target.value)} />
        <TextField label="Tag" value={vm.tag} onChange={(e) => vm.setTag(e.target.value)} maxLength={64} />
        {vm.filtered && (
          <Button onClick={vm.clear} style={{ alignSelf: "flex-end" }}>
            Clear
          </Button>
        )}
      </Stack>
      <Muted>Reports are sealed on the sender's device. Open one to read it with the key on this device.</Muted>
      {vm.loading && <Muted>Loading the inbox…</Muted>}
      {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
      {vm.rows.length > 0 && (
        <Table head={["Received", "For", "From", "State", "Tags", ""]}>
          {vm.rows.map((row) => (
            <tr key={row.id}>
              <td style={{ ...cellStyle, whiteSpace: "nowrap" }}>{row.received}</td>
              <td style={cellStyle}>{row.journalistName}</td>
              <td style={cellStyle}>{row.sender}</td>
              <td style={cellStyle}>{row.stateLabel}</td>
              <td style={cellStyle}>
                <Muted>{row.tags}</Muted>
              </td>
              <td style={{ ...cellStyle, textAlign: "right" }}>
                <Link to={`/inbox/${row.id}`}>Open</Link>
              </td>
            </tr>
          ))}
        </Table>
      )}
    </Card>
  );
}
