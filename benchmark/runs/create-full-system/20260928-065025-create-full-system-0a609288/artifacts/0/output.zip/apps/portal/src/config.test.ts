import { describe, expect, it } from "vitest";
import { ConfigError, DEFAULT_REQUEST_TIMEOUT_MS, parseConfig } from "./config";

describe("parseConfig", () => {
  it("reads the file the deploy workflow writes", () => {
    expect(parseConfig({ apiOrigin: "https://api.example.org", errorTrackingDsn: "", environment: "staging" })).toEqual({
      apiOrigin: "https://api.example.org",
      requestTimeoutMs: DEFAULT_REQUEST_TIMEOUT_MS,
      errorTrackingDsn: null,
      environment: "staging",
    });
  });

  it("takes the request timeout when the file names one", () => {
    expect(parseConfig({ apiOrigin: "http://localhost:8000/", requestTimeoutMs: 5000 }).requestTimeoutMs).toBe(5000);
  });

  it("refuses a file without the API origin or with a bad timeout", () => {
    expect(() => parseConfig({})).toThrow(ConfigError);
    expect(() => parseConfig({ apiOrigin: "http://x", requestTimeoutMs: -1 })).toThrow(ConfigError);
  });
});
