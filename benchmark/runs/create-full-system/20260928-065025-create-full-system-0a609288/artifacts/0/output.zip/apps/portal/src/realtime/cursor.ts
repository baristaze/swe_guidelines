// The last contiguous seq, pure. A gap (42 arriving after 40) is a replay after 40, never a skip;
// a head_seq on hello or on a pong above the cursor is a gap like a missing event.

export type CursorVerdict = "apply" | "duplicate" | "gap";

export class Cursor {
  /** null until the first hello: then the caches are as fresh as the head it names. */
  last: number | null = null;

  /** An event hint: apply it when it is the next one, ignore it when already seen. */
  offer(seq: number): CursorVerdict {
    if (this.last === null) return "gap";
    if (seq <= this.last) return "duplicate";
    if (seq === this.last + 1) {
      this.last = seq;
      return "apply";
    }
    return "gap";
  }

  /** hello or pong. A cursor that starts at hello starts at its head. */
  head(headSeq: number, isHello: boolean): "ok" | "gap" {
    if (this.last === null) {
      if (isHello) {
        this.last = headSeq;
        return "ok";
      }
      return "gap";
    }
    return headSeq > this.last ? "gap" : "ok";
  }
}
