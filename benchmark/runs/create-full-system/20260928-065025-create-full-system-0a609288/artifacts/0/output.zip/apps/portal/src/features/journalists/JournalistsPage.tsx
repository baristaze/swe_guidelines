import { Banner, Button, Card, cellStyle, Muted, Stack, Table, TextAreaField, TextField } from "../../design/kit";
import { font } from "../../design/tokens";
import { useJournalistsVm } from "./useJournalistsVm";

export function JournalistsPage() {
  const vm = useJournalistsVm();

  return (
    <Stack gap={24}>
      <Card title="Add a journalist">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            vm.add();
          }}
        >
          <Stack row>
            <TextField label="Display name" value={vm.newName} onChange={(e) => vm.setNewName(e.target.value)} />
            <Button variant="primary" type="submit" disabled={!vm.canAdd} style={{ alignSelf: "flex-end" }}>
              Add
            </Button>
          </Stack>
        </form>
      </Card>

      <Card title="Journalists" actions={<Muted>{vm.countText}</Muted>}>
        {vm.loading && <Muted>Loading journalists…</Muted>}
        {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
        {vm.rows.length > 0 && (
          <Table head={["Display name", "Public", "Added", "Updated", ""]}>
            {vm.rows.map((row) =>
              vm.editingId === row.id ? (
                <tr key={row.id}>
                  <td style={cellStyle} colSpan={4}>
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        vm.saveEdit();
                      }}
                    >
                      <Stack row>
                        <TextField label="Display name" value={vm.draft} onChange={(e) => vm.setDraft(e.target.value)} autoFocus />
                        <Button variant="primary" type="submit" disabled={!vm.canSaveEdit} style={{ alignSelf: "flex-end" }}>
                          Save
                        </Button>
                        <Button onClick={vm.cancelEdit} style={{ alignSelf: "flex-end" }}>
                          Cancel
                        </Button>
                      </Stack>
                    </form>
                  </td>
                  <td style={cellStyle} />
                </tr>
              ) : (
                <tr key={row.id}>
                  <td style={cellStyle}>{row.displayName}</td>
                  <td style={cellStyle}>
                    <Muted>{row.published ? "published" : "private"}</Muted>
                  </td>
                  <td style={cellStyle}>{row.added}</td>
                  <td style={cellStyle}>{row.updated}</td>
                  <td style={{ ...cellStyle, textAlign: "right" }}>
                    <Stack row style={{ justifyContent: "flex-end" }}>
                      <Button onClick={() => vm.manage(row.id)}>Profile</Button>
                      <Button onClick={() => vm.startEdit(row.id, row.displayName)}>Edit</Button>
                      <Button variant="danger" disabled={vm.removing} onClick={() => vm.remove(row.id)}>
                        Delete
                      </Button>
                    </Stack>
                  </td>
                </tr>
              ),
            )}
          </Table>
        )}
      </Card>

      {vm.managed && (
        <Card title={`Profile of ${vm.managed.name}`} actions={<Button onClick={vm.closeProfile}>Close</Button>}>
          {vm.profileError && <Banner tone="danger">{vm.profileError}</Banner>}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              vm.saveBio();
            }}
          >
            <Stack>
              <TextAreaField label="Bio" value={vm.bioDraft} onChange={(e) => vm.setBioDraft(e.target.value)} maxLength={2000} />
              <Stack row>
                <Button type="submit" disabled={!vm.canSaveBio}>
                  Save bio
                </Button>
              </Stack>
            </Stack>
          </form>

          <Stack row>
            <Muted>{vm.managed.published ? "Published: anyone with the link reads this profile." : "Private: only the desk sees this profile."}</Muted>
            <Button disabled={vm.updating} onClick={vm.togglePublished}>
              {vm.managed.published ? "Unpublish" : "Publish"}
            </Button>
          </Stack>

          <Stack gap={8}>
            <Muted>{vm.managed.keyText}</Muted>
            <Stack row>
              <Button variant="primary" disabled={vm.generating || vm.updating} onClick={vm.generateKey}>
                {vm.generating ? "Generating…" : vm.managed.keyAction}
              </Button>
            </Stack>
          </Stack>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              vm.startPayouts();
            }}
          >
            <Stack row>
              <TextField label="Payout country (two letters)" value={vm.country} onChange={(e) => vm.setCountry(e.target.value)} maxLength={2} />
              <Button type="submit" disabled={!vm.canStartPayouts} style={{ alignSelf: "flex-end" }}>
                {vm.managed.payoutsReady ? "Update payouts" : "Set up payouts"}
              </Button>
              <Muted>{vm.managed.payoutsReady ? "Payouts are set up." : "Payouts are not set up yet."}</Muted>
            </Stack>
          </form>

          <Stack gap={4}>
            <Muted>The link to share with readers and sources</Muted>
            <code style={{ fontFamily: font.mono, wordBreak: "break-all" }}>{vm.managed.link}</code>
          </Stack>
        </Card>
      )}
    </Stack>
  );
}
