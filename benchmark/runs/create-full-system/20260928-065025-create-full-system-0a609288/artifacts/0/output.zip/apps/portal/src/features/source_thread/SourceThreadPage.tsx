import { Banner, Button, Card, Muted, Stack, TextAreaField } from "../../design/kit";
import { color, font, space } from "../../design/tokens";
import { useSourceThreadVm } from "./useSourceThreadVm";

export function SourceThreadPage() {
  const vm = useSourceThreadVm();
  if (vm.loading) return <Muted>Loading your report…</Muted>;
  if (vm.noSecret) return <Banner tone="danger">This link is missing its secret. Open the full link you kept when you sent the report.</Banner>;
  if (vm.loadError) return <Banner tone="danger">No report was found for this link. Check that you opened the full link you kept.</Banner>;

  return (
    <Stack gap={24}>
      <Card title="Your report">
        {vm.stateText && <Muted>{vm.stateText}</Muted>}
        {vm.noKeysText && <Banner tone="warn">{vm.noKeysText}</Banner>}
      </Card>

      <Card title="Replies">
        {vm.rows.length === 0 && <Muted>No replies yet.</Muted>}
        {vm.rows.map((row) => (
          <div key={row.id} style={{ borderLeft: `3px solid ${row.mine ? color.line : color.accent}`, paddingLeft: space.md }}>
            <Muted>
              {row.label} · {row.when}
            </Muted>
            <div style={{ whiteSpace: "pre-wrap", fontFamily: font.body }}>{row.text ?? <Muted>Cannot be opened on this device.</Muted>}</div>
          </div>
        ))}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            vm.send();
          }}
        >
          <Stack>
            <TextAreaField label="Answer" value={vm.text} onChange={(e) => vm.setText(e.target.value)} />
            <Stack row>
              <Button variant="primary" type="submit" disabled={!vm.canSend}>
                {vm.sending ? "Encrypting…" : "Encrypt and send"}
              </Button>
              <Muted>Encrypted in this browser for the journalist before it is sent.</Muted>
            </Stack>
          </Stack>
        </form>
      </Card>
    </Stack>
  );
}
