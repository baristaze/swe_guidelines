// The app's one socket. Opened with a ticket from POST /v1/realtime/tickets on
// /v1/realtime/socket?ticket=, where the service subscribes it to the desk's stream (the client
// sends no subscribe). Every frame goes to the router, which writes the query cache; the socket's
// own state goes to the connection store. The provider owns reconnection with backoff and, after
// more than one failed cycle, the degraded mode: a slow fixed poll of the event log, with a banner.
// It is mounted once per tenant session (keyed by it), so a switch or a sign-out closes it.
import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ReactNode } from "react";
import { api } from "../api";
import { useConnection } from "../store/connection";
import { encodeFrame, parseFrame } from "./envelopes";
import { createRealtimeRouter } from "./router";
import { DEGRADED_POLL_MS, PING_INTERVAL_MS, reconnectDelay, SILENCE_LIMIT_MS } from "./timeouts";

async function mintTicket(): Promise<string> {
  const first = await api.realtime.ticket();
  if (first.ticket) return first.ticket;
  // A replayed create answers without the ticket: ask for a fresh one under a new key.
  const second = await api.realtime.ticket();
  if (!second.ticket) throw new Error("realtime: no ticket issued");
  return second.ticket;
}

export function RealtimeProvider({ children }: { children: ReactNode }) {
  const queryClient = useQueryClient();
  // Children render once the first ticket attempt settles, so the socket of this tenant session
  // is on its way before the screens' first requests.
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const connection = useConnection.getState();
    const router = createRealtimeRouter({
      queryClient,
      listEvents: (afterSeq, limit) => api.events.list(afterSeq, limit),
      onError: (error) => console.warn(error),
    });
    let disposed = false;
    let socket: WebSocket | null = null;
    let failedCycles = 0;
    let pingTimer: ReturnType<typeof setInterval> | undefined;
    let silenceTimer: ReturnType<typeof setTimeout> | undefined;
    let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
    let pollTimer: ReturnType<typeof setInterval> | undefined;

    // The degraded mode's poll: a replay after the cursor, or, before any hello gave one, a re-read
    // of what the screens show.
    const poll = () => {
      if (router.cursor.last === null) queryClient.invalidateQueries().catch(() => {});
      else void router.replay();
    };

    const stopPolling = () => {
      clearInterval(pollTimer);
      pollTimer = undefined;
    };

    const armSilence = () => {
      clearTimeout(silenceTimer);
      silenceTimer = setTimeout(() => socket?.close(4000, "silent"), SILENCE_LIMIT_MS);
    };

    const scheduleReconnect = () => {
      if (disposed) return;
      failedCycles += 1;
      if (failedCycles > 1) {
        connection.set("degraded", failedCycles);
        if (pollTimer === undefined) pollTimer = setInterval(poll, DEGRADED_POLL_MS);
      } else {
        connection.set("reconnecting", failedCycles);
      }
      reconnectTimer = setTimeout(() => void connect(), reconnectDelay(failedCycles));
    };

    async function connect(): Promise<void> {
      let ticket: string;
      try {
        ticket = await mintTicket();
      } catch {
        if (!disposed) setReady(true);
        scheduleReconnect();
        return;
      }
      if (disposed) return;
      setReady(true);
      const ws = new WebSocket(api.realtime.socketUrl(ticket));
      socket = ws;
      let opened = false;

      ws.onopen = () => {
        opened = true;
        failedCycles = 0;
        stopPolling();
        connection.set("open", 0);
        armSilence();
        pingTimer = setInterval(() => {
          if (ws.readyState === WebSocket.OPEN) ws.send(encodeFrame({ type: "ping" }));
        }, PING_INTERVAL_MS);
      };
      ws.onmessage = (message: MessageEvent) => {
        armSilence();
        if (typeof message.data !== "string") return;
        const frame = parseFrame(message.data);
        // hello opens the cursor, or replays after it on a reconnect.
        if (frame) void router.handle(frame);
      };
      ws.onclose = () => {
        clearInterval(pingTimer);
        clearTimeout(silenceTimer);
        if (socket === ws) socket = null;
        if (disposed) return;
        // A socket that opened and then dropped starts a fresh cycle.
        if (opened) failedCycles = 0;
        scheduleReconnect();
      };
    }

    connection.set("connecting", 0);
    void connect();

    return () => {
      disposed = true;
      clearTimeout(reconnectTimer);
      clearInterval(pingTimer);
      clearTimeout(silenceTimer);
      stopPolling();
      socket?.close(1000, "session ended");
      socket = null;
      useConnection.getState().set("closed", 0);
    };
  }, [queryClient]);

  return ready ? children : null;
}
