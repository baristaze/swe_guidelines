// The updates domain: what the desk publishes under its profiles.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, type AddUpdateRequest, type UpdateView } from "../api";
import { placeInLists } from "./cache";
import { keys, PAGE_SIZE } from "./keys";

export const updatesCache = {
  place(queryClient: QueryClient, view: UpdateView): void {
    placeInLists(queryClient, keys.updates.lists(), view, () => true); // an update is never edited
  },
  reread(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.updates.all }).catch(() => {});
  },
};

export function useUpdates(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.updates.list(limit), queryFn: () => api.updates.list(limit) });
}

export function usePublishUpdate() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: AddUpdateRequest) => api.updates.create(body),
    onSuccess: (view) => updatesCache.place(queryClient, view),
  });
}
