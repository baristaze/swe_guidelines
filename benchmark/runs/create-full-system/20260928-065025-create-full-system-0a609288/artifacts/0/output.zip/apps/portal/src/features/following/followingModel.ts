// The following screen's pure rules: the journalists this reader follows, by the name the feed
// knows them by, each with the link to their page, and the feed newest first.
import type { FeedItemView, FollowView } from "../../api";
import { formatDate } from "../api_keys/apiKeysModel";
import { formatDateTime } from "../updates/updatesModel";

export interface FollowRow {
  id: string;
  name: string;
  path: string;
  since: string;
}

/** The public page of a journalist, by desk and profile. */
export function profilePath(deskId: string, journalistId: string): string {
  return `/p/${deskId}/${journalistId}`;
}

export function followRows(follows: readonly FollowView[], feed: readonly FeedItemView[]): FollowRow[] {
  const names = new Map(feed.map((item) => [item.journalist_id, item.journalist_name]));
  return [...follows]
    .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || (a.id < b.id ? 1 : -1))
    .map((f) => ({
      id: f.id,
      name: names.get(f.journalist_id) ?? "A journalist",
      path: profilePath(f.desk_id, f.journalist_id),
      since: formatDate(f.created_at),
    }));
}

export interface FeedRow {
  id: string;
  name: string;
  path: string;
  body: string;
  published: string;
}

export function feedRows(feed: readonly FeedItemView[]): FeedRow[] {
  return [...feed]
    .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || (a.id < b.id ? 1 : -1))
    .map((item) => ({
      id: item.id,
      name: item.journalist_name,
      path: profilePath(item.desk_id, item.journalist_id),
      body: item.body,
      published: formatDateTime(item.created_at),
    }));
}

export function followCountText(count: number): string {
  return count === 0 ? "You follow no one yet" : count === 1 ? "1 journalist" : `${count} journalists`;
}
