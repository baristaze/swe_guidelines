// The org chip's view-model. A switch is a second exchange presenting the current session; before
// the new session is used, the query cache and every tenant store are dropped, and the tenant tree
// (and with it the socket) mounts afresh under the new session. Sign-out ends the session on the
// server, then drops everything the tab held.
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import type { MembershipChoiceView } from "../../api";
import { errorText } from "../../app/errorText";
import { useExchange, useLogout } from "../../queries/auth";
import { useMemberships } from "../../queries/tenancy";
import { useSession } from "../../store/session";
import { dropTenantState } from "../../store/tenant";
import { canSwitch, deskRows, initials } from "./orgChipModel";

export function useOrgChipVm() {
  const queryClient = useQueryClient();
  const org = useSession((s) => s.org);
  const known = useSession((s) => s.memberships);
  const enteredDesk = useSession((s) => s.enteredDesk);
  const clear = useSession((s) => s.clear);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const memberships = useMemberships(open && canSwitch(known));
  const exchange = useExchange();
  const logout = useLogout();

  const list = memberships.data ?? known;

  const switchTo = (orgId: string) => {
    const membership = list.find((m: MembershipChoiceView) => m.org_id === orgId);
    if (!membership || membership.org_id === org?.id) return;
    setError(null);
    exchange.mutate(orgId, {
      onSuccess: (session) => {
        dropTenantState(queryClient);
        useSession.setState({ memberships: list });
        enteredDesk(session.token, membership);
      },
      onError: (e) => setError(errorText(e)),
    });
  };

  const signOut = () => {
    logout.mutate(undefined, {
      // The tab forgets the session whether or not the server answered.
      onSettled: () => {
        clear();
        dropTenantState(queryClient);
      },
    });
  };

  return {
    name: org?.name ?? "",
    badge: initials(org?.name ?? ""),
    switchable: canSwitch(known),
    open,
    toggle: () => setOpen((o) => !o),
    rows: deskRows(list, org),
    loading: memberships.isFetching,
    switching: exchange.isPending,
    switchTo,
    signOut,
    signingOut: logout.isPending,
    error: error ?? (memberships.error ? errorText(memberships.error) : null),
  };
}
