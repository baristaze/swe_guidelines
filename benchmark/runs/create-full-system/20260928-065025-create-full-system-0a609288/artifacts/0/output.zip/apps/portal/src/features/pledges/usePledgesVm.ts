// The pledges view-model: the support this reader started, and its cancel. A cancel puts its
// answer into the cache; a settled payment arrives as a hint through the realtime router.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { useCancelPledge, usePledges } from "../../queries/support";
import { pledgeCountText, pledgeRows } from "./pledgesModel";

export function usePledgesVm() {
  const pledges = usePledges();
  const cancel = useCancelPledge();
  const [error, setError] = useState<string | null>(null);
  const rows = pledgeRows(pledges.data ?? []);

  return {
    loading: pledges.isPending,
    loadError: pledges.error ? errorText(pledges.error) : null,
    rows,
    countText: pledgeCountText(rows.length),
    error,
    cancel: (id: string) => {
      setError(null);
      cancel.mutate(id, { onError: (e) => setError(errorText(e)) });
    },
    cancelling: cancel.isPending,
  };
}
