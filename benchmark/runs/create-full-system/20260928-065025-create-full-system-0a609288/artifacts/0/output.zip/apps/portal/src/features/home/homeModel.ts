// The home screen's pure rules: the desk's members as rows. Who may change a role or remove a
// member is the server's decision; the screen shows its refusal.
import type { MemberView, Role } from "../../api";

const RANK: Record<Role, number> = { owner: 0, admin: 1, member: 2, viewer: 3, service: 4 };

export const ROLE_LABELS: Record<Role, string> = {
  owner: "Owner",
  admin: "Editor-in-chief",
  member: "Journalist",
  viewer: "Reader",
  service: "Service",
};

/** The roles a person can be given; `service` belongs to API keys. */
export const PERSON_ROLES: ReadonlyArray<{ value: Role; label: string }> = (["owner", "admin", "member", "viewer"] as const).map((r) => ({
  value: r,
  label: ROLE_LABELS[r],
}));

export interface MemberRow {
  userId: string;
  name: string;
  role: Role;
  roleLabel: string;
  isMe: boolean;
}

export function memberRows(members: readonly MemberView[], meId: string | undefined): MemberRow[] {
  return [...members]
    .sort((a, b) => RANK[a.role] - RANK[b.role] || a.name.localeCompare(b.name))
    .map((m) => ({ userId: m.user_id, name: m.name, role: m.role, roleLabel: ROLE_LABELS[m.role], isMe: m.user_id === meId }));
}

export function memberCountText(count: number): string {
  return count === 1 ? "1 member" : `${count} members`;
}
