import { Banner, Button, Card, Muted, SelectField, Stack, TextAreaField, TextField } from "../../design/kit";
import type { SupportMode } from "../../api";
import { color, font, space } from "../../design/tokens";
import type { Currency } from "./publicProfileModel";
import { usePublicProfileVm } from "./usePublicProfileVm";

export function PublicProfilePage() {
  const vm = usePublicProfileVm();
  if (vm.loading) return <Muted>Loading the profile…</Muted>;
  if (vm.loadError || !vm.profile) return <Banner tone="danger">{vm.loadError ?? "This profile is not published."}</Banner>;

  return (
    <Stack gap={24}>
      <Card
        title={vm.profile.name}
        actions={
          vm.signedIn &&
          (vm.following ? (
            <Muted>You follow this journalist</Muted>
          ) : (
            <Button variant="primary" disabled={!vm.canFollow} onClick={vm.follow}>
              Follow
            </Button>
          ))
        }
      >
        {vm.profile.bio && <p style={{ margin: 0, whiteSpace: "pre-wrap", fontFamily: font.body }}>{vm.profile.bio}</p>}
        {!vm.signedIn && <Muted>Sign in to follow or support this journalist.</Muted>}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
      </Card>

      {vm.signedIn && vm.profile.acceptsSupport && (
        <Card title="Support">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              vm.startSupport();
            }}
          >
            <Stack row>
              <TextField label="Amount" inputMode="decimal" value={vm.support.amount} onChange={(e) => vm.setSupport("amount", e.target.value)} />
              <SelectField label="Currency" value={vm.support.currency} options={vm.currencyOptions} onChange={(e) => vm.setSupport("currency", e.target.value as Currency)} />
              <SelectField label="Kind" value={vm.support.mode} options={vm.modeOptions} onChange={(e) => vm.setSupport("mode", e.target.value as SupportMode)} />
              <TextField label="Name shown to the journalist" placeholder="A reader" value={vm.support.name} onChange={(e) => vm.setSupport("name", e.target.value)} />
              <Button variant="primary" type="submit" disabled={!vm.canSupport} style={{ alignSelf: "flex-end" }}>
                Continue to payment
              </Button>
            </Stack>
          </form>
        </Card>
      )}

      <Card title="Send information">
        {vm.sentLink ? (
          <Banner tone="warn">
            <Stack gap={space.sm}>
              <span>Sent. Keep this link to read replies and answer; it is the only way back, and it is shown once.</span>
              <code style={{ fontFamily: font.mono, background: color.surface, padding: space.sm, wordBreak: "break-all" }}>{vm.sentLink}</code>
              <Button onClick={vm.dismissSent}>I have kept it</Button>
            </Stack>
          </Banner>
        ) : !vm.acceptsReports ? (
          <Muted>This journalist cannot receive reports yet.</Muted>
        ) : (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              vm.send();
            }}
          >
            <Stack>
              <Muted>What you write is encrypted in this browser for this journalist alone before it is sent.</Muted>
              <TextField label="Subject" value={vm.report.subject} onChange={(e) => vm.setReport("subject", e.target.value)} />
              <TextAreaField label="Description" rows={6} value={vm.report.description} onChange={(e) => vm.setReport("description", e.target.value)} />
              <Stack row>
                <TextField label="Tags (comma-separated)" value={vm.report.tags} onChange={(e) => vm.setReport("tags", e.target.value)} />
                <TextField label="Approximate place" value={vm.report.place} onChange={(e) => vm.setReport("place", e.target.value)} />
                <TextField label="When it happened" type="datetime-local" value={vm.report.occurredAt} onChange={(e) => vm.setReport("occurredAt", e.target.value)} />
              </Stack>
              <TextField
                label="Email for reply notices (optional; kept apart from the report)"
                type="email"
                value={vm.report.contactEmail}
                onChange={(e) => vm.setReport("contactEmail", e.target.value)}
              />
              {vm.signedIn && (
                <SelectField
                  label="Send"
                  value={vm.report.named ? "named" : "anonymous"}
                  options={[
                    { value: "anonymous", label: "Anonymously" },
                    { value: "named", label: "Under my name" },
                  ]}
                  onChange={(e) => vm.setReport("named", e.target.value === "named")}
                />
              )}
              <Stack row>
                <Button variant="primary" type="submit" disabled={!vm.canSend}>
                  {vm.sending ? "Encrypting…" : "Encrypt and send"}
                </Button>
              </Stack>
              {vm.reportError && <Banner tone="danger">{vm.reportError}</Banner>}
            </Stack>
          </form>
        )}
      </Card>

      <Card title="Updates">
        {vm.updates.length === 0 && <Muted>No updates yet.</Muted>}
        {vm.updates.map((u) => (
          <article key={u.id} style={{ borderBottom: `1px solid ${color.line}`, paddingBottom: space.md }}>
            <Muted>{u.published}</Muted>
            <p style={{ margin: `${space.xs}px 0 0`, whiteSpace: "pre-wrap", fontFamily: font.body }}>{u.body}</p>
          </article>
        ))}
      </Card>
    </Stack>
  );
}
