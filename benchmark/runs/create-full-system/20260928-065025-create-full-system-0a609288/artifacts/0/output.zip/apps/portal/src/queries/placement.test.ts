import { describe, expect, it } from "vitest";
import { newerByUpdatedAt, place, removeFrom } from "./placement";

const row = (id: string, updated_at = "2026-01-01T00:00:00Z") => ({ id, updated_at });

describe("place", () => {
  it("inserts a new row in id order", () => {
    const result = place([row("a"), row("c")], row("b"), 10, newerByUpdatedAt);
    expect(result).toEqual({ kind: "page", page: [row("a"), row("b"), row("c")] });
  });

  it("replaces a cached row with a newer copy", () => {
    const newer = row("a", "2026-02-01T00:00:00Z");
    expect(place([row("a")], newer, 10, newerByUpdatedAt)).toEqual({ kind: "page", page: [newer] });
  });

  it("never lets a late answer overwrite a newer version", () => {
    const cached = row("a", "2026-03-01T00:00:00Z");
    expect(place([cached], row("a", "2026-02-01T00:00:00Z"), 10, newerByUpdatedAt)).toEqual({ kind: "page", page: [cached] });
  });

  it("asks for a re-read when a new row falls past the edge of a full page", () => {
    expect(place([row("a"), row("b")], row("c"), 2, newerByUpdatedAt)).toEqual({ kind: "reread" });
  });

  it("places a new row inside a full page and drops the one pushed past its edge", () => {
    expect(place([row("a"), row("c")], row("b"), 2, newerByUpdatedAt)).toEqual({ kind: "page", page: [row("a"), row("b")] });
  });

  it("removes a row", () => {
    expect(removeFrom([row("a"), row("b")], "a")).toEqual([row("b")]);
  });
});
