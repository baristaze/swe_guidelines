import { Link } from "react-router";
import { Banner, Button, Card, Muted, SelectField, Stack, TextAreaField, TextField } from "../../design/kit";
import { color, font, space } from "../../design/tokens";
import { useSubmissionVm } from "./useSubmissionVm";

function Field({ label, value }: { label: string; value: string }) {
  return (
    <Stack gap={space.xs}>
      <Muted>{label}</Muted>
      <span style={{ whiteSpace: "pre-wrap", fontFamily: font.body }}>{value}</span>
    </Stack>
  );
}

export function SubmissionPage() {
  const vm = useSubmissionVm();
  if (vm.loading) return <Muted>Loading the submission…</Muted>;
  if (vm.loadError) return <Banner tone="danger">{vm.loadError}</Banner>;

  return (
    <Stack gap={24}>
      <Link to="/inbox">Back to the inbox</Link>
      {vm.error && <Banner tone="danger">{vm.error}</Banner>}

      <Card title={vm.heading} actions={vm.hasContact ? <Muted>The source left a contact address for reply notices.</Muted> : undefined}>
        {vm.openingText && <Banner tone={vm.openingTone}>{vm.openingText}</Banner>}
        {vm.report && (
          <Stack>
            <Field label="Subject" value={vm.report.subject} />
            <Field label="Description" value={vm.report.description} />
            <Stack row gap={space.xl}>
              <Field label="Sender's tags" value={vm.report.tags || "—"} />
              <Field label="Place" value={vm.report.place} />
              <Field label="When" value={vm.report.occurred} />
            </Stack>
          </Stack>
        )}
      </Card>

      {vm.triage && (
        <Card title="Triage">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              vm.saveTriage();
            }}
          >
            <Stack row>
              <SelectField label="State" value={vm.triage.state} options={vm.stateOptions} onChange={(e) => vm.setState(e.target.value)} />
              <TextField label="Tags (comma-separated)" value={vm.triage.tags} onChange={(e) => vm.setTags(e.target.value)} />
              <Button type="submit" disabled={!vm.canSaveTriage} style={{ alignSelf: "flex-end" }}>
                Save
              </Button>
            </Stack>
          </form>
        </Card>
      )}

      <Card title="Thread">
        {vm.messagesLoading && <Muted>Loading the thread…</Muted>}
        {!vm.messagesLoading && vm.messages.length === 0 && <Muted>No messages yet.</Muted>}
        {vm.messages.map((m) => (
          <div key={m.id} style={{ borderLeft: `3px solid ${m.fromSource ? color.accent : color.line}`, paddingLeft: space.md }}>
            <Muted>
              {m.label} · {m.when}
            </Muted>
            <div style={{ whiteSpace: "pre-wrap", fontFamily: font.body }}>{m.text ?? <Muted>Cannot be opened on this device.</Muted>}</div>
          </div>
        ))}
        {vm.noDeskKey && <Banner tone="warn">This profile has no key, so nothing can be sealed from it. Generate one under Journalists.</Banner>}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            vm.send();
          }}
        >
          <Stack>
            <SelectField label="Write" value={vm.writing} options={vm.writingOptions} onChange={(e) => vm.setWriting(e.target.value)} />
            <TextAreaField label="Message" value={vm.text} onChange={(e) => vm.setText(e.target.value)} />
            <Stack row>
              <Button variant="primary" type="submit" disabled={!vm.canSend}>
                {vm.sending ? "Sealing…" : "Seal and send"}
              </Button>
              <Muted>Sealed on this device before it is sent.</Muted>
            </Stack>
          </Stack>
        </form>
      </Card>
    </Stack>
  );
}
