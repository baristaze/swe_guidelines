import { describe, expect, it } from "vitest";
import {
  amountMinor,
  canSendReport,
  canSupport,
  EMPTY_REPORT_FORM,
  EMPTY_SUPPORT_FORM,
  followOf,
  followUpLink,
  publicUpdateRows,
  toAddPledgeRequest,
  toReportContent,
  toSubmitReportRequest,
} from "./publicProfileModel";

describe("public profile model", () => {
  it("reads an amount as minor units", () => {
    expect(amountMinor("12")).toBe(1200);
    expect(amountMinor(" 12.5 ")).toBe(1250);
    expect(amountMinor("12,05")).toBe(1205);
    expect(amountMinor("0")).toBeNull();
    expect(amountMinor("1.234")).toBeNull();
    expect(amountMinor("abc")).toBeNull();
    expect(canSupport({ ...EMPTY_SUPPORT_FORM, amount: "" })).toBe(false);
  });

  it("pledges to this desk's profile, as a reader when no name is given", () => {
    expect(toAddPledgeRequest("d", "j", { amount: "7.50", currency: "gbp", mode: "monthly", name: " " })).toEqual({
      desk_id: "d",
      journalist_id: "j",
      amount_minor: 750,
      currency: "gbp",
      mode: "monthly",
      supporter_name: "A reader",
    });
  });

  it("finds this profile's follow", () => {
    const follows = [{ id: "f", desk_id: "d", journalist_id: "j", created_at: "2026-05-01T10:00:00Z" }];
    expect(followOf(follows, "d", "j")?.id).toBe("f");
    expect(followOf(follows, "d", "k")).toBeUndefined();
  });

  it("sends a report with a subject, a description, and a well-formed contact if any", () => {
    const form = { ...EMPTY_REPORT_FORM, subject: "S", description: "D" };
    expect(canSendReport(EMPTY_REPORT_FORM)).toBe(false);
    expect(canSendReport(form)).toBe(true);
    expect(canSendReport({ ...form, contactEmail: "not an address" })).toBe(false);
    expect(canSendReport({ ...form, contactEmail: "me@example.org" })).toBe(true);
  });

  it("seals everything but the contact address", () => {
    const content = toReportContent({ ...EMPTY_REPORT_FORM, subject: " S ", description: "D", tags: "Water, city", place: " Riverside ", occurredAt: "2026-09-01T10:00", contactEmail: "me@example.org" });
    expect(content).toEqual({ subject: "S", description: "D", tags: ["water", "city"], place: "Riverside", occurred_at: "2026-09-01T10:00", attachments: [] });
    expect(toReportContent(EMPTY_REPORT_FORM).occurred_at).toBeNull();
  });

  it("builds the intake request for one recipient", () => {
    const body = toSubmitReportRequest({
      reportId: "r",
      submissionId: "s",
      deskId: "d",
      journalistId: "j",
      sealed: { ciphertext: "c", wrappedKeys: ["w"], algorithm: "p256-hkdf-sha256-aesgcm-v1" },
      sourcePublicKey: "pk",
      replySecret: "secret",
      contactEmail: " ",
    });
    expect(body).toEqual({
      report_id: "r",
      ciphertext: "c",
      algorithm: "p256-hkdf-sha256-aesgcm-v1",
      source_public_key: "pk",
      reply_secret: "secret",
      contact_email: null,
      recipients: [{ desk_id: "d", journalist_id: "j", submission_id: "s", wrapped_key: "w" }],
    });
  });

  it("keeps the secret in the follow-up link's fragment", () => {
    expect(followUpLink("https://portal.example", "d", "s", "secret")).toBe("https://portal.example/r/d/s#secret");
  });

  it("lists published updates newest first", () => {
    const rows = publicUpdateRows([
      { id: "1", body: "a", created_at: "2026-05-01T10:00:00Z" },
      { id: "2", body: "b", created_at: "2026-05-02T10:00:00Z" },
    ]);
    expect(rows.map((r) => r.id)).toEqual(["2", "1"]);
  });
});
