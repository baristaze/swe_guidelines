import { describe, expect, it } from "vitest";
import type { PledgeView } from "../../api";
import { formatAmount, offersCancel, pledgeCountText, pledgeRows } from "./pledgesModel";

const p = (id: string, status: PledgeView["status"], mode: PledgeView["mode"], created_at: string): PledgeView => ({
  id,
  desk_id: "d",
  journalist_id: "j",
  amount_minor: 1250,
  currency: "eur",
  mode,
  supporter_name: "A reader",
  status,
  platform_fee_minor: 62,
  settled_at: null,
  created_at,
  updated_at: created_at,
});

describe("pledges model", () => {
  it("formats minor units", () => {
    expect(formatAmount(1250, "eur")).toBe("12.50 EUR");
    expect(formatAmount(5, "usd")).toBe("0.05 USD");
  });

  it("offers a cancel for a pending pledge or an active monthly one", () => {
    expect(offersCancel({ status: "pending", mode: "one_time" })).toBe(true);
    expect(offersCancel({ status: "active", mode: "monthly" })).toBe(true);
    expect(offersCancel({ status: "paid", mode: "one_time" })).toBe(false);
    expect(offersCancel({ status: "cancelled", mode: "monthly" })).toBe(false);
  });

  it("lists pledges newest first with their status", () => {
    const rows = pledgeRows([p("1", "paid", "one_time", "2026-05-01T10:00:00Z"), p("2", "active", "monthly", "2026-05-02T10:00:00Z")]);
    expect(rows).toEqual([
      { id: "2", amount: "12.50 EUR", mode: "Monthly", status: "Active", started: "2026-05-02", cancellable: true },
      { id: "1", amount: "12.50 EUR", mode: "One-time", status: "Paid", started: "2026-05-01", cancellable: false },
    ]);
  });

  it("counts", () => {
    expect(pledgeCountText(0)).toBe("No pledges yet");
    expect(pledgeCountText(3)).toBe("3 pledges");
  });
});
