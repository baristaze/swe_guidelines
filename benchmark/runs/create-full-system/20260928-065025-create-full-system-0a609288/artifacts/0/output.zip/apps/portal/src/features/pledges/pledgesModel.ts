// The pledges screen's pure rules: this reader's pledges with their status, the amounts as they
// read, and which pledge the screen offers to cancel. Whether a cancel lands is the server's
// decision; the screen shows its refusal.
import type { PledgeStatus, PledgeView, SupportMode } from "../../api";
import { formatDate } from "../api_keys/apiKeysModel";

/** Minor units as major units with the currency's code: every supported currency has two decimals. */
export function formatAmount(minor: number, currency: string): string {
  return `${(minor / 100).toFixed(2)} ${currency.toUpperCase()}`;
}

export const MODE_LABELS: Record<SupportMode, string> = { one_time: "One-time", monthly: "Monthly" };

export const STATUS_LABELS: Record<PledgeStatus, string> = {
  pending: "Waiting for payment",
  paid: "Paid",
  active: "Active",
  cancelled: "Cancelled",
};

export interface PledgeRow {
  id: string;
  amount: string;
  mode: string;
  status: string;
  started: string;
  cancellable: boolean;
}

/** A pending pledge, or an active monthly one, can be cancelled; a paid one-time pledge is done. */
export function offersCancel(pledge: Pick<PledgeView, "status" | "mode">): boolean {
  return pledge.status === "pending" || (pledge.status === "active" && pledge.mode === "monthly");
}

export function pledgeRows(pledges: readonly PledgeView[]): PledgeRow[] {
  return [...pledges]
    .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || (a.id < b.id ? 1 : -1))
    .map((p) => ({
      id: p.id,
      amount: formatAmount(p.amount_minor, p.currency),
      mode: MODE_LABELS[p.mode],
      status: STATUS_LABELS[p.status],
      started: formatDate(p.created_at),
      cancellable: offersCancel(p),
    }));
}

export function pledgeCountText(count: number): string {
  return count === 0 ? "No pledges yet" : count === 1 ? "1 pledge" : `${count} pledges`;
}
