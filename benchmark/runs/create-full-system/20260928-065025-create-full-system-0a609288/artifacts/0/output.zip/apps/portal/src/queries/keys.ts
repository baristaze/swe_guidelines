// The query-key factory. The entity name is first in every key, so a write and a realtime hint
// find every cached collection of an entity with one prefix.

export const keys = {
  org: {
    all: ["org"] as const,
    current: () => ["org", "current"] as const,
  },
  me: {
    all: ["me"] as const,
    current: () => ["me", "current"] as const,
  },
  memberships: {
    all: ["memberships"] as const,
    list: (limit: number) => ["memberships", "list", { limit }] as const,
  },
  members: {
    all: ["members"] as const,
    lists: () => ["members", "list"] as const,
    list: (limit: number) => ["members", "list", { limit }] as const,
  },
  apiKeys: {
    all: ["apiKeys"] as const,
    lists: () => ["apiKeys", "list"] as const,
    list: (limit: number) => ["apiKeys", "list", { limit }] as const,
  },
  journalists: {
    all: ["journalists"] as const,
    lists: () => ["journalists", "list"] as const,
    list: (limit: number) => ["journalists", "list", { limit }] as const,
    details: () => ["journalists", "detail"] as const,
    detail: (id: string) => ["journalists", "detail", id] as const,
  },
  follows: {
    all: ["follows"] as const,
    lists: () => ["follows", "list"] as const,
    list: (limit: number) => ["follows", "list", { limit }] as const,
  },
  feed: {
    all: ["feed"] as const,
    list: (limit: number) => ["feed", "list", { limit }] as const,
  },
  updates: {
    all: ["updates"] as const,
    lists: () => ["updates", "list"] as const,
    list: (limit: number) => ["updates", "list", { limit }] as const,
  },
  pledges: {
    all: ["pledges"] as const,
    lists: () => ["pledges", "list"] as const,
    list: (limit: number) => ["pledges", "list", { limit }] as const,
  },
  contributions: {
    all: ["contributions"] as const,
    list: (limit: number) => ["contributions", "list", { limit }] as const,
  },
  submissions: {
    all: ["submissions"] as const,
    lists: () => ["submissions", "list"] as const,
    list: (limit: number, state?: string, tag?: string) => ["submissions", "list", { limit, state, tag }] as const,
    detail: (id: string) => ["submissions", "detail", id] as const,
    /** The sealed report and this desk's wrapped key; read on opening, never placed. */
    sealed: (id: string) => ["submissions", "sealed", id] as const,
  },
  messages: {
    all: ["messages"] as const,
    lists: (submissionId: string) => ["messages", "list", submissionId] as const,
    list: (submissionId: string, limit: number) => ["messages", "list", submissionId, { limit }] as const,
  },
  // What anyone reads by a desk's link, outside the sign-in gate.
  publishedJournalists: {
    all: ["publishedJournalists"] as const,
    detail: (deskId: string, journalistId: string) => ["publishedJournalists", "detail", deskId, journalistId] as const,
  },
  publishedUpdates: {
    all: ["publishedUpdates"] as const,
    list: (deskId: string, journalistId: string, limit: number) => ["publishedUpdates", "list", { deskId, journalistId, limit }] as const,
  },
  sourceThreads: {
    all: ["sourceThreads"] as const,
    detail: (deskId: string, submissionId: string) => ["sourceThreads", "detail", deskId, submissionId] as const,
  },
  // What this device holds and opens, never the server's: the keys in the key store, and what they open.
  device: {
    all: ["device"] as const,
    journalistKey: (journalistId: string) => ["device", "journalistKey", journalistId] as const,
    sourceKeys: (submissionId: string) => ["device", "sourceKeys", submissionId] as const,
    openedReport: (submissionId: string) => ["device", "openedReport", submissionId] as const,
    openedMessages: (submissionId: string, messageIds: readonly string[]) => ["device", "openedMessages", submissionId, messageIds] as const,
  },
};

/** The page size every list screen asks for; the server clamps it. */
export const PAGE_SIZE = 100;

/** The `limit` a list key was built with, so placement knows where a loaded page ends. */
export function limitOf(queryKey: readonly unknown[]): number | null {
  const params = queryKey[queryKey.length - 1];
  if (typeof params === "object" && params !== null && "limit" in params) {
    const limit = (params as { limit: unknown }).limit;
    return typeof limit === "number" ? limit : null;
  }
  return null;
}
