// The submission view-model: one report of the inbox, fetched sealed and opened on this device with
// the profile's private key from the key store, its triage (state and tags), and the thread with
// the source. Each message is opened here too; a new one is sealed here before it is sent, so the
// server only ever holds ciphertext.
import { useState } from "react";
import { useParams } from "react-router";
import { errorText } from "../../app/errorText";
import { parseReportContent } from "../../crypto/reportContent";
import { sealMessage } from "../../crypto/sealing";
import { useJournalistDeviceKey, useOpenedMessages, useOpenedReport } from "../../queries/device";
import { useJournalist } from "../../queries/journalists";
import { useAddMessage, useMessages, useSealedSubmission, useSubmission, useUpdateSubmission } from "../../queries/reports";
import { STATE_LABELS, STATE_OPTIONS } from "../inbox/inboxModel";
import {
  canWrite,
  messageRows,
  occurredText,
  opening,
  OPENING_TEXT,
  recipientsFor,
  toUpdateSubmissionRequest,
  triageOf,
  WRITING_OPTIONS,
  type Triage,
  type Writing,
} from "./submissionModel";

export function useSubmissionVm() {
  const { submissionId = "" } = useParams();
  const submission = useSubmission(submissionId);
  const sealed = useSealedSubmission(submissionId);
  const journalistId = submission.data?.journalist_id;
  const journalist = useJournalist(journalistId);
  const deviceKey = useJournalistDeviceKey(journalistId);
  const report = useOpenedReport(submissionId, sealed.data, deviceKey.data);
  const messages = useMessages(submissionId);
  const openedMessages = useOpenedMessages(submissionId, messages.data, deviceKey.data);
  const update = useUpdateSubmission();
  const addMessage = useAddMessage();

  const [triage, setTriage] = useState<Triage | null>(null);
  const [writing, setWriting] = useState<Writing>("to_source");
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const onError = (e: unknown) => setError(errorText(e));

  const state = opening({
    keyLoading: journalistId === undefined || deviceKey.isPending,
    hasKey: !!deviceKey.data,
    opening: sealed.isPending || report.isPending,
    failed: report.isError,
  });
  const content = report.data === undefined ? null : parseReportContent(report.data);
  const current = submission.data;
  const draft = triage ?? (current ? triageOf(current) : null);
  const deskPublicKey = journalist.data?.public_key;
  const loadError = submission.error ?? sealed.error ?? messages.error;

  const send = async () => {
    if (!sealed.data || !deskPublicKey) return;
    setError(null);
    setSending(true);
    try {
      const sealedBody = await sealMessage(text.trim(), recipientsFor(writing, sealed.data.source_public_key, deskPublicKey));
      await addMessage.mutateAsync({ submissionId, body: { direction: writing, sealed_body: sealedBody } });
      setText("");
    } catch (e) {
      onError(e);
    } finally {
      setSending(false);
    }
  };

  return {
    loading: submission.isPending,
    loadError: loadError ? errorText(loadError) : null,
    error,
    heading: current ? `${current.sender_name ?? "Anonymous"} · ${STATE_LABELS[current.state]}` : "Submission",
    hasContact: current?.has_contact ?? false,

    openingText: state === "open" ? null : OPENING_TEXT[state],
    openingTone: state === "loading" ? ("info" as const) : ("warn" as const),
    report: content && {
      subject: content.subject,
      description: content.description,
      tags: content.tags.join(", "),
      place: content.place || "—",
      occurred: occurredText(content.occurred_at),
    },

    stateOptions: STATE_OPTIONS,
    triage: draft,
    setState: (value: string) => draft && setTriage({ ...draft, state: value as Triage["state"] }),
    setTags: (tags: string) => draft && setTriage({ ...draft, tags }),
    canSaveTriage: !!draft && !!current && toUpdateSubmissionRequest(draft, current) !== null && !update.isPending,
    saveTriage: () => {
      if (!draft || !current) return;
      const body = toUpdateSubmissionRequest(draft, current);
      if (!body) return;
      setError(null);
      update.mutate({ id: current.id, body }, { onSuccess: () => setTriage(null), onError });
    },

    messages: messageRows(messages.data ?? [], openedMessages.data),
    messagesLoading: messages.isPending,
    writingOptions: WRITING_OPTIONS,
    writing,
    setWriting: (value: string) => setWriting(value as Writing),
    text,
    setText,
    noDeskKey: journalist.isSuccess && !deskPublicKey,
    canSend: canWrite(text, deskPublicKey) && !!sealed.data && !sending,
    send: () => void send(),
    sending,
  };
}
