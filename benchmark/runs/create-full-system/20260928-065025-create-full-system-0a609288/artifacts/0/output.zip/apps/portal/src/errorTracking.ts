// What an error event carries out of the tab. The scrubber removes the same headers and fields the
// Python processes scrub (infra's SCRUBBED_HEADERS and SCRUBBED_FIELDS) before an event leaves, and
// tags the event with the request id the API answered with: the failing call's own when the error is
// an ApiError, else the last response the transport saw, so an event joins its log line and trace.
import type { ErrorEvent, EventHint } from "@sentry/react";
import { isApiError } from "./api";

export const SERVICE = "portal";
export const SCRUBBED = "[scrubbed]";
export const SCRUBBED_HEADERS: ReadonlySet<string> = new Set(["authorization", "cookie", "set-cookie", "x-api-key", "idempotency-key"]);
export const SCRUBBED_FIELDS: ReadonlySet<string> = new Set(["password", "totp_code", "token", "secret", "api_key", "bearer", "ticket"]);

let lastRequestId: string | null = null;

/** The transport's hook: the request id of the latest response, whatever its status. */
export function recordRequestId(requestId: string | null): void {
  if (requestId) lastRequestId = requestId;
}

export function currentRequestId(): string | null {
  return lastRequestId;
}

function scrubValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(scrubValue);
  if (value !== null && typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [name, inner] of Object.entries(value as Record<string, unknown>)) {
      out[name] = SCRUBBED_FIELDS.has(name.toLowerCase()) ? SCRUBBED : scrubValue(inner);
    }
    return out;
  }
  return value;
}

function scrubQuery(query: string): string {
  const params = new URLSearchParams(query);
  for (const name of [...params.keys()]) {
    if (SCRUBBED_FIELDS.has(name.toLowerCase())) params.set(name, SCRUBBED);
  }
  return params.toString();
}

/** A URL with every credential-named query parameter (the socket's ticket) replaced. */
export function scrubUrl(raw: string): string {
  const mark = raw.indexOf("?");
  if (mark < 0) return raw;
  const hash = raw.indexOf("#", mark);
  const query = hash < 0 ? raw.slice(mark + 1) : raw.slice(mark + 1, hash);
  return `${raw.slice(0, mark)}?${scrubQuery(query)}${hash < 0 ? "" : raw.slice(hash)}`;
}

function scrubData(data: unknown): unknown {
  if (typeof data !== "string") return scrubValue(data);
  try {
    return JSON.stringify(scrubValue(JSON.parse(data)));
  } catch {
    return data;
  }
}

/** Removes the credential headers, the cookies, and the credential fields; mutates and returns the event. */
export function scrubEvent(event: ErrorEvent): ErrorEvent {
  const request = event.request;
  if (request) {
    if (request.headers) {
      for (const name of Object.keys(request.headers)) {
        if (SCRUBBED_HEADERS.has(name.toLowerCase())) request.headers[name] = SCRUBBED;
      }
    }
    delete request.cookies;
    if (request.data !== undefined) request.data = scrubData(request.data);
    if (request.url) request.url = scrubUrl(request.url);
    if (typeof request.query_string === "string") request.query_string = scrubQuery(request.query_string);
    else if (Array.isArray(request.query_string)) {
      request.query_string = request.query_string.map(([name, value]) => [name, SCRUBBED_FIELDS.has(name.toLowerCase()) ? SCRUBBED : value]);
    } else if (request.query_string) request.query_string = scrubValue(request.query_string) as Record<string, string>;
  }
  if (event.extra) event.extra = scrubValue(event.extra) as Record<string, unknown>;
  for (const crumb of event.breadcrumbs ?? []) {
    if (crumb.data) {
      crumb.data = scrubValue(crumb.data) as Record<string, unknown>;
      if (typeof crumb.data.url === "string") crumb.data.url = scrubUrl(crumb.data.url);
    }
  }
  return event;
}

/** Sentry's beforeSend: scrub, then tag the request id. */
export function beforeSend(event: ErrorEvent, hint: EventHint): ErrorEvent {
  const failed = hint.originalException;
  const requestId = (isApiError(failed) ? failed.requestId : null) ?? lastRequestId;
  if (requestId) event.tags = { ...event.tags, request_id: requestId };
  return scrubEvent(event);
}
