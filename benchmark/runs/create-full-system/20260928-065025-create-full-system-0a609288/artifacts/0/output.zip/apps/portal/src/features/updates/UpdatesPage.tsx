import { Banner, Button, Card, cellStyle, Muted, SelectField, Stack, Table, TextAreaField } from "../../design/kit";
import { useUpdatesVm } from "./useUpdatesVm";

export function UpdatesPage() {
  const vm = useUpdatesVm();

  return (
    <Stack gap={24}>
      <Card title="Publish an update">
        {!vm.loading && !vm.hasProfiles && <Muted>Add a journalist profile first; an update is published under one.</Muted>}
        {vm.hasProfiles && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              vm.publish();
            }}
          >
            <Stack>
              <SelectField label="Profile" value={vm.form.journalistId} options={vm.options} onChange={(e) => vm.setJournalist(e.target.value)} />
              <TextAreaField label="Update" value={vm.form.body} maxLength={vm.maxLength} onChange={(e) => vm.setBody(e.target.value)} />
              <Stack row>
                <Button variant="primary" type="submit" disabled={!vm.canPublish}>
                  Publish
                </Button>
                <Muted>Readers of a published profile see it on the profile's page and in their feed.</Muted>
              </Stack>
            </Stack>
          </form>
        )}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
      </Card>

      <Card title="Updates" actions={<Muted>{vm.countText}</Muted>}>
        {vm.loading && <Muted>Loading updates…</Muted>}
        {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
        {vm.rows.length > 0 && (
          <Table head={["Published", "Profile", "Update"]}>
            {vm.rows.map((row) => (
              <tr key={row.id}>
                <td style={{ ...cellStyle, whiteSpace: "nowrap" }}>{row.published}</td>
                <td style={cellStyle}>{row.journalistName}</td>
                <td style={{ ...cellStyle, whiteSpace: "pre-wrap" }}>{row.body}</td>
              </tr>
            ))}
          </Table>
        )}
      </Card>
    </Stack>
  );
}
