// The sign-in gate. Nothing past it renders before a membership is chosen and exchanged. Past it,
// the signed-in tree, the realtime socket included, is mounted afresh per tenant session: a switch
// or a sign-out unmounts it, which closes the socket, and the next session mounts a new one.
import { Outlet } from "react-router";
import { SignInPage } from "../features/sign_in/SignInPage";
import { RealtimeProvider } from "../realtime/RealtimeProvider";
import { useSession } from "../store/session";

export function RequireAuth() {
  const stage = useSession((s) => s.stage);
  const orgId = useSession((s) => s.org?.id);
  const epoch = useSession((s) => s.epoch);

  if (stage !== "tenant" || !orgId) return <SignInPage />;
  return (
    <RealtimeProvider key={`${orgId}:${epoch}`}>
      <Outlet />
    </RealtimeProvider>
  );
}
