// The device's side of the envelope, under WebCrypto: what a source's and a journalist's browser do
// so the platform never sees a key or a plaintext (ADR 0004). It interoperates byte for byte with
// clients/python/src/acme/clients/api/sealing.py: a report is sealed once under a fresh 256-bit key
// (AES-256-GCM, a 12-byte nonce in front); that key is wrapped for each recipient's public key (ECDH
// on P-256, an ephemeral key per wrap, HKDF-SHA256 with an empty salt, AES-256-GCM). Every value on
// the wire is standard base64; a public key is the raw uncompressed point.

export const ALGORITHM = "p256-hkdf-sha256-aesgcm-v1";

const WRAP_INFO = new TextEncoder().encode("free-journalism key wrap v1");
const NONCE = 12;
const POINT = 65;
const EC = { name: "ECDH", namedCurve: "P-256" } as const;

const subtle = (): SubtleCrypto => globalThis.crypto.subtle;

export function toBase64(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

export function fromBase64(text: string): Uint8Array<ArrayBuffer> {
  const binary = atob(text);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function randomBytes(length: number): Uint8Array<ArrayBuffer> {
  return globalThis.crypto.getRandomValues(new Uint8Array(length));
}

function concat(...parts: Uint8Array[]): Uint8Array<ArrayBuffer> {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

/**
 * A device key pair. The private half is not extractable unless asked: it is used here and kept in
 * the key store, never exported.
 */
export async function generateKeyPair(extractable = false): Promise<CryptoKeyPair> {
  return (await subtle().generateKey(EC, extractable, ["deriveBits"])) as CryptoKeyPair;
}

/** The public key as the platform stores it: base64 of the raw uncompressed point. */
export async function exportPublicKey(key: CryptoKey): Promise<string> {
  return toBase64(new Uint8Array(await subtle().exportKey("raw", key)));
}

export async function importPublicKey(publicKey: string): Promise<CryptoKey> {
  return subtle().importKey("raw", fromBase64(publicKey), EC, true, []);
}

/** A private key given as a JWK (a backup, or a test fixture), imported for use only. */
export async function importPrivateJwk(jwk: JsonWebKey, extractable = false): Promise<CryptoKey> {
  return subtle().importKey("jwk", jwk, EC, extractable, ["deriveBits"]);
}

async function keyEncryptionKey(privateKey: CryptoKey, publicKey: CryptoKey): Promise<CryptoKey> {
  const shared = await subtle().deriveBits({ name: "ECDH", public: publicKey }, privateKey, 256);
  const ikm = await subtle().importKey("raw", shared, "HKDF", false, ["deriveBits"]);
  const kek = await subtle().deriveBits({ name: "HKDF", hash: "SHA-256", salt: new Uint8Array(0), info: WRAP_INFO }, ikm, 256);
  return subtle().importKey("raw", kek, "AES-GCM", false, ["encrypt", "decrypt"]);
}

async function aesKey(raw: Uint8Array<ArrayBuffer>): Promise<CryptoKey> {
  return subtle().importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}

/** The content key, readable only with the recipient's private key. */
export async function wrapKey(key: Uint8Array<ArrayBuffer>, recipientPublicKey: string): Promise<string> {
  const recipient = await importPublicKey(recipientPublicKey);
  const ephemeral = await generateKeyPair();
  const kek = await keyEncryptionKey(ephemeral.privateKey, recipient);
  const nonce = randomBytes(NONCE);
  const sealed = new Uint8Array(await subtle().encrypt({ name: "AES-GCM", iv: nonce }, kek, key));
  const point = new Uint8Array(await subtle().exportKey("raw", ephemeral.publicKey));
  return toBase64(concat(point, nonce, sealed));
}

/** Rejects when the key was wrapped for someone else. */
export async function unwrapKey(wrapped: string, privateKey: CryptoKey): Promise<Uint8Array<ArrayBuffer>> {
  const raw = fromBase64(wrapped);
  const ephemeral = await subtle().importKey("raw", raw.slice(0, POINT), EC, true, []);
  const kek = await keyEncryptionKey(privateKey, ephemeral);
  const nonce = raw.slice(POINT, POINT + NONCE);
  return new Uint8Array(await subtle().decrypt({ name: "AES-GCM", iv: nonce }, kek, raw.slice(POINT + NONCE)));
}

export async function seal(plaintext: Uint8Array<ArrayBuffer>, key: Uint8Array<ArrayBuffer>): Promise<string> {
  const nonce = randomBytes(NONCE);
  const sealed = new Uint8Array(await subtle().encrypt({ name: "AES-GCM", iv: nonce }, await aesKey(key), plaintext));
  return toBase64(concat(nonce, sealed));
}

export async function openSealed(ciphertext: string, key: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>> {
  const raw = fromBase64(ciphertext);
  return new Uint8Array(await subtle().decrypt({ name: "AES-GCM", iv: raw.slice(0, NONCE) }, await aesKey(key), raw.slice(NONCE)));
}

const encode = (text: string) => new TextEncoder().encode(text);
const decode = (bytes: Uint8Array) => new TextDecoder().decode(bytes);

/** One ciphertext for every recipient, and one wrapped key per recipient public key, in the order given. */
export interface SealedReport {
  ciphertext: string;
  wrappedKeys: string[];
  algorithm: string;
}

/** The whole report sealed once under a fresh key, as UTF-8 JSON. */
export async function sealReport(report: object, recipientPublicKeys: readonly string[]): Promise<SealedReport> {
  const key = randomBytes(32);
  const ciphertext = await seal(encode(JSON.stringify(report)), key);
  const wrappedKeys = await Promise.all(recipientPublicKeys.map((pk) => wrapKey(key, pk)));
  return { ciphertext, wrappedKeys, algorithm: ALGORITHM };
}

export async function openReport(ciphertext: string, wrappedKey: string, privateKey: CryptoKey): Promise<unknown> {
  return JSON.parse(decode(await openSealed(ciphertext, await unwrapKey(wrappedKey, privateKey))));
}

interface MessageBody {
  c: string;
  k: string[];
}

/**
 * A thread message: sealed under its own key, wrapped for each reader (the other party, and the
 * writer's own side so it can read back what it wrote).
 */
export async function sealMessage(text: string, recipientPublicKeys: readonly string[]): Promise<string> {
  const key = randomBytes(32);
  const body: MessageBody = { c: await seal(encode(text), key), k: await Promise.all(recipientPublicKeys.map((pk) => wrapKey(key, pk))) };
  return toBase64(encode(JSON.stringify(body)));
}

/** Tries each wrapped key; rejects when none is this reader's. */
export async function openMessage(sealedBody: string, privateKey: CryptoKey): Promise<string> {
  const body = JSON.parse(decode(fromBase64(sealedBody))) as MessageBody;
  for (const wrapped of body.k) {
    let key: Uint8Array<ArrayBuffer>;
    try {
      key = await unwrapKey(wrapped, privateKey);
    } catch {
      continue; // this wrap is someone else's
    }
    return decode(await openSealed(body.c, key));
  }
  throw new Error("this message was not sealed for these keys");
}

/** The secret a source's device keeps to follow up: 32 random bytes, base64url without padding. */
export function newReplySecret(): string {
  return toBase64(randomBytes(32)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
