import { describe, expect, it } from "vitest";
import type { ApiKeyView } from "../../api";
import { canCreate, EMPTY_KEY_FORM, keyRows, keyState, toAddApiKeyRequest } from "./apiKeysModel";

const now = new Date("2026-06-01T00:00:00Z");
const key = (id: string, over: Partial<ApiKeyView> = {}): ApiKeyView => ({
  id,
  name: `key ${id}`,
  role: "service",
  created_at: "2026-05-01T00:00:00Z",
  expires_at: "2026-07-01T00:00:00Z",
  revoked_at: null,
  ...over,
});

describe("api keys model", () => {
  it("tells an active key from a revoked one and an expired one", () => {
    expect(keyState(key("a"), now)).toBe("active");
    expect(keyState(key("b", { revoked_at: "2026-05-02T00:00:00Z" }), now)).toBe("revoked");
    expect(keyState(key("c", { expires_at: "2026-05-15T00:00:00Z" }), now)).toBe("expired");
  });

  it("lists active keys first, and offers revoke only on them", () => {
    const rows = keyRows([key("b", { revoked_at: "2026-05-02T00:00:00Z" }), key("a")], now);
    expect(rows.map((r) => [r.id, r.state, r.revocable])).toEqual([
      ["a", "active", true],
      ["b", "revoked", false],
    ]);
    expect(rows[0]?.expires).toBe("2026-07-01");
  });

  it("builds the create request in seconds", () => {
    expect(canCreate(EMPTY_KEY_FORM)).toBe(false);
    expect(toAddApiKeyRequest({ name: " ci ", role: "viewer", expiresInDays: "7" })).toEqual({ name: "ci", role: "viewer", expires_in: 604_800 });
  });
});
