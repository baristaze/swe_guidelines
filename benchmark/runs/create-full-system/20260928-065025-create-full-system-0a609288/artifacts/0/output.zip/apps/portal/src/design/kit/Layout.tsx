import type { CSSProperties, ReactNode } from "react";
import { color, font, radius, space } from "../tokens";

export function Card({ title, children, actions }: { title?: string; children: ReactNode; actions?: ReactNode }) {
  return (
    <section
      style={{ background: color.surface, border: `1px solid ${color.line}`, borderRadius: radius.md, padding: space.xl, display: "grid", gap: space.lg }}
    >
      {(title || actions) && (
        <header style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: space.md }}>
          {title && <h2 style={{ margin: 0, fontFamily: font.body, fontSize: font.size.lg }}>{title}</h2>}
          {actions}
        </header>
      )}
      {children}
    </section>
  );
}

export function Stack({ children, gap = space.md, row = false, style }: { children: ReactNode; gap?: number; row?: boolean; style?: CSSProperties }) {
  return (
    <div style={{ display: "flex", flexDirection: row ? "row" : "column", gap, alignItems: row ? "center" : "stretch", flexWrap: row ? "wrap" : "nowrap", ...style }}>
      {children}
    </div>
  );
}

type Tone = "info" | "warn" | "danger";
const tones: Record<Tone, { ink: string; paper: string }> = {
  info: { ink: color.info, paper: color.infoPaper },
  warn: { ink: color.warn, paper: color.warnPaper },
  danger: { ink: color.danger, paper: color.dangerPaper },
};

export function Banner({ tone = "info", children }: { tone?: Tone; children: ReactNode }) {
  const t = tones[tone];
  return (
    <div role={tone === "danger" ? "alert" : "status"} style={{ background: t.paper, color: t.ink, padding: `${space.sm}px ${space.lg}px`, borderRadius: radius.sm, fontFamily: font.ui, fontSize: font.size.sm }}>
      {children}
    </div>
  );
}

export function Muted({ children }: { children: ReactNode }) {
  return <span style={{ color: color.muted, fontFamily: font.ui, fontSize: font.size.sm }}>{children}</span>;
}

export function Table({ head, children }: { head: string[]; children: ReactNode }) {
  return (
    <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: font.ui, fontSize: font.size.md }}>
      <thead>
        <tr>
          {head.map((h) => (
            <th key={h} style={{ textAlign: "left", color: color.muted, fontWeight: 500, fontSize: font.size.sm, borderBottom: `1px solid ${color.line}`, padding: `${space.sm}px ${space.sm}px` }}>
              {h}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>{children}</tbody>
    </table>
  );
}

export const cellStyle: CSSProperties = { padding: `${space.sm}px ${space.sm}px`, borderBottom: `1px solid ${color.line}`, verticalAlign: "middle" };
