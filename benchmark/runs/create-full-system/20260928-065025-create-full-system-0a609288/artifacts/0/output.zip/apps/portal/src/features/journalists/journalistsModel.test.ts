import { describe, expect, it } from "vitest";
import type { JournalistView } from "../../api";
import {
  bioChanged,
  canSave,
  canStartPayouts,
  countText,
  journalistRows,
  keyActionText,
  keyStatus,
  publicLink,
  toAddJournalistRequest,
  toBioRequest,
  toPublicKeyRequest,
  toPublishedRequest,
  toStartPayoutsRequest,
  toUpdateJournalistRequest,
} from "./journalistsModel";

const j = (id: string, display_name: string, published = false): JournalistView => ({
  id,
  display_name,
  bio: "",
  public_key: null,
  published,
  payouts_ready: false,
  created_at: "2026-05-01T10:00:00Z",
  updated_at: "2026-05-02T10:00:00Z",
});

describe("journalists model", () => {
  it("lists profiles by name", () => {
    expect(journalistRows([j("2", "Zora", true), j("1", "Ada")])).toEqual([
      { id: "1", displayName: "Ada", published: false, added: "2026-05-01", updated: "2026-05-02" },
      { id: "2", displayName: "Zora", published: true, added: "2026-05-01", updated: "2026-05-02" },
    ]);
  });

  it("saves only a non-empty name that changed", () => {
    expect(canSave("  ")).toBe(false);
    expect(canSave("Ada", "Ada")).toBe(false);
    expect(canSave("Ada L.", "Ada")).toBe(true);
  });

  it("trims what it sends, and adds a profile unpublished", () => {
    expect(toAddJournalistRequest(" Ada ")).toEqual({ display_name: "Ada", bio: "", published: false });
    expect(toUpdateJournalistRequest(" Ada ")).toEqual({ display_name: "Ada" });
    expect(toBioRequest(" Covers the city. ")).toEqual({ bio: "Covers the city." });
    expect(toPublishedRequest(true)).toEqual({ published: true });
    expect(toPublicKeyRequest("BASE64")).toEqual({ public_key: "BASE64" });
  });

  it("sends a bio only when it changed", () => {
    expect(bioChanged(" Covers the city.", "Covers the city.")).toBe(false);
    expect(bioChanged("Covers the region.", "Covers the city.")).toBe(true);
  });

  it("tells where the key is", () => {
    expect(keyStatus(null, false)).toBe("none");
    expect(keyStatus(null, true)).toBe("none");
    expect(keyStatus("pk", true)).toBe("here");
    expect(keyStatus("pk", false)).toBe("elsewhere");
    expect(keyActionText("none")).toBe("Generate the key on this device");
    expect(keyActionText("elsewhere")).toMatch(/^Replace/);
  });

  it("asks payouts for a two-letter country", () => {
    expect(canStartPayouts("d")).toBe(false);
    expect(canStartPayouts("deu")).toBe(false);
    expect(canStartPayouts(" de ")).toBe(true);
    expect(toStartPayoutsRequest(" de ")).toEqual({ country: "DE" });
  });

  it("builds the shareable link from the desk and the journalist", () => {
    expect(publicLink("https://portal.example", "desk-1", "j-1")).toBe("https://portal.example/p/desk-1/j-1");
  });

  it("counts", () => {
    expect(countText(0)).toBe("No journalists yet");
    expect(countText(2)).toBe("2 journalists");
  });
});
