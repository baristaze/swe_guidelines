// The submission screen's pure rules: whether the report can be opened on this device, the thread
// as rows, who a new message is sealed for, and the desk's edit of state and tags. The server
// holds ciphertext alone; whatever is read here was opened on this device.
import type { MessageDirection, MessageView, SubmissionState, SubmissionView, UpdateSubmissionRequest } from "../../api";
import { parseTags } from "../../crypto/reportContent";
import { formatDateTime } from "../updates/updatesModel";

/**
 * `no_key`: this device holds no private key for the profile the report was sent to.
 * `cannot_open`: it holds one, but not the one the report was sealed for (the key was replaced).
 */
export type Opening = "loading" | "no_key" | "cannot_open" | "open";

export function opening(args: { keyLoading: boolean; hasKey: boolean; opening: boolean; failed: boolean }): Opening {
  if (args.keyLoading) return "loading";
  if (!args.hasKey) return "no_key";
  if (args.failed) return "cannot_open";
  return args.opening ? "loading" : "open";
}

export const OPENING_TEXT: Record<Exclude<Opening, "open">, string> = {
  loading: "Opening the report on this device…",
  no_key:
    "The private key for this profile is not on this device, so the report cannot be opened here. Open it on the device that generated the key.",
  cannot_open: "The key on this device does not open this report: it was sealed to a key that was replaced since.",
};

export const DIRECTION_LABELS: Record<MessageDirection, string> = {
  to_source: "Reply to the source",
  from_source: "From the source",
  note: "Internal note",
};

export interface MessageRow {
  id: string;
  label: string;
  when: string;
  /** Null when this device cannot open it (or has not yet). */
  text: string | null;
  fromSource: boolean;
}

export function messageRows(messages: readonly MessageView[], opened: Readonly<Record<string, string | null>> | undefined): MessageRow[] {
  return [...messages]
    .sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at) || (a.id < b.id ? -1 : 1))
    .map((m) => ({
      id: m.id,
      label: DIRECTION_LABELS[m.direction],
      when: formatDateTime(m.created_at),
      text: opened?.[m.id] ?? null,
      fromSource: m.direction === "from_source",
    }));
}

/** What the desk writes: a reply the source reads, or a note only the desk reads. */
export type Writing = Exclude<MessageDirection, "from_source">;

export const WRITING_OPTIONS: ReadonlyArray<{ value: Writing; label: string }> = [
  { value: "to_source", label: "Reply to the source" },
  { value: "note", label: "Internal note (never shown to the source)" },
];

/** A reply is sealed to the source and to the desk's own key, so the desk reads back what it wrote; a note to the desk alone. */
export function recipientsFor(direction: Writing, sourcePublicKey: string, deskPublicKey: string): string[] {
  return direction === "to_source" ? [sourcePublicKey, deskPublicKey] : [deskPublicKey];
}

export function canWrite(text: string, deskPublicKey: string | null | undefined): boolean {
  return text.trim().length > 0 && !!deskPublicKey;
}

export interface Triage {
  state: SubmissionState;
  tags: string;
}

export function triageOf(submission: SubmissionView): Triage {
  return { state: submission.state, tags: submission.tags.join(", ") };
}

/** A partial update: only what changed is sent; null when nothing did. */
export function toUpdateSubmissionRequest(draft: Triage, current: SubmissionView): UpdateSubmissionRequest | null {
  const tags = parseTags(draft.tags);
  const body: UpdateSubmissionRequest = {};
  if (draft.state !== current.state) body.state = draft.state;
  if (tags.join(",") !== current.tags.join(",")) body.tags = tags;
  return Object.keys(body).length > 0 ? body : null;
}

/** The event's time as the source entered it, or a dash. */
export function occurredText(occurredAt: string | null): string {
  return occurredAt ? occurredAt.replace("T", " ") : "—";
}
