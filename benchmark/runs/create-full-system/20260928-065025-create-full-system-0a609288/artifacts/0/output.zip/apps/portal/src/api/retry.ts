// The app's one retry policy, pure so it is tested alone; the transport in client.ts applies it.
// Only a failure that can differ on a second attempt is retried, bounded in count and spaced by
// a delay that grows and carries jitter. The query library's own retry is off (queries/client.ts).

export const MAX_ATTEMPTS = 3;
export const BASE_DELAY_MS = 300;
export const MAX_DELAY_MS = 3000;

export type Outcome =
  | { kind: "timeout" }
  | { kind: "network" }
  | { kind: "status"; status: number };

export interface Attempt {
  method: string;
  /** The creating call carries an Idempotency-Key, so a retry returns the stored answer. */
  idempotencyKey: boolean;
  outcome: Outcome;
  /** 1 for the first attempt. */
  attempt: number;
}

const TRANSIENT_STATUSES = new Set([502, 503, 504]);
const REPEATABLE_METHODS = new Set(["GET", "HEAD", "PUT", "PATCH", "DELETE"]);

export function shouldRetry({ method, idempotencyKey, outcome, attempt }: Attempt): boolean {
  if (attempt >= MAX_ATTEMPTS) return false;
  const repeatable = REPEATABLE_METHODS.has(method.toUpperCase()) || idempotencyKey;
  if (outcome.kind === "status") {
    if (!TRANSIENT_STATUSES.has(outcome.status)) return false;
    // A 503 is the service refusing before it handled the call (admission, readiness), so even
    // a POST that is not replay-safe may be sent again; a 502 or 504 may have been handled.
    return repeatable || outcome.status === 503;
  }
  // A timeout or a dropped connection may have been handled: only a replay-safe call goes again.
  return repeatable;
}

/** Full jitter over an exponential ceiling: attempt 1 waits up to BASE, attempt 2 up to 2 BASE... */
export function backoffDelay(attempt: number, random: () => number = Math.random): number {
  const ceiling = Math.min(MAX_DELAY_MS, BASE_DELAY_MS * 2 ** (attempt - 1));
  return Math.round(ceiling / 2 + (random() * ceiling) / 2);
}

/** A Retry-After in seconds wins over the backoff when it stays within the cap. */
export function retryAfterDelay(header: string | null): number | null {
  if (header === null) return null;
  const seconds = Number(header);
  if (!Number.isFinite(seconds) || seconds < 0) return null;
  const ms = seconds * 1000;
  return ms <= MAX_DELAY_MS ? ms : null;
}
