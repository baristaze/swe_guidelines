// The public profile screen's pure rules: the support form, the "send information" form and the
// sealed request it becomes, and the follow-up link the source keeps. The amount limits, whether a
// profile accepts support, and whether it can take a report are the server's decisions; the
// screen shows its refusal.
import type { AddPledgeRequest, FollowView, SubmitReportRequest, SupportMode } from "../../api";
import { parseTags, type ReportContent } from "../../crypto/reportContent";
import type { SealedReport } from "../../crypto/sealing";
import { formatDateTime } from "../updates/updatesModel";

export const CURRENCIES = ["eur", "usd", "gbp"] as const;
export type Currency = (typeof CURRENCIES)[number];

export const CURRENCY_OPTIONS: ReadonlyArray<{ value: Currency; label: string }> = CURRENCIES.map((c) => ({ value: c, label: c.toUpperCase() }));

export const MODE_OPTIONS: ReadonlyArray<{ value: SupportMode; label: string }> = [
  { value: "one_time", label: "One-time" },
  { value: "monthly", label: "Monthly" },
];

export interface SupportForm {
  amount: string;
  currency: Currency;
  mode: SupportMode;
  name: string;
}

export const EMPTY_SUPPORT_FORM: SupportForm = { amount: "5", currency: "eur", mode: "one_time", name: "" };

/** "12", "12.5", or "12,50" as minor units; null for anything else or for nothing. */
export function amountMinor(draft: string): number | null {
  const match = /^(\d{1,7})(?:[.,](\d{1,2}))?$/.exec(draft.trim());
  if (!match) return null;
  const minor = Number(match[1]) * 100 + Number((match[2] ?? "").padEnd(2, "0"));
  return minor > 0 ? minor : null;
}

export function canSupport(form: SupportForm): boolean {
  return amountMinor(form.amount) !== null;
}

export function toAddPledgeRequest(deskId: string, journalistId: string, form: SupportForm): AddPledgeRequest {
  return {
    desk_id: deskId,
    journalist_id: journalistId,
    amount_minor: amountMinor(form.amount) ?? 0,
    currency: form.currency,
    mode: form.mode,
    supporter_name: form.name.trim() || "A reader",
  };
}

export function followOf(follows: readonly FollowView[], deskId: string, journalistId: string): FollowView | undefined {
  return follows.find((f) => f.desk_id === deskId && f.journalist_id === journalistId);
}

export interface ReportForm {
  subject: string;
  description: string;
  tags: string;
  place: string;
  /** From a datetime-local input: `YYYY-MM-DDTHH:mm`, or empty. */
  occurredAt: string;
  contactEmail: string;
  /** Sent under the signed-in reader's name instead of anonymously. */
  named: boolean;
}

export const EMPTY_REPORT_FORM: ReportForm = { subject: "", description: "", tags: "", place: "", occurredAt: "", contactEmail: "", named: false };

export function contactValid(draft: string): boolean {
  const email = draft.trim();
  return email === "" || /^[^@\s]+@[^@\s]+$/.test(email);
}

export function canSendReport(form: ReportForm): boolean {
  return form.subject.trim().length > 0 && form.description.trim().length > 0 && contactValid(form.contactEmail);
}

/** What is sealed: everything the source wrote except the contact address, which the server keeps apart. */
export function toReportContent(form: ReportForm): ReportContent {
  return {
    subject: form.subject.trim(),
    description: form.description.trim(),
    tags: parseTags(form.tags),
    place: form.place.trim(),
    occurred_at: form.occurredAt || null,
    attachments: [],
  };
}

export interface Intake {
  reportId: string;
  submissionId: string;
  deskId: string;
  journalistId: string;
  sealed: SealedReport;
  sourcePublicKey: string;
  replySecret: string;
  contactEmail: string;
}

export function toSubmitReportRequest(intake: Intake): SubmitReportRequest {
  const contact = intake.contactEmail.trim();
  return {
    report_id: intake.reportId,
    ciphertext: intake.sealed.ciphertext,
    algorithm: intake.sealed.algorithm,
    source_public_key: intake.sourcePublicKey,
    reply_secret: intake.replySecret,
    contact_email: contact || null,
    recipients: [
      {
        desk_id: intake.deskId,
        journalist_id: intake.journalistId,
        submission_id: intake.submissionId,
        wrapped_key: intake.sealed.wrappedKeys[0] ?? "",
      },
    ],
  };
}

/** The source's way back: the secret rides in the fragment, which a browser never sends to a server. */
export function followUpLink(origin: string, deskId: string, submissionId: string, replySecret: string): string {
  return `${origin}/r/${deskId}/${submissionId}#${replySecret}`;
}

export interface PublicUpdateRow {
  id: string;
  body: string;
  published: string;
}

export function publicUpdateRows(updates: ReadonlyArray<{ id: string; body: string; created_at: string }>): PublicUpdateRow[] {
  return [...updates]
    .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || (a.id < b.id ? 1 : -1))
    .map((u) => ({ id: u.id, body: u.body, published: formatDateTime(u.created_at) }));
}
