import { describe, expect, it } from "vitest";
import type { MessageView, SubmissionView } from "../../api";
import { canWrite, messageRows, occurredText, opening, recipientsFor, toUpdateSubmissionRequest, triageOf } from "./submissionModel";

const submission: SubmissionView = {
  id: "s",
  report_id: "r",
  journalist_id: "j",
  state: "new",
  tags: ["water"],
  sender_name: null,
  has_contact: false,
  created_at: "2026-05-01T10:00:00Z",
  updated_at: "2026-05-01T10:00:00Z",
};

const m = (id: string, direction: MessageView["direction"], created_at: string): MessageView => ({
  id,
  submission_id: "s",
  direction,
  sealed_body: "sealed",
  author_user_id: null,
  created_at,
});

describe("submission model", () => {
  it("tells whether this device can open the report", () => {
    expect(opening({ keyLoading: true, hasKey: false, opening: false, failed: false })).toBe("loading");
    expect(opening({ keyLoading: false, hasKey: false, opening: false, failed: false })).toBe("no_key");
    expect(opening({ keyLoading: false, hasKey: true, opening: false, failed: true })).toBe("cannot_open");
    expect(opening({ keyLoading: false, hasKey: true, opening: true, failed: false })).toBe("loading");
    expect(opening({ keyLoading: false, hasKey: true, opening: false, failed: false })).toBe("open");
  });

  it("shows the thread oldest first with what this device opened", () => {
    const rows = messageRows([m("2", "to_source", "2026-05-02T10:00:00Z"), m("1", "from_source", "2026-05-01T10:00:00Z")], { "1": "Hello", "2": null });
    expect(rows.map((r) => [r.id, r.label, r.text, r.fromSource])).toEqual([
      ["1", "From the source", "Hello", true],
      ["2", "Reply to the source", null, false],
    ]);
  });

  it("seals a reply to the source and the desk, a note to the desk alone", () => {
    expect(recipientsFor("to_source", "src", "desk")).toEqual(["src", "desk"]);
    expect(recipientsFor("note", "src", "desk")).toEqual(["desk"]);
    expect(canWrite("  ", "desk")).toBe(false);
    expect(canWrite("Hi", null)).toBe(false);
    expect(canWrite("Hi", "desk")).toBe(true);
  });

  it("sends only the triage that changed", () => {
    expect(toUpdateSubmissionRequest(triageOf(submission), submission)).toBeNull();
    expect(toUpdateSubmissionRequest({ state: "useful", tags: "Water" }, submission)).toEqual({ state: "useful" });
    expect(toUpdateSubmissionRequest({ state: "new", tags: "water, city" }, submission)).toEqual({ tags: ["water", "city"] });
    expect(toUpdateSubmissionRequest({ state: "new", tags: "" }, submission)).toEqual({ tags: [] });
  });

  it("shows the event's time as entered", () => {
    expect(occurredText("2026-09-01T10:00")).toBe("2026-09-01 10:00");
    expect(occurredText(null)).toBe("—");
  });
});
