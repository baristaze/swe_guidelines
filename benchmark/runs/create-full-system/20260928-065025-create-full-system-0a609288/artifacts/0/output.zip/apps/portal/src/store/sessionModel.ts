// What the session store mirrors to the tab's session storage, and how it is read back. Pure.
import type { MembershipChoiceView } from "../api";

export interface CurrentOrg {
  id: string;
  name: string;
  slug: string;
}

/** signed_out: no bearer. choosing: the sign-in bearer, before any desk. tenant: one desk's session. */
export type Stage = "signed_out" | "choosing" | "tenant";

export interface PersistedSession {
  token: string | null;
  stage: Stage;
  memberships: MembershipChoiceView[];
  org: CurrentOrg | null;
}

export const SIGNED_OUT: PersistedSession = { token: null, stage: "signed_out", memberships: [], org: null };

export function parseSession(raw: string | null): PersistedSession {
  if (!raw) return SIGNED_OUT;
  try {
    const value = JSON.parse(raw) as Partial<PersistedSession>;
    if (typeof value.token !== "string" || !value.token) return SIGNED_OUT;
    if (value.stage === "tenant" && value.org && typeof value.org.id === "string") {
      return { token: value.token, stage: "tenant", memberships: value.memberships ?? [], org: value.org };
    }
    if (value.stage === "choosing") {
      return { token: value.token, stage: "choosing", memberships: value.memberships ?? [], org: null };
    }
  } catch {
    // unreadable: start signed out
  }
  return SIGNED_OUT;
}

export function serializeSession(session: PersistedSession): string | null {
  return session.token ? JSON.stringify(session) : null;
}
