// The shell's providers: the query cache and the router.
import { QueryClientProvider, type QueryClient } from "@tanstack/react-query";
import { RouterProvider } from "react-router/dom";
import type { createRouter } from "./routes";

export function App({ queryClient, router }: { queryClient: QueryClient; router: ReturnType<typeof createRouter> }) {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
}
