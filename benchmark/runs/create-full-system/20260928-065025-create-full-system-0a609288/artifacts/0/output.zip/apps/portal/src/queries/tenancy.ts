// The tenancy domain as the portal sees it: the desk, the person, the members, the memberships.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, type MemberView, type Role } from "../api";
import { keys, PAGE_SIZE } from "./keys";

export const tenancyCache = {
  /** Membership hints name the membership, which no route reads alone: re-read the member pages. */
  rereadMembers(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.members.all }).catch(() => {});
  },
  rereadMe(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.me.all }).catch(() => {});
  },
  rereadOrg(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.org.all }).catch(() => {});
  },
};

export function useOrg() {
  return useQuery({ queryKey: keys.org.current(), queryFn: () => api.org.get() });
}

export function useMe() {
  return useQuery({ queryKey: keys.me.current(), queryFn: () => api.me.get() });
}

export function useRenameMe() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (name: string) => api.me.update({ name }),
    onSuccess: (user) => {
      queryClient.setQueryData(keys.me.current(), user);
      queryClient.setQueriesData<MemberView[]>({ queryKey: keys.members.lists() }, (page) =>
        page?.map((m) => (m.user_id === user.id ? { ...m, name: user.name } : m)),
      );
    },
  });
}

export function useMembers(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.members.list(limit), queryFn: () => api.members.list(limit) });
}

export function useChangeRole() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ userId, role }: { userId: string; role: Role }) => api.members.updateRole(userId, role),
    onSuccess: (member) =>
      queryClient.setQueriesData<MemberView[]>({ queryKey: keys.members.lists() }, (page) =>
        page?.map((m) => (m.user_id === member.user_id ? member : m)),
      ),
  });
}

export function useRemoveMember() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (userId: string) => {
      await api.members.remove(userId);
      return userId;
    },
    onSuccess: (userId) =>
      queryClient.setQueriesData<MemberView[]>({ queryKey: keys.members.lists() }, (page) =>
        page?.filter((m) => m.user_id !== userId),
      ),
  });
}

export function useMemberships(enabled: boolean, limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.memberships.list(limit), queryFn: () => api.auth.memberships(limit), enabled });
}
