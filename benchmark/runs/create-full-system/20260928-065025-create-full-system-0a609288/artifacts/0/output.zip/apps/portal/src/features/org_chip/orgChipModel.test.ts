import { describe, expect, it } from "vitest";
import type { MembershipChoiceView } from "../../api";
import { canSwitch, deskRows, initials } from "./orgChipModel";

const m = (id: string, name: string): MembershipChoiceView => ({ org_id: id, org_name: name, org_slug: id, role: "member" });

describe("org chip model", () => {
  it("opens a list only with more than one desk", () => {
    expect(canSwitch([m("a", "A")])).toBe(false);
    expect(canSwitch([m("a", "A"), m("b", "B")])).toBe(true);
  });

  it("lists the desks by name and marks the current one", () => {
    expect(deskRows([m("b", "Beta"), m("a", "Alpha")], { id: "b", name: "Beta", slug: "b" })).toEqual([
      { orgId: "a", name: "Alpha", role: "member", current: false },
      { orgId: "b", name: "Beta", role: "member", current: true },
    ]);
  });

  it("abbreviates the desk's name", () => {
    expect(initials("the daily  record")).toBe("TD");
    expect(initials("")).toBe("");
  });
});
