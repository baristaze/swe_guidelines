// The inbox screen's pure rules: the desk's submissions as rows, newest first, and the filters on
// what is not encrypted by design, the state and the desk's own tags (ADR 0004).
import type { JournalistView, SubmissionState, SubmissionView } from "../../api";
import type { SubmissionFilter } from "../../queries/reports";
import { nameOf, formatDateTime } from "../updates/updatesModel";

export const STATE_LABELS: Record<SubmissionState, string> = {
  new: "New",
  reviewing: "Reviewing",
  "follow-up": "Follow-up",
  useful: "Useful",
  archived: "Archived",
};

export const STATES: readonly SubmissionState[] = ["new", "reviewing", "follow-up", "useful", "archived"];

export const STATE_OPTIONS: ReadonlyArray<{ value: SubmissionState; label: string }> = STATES.map((s) => ({ value: s, label: STATE_LABELS[s] }));

/** The filter's choices: every state, or any. */
export const STATE_FILTER_OPTIONS: ReadonlyArray<{ value: string; label: string }> = [{ value: "", label: "Any state" }, ...STATE_OPTIONS];

export interface SubmissionRow {
  id: string;
  received: string;
  journalistName: string;
  stateLabel: string;
  tags: string;
  sender: string;
}

export function submissionRows(submissions: readonly SubmissionView[], journalists: readonly JournalistView[]): SubmissionRow[] {
  return [...submissions]
    .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || (a.id < b.id ? 1 : -1))
    .map((s) => ({
      id: s.id,
      received: formatDateTime(s.created_at),
      journalistName: nameOf(journalists, s.journalist_id),
      stateLabel: STATE_LABELS[s.state],
      tags: s.tags.join(", "),
      sender: s.sender_name ?? "Anonymous",
    }));
}

export function isState(value: string): value is SubmissionState {
  return (STATES as readonly string[]).includes(value);
}

export function toFilter(state: string, tagDraft: string): SubmissionFilter {
  const tag = tagDraft.trim().toLowerCase();
  return { ...(isState(state) ? { state } : {}), ...(tag ? { tag } : {}) };
}

export function inboxCountText(count: number, filtered: boolean): string {
  if (count === 0) return filtered ? "Nothing matches" : "The inbox is empty";
  return count === 1 ? "1 submission" : `${count} submissions`;
}
