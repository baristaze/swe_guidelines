import type { ErrorEvent } from "@sentry/react";
import { describe, expect, it } from "vitest";
import { ApiError } from "./api";
import { beforeSend, recordRequestId, SCRUBBED, scrubEvent, scrubUrl } from "./errorTracking";

function event(): ErrorEvent {
  return {
    type: undefined,
    request: {
      url: "https://api.example/v1/realtime/socket?ticket=abc&since=4",
      headers: { Authorization: "Bearer tok", Cookie: "s=1", "X-Api-Key": "k", "Idempotency-Key": "i", "User-Agent": "ua" },
      cookies: { s: "1" },
      data: { email: "a@b.c", password: "pw", nested: { totp_code: "123456", token: "t" } },
      query_string: "ticket=abc&limit=10",
    },
    extra: { secret: "s", kept: 1 },
    breadcrumbs: [{ category: "fetch", data: { url: "https://api.example/x?token=t&a=1", method: "GET" } }],
  };
}

describe("scrubEvent", () => {
  it("removes the credential headers, the cookies, and the credential fields", () => {
    const scrubbed = scrubEvent(event());
    expect(scrubbed.request?.headers).toEqual({
      Authorization: SCRUBBED,
      Cookie: SCRUBBED,
      "X-Api-Key": SCRUBBED,
      "Idempotency-Key": SCRUBBED,
      "User-Agent": "ua",
    });
    expect(scrubbed.request?.cookies).toBeUndefined();
    expect(scrubbed.request?.data).toEqual({ email: "a@b.c", password: SCRUBBED, nested: { totp_code: SCRUBBED, token: SCRUBBED } });
    expect(scrubbed.request?.url).toBe(`https://api.example/v1/realtime/socket?ticket=${encodeURIComponent(SCRUBBED)}&since=4`);
    expect(scrubbed.request?.query_string).toBe(`ticket=${encodeURIComponent(SCRUBBED)}&limit=10`);
    expect(scrubbed.extra).toEqual({ secret: SCRUBBED, kept: 1 });
    expect(scrubbed.breadcrumbs?.[0]?.data).toEqual({ url: `https://api.example/x?token=${encodeURIComponent(SCRUBBED)}&a=1`, method: "GET" });
  });

  it("scrubs a JSON body sent as a string and leaves any other string alone", () => {
    const withString: ErrorEvent = { type: undefined, request: { data: JSON.stringify({ api_key: "k", name: "n" }) } };
    expect(JSON.parse(scrubEvent(withString).request?.data as string)).toEqual({ api_key: SCRUBBED, name: "n" });
    const plain: ErrorEvent = { type: undefined, request: { data: "not json" } };
    expect(scrubEvent(plain).request?.data).toBe("not json");
  });

  it("leaves a URL without a query as it is", () => {
    expect(scrubUrl("https://app.example/inbox")).toBe("https://app.example/inbox");
  });
});

describe("beforeSend", () => {
  it("tags the failing call's request id, else the last response's", () => {
    recordRequestId("req-last");
    const failed = new ApiError(500, "internal", "boom", "req-failed", null);
    expect(beforeSend(event(), { originalException: failed }).tags).toEqual({ request_id: "req-failed" });
    expect(beforeSend(event(), { originalException: new Error("render") }).tags).toEqual({ request_id: "req-last" });
  });

  it("scrubs the event it sends", () => {
    expect(beforeSend(event(), {}).request?.headers?.Authorization).toBe(SCRUBBED);
  });
});
