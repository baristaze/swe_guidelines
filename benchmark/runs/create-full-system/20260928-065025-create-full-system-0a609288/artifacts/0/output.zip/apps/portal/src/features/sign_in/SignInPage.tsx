import { Banner, Button, Card, Muted, Stack, TextField } from "../../design/kit";
import { color, font, space } from "../../design/tokens";
import { useSignInVm } from "./useSignInVm";

export function SignInPage() {
  const vm = useSignInVm();

  return (
    <main style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: color.paper, padding: space.xl }}>
      <div style={{ width: "100%", maxWidth: 420, display: "grid", gap: space.lg }}>
        <h1 style={{ fontFamily: font.body, fontSize: font.size.xl, margin: 0, textAlign: "center" }}>Free Journalism</h1>
        {vm.step ? <ChooseDesk vm={vm} /> : <SignInForm vm={vm} />}
      </div>
    </main>
  );
}

type Vm = ReturnType<typeof useSignInVm>;

function SignInForm({ vm }: { vm: Vm }) {
  const signup = vm.mode === "signup";
  return (
    <Card title={signup ? "Open your desk" : "Sign in"}>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          vm.submit();
        }}
      >
        <Stack>
          {signup && (
            <TextField label="Your name" value={vm.form.displayName} onChange={(e) => vm.update("displayName", e.target.value)} autoComplete="name" />
          )}
          <TextField label="Email" type="email" value={vm.form.email} onChange={(e) => vm.update("email", e.target.value)} autoComplete="email" />
          <TextField
            label="Password"
            type="password"
            value={vm.form.password}
            onChange={(e) => vm.update("password", e.target.value)}
            autoComplete={signup ? "new-password" : "current-password"}
          />
          {!signup && vm.askTotp && (
            <TextField
              label="Authenticator code"
              inputMode="numeric"
              autoComplete="one-time-code"
              value={vm.form.totpCode}
              onChange={(e) => vm.update("totpCode", e.target.value)}
            />
          )}
          {signup && (
            <>
              <TextField label="Desk name" value={vm.form.orgName} onChange={(e) => vm.update("orgName", e.target.value)} />
              <TextField label="Desk address" value={vm.form.orgSlug} onChange={(e) => vm.update("orgSlug", e.target.value)} />
            </>
          )}
          {vm.error && <Banner tone="danger">{vm.error}</Banner>}
          <Button variant="primary" type="submit" disabled={!vm.canSubmit}>
            {vm.pending ? "Working…" : signup ? "Create desk" : "Sign in"}
          </Button>
          <Button type="button" onClick={vm.switchMode} style={{ border: "none", background: "transparent" }}>
            {signup ? "I already have an account" : "New here? Open a desk"}
          </Button>
        </Stack>
      </form>
    </Card>
  );
}

function ChooseDesk({ vm }: { vm: Vm }) {
  const step = vm.step;
  if (!step) return null;
  if (step.kind === "none") {
    return (
      <Card title="No desk yet">
        <Muted>Your account is not a member of any desk. Ask a desk's owner to invite you.</Muted>
        <Button onClick={vm.startOver}>Back to sign-in</Button>
      </Card>
    );
  }
  const choices = step.kind === "choose" ? step.memberships : [step.membership];
  return (
    <Card title="Choose a desk">
      <Stack>
        {choices.map((m) => (
          <Button key={m.org_id} onClick={() => vm.enter(m)} disabled={vm.pending} style={{ textAlign: "left" }}>
            {m.org_name} <Muted>· {m.role}</Muted>
          </Button>
        ))}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
        <Button onClick={vm.startOver} style={{ border: "none", background: "transparent" }}>
          Use another account
        </Button>
      </Stack>
    </Card>
  );
}
