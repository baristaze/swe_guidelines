// The realtime connection's state, a UI-side store: the provider writes it, the banner reads it.
import { create } from "zustand";

export type ConnectionStatus = "connecting" | "open" | "reconnecting" | "degraded" | "closed";

interface ConnectionState {
  status: ConnectionStatus;
  /** Connection cycles that failed in a row; past one, the app polls and shows the banner. */
  failedCycles: number;
  set: (status: ConnectionStatus, failedCycles?: number) => void;
  reset: () => void;
}

export const useConnection = create<ConnectionState>()((set) => ({
  status: "connecting",
  failedCycles: 0,
  set: (status, failedCycles) => set((s) => ({ status, failedCycles: failedCycles ?? s.failedCycles })),
  reset: () => set({ status: "connecting", failedCycles: 0 }),
}));
