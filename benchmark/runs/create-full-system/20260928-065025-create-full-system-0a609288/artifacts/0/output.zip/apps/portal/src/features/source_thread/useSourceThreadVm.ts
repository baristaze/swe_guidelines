// The source thread view-model, outside the sign-in gate: the reply secret from the link's
// fragment (or this device's key store) reads the thread; the replies are opened with the source's
// own private key kept on this device; an answer is sealed here to the journalist's public key from
// the published profile, and to the source's own.
import { useState } from "react";
import { useLocation, useParams } from "react-router";
import { errorText } from "../../app/errorText";
import { newId } from "../../crypto/ids";
import { sealMessage } from "../../crypto/sealing";
import { useOpenedMessages, useSourceDeviceKeys } from "../../queries/device";
import { useAnswerSource, usePublishedJournalist, useSourceThread } from "../../queries/public";
import { answerRecipients, canAnswer, NO_KEYS_TEXT, replySecretOf, SOURCE_STATE_TEXT, threadRows } from "./sourceThreadModel";

export function useSourceThreadVm() {
  const { deskId = "", submissionId = "" } = useParams();
  const { hash } = useLocation();
  const keys = useSourceDeviceKeys(submissionId);
  const secret = keys.isPending ? null : replySecretOf(hash, keys.data?.replySecret);
  const thread = useSourceThread(deskId, submissionId, secret);
  const sourceKeys = keys.data ?? null;
  const journalist = usePublishedJournalist(deskId, sourceKeys?.journalistId ?? "", sourceKeys !== null);
  const opened = useOpenedMessages(submissionId, thread.data?.messages, sourceKeys?.privateKey);
  const answer = useAnswerSource();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const journalistPublicKey = sourceKeys ? journalist.data?.public_key : null;

  const send = async () => {
    if (!sourceKeys || !journalistPublicKey || !secret) return;
    setError(null);
    setSending(true);
    try {
      const sealedBody = await sealMessage(text.trim(), answerRecipients(journalistPublicKey, sourceKeys.publicKey));
      await answer.mutateAsync({ deskId, submissionId, replySecret: secret, body: { id: newId(), sealed_body: sealedBody } });
      setText("");
    } catch (e) {
      setError(errorText(e));
    } finally {
      setSending(false);
    }
  };

  return {
    loading: keys.isPending || (secret !== null && thread.isPending),
    noSecret: !keys.isPending && secret === null,
    loadError: thread.error ? errorText(thread.error) : null,
    stateText: thread.data ? SOURCE_STATE_TEXT[thread.data.state] : null,
    noKeysText: !keys.isPending && !sourceKeys ? NO_KEYS_TEXT : null,
    rows: threadRows(thread.data?.messages ?? [], opened.data),
    text,
    setText,
    canSend: canAnswer(text, journalistPublicKey, !!sourceKeys) && !sending && secret !== null,
    send: () => void send(),
    sending,
    error,
  };
}
