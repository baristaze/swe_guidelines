import { describe, expect, it } from "vitest";
import { Cursor } from "./cursor";

describe("Cursor", () => {
  it("starts at the hello frame's head", () => {
    const c = new Cursor();
    expect(c.head(40, true)).toBe("ok");
    expect(c.last).toBe(40);
  });

  it("applies the next seq and ignores one already seen", () => {
    const c = new Cursor();
    c.head(40, true);
    expect(c.offer(41)).toBe("apply");
    expect(c.offer(41)).toBe("duplicate");
    expect(c.last).toBe(41);
  });

  it("calls a missing seq a gap and does not skip past it", () => {
    const c = new Cursor();
    c.head(40, true);
    expect(c.offer(42)).toBe("gap");
    expect(c.last).toBe(40);
  });

  it("calls a head above the cursor a gap, on a pong or on a reconnect's hello", () => {
    const c = new Cursor();
    c.head(40, true);
    expect(c.head(40, false)).toBe("ok");
    expect(c.head(43, false)).toBe("gap");
    expect(c.head(44, true)).toBe("gap");
    expect(c.last).toBe(40);
  });
});
