// The facade: the only names feature code uses from the API's contract. Everything else in
// src/ imports from here (through src/api), never from the generated schema.
import type { components } from "./schema";

type Schemas = components["schemas"];

export type ErrorBody = Schemas["ErrorBody"];
export type ErrorResponse = Schemas["ErrorResponse"];
export type Role = Schemas["Role"];

export type SignInRequest = Schemas["SignInRequest"];
export type SignUpRequest = Schemas["SignUpRequest"];
export type IssuedSignInView = Schemas["IssuedSignInView"];
export type MembershipChoiceView = Schemas["MembershipChoiceView"];
export type IssuedSessionView = Schemas["IssuedSessionView"];

export type OrgView = Schemas["OrgView"];
export type UserView = Schemas["UserView"];
export type UpdateUserRequest = Schemas["UpdateUserRequest"];
export type MemberView = Schemas["MemberView"];
export type UpdateMemberRoleRequest = Schemas["UpdateMemberRoleRequest"];

export type ApiKeyView = Schemas["ApiKeyView"];
export type AddApiKeyRequest = Schemas["AddApiKeyRequest"];
export type IssuedApiKeyView = Schemas["IssuedApiKeyView"];

export type EventView = Schemas["EventView"];
export type RealtimeTicketView = Schemas["RealtimeTicketView"];

// The desk's journalist profiles.
export type JournalistView = Schemas["JournalistView"];
export type AddJournalistRequest = Schemas["AddJournalistRequest"];
export type UpdateJournalistRequest = Schemas["UpdateJournalistRequest"];
export type StartPayoutsRequest = Schemas["StartPayoutsRequest"];
export type PayoutOnboardingView = Schemas["PayoutOnboardingView"];
/** A published profile, as anyone with the desk's link reads it. */
export type PublishedJournalistView = Schemas["PublishedJournalistView"];

// A reader's follows and the feed of the journalists they follow.
export type FollowView = Schemas["FollowView"];
export type AddFollowRequest = Schemas["AddFollowRequest"];
export type FeedItemView = Schemas["FeedItemView"];

// The desk's published updates.
export type UpdateView = Schemas["UpdateView"];
export type AddUpdateRequest = Schemas["AddUpdateRequest"];

// Support: a reader's pledges and the desk's contributions.
export type SupportMode = Schemas["SupportMode"];
export type PledgeStatus = Schemas["PledgeStatus"];
export type PledgeView = Schemas["PledgeView"];
export type StartedPledgeView = Schemas["StartedPledgeView"];
export type AddPledgeRequest = Schemas["AddPledgeRequest"];
export type ContributionView = Schemas["ContributionView"];

// Reports: the sealed intake, the desk's inbox and thread, and the source's side of it.
export type SubmissionState = Schemas["SubmissionState"];
export type MessageDirection = Schemas["MessageDirection"];
export type RecipientRequest = Schemas["RecipientRequest"];
export type SubmitReportRequest = Schemas["SubmitReportRequest"];
export type SubmissionReceiptView = Schemas["SubmissionReceiptView"];
export type SubmissionView = Schemas["SubmissionView"];
export type OpenedSubmissionView = Schemas["OpenedSubmissionView"];
export type UpdateSubmissionRequest = Schemas["UpdateSubmissionRequest"];
export type MessageView = Schemas["MessageView"];
export type AddMessageRequest = Schemas["AddMessageRequest"];
export type SourceMessageRequest = Schemas["SourceMessageRequest"];
export type SourceThreadView = Schemas["SourceThreadView"];
