// The support domain: this reader's pledges, and the contributions the desk received.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, type AddPledgeRequest, type PledgeView } from "../api";
import { placeInLists } from "./cache";
import { keys, PAGE_SIZE } from "./keys";
import { newerByUpdatedAt } from "./placement";

export const supportCache = {
  place(queryClient: QueryClient, view: PledgeView): void {
    placeInLists(queryClient, keys.pledges.lists(), view, newerByUpdatedAt);
  },
  /** A settled pledge is a contribution on the desk's side: both are read again. */
  reread(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.pledges.all }).catch(() => {});
    queryClient.invalidateQueries({ queryKey: keys.contributions.all }).catch(() => {});
  },
};

export function usePledges(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.pledges.list(limit), queryFn: () => api.support.pledges(limit) });
}

export function useContributions(limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.contributions.list(limit), queryFn: () => api.support.contributions(limit) });
}

/** Starts a pledge; the answer carries the checkout the reader pays at. */
export function usePledge() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (body: AddPledgeRequest) => api.support.pledgeTo(body),
    onSuccess: (started) => supportCache.place(queryClient, started.pledge),
  });
}

export function useCancelPledge() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.support.cancel(id),
    onSuccess: (view) => supportCache.place(queryClient, view),
  });
}
