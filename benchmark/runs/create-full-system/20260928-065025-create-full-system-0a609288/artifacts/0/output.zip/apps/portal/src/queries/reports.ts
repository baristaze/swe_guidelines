// The reports domain as the desk sees it: the inbox, one submission sealed and opened on this
// device, its state and tags, and the thread with the source.
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { api, type AddMessageRequest, type SubmissionState, type SubmissionView, type UpdateSubmissionRequest } from "../api";
import { placeInLists } from "./cache";
import { keys, PAGE_SIZE } from "./keys";
import { newerByUpdatedAt } from "./placement";

export const reportsCache = {
  /** A filtered page may no longer own a changed submission: the detail is placed, the lists read again. */
  placeSubmission(queryClient: QueryClient, view: SubmissionView): void {
    queryClient.setQueryData(keys.submissions.detail(view.id), view);
    queryClient.invalidateQueries({ queryKey: keys.submissions.lists() }).catch(() => {});
  },
  rereadSubmissions(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.submissions.lists() }).catch(() => {});
    queryClient.invalidateQueries({ queryKey: [...keys.submissions.all, "detail"] }).catch(() => {});
  },
  rereadMessages(queryClient: QueryClient): void {
    queryClient.invalidateQueries({ queryKey: keys.messages.all }).catch(() => {});
    queryClient.invalidateQueries({ queryKey: keys.sourceThreads.all }).catch(() => {});
  },
};

export interface SubmissionFilter {
  state?: SubmissionState;
  tag?: string;
}

export function useSubmissions(filter: SubmissionFilter, limit = PAGE_SIZE) {
  return useQuery({
    queryKey: keys.submissions.list(limit, filter.state, filter.tag),
    queryFn: () => api.reports.submissions({ ...filter, limit }),
  });
}

export function useSubmission(id: string) {
  return useQuery({ queryKey: keys.submissions.detail(id), queryFn: () => api.reports.submission(id) });
}

/** The sealed report and this desk's wrapped key. Each read is audited, so it is read once per visit. */
export function useSealedSubmission(id: string) {
  return useQuery({ queryKey: keys.submissions.sealed(id), queryFn: () => api.reports.sealed(id), staleTime: Infinity });
}

export function useUpdateSubmission() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: UpdateSubmissionRequest }) => api.reports.update(id, body),
    onSuccess: (view) => {
      const cached = queryClient.getQueryData<SubmissionView>(keys.submissions.detail(view.id));
      if (!cached || newerByUpdatedAt(view, cached)) reportsCache.placeSubmission(queryClient, view);
    },
  });
}

export function useMessages(submissionId: string, limit = PAGE_SIZE) {
  return useQuery({ queryKey: keys.messages.list(submissionId, limit), queryFn: () => api.reports.messages(submissionId, limit) });
}

export function useAddMessage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ submissionId, body }: { submissionId: string; body: AddMessageRequest }) => api.reports.addMessage(submissionId, body),
    onSuccess: (view) => placeInLists(queryClient, keys.messages.lists(view.submission_id), view, () => true),
  });
}
