// The sign-in screen's pure rules: what the form sends, what comes after the answer, and how a
// refusal reads. Password and slug rules stay on the server; the screen shows its refusal.
import type { MembershipChoiceView, SignInRequest, SignUpRequest } from "../../api";
import { isApiError } from "../../api";
import { errorText } from "../../app/errorText";

export type Mode = "login" | "signup";

export interface SignInForm {
  email: string;
  password: string;
  totpCode: string;
  displayName: string;
  orgName: string;
  orgSlug: string;
}

export const EMPTY_FORM: SignInForm = { email: "", password: "", totpCode: "", displayName: "", orgName: "", orgSlug: "" };

const filled = (value: string) => value.trim().length > 0;

export function canSubmit(mode: Mode, form: SignInForm): boolean {
  if (!filled(form.email) || form.password.length === 0) return false;
  if (mode === "login") return true;
  return filled(form.displayName) && filled(form.orgName) && filled(form.orgSlug);
}

export function toLoginRequest(form: SignInForm): SignInRequest {
  const code = form.totpCode.trim();
  return code ? { email: form.email.trim(), password: form.password, totp_code: code } : { email: form.email.trim(), password: form.password };
}

export function toSignUpRequest(form: SignInForm): SignUpRequest {
  return {
    email: form.email.trim(),
    password: form.password,
    display_name: form.displayName.trim(),
    org_name: form.orgName.trim(),
    org_slug: form.orgSlug.trim(),
  };
}

/** A suggestion for the desk's address from its name; the server decides what it accepts. */
export function slugFromName(name: string): string {
  return name
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 63);
}

export type NextStep =
  | { kind: "none" }
  | { kind: "enter"; membership: MembershipChoiceView }
  | { kind: "choose"; memberships: MembershipChoiceView[] };

/** One desk goes straight in, several show the picker, none say so plainly. */
export function nextStep(memberships: readonly MembershipChoiceView[]): NextStep {
  if (memberships.length === 0) return { kind: "none" };
  if (memberships.length === 1) return { kind: "enter", membership: memberships[0] as MembershipChoiceView };
  return { kind: "choose", memberships: [...memberships].sort((a, b) => a.org_name.localeCompare(b.org_name)) };
}

export function needsSecondFactor(error: unknown): boolean {
  return isApiError(error) && error.code === "second_factor_required";
}

export function signInErrorText(error: unknown): string {
  if (isApiError(error) && error.status === 429) {
    const wait = error.retryAfterSeconds;
    return wait ? `Too many attempts. Try again in ${formatWait(wait)}.` : "Too many attempts. Try again later.";
  }
  if (needsSecondFactor(error)) return "Enter the six-digit code from your authenticator app.";
  return errorText(error);
}

export function formatWait(seconds: number): string {
  if (seconds < 60) return `${Math.ceil(seconds)} s`;
  return `${Math.ceil(seconds / 60)} min`;
}
