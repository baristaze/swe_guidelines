// Everything that belongs to one desk, dropped in one place on a switch or a sign-out: the query
// cache and every tenant store entry. The realtime socket closes with the tree that held it.
import type { QueryClient } from "@tanstack/react-query";
import { useConnection } from "./connection";

export function dropTenantState(queryClient: QueryClient): void {
  queryClient.cancelQueries().catch(() => {});
  queryClient.clear();
  useConnection.getState().reset();
}
