// The envelope router: every frame lands in the query cache (or, for the socket's own state, the
// connection store), never in a component. A hint names one entity; the router reads that one
// entity through the authorized read and places it in the cached collections, a read that finds
// nothing removing it. A collection is re-read only where placement cannot decide: at a full
// page's edge (placement.ts) or past a burst of hints. The cursor is the last contiguous seq; a
// gap is a replay from GET /v1/events after it.
import type { QueryClient } from "@tanstack/react-query";
import type { EventView, JournalistView } from "../api";
import { apiKeysCache } from "../queries/apiKeys";
import { followsCache } from "../queries/follows";
import { journalistsCache } from "../queries/journalists";
import { reportsCache } from "../queries/reports";
import { supportCache } from "../queries/support";
import { tenancyCache } from "../queries/tenancy";
import { updatesCache } from "../queries/updates";
import { Cursor } from "./cursor";
import type { ServerFrame } from "./envelopes";

export type Hint = Pick<EventView, "seq" | "kind" | "target_id" | "actor_id"> & { version?: number | null };

export interface EntityRoute {
  /** Places what one hint names. */
  apply(queryClient: QueryClient, hint: Hint): Promise<void> | void;
  /** Past a burst, one re-read of the loaded pages is cheaper than a read per entity. */
  rereadAll(queryClient: QueryClient): void;
}

export interface Readers {
  journalist: (id: string) => Promise<JournalistView | null>;
}

const action = (kind: string): string => kind.slice(kind.lastIndexOf(".") + 1);

/** A route whose hint and burst alike re-read the loaded pages: enough where one read per entity buys little. */
const rereading = (reread: (queryClient: QueryClient) => void): EntityRoute => ({ apply: reread, rereadAll: reread });

/** The routes by the hint kind's `<namespace>.<entity>` prefix. */
export function entityRoutes(readers: Readers): Record<string, EntityRoute> {
  return {
    "journalists.journalist": {
      async apply(queryClient, hint) {
        if (action(hint.kind) === "deleted") {
          journalistsCache.remove(queryClient, hint.target_id);
          return;
        }
        const view = await readers.journalist(hint.target_id);
        if (view) journalistsCache.place(queryClient, view);
        else journalistsCache.remove(queryClient, hint.target_id);
      },
      rereadAll: (queryClient) => queryClient.invalidateQueries({ queryKey: ["journalists"] }).catch(() => {}),
    },
    "tenancy.api_key": {
      apply: (queryClient) => apiKeysCache.reread(queryClient),
      rereadAll: (queryClient) => apiKeysCache.reread(queryClient),
    },
    "tenancy.membership": {
      apply: (queryClient) => tenancyCache.rereadMembers(queryClient),
      rereadAll: (queryClient) => tenancyCache.rereadMembers(queryClient),
    },
    "tenancy.user": {
      apply: (queryClient) => {
        tenancyCache.rereadMembers(queryClient);
        tenancyCache.rereadMe(queryClient);
      },
      rereadAll: (queryClient) => {
        tenancyCache.rereadMembers(queryClient);
        tenancyCache.rereadMe(queryClient);
      },
    },
    "tenancy.org": {
      apply: (queryClient) => tenancyCache.rereadOrg(queryClient),
      rereadAll: (queryClient) => tenancyCache.rereadOrg(queryClient),
    },
    "follows.follow": rereading(followsCache.reread),
    "updates.update": rereading(updatesCache.reread),
    "support.pledge": rereading(supportCache.reread),
    "reports.submission": rereading(reportsCache.rereadSubmissions),
    "reports.message": rereading(reportsCache.rereadMessages),
  };
}

export const defaultRoutes = (): Record<string, EntityRoute> => entityRoutes({ journalist: journalistsCache.read });

export function routeOf(kind: string): string {
  const parts = kind.split(".");
  return parts.slice(0, 2).join(".");
}

export interface RouterOptions {
  queryClient: QueryClient;
  listEvents: (afterSeq: number, limit: number) => Promise<EventView[]>;
  routes?: Record<string, EntityRoute>;
  /** More distinct entities than this in one batch re-reads the collection instead. */
  burstLimit?: number;
  replayPageSize?: number;
  onError?: (error: unknown) => void;
}

export interface RealtimeRouter {
  readonly cursor: Cursor;
  handle(frame: ServerFrame): Promise<void>;
  /** A replay after the cursor: on a gap, on a reconnect, and on each degraded-mode poll. */
  replay(): Promise<void>;
}

export function createRealtimeRouter(options: RouterOptions): RealtimeRouter {
  const { queryClient, listEvents } = options;
  const routes = options.routes ?? defaultRoutes();
  const burstLimit = options.burstLimit ?? 20;
  const pageSize = options.replayPageSize ?? 100;
  const onError = options.onError ?? (() => {});
  const cursor = new Cursor();
  let replaying: Promise<void> | null = null;
  let again = false;

  async function applyBatch(hints: Hint[]): Promise<void> {
    const byRoute = new Map<string, Map<string, Hint>>();
    for (const hint of hints) {
      const name = routeOf(hint.kind);
      if (!(name in routes)) continue;
      const targets = byRoute.get(name) ?? new Map<string, Hint>();
      targets.set(hint.target_id, hint); // the last hint per entity decides
      byRoute.set(name, targets);
    }
    const work: Array<Promise<void>> = [];
    for (const [name, targets] of byRoute) {
      const route = routes[name] as EntityRoute;
      if (targets.size > burstLimit) {
        route.rereadAll(queryClient);
        continue;
      }
      for (const hint of targets.values()) {
        work.push(
          Promise.resolve()
            .then(() => route.apply(queryClient, hint))
            .catch((error: unknown) => {
              onError(error);
              route.rereadAll(queryClient);
            }),
        );
      }
    }
    await Promise.all(work);
  }

  async function drain(): Promise<void> {
    for (;;) {
      if (cursor.last === null) return;
      const page = await listEvents(cursor.last, pageSize);
      const applied = page.filter((event) => cursor.offer(event.seq) === "apply");
      await applyBatch(applied);
      if (page.length === 0 || applied.length === 0) return;
    }
  }

  function replay(): Promise<void> {
    if (replaying) {
      again = true;
      return replaying;
    }
    replaying = (async () => {
      try {
        do {
          again = false;
          await drain();
        } while (again);
      } catch (error) {
        onError(error);
      } finally {
        replaying = null;
      }
    })();
    return replaying;
  }

  async function handle(frame: ServerFrame): Promise<void> {
    switch (frame.type) {
      case "hello":
      case "pong":
        if (cursor.head(frame.head_seq, frame.type === "hello") === "gap") await replay();
        return;
      case "event": {
        const verdict = cursor.offer(frame.seq);
        if (verdict === "apply") await applyBatch([frame]);
        else if (verdict === "gap") await replay();
        return;
      }
      case "error":
        onError(new Error(`realtime: ${frame.code}: ${frame.message}`));
        return;
      case "subscribed":
      case "unsubscribed":
        return;
    }
  }

  return { cursor, handle, replay };
}
