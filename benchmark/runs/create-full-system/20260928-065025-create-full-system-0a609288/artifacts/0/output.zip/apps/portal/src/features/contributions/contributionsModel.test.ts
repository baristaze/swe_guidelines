import { describe, expect, it } from "vitest";
import type { ContributionView } from "../../api";
import { contributionCountText, contributionRows } from "./contributionsModel";

const c = (id: string, received_at: string): ContributionView => ({
  id,
  journalist_id: "j",
  pledge_id: "p",
  supporter_name: "A reader",
  amount_minor: 1000,
  currency: "gbp",
  mode: "monthly",
  platform_fee_minor: 50,
  received_at,
});

describe("contributions model", () => {
  it("lists contributions newest first with the fee and what the desk keeps", () => {
    const rows = contributionRows([c("1", "2026-05-01T10:00:00Z"), c("2", "2026-05-02T10:00:00Z")], []);
    expect(rows[0]).toEqual({
      id: "2",
      received: "2026-05-02 10:00",
      journalistName: "A removed profile",
      supporter: "A reader",
      amount: "10.00 GBP",
      fee: "0.50 GBP",
      net: "9.50 GBP",
      mode: "Monthly",
    });
    expect(rows[1]?.id).toBe("1");
  });

  it("counts", () => {
    expect(contributionCountText(0)).toBe("No contributions yet");
    expect(contributionCountText(1)).toBe("1 contribution");
  });
});
