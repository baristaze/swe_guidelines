// The source thread screen's pure rules: where the reply secret comes from, how the desk's state
// reads to the source, the thread as rows, and who an answer is sealed for. A wrong secret reads as
// a missing submission; the screen says so without telling which.
import type { MessageView, SubmissionState } from "../../api";
import { formatDateTime } from "../updates/updatesModel";

/** The secret from the link's fragment, else the one this device kept when it sent the report. */
export function replySecretOf(hash: string, stored: string | null | undefined): string | null {
  const fromLink = hash.startsWith("#") ? hash.slice(1) : hash;
  return fromLink || stored || null;
}

export const SOURCE_STATE_TEXT: Record<SubmissionState, string> = {
  new: "Received, not yet read",
  reviewing: "The journalist is reviewing it",
  "follow-up": "The journalist is following it up",
  useful: "The journalist found it useful",
  archived: "Archived",
};

export interface ThreadRow {
  id: string;
  label: string;
  when: string;
  text: string | null;
  mine: boolean;
}

export function threadRows(messages: readonly MessageView[], opened: Readonly<Record<string, string | null>> | undefined): ThreadRow[] {
  return [...messages]
    .sort((a, b) => Date.parse(a.created_at) - Date.parse(b.created_at) || (a.id < b.id ? -1 : 1))
    .map((m) => ({
      id: m.id,
      label: m.direction === "from_source" ? "You" : "The journalist",
      when: formatDateTime(m.created_at),
      text: opened?.[m.id] ?? null,
      mine: m.direction === "from_source",
    }));
}

/** An answer is sealed to the journalist and to the source's own key, so this device reads back what it wrote. */
export function answerRecipients(journalistPublicKey: string, sourcePublicKey: string): string[] {
  return [journalistPublicKey, sourcePublicKey];
}

export function canAnswer(text: string, journalistPublicKey: string | null | undefined, hasKeys: boolean): boolean {
  return text.trim().length > 0 && !!journalistPublicKey && hasKeys;
}

export const NO_KEYS_TEXT =
  "The keys for this report are not on this device, so replies cannot be opened and answers cannot be sealed here. Use the browser you sent it from.";
