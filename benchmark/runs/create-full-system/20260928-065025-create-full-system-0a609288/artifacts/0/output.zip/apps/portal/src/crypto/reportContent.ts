// The plaintext inside a sealed report: what a source's device seals and a journalist's device
// opens. The server never sees it, so this shape is a contract between devices alone; a sender's
// tags and place are inside it (ADR 0004). Pure.

/** A file sealed with the report; the portal does not send any yet, so the list is always empty. */
export interface ReportAttachment {
  name: string;
  mediaType: string;
  data: string;
}

export interface ReportContent {
  subject: string;
  description: string;
  tags: string[];
  place: string;
  /** The event's local date and time as the source entered it (`YYYY-MM-DDTHH:mm`), or null. */
  occurred_at: string | null;
  attachments: ReportAttachment[];
}

const text = (value: unknown): string => (typeof value === "string" ? value : "");

/** Reads an opened report defensively: a device of another version may have sealed it. */
export function parseReportContent(value: unknown): ReportContent {
  const v = typeof value === "object" && value !== null ? (value as Record<string, unknown>) : {};
  return {
    subject: text(v.subject),
    description: text(v.description),
    tags: Array.isArray(v.tags) ? v.tags.filter((t): t is string => typeof t === "string") : [],
    place: text(v.place),
    occurred_at: typeof v.occurred_at === "string" && v.occurred_at ? v.occurred_at : null,
    attachments: [],
  };
}

/** Comma-separated tags as a list: trimmed, lower case, each once, in the order first given. */
export function parseTags(draft: string): string[] {
  const out: string[] = [];
  for (const part of draft.split(",")) {
    const tag = part.trim().toLowerCase();
    if (tag && !out.includes(tag)) out.push(tag);
  }
  return out;
}
