// The following view-model: the journalists this reader follows, unfollowed here, and the feed of
// their updates. An unfollow puts its answer into the cache and re-reads the feed it changes.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { useFeed, useFollows, useUnfollow } from "../../queries/follows";
import { feedRows, followCountText, followRows } from "./followingModel";

export function useFollowingVm() {
  const follows = useFollows();
  const feed = useFeed();
  const unfollow = useUnfollow();
  const [error, setError] = useState<string | null>(null);
  const rows = followRows(follows.data ?? [], feed.data ?? []);
  const loadError = follows.error ?? feed.error;

  return {
    loading: follows.isPending || feed.isPending,
    loadError: loadError ? errorText(loadError) : null,
    rows,
    countText: followCountText(rows.length),
    feed: feedRows(feed.data ?? []),
    error,
    unfollow: (id: string) => {
      setError(null);
      unfollow.mutate(id, { onError: (e) => setError(errorText(e)) });
    },
    unfollowing: unfollow.isPending,
  };
}
