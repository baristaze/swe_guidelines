import { describe, expect, it } from "vitest";
import { newId } from "./ids";
import { createMemoryKeyStore } from "./keyStore";
import fixture from "./pythonFixture.json";
import {
  ALGORITHM,
  exportPublicKey,
  fromBase64,
  generateKeyPair,
  importPrivateJwk,
  newReplySecret,
  openMessage,
  openReport,
  sealMessage,
  sealReport,
  unwrapKey,
  wrapKey,
} from "./sealing";

const report = { subject: "Water contract", description: "The tender was rigged.", tags: ["water"], place: "Riverside", occurred_at: null };

describe("sealing", () => {
  it("exports a public key as the raw uncompressed point", async () => {
    const pair = await generateKeyPair();
    const raw = fromBase64(await exportPublicKey(pair.publicKey));
    expect(raw.length).toBe(65);
    expect(raw[0]).toBe(0x04);
  });

  it("round-trips a report for each recipient and refuses anyone else", async () => {
    const [a, b, stranger] = await Promise.all([generateKeyPair(), generateKeyPair(), generateKeyPair()]);
    const sealed = await sealReport(report, [await exportPublicKey(a.publicKey), await exportPublicKey(b.publicKey)]);
    expect(sealed.algorithm).toBe(ALGORITHM);
    expect(sealed.wrappedKeys).toHaveLength(2);
    expect(await openReport(sealed.ciphertext, sealed.wrappedKeys[0] as string, a.privateKey)).toEqual(report);
    expect(await openReport(sealed.ciphertext, sealed.wrappedKeys[1] as string, b.privateKey)).toEqual(report);
    await expect(openReport(sealed.ciphertext, sealed.wrappedKeys[0] as string, stranger.privateKey)).rejects.toThrow();
  });

  it("wraps a key with an ephemeral point and a fresh nonce each time", async () => {
    const pair = await generateKeyPair();
    const key = globalThis.crypto.getRandomValues(new Uint8Array(32));
    const pk = await exportPublicKey(pair.publicKey);
    const [one, two] = [await wrapKey(key, pk), await wrapKey(key, pk)];
    expect(one).not.toBe(two);
    expect(fromBase64(one).length).toBe(65 + 12 + 32 + 16);
    expect(await unwrapKey(two, pair.privateKey)).toEqual(key);
  });

  it("round-trips a message for either reader", async () => {
    const [desk, source, stranger] = await Promise.all([generateKeyPair(), generateKeyPair(), generateKeyPair()]);
    const sealed = await sealMessage("Can we talk?", [await exportPublicKey(source.publicKey), await exportPublicKey(desk.publicKey)]);
    const body = JSON.parse(new TextDecoder().decode(fromBase64(sealed))) as { c: string; k: string[] };
    expect(body.k).toHaveLength(2);
    expect(await openMessage(sealed, desk.privateKey)).toBe("Can we talk?");
    expect(await openMessage(sealed, source.privateKey)).toBe("Can we talk?");
    await expect(openMessage(sealed, stranger.privateKey)).rejects.toThrow("not sealed for these keys");
  });

  it("mints a reply secret of 32 bytes, base64url without padding", () => {
    const secret = newReplySecret();
    expect(secret).toMatch(/^[A-Za-z0-9_-]{43}$/);
    expect(newReplySecret()).not.toBe(secret);
  });
});

describe("interop with the Python client", () => {
  it("opens a report and a message the Python implementation sealed", async () => {
    const privateKey = await importPrivateJwk(fixture.private_jwk);
    expect(fixture.algorithm).toBe(ALGORITHM);
    expect(await openReport(fixture.ciphertext, fixture.wrapped_key, privateKey)).toEqual(fixture.report);
    expect(await openMessage(fixture.sealed_message, privateKey)).toBe(fixture.message);
  });

  it("seals for a Python-made public key what that key's holder opens", async () => {
    // The other direction: sealed here for the Python-made key, opened with its private half. When
    // the fixture was made, sealing.py opened output of this code sealed for the same key.
    const privateKey = await importPrivateJwk(fixture.private_jwk);
    const sealed = await sealReport(report, [fixture.public_key]);
    expect(await openReport(sealed.ciphertext, sealed.wrappedKeys[0] as string, privateKey)).toEqual(report);
    expect(await openMessage(await sealMessage("ünïcode reply", [fixture.public_key]), privateKey)).toBe("ünïcode reply");
  });

  it("keeps a private key usable but not extractable", async () => {
    const privateKey = await importPrivateJwk(fixture.private_jwk);
    expect(privateKey.extractable).toBe(false);
    await expect(globalThis.crypto.subtle.exportKey("jwk", privateKey)).rejects.toThrow();
  });
});

describe("device keys", () => {
  it("keeps a journalist's key and a source's keys per id", async () => {
    const store = createMemoryKeyStore();
    const pair = await generateKeyPair();
    expect(await store.journalistKey("j1")).toBeNull();
    await store.putJournalistKey("j1", pair.privateKey);
    expect(await store.journalistKey("j1")).toBe(pair.privateKey);
    const keys = { deskId: "d", journalistId: "j1", privateKey: pair.privateKey, publicKey: "pk", replySecret: "s" };
    await store.putSourceKeys("s1", keys);
    expect(await store.sourceKeys("s1")).toEqual(keys);
    expect(await store.sourceKeys("s2")).toBeNull();
  });

  it("mints UUID v7 ids that order by time", () => {
    const zero = new Uint8Array(10);
    const early = newId(1_700_000_000_000, zero);
    const late = newId(1_700_000_000_001, zero);
    expect(early).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    expect(early < late).toBe(true);
    expect(newId()).not.toBe(newId());
  });
});
