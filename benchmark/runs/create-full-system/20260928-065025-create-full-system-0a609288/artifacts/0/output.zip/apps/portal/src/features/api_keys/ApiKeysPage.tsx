import type { Role } from "../../api";
import { Banner, Button, Card, cellStyle, Muted, SelectField, Stack, Table, TextField } from "../../design/kit";
import { color, font, space } from "../../design/tokens";
import { useApiKeysVm } from "./useApiKeysVm";

export function ApiKeysPage() {
  const vm = useApiKeysVm();

  return (
    <Stack gap={24}>
      <Card title="New API key">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            vm.create();
          }}
        >
          <Stack row>
            <TextField label="Name" value={vm.form.name} onChange={(e) => vm.update("name", e.target.value)} />
            <SelectField label="Role" value={vm.form.role} options={vm.roleOptions} onChange={(e) => vm.update("role", e.target.value as Role)} />
            <SelectField label="Expires in" value={vm.form.expiresInDays} options={vm.expiryOptions} onChange={(e) => vm.update("expiresInDays", e.target.value)} />
            <Button variant="primary" type="submit" disabled={!vm.canCreate} style={{ alignSelf: "flex-end" }}>
              Create
            </Button>
          </Stack>
        </form>
        {vm.issued && (
          <Banner tone="warn">
            <Stack gap={space.sm}>
              <span>Copy the key “{vm.issued.name}” now. It is shown once and cannot be read again.</span>
              <code style={{ fontFamily: font.mono, background: color.surface, padding: space.sm, wordBreak: "break-all" }}>{vm.issued.token}</code>
              <Button onClick={vm.dismissIssued}>I have copied it</Button>
            </Stack>
          </Banner>
        )}
        {vm.error && <Banner tone="danger">{vm.error}</Banner>}
      </Card>

      <Card title="API keys">
        {vm.loading && <Muted>Loading keys…</Muted>}
        {vm.loadError && <Banner tone="danger">{vm.loadError}</Banner>}
        {!vm.loading && vm.rows.length === 0 && <Muted>No API keys yet.</Muted>}
        {vm.rows.length > 0 && (
          <Table head={["Name", "Role", "Created", "Expires", "State", ""]}>
            {vm.rows.map((row) => (
              <tr key={row.id}>
                <td style={cellStyle}>{row.name}</td>
                <td style={cellStyle}>{row.roleLabel}</td>
                <td style={cellStyle}>{row.created}</td>
                <td style={cellStyle}>{row.expires}</td>
                <td style={cellStyle}>
                  <Muted>{row.state}</Muted>
                </td>
                <td style={{ ...cellStyle, textAlign: "right" }}>
                  {row.revocable && (
                    <Button variant="danger" disabled={vm.revoking} onClick={() => vm.revoke(row.id)}>
                      Revoke
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Card>
    </Stack>
  );
}
