// Placing one entity into a cached page, pure. A write and a hint both place the one entity they
// know about instead of re-reading the collection; the collection is read again only when
// placement cannot decide, at the edge of a full page.

export interface Identified {
  id: string;
}

export type Placement<T> = { kind: "page"; page: T[] } | { kind: "reread" };

/** The service lists by id (the UUID value, which the canonical lower-case string orders alike). */
export function byId(a: Identified, b: Identified): number {
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/**
 * Upserts `item` into `page`. `isNewer(incoming, cached)` guards against a late answer: a cached
 * row newer than the incoming one stays. A new row past the end of a full page cannot be placed,
 * since the next page may own it; that is a re-read.
 */
export function place<T extends Identified>(
  page: readonly T[],
  item: T,
  limit: number | null,
  isNewer: (incoming: T, cached: T) => boolean,
): Placement<T> {
  const index = page.findIndex((row) => row.id === item.id);
  if (index >= 0) {
    const cached = page[index] as T;
    if (!isNewer(item, cached)) return { kind: "page", page: [...page] };
    const next = [...page];
    next[index] = item;
    return { kind: "page", page: next };
  }
  const full = limit !== null && page.length >= limit;
  const last = page[page.length - 1];
  if (full && last !== undefined && byId(item, last) > 0) return { kind: "reread" };
  const next = [...page, item].sort(byId);
  if (full) next.pop();
  return { kind: "page", page: next };
}

export function removeFrom<T extends Identified>(page: readonly T[], id: string): T[] {
  return page.filter((row) => row.id !== id);
}

/** Compares ISO timestamps: the one with the later `updated_at` is the newer copy. */
export function newerByUpdatedAt<T extends { updated_at: string }>(incoming: T, cached: T): boolean {
  return Date.parse(incoming.updated_at) >= Date.parse(cached.updated_at);
}
