import { describe, expect, it } from "vitest";
import type { JournalistView, UpdateView } from "../../api";
import { canPublish, formatDateTime, journalistOptions, toAddUpdateRequest, updateCountText, updateRows } from "./updatesModel";

const j = (id: string, display_name: string, published = true): JournalistView => ({
  id,
  display_name,
  bio: "",
  public_key: null,
  published,
  payouts_ready: false,
  created_at: "2026-05-01T10:00:00Z",
  updated_at: "2026-05-01T10:00:00Z",
});
const u = (id: string, journalist_id: string, created_at: string): UpdateView => ({ id, journalist_id, body: `update ${id}`, created_at });

describe("updates model", () => {
  it("lists updates newest first under the profile's name", () => {
    const rows = updateRows([u("1", "a", "2026-05-01T10:00:00Z"), u("2", "gone", "2026-05-03T09:30:00Z")], [j("a", "Ada")]);
    expect(rows).toEqual([
      { id: "2", journalistName: "A removed profile", body: "update 2", published: "2026-05-03 09:30" },
      { id: "1", journalistName: "Ada", body: "update 1", published: "2026-05-01 10:00" },
    ]);
  });

  it("offers the profiles by name and marks the private ones", () => {
    expect(journalistOptions([j("b", "Zora", false), j("a", "Ada")])).toEqual([
      { value: "a", label: "Ada" },
      { value: "b", label: "Zora (private)" },
    ]);
  });

  it("publishes a non-empty body under a chosen profile", () => {
    expect(canPublish({ journalistId: "", body: "Hi" })).toBe(false);
    expect(canPublish({ journalistId: "a", body: "  " })).toBe(false);
    expect(canPublish({ journalistId: "a", body: "x".repeat(2001) })).toBe(false);
    expect(canPublish({ journalistId: "a", body: "Hi" })).toBe(true);
    expect(toAddUpdateRequest({ journalistId: "a", body: " Hi " })).toEqual({ journalist_id: "a", body: "Hi" });
  });

  it("formats and counts", () => {
    expect(formatDateTime("2026-05-01T10:00:59Z")).toBe("2026-05-01 10:00");
    expect(updateCountText(0)).toBe("No updates yet");
    expect(updateCountText(1)).toBe("1 update");
  });
});
