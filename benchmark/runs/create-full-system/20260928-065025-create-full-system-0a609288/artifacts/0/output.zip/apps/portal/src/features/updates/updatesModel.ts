// The updates screen's pure rules: the desk's updates as rows, newest first, under the name of the
// profile they were published under, and the publish form's request.
import type { AddUpdateRequest, JournalistView, UpdateView } from "../../api";

export const UPDATE_MAX = 2000;

export interface UpdateRow {
  id: string;
  journalistName: string;
  body: string;
  published: string;
}

/** An ISO timestamp as a UTC date and minute. */
export function formatDateTime(iso: string): string {
  return new Date(iso).toISOString().slice(0, 16).replace("T", " ");
}

export function nameOf(journalists: readonly JournalistView[], id: string): string {
  return journalists.find((j) => j.id === id)?.display_name ?? "A removed profile";
}

export function updateRows(updates: readonly UpdateView[], journalists: readonly JournalistView[]): UpdateRow[] {
  return [...updates]
    .sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at) || (a.id < b.id ? 1 : -1))
    .map((u) => ({ id: u.id, journalistName: nameOf(journalists, u.journalist_id), body: u.body, published: formatDateTime(u.created_at) }));
}

export function journalistOptions(journalists: readonly JournalistView[]): Array<{ value: string; label: string }> {
  return [...journalists]
    .sort((a, b) => a.display_name.localeCompare(b.display_name))
    .map((j) => ({ value: j.id, label: j.published ? j.display_name : `${j.display_name} (private)` }));
}

export interface UpdateForm {
  journalistId: string;
  body: string;
}

export function canPublish(form: UpdateForm): boolean {
  const body = form.body.trim();
  return form.journalistId !== "" && body.length > 0 && body.length <= UPDATE_MAX;
}

export function toAddUpdateRequest(form: UpdateForm): AddUpdateRequest {
  return { journalist_id: form.journalistId, body: form.body.trim() };
}

export function updateCountText(count: number): string {
  return count === 0 ? "No updates yet" : count === 1 ? "1 update" : `${count} updates`;
}
