// The portal's lint: the root configuration, the hooks rules, and the rule that keeps
// feature code off the generated schema (everything goes through src/api/).
import reactHooks from "eslint-plugin-react-hooks";
import tseslint from "typescript-eslint";
import root from "../../eslint.config.js";

export default tseslint.config(
  ...root,
  { ignores: ["dist/**", "src/api/schema.d.ts"] },
  reactHooks.configs.flat.recommended,
  {
    // The transport, and the one read that tells it where the API is, are the only callers of fetch.
    files: ["src/api/client.ts", "src/config.ts"],
    rules: { "no-restricted-globals": "off" },
  },
  {
    files: ["src/**/*.{ts,tsx}"],
    ignores: ["src/api/**"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          patterns: [
            {
              regex: "(^|/)api/schema(\\.d)?(\\.ts)?$",
              message: "import the facade (src/api) instead of the generated schema",
            },
          ],
        },
      ],
    },
  },
);
