// Each route's error element: reports to the error tracker (a no-op when no DSN is configured) and
// offers a way back.
import * as Sentry from "@sentry/react";
import { useEffect } from "react";
import { isRouteErrorResponse, Link, useRouteError } from "react-router";
import { Banner, Card } from "../design/kit";
import { space } from "../design/tokens";
import { errorText } from "./errorText";

export function RouteError() {
  const error = useRouteError();
  useEffect(() => {
    if (!isRouteErrorResponse(error)) Sentry.captureException(error);
  }, [error]);
  const text = isRouteErrorResponse(error) ? `${error.status} ${error.statusText}` : errorText(error);
  return (
    <div style={{ maxWidth: 560, margin: "10vh auto", padding: space.xl }}>
      <Card title="Something went wrong">
        <Banner tone="danger">{text}</Banner>
        <Link to="/">Back to your desk</Link>
      </Card>
    </div>
  );
}
