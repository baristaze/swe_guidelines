import { QueryClient } from "@tanstack/react-query";
import { describe, expect, it, vi } from "vitest";
import type { EventView, JournalistView } from "../api";
import { keys } from "../queries/keys";
import { createRealtimeRouter, entityRoutes } from "./router";

const ID_A = "00000000-0000-7000-8000-00000000000a";
const ID_B = "00000000-0000-7000-8000-00000000000b";
const ACTOR = "00000000-0000-7000-8000-0000000000ff";

const journalist = (id: string, name: string, updated_at = "2026-01-01T00:00:00Z"): JournalistView => ({
  id,
  display_name: name,
  bio: "",
  public_key: null,
  published: false,
  payouts_ready: false,
  created_at: "2026-01-01T00:00:00Z",
  updated_at,
});

const hint = (seq: number, kind: string, target_id: string): EventView => ({ seq, kind, target_id, actor_id: ACTOR, version: null });

function setup(store: Map<string, JournalistView>, events: EventView[] = []) {
  const queryClient = new QueryClient();
  queryClient.setQueryData(keys.journalists.list(100), [] as JournalistView[]);
  const reads = vi.fn(async (id: string) => store.get(id) ?? null);
  const listEvents = vi.fn(async (after: number) => events.filter((e) => e.seq > after));
  const router = createRealtimeRouter({ queryClient, listEvents, routes: entityRoutes({ journalist: reads }) });
  return { queryClient, router, reads, listEvents };
}

const list = (qc: QueryClient) => qc.getQueryData<JournalistView[]>(keys.journalists.list(100));

describe("realtime router", () => {
  it("reads the one entity a hint names and places it in the cached lists", async () => {
    const store = new Map([[ID_A, journalist(ID_A, "Ada")]]);
    const { queryClient, router, reads } = setup(store);
    await router.handle({ type: "hello", head_seq: 10 });
    await router.handle({ type: "event", ...hint(11, "journalists.journalist.created", ID_A) });
    expect(reads).toHaveBeenCalledWith(ID_A);
    expect(list(queryClient)).toEqual([journalist(ID_A, "Ada")]);
    expect(router.cursor.last).toBe(11);
  });

  it("removes an entity a read no longer finds, and one a delete hint names", async () => {
    const store = new Map<string, JournalistView>();
    const { queryClient, router } = setup(store);
    queryClient.setQueryData(keys.journalists.list(100), [journalist(ID_A, "Ada"), journalist(ID_B, "Bo")]);
    await router.handle({ type: "hello", head_seq: 0 });
    await router.handle({ type: "event", ...hint(1, "journalists.journalist.updated", ID_A) });
    await router.handle({ type: "event", ...hint(2, "journalists.journalist.deleted", ID_B) });
    expect(list(queryClient)).toEqual([]);
  });

  it("replays after the cursor on a gap instead of skipping", async () => {
    const store = new Map([
      [ID_A, journalist(ID_A, "Ada")],
      [ID_B, journalist(ID_B, "Bo")],
    ]);
    const events = [hint(11, "journalists.journalist.created", ID_A), hint(12, "journalists.journalist.created", ID_B)];
    const { queryClient, router, listEvents } = setup(store, events);
    await router.handle({ type: "hello", head_seq: 10 });
    await router.handle({ type: "event", ...hint(12, "journalists.journalist.created", ID_B) });
    expect(listEvents).toHaveBeenCalledWith(10, 100);
    expect(router.cursor.last).toBe(12);
    expect(list(queryClient)?.map((j) => j.id)).toEqual([ID_A, ID_B]);
  });

  it("treats a pong's head above the cursor as a gap", async () => {
    const store = new Map([[ID_A, journalist(ID_A, "Ada")]]);
    const { router, listEvents } = setup(store, [hint(6, "journalists.journalist.created", ID_A)]);
    await router.handle({ type: "hello", head_seq: 5 });
    await router.handle({ type: "pong", head_seq: 6 });
    expect(listEvents).toHaveBeenCalledWith(5, 100);
    expect(router.cursor.last).toBe(6);
  });

  it("never lets a late read overwrite a newer copy", async () => {
    const newer = journalist(ID_A, "Ada Lovelace", "2026-03-01T00:00:00Z");
    const store = new Map([[ID_A, journalist(ID_A, "Ada", "2026-02-01T00:00:00Z")]]);
    const { queryClient, router } = setup(store);
    queryClient.setQueryData(keys.journalists.list(100), [newer]);
    await router.handle({ type: "hello", head_seq: 0 });
    await router.handle({ type: "event", ...hint(1, "journalists.journalist.updated", ID_A) });
    expect(list(queryClient)).toEqual([newer]);
  });

  it("re-reads the collection past a burst instead of one read per entity", async () => {
    const ids = Array.from({ length: 25 }, (_, i) => `00000000-0000-7000-8000-${String(i).padStart(12, "0")}`);
    const events = ids.map((id, i) => hint(i + 1, "journalists.journalist.created", id));
    const { queryClient, router, reads } = setup(new Map(), events);
    const invalidate = vi.spyOn(queryClient, "invalidateQueries");
    await router.handle({ type: "hello", head_seq: 0 });
    await router.handle({ type: "pong", head_seq: 25 });
    expect(reads).not.toHaveBeenCalled();
    expect(invalidate).toHaveBeenCalledWith({ queryKey: ["journalists"] });
    expect(router.cursor.last).toBe(25);
  });

  it.each([
    ["follows.follow.created", ["follows"]],
    ["updates.update.created", ["updates"]],
    ["support.pledge.updated", ["pledges"]],
    ["reports.submission.created", ["submissions", "list"]],
    ["reports.message.created", ["messages"]],
  ])("re-reads the loaded pages a %s hint touches", async (kind, queryKey) => {
    const { queryClient, router } = setup(new Map());
    const invalidate = vi.spyOn(queryClient, "invalidateQueries");
    await router.handle({ type: "hello", head_seq: 0 });
    await router.handle({ type: "event", ...hint(1, kind, ID_A) });
    expect(invalidate).toHaveBeenCalledWith({ queryKey });
  });
});
