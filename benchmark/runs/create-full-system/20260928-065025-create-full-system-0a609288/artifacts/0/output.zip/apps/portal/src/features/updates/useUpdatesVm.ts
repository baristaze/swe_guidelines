// The updates view-model: publish an update under one of the desk's profiles, and list them. A
// publish puts its answer into the cache; hints from other tabs arrive through the realtime router.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { useJournalists } from "../../queries/journalists";
import { usePublishUpdate, useUpdates } from "../../queries/updates";
import { canPublish, journalistOptions, toAddUpdateRequest, UPDATE_MAX, updateCountText, updateRows, type UpdateForm } from "./updatesModel";

export function useUpdatesVm() {
  const updates = useUpdates();
  const journalists = useJournalists();
  const publish = usePublishUpdate();
  const [form, setForm] = useState<UpdateForm>({ journalistId: "", body: "" });
  const [error, setError] = useState<string | null>(null);

  const options = journalistOptions(journalists.data ?? []);
  // Until a profile is picked, the first one is.
  const current: UpdateForm = { ...form, journalistId: form.journalistId || (options[0]?.value ?? "") };
  const rows = updateRows(updates.data ?? [], journalists.data ?? []);
  const loadError = updates.error ?? journalists.error;

  return {
    loading: updates.isPending || journalists.isPending,
    loadError: loadError ? errorText(loadError) : null,
    rows,
    countText: updateCountText(rows.length),
    options,
    hasProfiles: options.length > 0,
    form: current,
    maxLength: UPDATE_MAX,
    setJournalist: (journalistId: string) => setForm((f) => ({ ...f, journalistId })),
    setBody: (body: string) => setForm((f) => ({ ...f, body })),
    error,
    canPublish: canPublish(current) && !publish.isPending,
    publish: () => {
      setError(null);
      publish.mutate(toAddUpdateRequest(current), {
        onSuccess: () => setForm((f) => ({ ...f, body: "" })),
        onError: (e) => setError(errorText(e)),
      });
    },
  };
}
