import { describe, expect, it } from "vitest";
import type { MemberView } from "../../api";
import { memberCountText, memberRows, PERSON_ROLES } from "./homeModel";

const member = (user_id: string, name: string, role: MemberView["role"]): MemberView => ({ user_id, name, role });

describe("home model", () => {
  it("lists members by role, then by name, and marks the signed-in person", () => {
    const rows = memberRows([member("3", "Cleo", "member"), member("1", "Bo", "owner"), member("2", "Ada", "member")], "2");
    expect(rows.map((r) => [r.name, r.roleLabel, r.isMe])).toEqual([
      ["Bo", "Owner", false],
      ["Ada", "Journalist", true],
      ["Cleo", "Journalist", false],
    ]);
  });

  it("offers the people's roles, not the service role", () => {
    expect(PERSON_ROLES.map((r) => r.value)).toEqual(["owner", "admin", "member", "viewer"]);
  });

  it("counts members", () => {
    expect(memberCountText(1)).toBe("1 member");
    expect(memberCountText(3)).toBe("3 members");
  });
});
