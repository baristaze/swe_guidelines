// What this device holds and opens: the keys in the key store (src/crypto/keyStore.ts) and the
// plaintexts they open, cached in memory beside the server state and dropped with it. Nothing here
// reaches the server; a key that is not on this device reads as null.
import { useQuery, useQueryClient } from "@tanstack/react-query";
import type { MessageView } from "../api";
import { keyStore, type SourceKeys } from "../crypto/keyStore";
import { openMessage, openReport } from "../crypto/sealing";
import { keys } from "./keys";

const forever = { staleTime: Infinity, retry: false } as const;

export function useJournalistDeviceKey(journalistId: string | undefined) {
  return useQuery({
    queryKey: keys.device.journalistKey(journalistId ?? ""),
    queryFn: () => keyStore().journalistKey(journalistId ?? ""),
    enabled: journalistId !== undefined,
    ...forever,
  });
}

export function useSourceDeviceKeys(submissionId: string) {
  return useQuery({ queryKey: keys.device.sourceKeys(submissionId), queryFn: () => keyStore().sourceKeys(submissionId), ...forever });
}

/** Keeps a new private key on this device and tells the cache it is here. */
export function useKeepJournalistKey() {
  const queryClient = useQueryClient();
  return async (journalistId: string, privateKey: CryptoKey): Promise<void> => {
    await keyStore().putJournalistKey(journalistId, privateKey);
    queryClient.setQueryData(keys.device.journalistKey(journalistId), privateKey);
  };
}

export function useKeepSourceKeys() {
  const queryClient = useQueryClient();
  return async (submissionId: string, sourceKeys: SourceKeys): Promise<void> => {
    await keyStore().putSourceKeys(submissionId, sourceKeys);
    queryClient.setQueryData(keys.device.sourceKeys(submissionId), sourceKeys);
  };
}

/** The report opened with this device's key; the query fails when the key does not open it. */
export function useOpenedReport(
  submissionId: string,
  sealed: { ciphertext: string; wrapped_key: string } | undefined,
  privateKey: CryptoKey | null | undefined,
) {
  return useQuery({
    queryKey: keys.device.openedReport(submissionId),
    queryFn: () => openReport(sealed?.ciphertext ?? "", sealed?.wrapped_key ?? "", privateKey as CryptoKey),
    enabled: sealed !== undefined && !!privateKey,
    ...forever,
  });
}

/** Each message opened with this device's key: its text, or null when it was not sealed for it. */
export function useOpenedMessages(submissionId: string, messages: readonly MessageView[] | undefined, privateKey: CryptoKey | null | undefined) {
  const list = messages ?? [];
  return useQuery({
    queryKey: keys.device.openedMessages(submissionId, list.map((m) => m.id)),
    queryFn: async () => {
      const opened: Record<string, string | null> = {};
      for (const m of list) opened[m.id] = await openMessage(m.sealed_body, privateKey as CryptoKey).catch(() => null);
      return opened;
    },
    enabled: messages !== undefined && !!privateKey,
    ...forever,
  });
}
