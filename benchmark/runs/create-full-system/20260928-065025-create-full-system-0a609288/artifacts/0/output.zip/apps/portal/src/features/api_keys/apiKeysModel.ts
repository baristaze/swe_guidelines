// The API keys screen's pure rules: rows with their state, the create form's request, and the
// expiry choices. The cap on a key's lifetime is the server's; the screen shows its refusal.
import type { AddApiKeyRequest, ApiKeyView, Role } from "../../api";
import { ROLE_LABELS } from "../home/homeModel";

export type KeyState = "active" | "revoked" | "expired";

export interface KeyRow {
  id: string;
  name: string;
  roleLabel: string;
  created: string;
  expires: string;
  state: KeyState;
  revocable: boolean;
}

export function keyState(key: ApiKeyView, now: Date): KeyState {
  if (key.revoked_at) return "revoked";
  return Date.parse(key.expires_at) <= now.getTime() ? "expired" : "active";
}

export function formatDate(iso: string): string {
  return new Date(iso).toISOString().slice(0, 10);
}

export function keyRows(keys: readonly ApiKeyView[], now: Date): KeyRow[] {
  const order: Record<KeyState, number> = { active: 0, expired: 1, revoked: 2 };
  return keys
    .map((k) => {
      const state = keyState(k, now);
      return {
        id: k.id,
        name: k.name,
        roleLabel: ROLE_LABELS[k.role],
        created: formatDate(k.created_at),
        expires: formatDate(k.expires_at),
        state,
        revocable: state === "active",
      };
    })
    .sort((a, b) => order[a.state] - order[b.state] || a.name.localeCompare(b.name));
}

export const KEY_ROLES: ReadonlyArray<{ value: Role; label: string }> = (["viewer", "member", "admin", "service"] as const).map((r) => ({
  value: r,
  label: ROLE_LABELS[r],
}));

export const EXPIRY_CHOICES: ReadonlyArray<{ value: string; label: string }> = [
  { value: "7", label: "7 days" },
  { value: "30", label: "30 days" },
  { value: "90", label: "90 days" },
  { value: "365", label: "1 year" },
];

export interface KeyForm {
  name: string;
  role: Role;
  expiresInDays: string;
}

export const EMPTY_KEY_FORM: KeyForm = { name: "", role: "service", expiresInDays: "30" };

export function canCreate(form: KeyForm): boolean {
  return form.name.trim().length > 0;
}

export function toAddApiKeyRequest(form: KeyForm): AddApiKeyRequest {
  return { name: form.name.trim(), role: form.role, expires_in: Number(form.expiresInDays) * 86_400 };
}
