// The journalists view-model: the desk's profiles, added, renamed, and removed, and the one being
// managed: its bio, published flag, device key, payouts, and shareable link. Every write puts its
// answer into the cache; hints from other tabs and people arrive through the realtime router. The
// key pair is generated here, the public half sent, the private half kept in this device's key
// store and never sent.
import { useState } from "react";
import { errorText } from "../../app/errorText";
import { exportPublicKey, generateKeyPair } from "../../crypto/sealing";
import { useJournalistDeviceKey, useKeepJournalistKey } from "../../queries/device";
import { useAddJournalist, useJournalists, useRemoveJournalist, useStartPayouts, useUpdateJournalist } from "../../queries/journalists";
import { useSession } from "../../store/session";
import {
  bioChanged,
  canSave,
  canStartPayouts,
  countText,
  journalistRows,
  KEY_STATUS_TEXT,
  keyActionText,
  keyStatus,
  publicLink,
  toAddJournalistRequest,
  toBioRequest,
  toPublicKeyRequest,
  toPublishedRequest,
  toStartPayoutsRequest,
  toUpdateJournalistRequest,
} from "./journalistsModel";

export function useJournalistsVm() {
  const journalists = useJournalists();
  const add = useAddJournalist();
  const update = useUpdateJournalist();
  const remove = useRemoveJournalist();
  const [newName, setNewName] = useState("");
  const [editing, setEditing] = useState<{ id: string; draft: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const deskId = useSession((s) => s.org?.id ?? "");
  const startPayouts = useStartPayouts();
  const keepKey = useKeepJournalistKey();
  const [managedId, setManagedId] = useState<string | null>(null);
  const [bioDraft, setBioDraft] = useState<string | null>(null);
  const [country, setCountry] = useState("");
  const [generating, setGenerating] = useState(false);
  const [profileError, setProfileError] = useState<string | null>(null);

  const rows = journalistRows(journalists.data ?? []);
  const onError = (e: unknown) => setError(errorText(e));
  const editedRow = editing ? rows.find((r) => r.id === editing.id) : undefined;
  const managed = journalists.data?.find((j) => j.id === managedId) ?? null;
  const deviceKey = useJournalistDeviceKey(managed?.id);
  const status = managed ? keyStatus(managed.public_key, !!deviceKey.data) : "none";
  const onProfileError = (e: unknown) => setProfileError(errorText(e));

  const generateKey = async () => {
    if (!managed) return;
    setProfileError(null);
    setGenerating(true);
    try {
      const pair = await generateKeyPair();
      const view = await update.mutateAsync({ id: managed.id, body: toPublicKeyRequest(await exportPublicKey(pair.publicKey)) });
      await keepKey(view.id, pair.privateKey);
    } catch (e) {
      onProfileError(e);
    } finally {
      setGenerating(false);
    }
  };

  return {
    loading: journalists.isPending,
    loadError: journalists.error ? errorText(journalists.error) : null,
    rows,
    countText: countText(rows.length),
    error,

    newName,
    setNewName,
    canAdd: canSave(newName) && !add.isPending,
    add: () => {
      setError(null);
      add.mutate(toAddJournalistRequest(newName), { onSuccess: () => setNewName(""), onError });
    },

    editingId: editing?.id ?? null,
    draft: editing?.draft ?? "",
    startEdit: (id: string, current: string) => setEditing({ id, draft: current }),
    setDraft: (draft: string) => setEditing((e) => (e ? { ...e, draft } : e)),
    cancelEdit: () => setEditing(null),
    canSaveEdit: editing !== null && canSave(editing.draft, editedRow?.displayName) && !update.isPending,
    saveEdit: () => {
      if (!editing) return;
      setError(null);
      update.mutate({ id: editing.id, body: toUpdateJournalistRequest(editing.draft) }, { onSuccess: () => setEditing(null), onError });
    },

    remove: (id: string) => {
      setError(null);
      remove.mutate(id, { onError });
    },
    removing: remove.isPending,

    managedId,
    manage: (id: string) => {
      setManagedId(id);
      setBioDraft(null);
      setCountry("");
      setProfileError(null);
    },
    closeProfile: () => setManagedId(null),
    managed: managed && {
      name: managed.display_name,
      published: managed.published,
      payoutsReady: managed.payouts_ready,
      link: publicLink(window.location.origin, deskId, managed.id),
      keyText: deviceKey.isPending ? "Looking for the key on this device…" : KEY_STATUS_TEXT[status],
      keyAction: keyActionText(status),
    },
    profileError,
    bioDraft: bioDraft ?? managed?.bio ?? "",
    setBioDraft,
    canSaveBio: managed !== null && bioDraft !== null && bioChanged(bioDraft, managed.bio) && !update.isPending,
    saveBio: () => {
      if (!managed || bioDraft === null) return;
      setProfileError(null);
      update.mutate({ id: managed.id, body: toBioRequest(bioDraft) }, { onSuccess: () => setBioDraft(null), onError: onProfileError });
    },
    togglePublished: () => {
      if (!managed) return;
      setProfileError(null);
      update.mutate({ id: managed.id, body: toPublishedRequest(!managed.published) }, { onError: onProfileError });
    },
    updating: update.isPending,
    generateKey: () => void generateKey(),
    generating,
    country,
    setCountry,
    canStartPayouts: canStartPayouts(country) && !startPayouts.isPending,
    startPayouts: () => {
      if (!managed) return;
      setProfileError(null);
      startPayouts.mutate(
        { id: managed.id, body: toStartPayoutsRequest(country) },
        { onSuccess: (onboarding) => window.location.assign(onboarding.url), onError: onProfileError },
      );
    },
  };
}
