// How an error reads on screen, pure: the server's own message, with its request id so a
// person can quote it to support.
import { isApiError } from "../api";

export function errorText(error: unknown): string {
  if (!error) return "";
  if (isApiError(error)) {
    if (error.code === "timeout") return "The request took too long. Try again.";
    if (error.code === "network") return "The service could not be reached. Check your connection and try again.";
    return error.requestId ? `${error.message} (request ${error.requestId})` : error.message;
  }
  return error instanceof Error ? error.message : String(error);
}
