// The routes: a published profile (/p/) and a source's thread (/r/) are reached by a link, outside
// the sign-in gate; everything else sits behind it, inside the chrome.
import { createBrowserRouter, Navigate } from "react-router";
import { ApiKeysPage } from "../features/api_keys/ApiKeysPage";
import { ContributionsPage } from "../features/contributions/ContributionsPage";
import { FollowingPage } from "../features/following/FollowingPage";
import { HomePage } from "../features/home/HomePage";
import { InboxPage } from "../features/inbox/InboxPage";
import { JournalistsPage } from "../features/journalists/JournalistsPage";
import { PledgesPage } from "../features/pledges/PledgesPage";
import { PublicProfilePage } from "../features/public_profile/PublicProfilePage";
import { SourceThreadPage } from "../features/source_thread/SourceThreadPage";
import { SubmissionPage } from "../features/submission/SubmissionPage";
import { UpdatesPage } from "../features/updates/UpdatesPage";
import { PublicShell } from "./PublicShell";
import { RequireAuth } from "./RequireAuth";
import { RouteError } from "./RouteError";
import { Shell } from "./Shell";

export function createRouter() {
  return createBrowserRouter([
    {
      element: <PublicShell />,
      errorElement: <RouteError />,
      children: [
        { path: "p/:deskId/:journalistId", element: <PublicProfilePage /> },
        { path: "r/:deskId/:submissionId", element: <SourceThreadPage /> },
      ],
    },
    {
      element: <RequireAuth />,
      errorElement: <RouteError />,
      children: [
        {
          element: <Shell />,
          errorElement: <RouteError />,
          children: [
            { index: true, element: <HomePage /> },
            { path: "journalists", element: <JournalistsPage /> },
            { path: "updates", element: <UpdatesPage /> },
            { path: "inbox", element: <InboxPage /> },
            { path: "inbox/:submissionId", element: <SubmissionPage /> },
            { path: "contributions", element: <ContributionsPage /> },
            { path: "following", element: <FollowingPage /> },
            { path: "pledges", element: <PledgesPage /> },
            { path: "api-keys", element: <ApiKeysPage /> },
            { path: "*", element: <Navigate to="/" replace /> },
          ],
        },
      ],
    },
  ]);
}
