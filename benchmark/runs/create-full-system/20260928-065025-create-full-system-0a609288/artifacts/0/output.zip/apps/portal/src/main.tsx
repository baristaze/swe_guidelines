// Awaits the config, initializes error tracking only when a DSN is set (every event scrubbed and
// tagged with the service and the request id before it leaves the tab), wires the one transport to
// the session store and the request id to error tracking, then renders.
import * as Sentry from "@sentry/react";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { APP_VERSION, configureApi } from "./api";
import { App } from "./app/App";
import { createRouter } from "./app/routes";
import { loadConfig } from "./config";
import { beforeSend, recordRequestId, SERVICE } from "./errorTracking";
import { createQueryClient } from "./queries/client";
import { getToken, useSession } from "./store/session";
import { dropTenantState } from "./store/tenant";

async function start(element: HTMLElement): Promise<void> {
  const config = await loadConfig();

  if (config.errorTrackingDsn) {
    Sentry.init({
      dsn: config.errorTrackingDsn,
      environment: config.environment,
      release: APP_VERSION,
      sendDefaultPii: false,
      initialScope: { tags: { service: SERVICE } },
      beforeSend,
    });
  }

  const queryClient = createQueryClient();
  configureApi({
    apiOrigin: config.apiOrigin,
    requestTimeoutMs: config.requestTimeoutMs,
    getToken,
    onRequestId: recordRequestId,
    onUnauthorized: () => {
      useSession.getState().clear();
      dropTenantState(queryClient);
    },
  });

  createRoot(element, {
    onUncaughtError: Sentry.reactErrorHandler(),
    onCaughtError: Sentry.reactErrorHandler(),
    onRecoverableError: Sentry.reactErrorHandler(),
  }).render(
    <StrictMode>
      <App queryClient={queryClient} router={createRouter()} />
    </StrictMode>,
  );
}

const element = document.getElementById("root");
if (element) {
  start(element).catch((error: unknown) => {
    element.textContent = `The portal could not start: ${error instanceof Error ? error.message : String(error)}`;
  });
}
