// The design tokens every browser app shares; the operator console imports these.
export const color = {
  ink: "#1c1b1a",
  muted: "#6b6760",
  paper: "#fbfaf7",
  surface: "#ffffff",
  line: "#e3dfd6",
  accent: "#b3261e",
  accentInk: "#ffffff",
  info: "#1f4e79",
  infoPaper: "#e8f0f8",
  warn: "#7a4b00",
  warnPaper: "#fff4dc",
  danger: "#9b1c1c",
  dangerPaper: "#fdecec",
} as const;

export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 40 } as const;
export const radius = { sm: 4, md: 8, pill: 999 } as const;

export const font = {
  body: "Georgia, 'Times New Roman', serif",
  ui: "system-ui, -apple-system, 'Segoe UI', sans-serif",
  mono: "ui-monospace, SFMono-Regular, Menlo, monospace",
  size: { sm: 13, md: 15, lg: 18, xl: 24 },
} as const;
