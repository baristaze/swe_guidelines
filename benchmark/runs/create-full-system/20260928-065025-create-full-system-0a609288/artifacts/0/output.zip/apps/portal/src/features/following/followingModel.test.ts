import { describe, expect, it } from "vitest";
import type { FeedItemView, FollowView } from "../../api";
import { feedRows, followCountText, followRows, profilePath } from "./followingModel";

const follow = (id: string, journalist_id: string, created_at: string): FollowView => ({ id, desk_id: "d", journalist_id, created_at });
const item = (id: string, journalist_id: string, created_at: string): FeedItemView => ({
  id,
  desk_id: "d",
  journalist_id,
  journalist_name: `Name ${journalist_id}`,
  body: `body ${id}`,
  created_at,
});

describe("following model", () => {
  it("names a follow by the feed, and links its page", () => {
    const rows = followRows([follow("f1", "a", "2026-05-01T10:00:00Z"), follow("f2", "b", "2026-05-02T10:00:00Z")], [item("u1", "a", "2026-05-03T10:00:00Z")]);
    expect(rows).toEqual([
      { id: "f2", name: "A journalist", path: "/p/d/b", since: "2026-05-02" },
      { id: "f1", name: "Name a", path: "/p/d/a", since: "2026-05-01" },
    ]);
  });

  it("shows the feed newest first", () => {
    const rows = feedRows([item("u1", "a", "2026-05-01T10:00:00Z"), item("u2", "a", "2026-05-02T08:15:00Z")]);
    expect(rows.map((r) => [r.id, r.published])).toEqual([
      ["u2", "2026-05-02 08:15"],
      ["u1", "2026-05-01 10:00"],
    ]);
  });

  it("links and counts", () => {
    expect(profilePath("d", "j")).toBe("/p/d/j");
    expect(followCountText(0)).toBe("You follow no one yet");
    expect(followCountText(2)).toBe("2 journalists");
  });
});
