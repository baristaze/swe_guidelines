import { describe, expect, it } from "vitest";
import type { MessageView } from "../../api";
import { answerRecipients, canAnswer, replySecretOf, SOURCE_STATE_TEXT, threadRows } from "./sourceThreadModel";

const m = (id: string, direction: MessageView["direction"], created_at: string): MessageView => ({
  id,
  submission_id: "s",
  direction,
  sealed_body: "sealed",
  author_user_id: null,
  created_at,
});

describe("source thread model", () => {
  it("takes the secret from the link, else from this device", () => {
    expect(replySecretOf("#abc", "kept")).toBe("abc");
    expect(replySecretOf("", "kept")).toBe("kept");
    expect(replySecretOf("#", null)).toBeNull();
    expect(replySecretOf("", undefined)).toBeNull();
  });

  it("shows the thread oldest first, the source's own answers as its own", () => {
    const rows = threadRows([m("2", "from_source", "2026-05-02T10:00:00Z"), m("1", "to_source", "2026-05-01T10:00:00Z")], { "1": "Thanks" });
    expect(rows.map((r) => [r.id, r.label, r.text, r.mine])).toEqual([
      ["1", "The journalist", "Thanks", false],
      ["2", "You", null, true],
    ]);
  });

  it("seals an answer to the journalist and the source", () => {
    expect(answerRecipients("journalist", "source")).toEqual(["journalist", "source"]);
    expect(canAnswer("Hi", "journalist", true)).toBe(true);
    expect(canAnswer("Hi", "journalist", false)).toBe(false);
    expect(canAnswer("Hi", null, true)).toBe(false);
    expect(canAnswer(" ", "journalist", true)).toBe(false);
  });

  it("tells the source where the desk stands", () => {
    expect(SOURCE_STATE_TEXT["follow-up"]).toBe("The journalist is following it up");
  });
});
