// The chrome of the pages anyone reaches by a link, outside the sign-in gate: a published profile
// and a source's thread. No socket, no org chip; only a way to the desk or to sign in.
import { Link, Outlet } from "react-router";
import { color, font, space } from "../design/tokens";
import { useSession } from "../store/session";

export function PublicShell() {
  const signedIn = useSession((s) => s.stage === "tenant");
  return (
    <div style={{ minHeight: "100vh", background: color.paper, color: color.ink }}>
      <header style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: space.lg, padding: `${space.md}px ${space.xl}px`, borderBottom: `1px solid ${color.line}`, background: color.surface, fontFamily: font.ui }}>
        <strong style={{ fontFamily: font.body, fontSize: font.size.lg }}>Free Journalism</strong>
        <Link to="/" style={{ color: color.accent }}>
          {signedIn ? "Your desk" : "Sign in"}
        </Link>
      </header>
      <main style={{ maxWidth: 760, margin: "0 auto", padding: space.xl }}>
        <Outlet />
      </main>
    </div>
  );
}
