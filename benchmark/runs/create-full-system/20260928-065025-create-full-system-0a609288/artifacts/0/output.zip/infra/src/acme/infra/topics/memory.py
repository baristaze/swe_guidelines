"""The in-process topic bus: every subscriber of this process receives each publish, at most once."""

import logging
from collections.abc import Awaitable, Callable

from acme.infra.topics import TopicPayload, Topics, TopicsInterface

logger = logging.getLogger(__name__)

Handler = Callable[[TopicPayload], Awaitable[None]]


class TopicsMemoryImpl(TopicsInterface):
    def __init__(self) -> None:
        self._subscribers: dict[Topics, list[tuple[str, Handler]]] = {}
        self.accepting = True  # a test turns it off to stand for a bus that drops

    async def publish(self, topic: Topics, payload: TopicPayload) -> bool:
        if not self.accepting:
            return False
        for consumer, handler in list(self._subscribers.get(topic, [])):
            try:
                await handler(payload)
            except Exception:
                logger.exception("topic handler failed", extra={"consumer": consumer, "topic": topic.value})
        return True

    def subscribe(self, topic: Topics, consumer: str, handler: Handler) -> Callable[[], None]:
        entry = (consumer, handler)
        self._subscribers.setdefault(topic, []).append(entry)

        def unsubscribe() -> None:
            subscribers = self._subscribers.get(topic, [])
            if entry in subscribers:
                subscribers.remove(entry)

        return unsubscribe

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        self._subscribers.clear()

    def describe(self) -> str:
        return "topics: in-process dispatcher"
