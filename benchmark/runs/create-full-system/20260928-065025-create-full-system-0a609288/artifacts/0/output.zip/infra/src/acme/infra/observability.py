"""Logging, error reporting, and tracing, configured once at a container's boot.

Every log record carries the service, the environment, the request id, and the request that caused it.
The request id reaches the filter through a context variable set by the entry point that builds the stage.
"""

import json
import logging
import sys
from contextvars import ContextVar
from typing import Any

import sentry_sdk
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from prometheus_client import Counter

OUTCOMES = Counter("acme_outcomes_total", "Outcomes of every counted subsystem", ["subsystem", "operation", "outcome"])

request_id_var: ContextVar[str | None] = ContextVar("request_id", default=None)
caused_by_var: ContextVar[str | None] = ContextVar("caused_by_request_id", default=None)

SCRUBBED_HEADERS = frozenset({"authorization", "cookie", "set-cookie", "x-api-key", "idempotency-key"})
SCRUBBED_FIELDS = frozenset({"password", "totp_code", "token", "secret", "api_key", "bearer", "ticket"})


class ContextFilter(logging.Filter):
    def __init__(self, service: str, environment: str) -> None:
        super().__init__()
        self._service = service
        self._environment = environment

    def filter(self, record: logging.LogRecord) -> bool:
        record.service = self._service
        record.environment = self._environment
        record.request_id = request_id_var.get()
        record.caused_by_request_id = caused_by_var.get()
        return True


class JsonFormatter(logging.Formatter):
    RESERVED = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__) | {"message", "asctime"}

    def format(self, record: logging.LogRecord) -> str:
        body: dict[str, Any] = {
            "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S%z"),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        for key, value in record.__dict__.items():
            if key not in self.RESERVED and not key.startswith("_"):
                body[key] = value if isinstance(value, str | int | float | bool | type(None)) else str(value)
        if record.exc_info:
            body["exc"] = self.formatException(record.exc_info)
        return json.dumps(body)


def configure_logging(service: str, environment: str, json_logs: bool, level: str) -> None:
    handler = logging.StreamHandler(sys.stderr)  # standard output stays a command's own answer
    handler.addFilter(ContextFilter(service, environment))
    if json_logs:
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(service)s %(name)s [%(request_id)s] %(message)s")
        )
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level.upper())


def _scrub(event: Any, _hint: Any) -> Any:
    request = event.get("request") or {}
    headers = request.get("headers") or {}
    for name in list(headers):
        if name.lower() in SCRUBBED_HEADERS:
            headers[name] = "[scrubbed]"
    request.pop("cookies", None)
    data = request.get("data")
    if isinstance(data, dict):
        for name in list(data):
            if name.lower() in SCRUBBED_FIELDS:
                data[name] = "[scrubbed]"
    return event


def _tag_request(event: Any, hint: Any) -> Any:
    request_id = request_id_var.get()
    if request_id is not None:
        event.setdefault("tags", {})["request_id"] = request_id
    return _scrub(event, hint)


def configure_error_tracking(dsn: str, service: str, release: str, environment: str) -> bool:
    """Off until a DSN is set; an empty value or `off` means unset, so a missing tracker never stops a boot."""
    if not dsn or dsn.strip().lower() == "off":
        return False
    sentry_sdk.init(
        dsn=dsn,
        release=release,
        environment=environment,
        send_default_pii=False,
        include_local_variables=False,
        before_send=_tag_request,
        traces_sample_rate=0.0,
    )
    sentry_sdk.set_tag("service", service)
    return True


def configure_tracing(endpoint: str, service: str, environment: str) -> bool:
    """The tracer provider exists only when an endpoint is set; otherwise the no-op tracer runs."""
    if not endpoint:
        return False
    provider = TracerProvider(
        resource=Resource.create({"service.name": service, "deployment.environment": environment})
    )
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=f"{endpoint.rstrip('/')}/v1/traces")))
    trace.set_tracer_provider(provider)
    return True


def flush() -> None:
    provider = trace.get_tracer_provider()
    shutdown = getattr(provider, "force_flush", None)
    if shutdown is not None:
        shutdown()
    sentry_sdk.flush(timeout=2)
