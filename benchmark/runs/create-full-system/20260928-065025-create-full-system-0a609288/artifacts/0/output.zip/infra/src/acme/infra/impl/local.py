"""The all-local infra root: every capability in process or on disk, for tests and the fast gate."""

from pathlib import Path

from acme.infra.buckets import BucketsInterface
from acme.infra.buckets.local import BucketsLocalImpl
from acme.infra.cache import CacheInterface, CacheScope
from acme.infra.cache.memory import CacheMemoryImpl
from acme.infra.queues import QueuesInterface
from acme.infra.queues.memory import QueuesMemoryImpl
from acme.infra.root import InfraInterface
from acme.infra.secrets import SecretsInterface
from acme.infra.secrets.file import SecretsFileImpl
from acme.infra.topics import TopicsInterface
from acme.infra.topics.memory import TopicsMemoryImpl


class InfraLocalImpl(InfraInterface):
    def __init__(self, root: Path, max_receives: int = 5) -> None:
        store: dict[str, tuple[bytes, float]] = {}
        self._caches: dict[CacheScope, CacheInterface] = {s: CacheMemoryImpl(s, store) for s in CacheScope}
        self._buckets: BucketsInterface = BucketsLocalImpl(root / "buckets")
        self._topics: TopicsInterface = TopicsMemoryImpl()
        self._queues: QueuesInterface = QueuesMemoryImpl(max_receives)
        self._secrets: SecretsInterface = SecretsFileImpl(root / "secrets.json", "acme-test")

    def get_cache(self, scope: CacheScope) -> CacheInterface:
        return self._caches[scope]

    def get_buckets(self) -> BucketsInterface:
        return self._buckets

    def get_topics(self) -> TopicsInterface:
        return self._topics

    def get_queues(self) -> QueuesInterface:
        return self._queues

    def get_secrets(self) -> SecretsInterface:
        return self._secrets

    def describe(self) -> list[str]:
        return [
            *(c.describe() for c in self._caches.values()),
            self._buckets.describe(),
            self._topics.describe(),
            self._queues.describe(),
            self._secrets.describe(),
        ]

    async def start(self) -> None:
        for capability in (self._buckets, self._topics, self._queues, self._secrets):
            await capability.start()

    async def close(self) -> None:
        for capability in (self._secrets, self._queues, self._topics, self._buckets):
            await capability.close()
