"""The configured infra root: picks each impl from settings and refuses what is only safe locally."""

from acme.infra.buckets import BucketsInterface
from acme.infra.buckets.local import BucketsLocalImpl
from acme.infra.buckets.s3 import BucketsS3Impl
from acme.infra.cache import CacheInterface, CacheScope
from acme.infra.cache.memory import CacheMemoryImpl
from acme.infra.cache.valkey import CacheValkeyImpl, ValkeyConnection
from acme.infra.exceptions import UnsafeConfiguration
from acme.infra.impl.settings import CLOUD_ENVIRONMENTS, InfraSettings
from acme.infra.queues import QueuesInterface
from acme.infra.queues.memory import QueuesMemoryImpl
from acme.infra.queues.sqs import QueuesSqsImpl
from acme.infra.root import InfraInterface
from acme.infra.secrets import SecretsInterface
from acme.infra.secrets.aws import SecretsAwsImpl
from acme.infra.secrets.file import SecretsFileImpl
from acme.infra.topics import TopicsInterface
from acme.infra.topics.memory import TopicsMemoryImpl
from acme.infra.topics.postgres import TopicsPostgresImpl


def refuse_unsafe(settings: InfraSettings) -> None:
    """Each refusal is one check that names the setting; a process that names a cloud environment exits on it."""
    if settings.environment not in CLOUD_ENVIRONMENTS:
        return
    if settings.secrets_backend == "file":
        raise UnsafeConfiguration("ACME_SECRETS_BACKEND=file is refused outside local")
    if settings.cache_backend == "memory":
        raise UnsafeConfiguration("ACME_CACHE_BACKEND=memory is a twin and is refused outside local")
    if settings.cache_url.startswith("redis://"):
        raise UnsafeConfiguration("ACME_CACHE_URL must be rediss:// outside local")
    if settings.topics_backend == "memory":
        raise UnsafeConfiguration("ACME_TOPICS_BACKEND=memory is a twin and is refused outside local")
    if settings.queues_backend == "memory":
        raise UnsafeConfiguration("ACME_QUEUES_BACKEND=memory is a twin and is refused outside local")
    if settings.buckets_backend == "local":
        raise UnsafeConfiguration("ACME_BUCKETS_BACKEND=local is refused outside local")


class InfraConfiguredImpl(InfraInterface):
    def __init__(self, settings: InfraSettings) -> None:
        refuse_unsafe(settings)
        timeout = settings.call_timeout_seconds
        self._valkey: ValkeyConnection | None = None
        if settings.cache_backend == "valkey":
            self._valkey = ValkeyConnection(settings.cache_url, settings.cache_timeout_ms)
            connection = self._valkey
            self._caches: dict[CacheScope, CacheInterface] = {s: CacheValkeyImpl(s, connection) for s in CacheScope}
        else:
            store: dict[str, tuple[bytes, float]] = {}
            self._caches = {s: CacheMemoryImpl(s, store) for s in CacheScope}

        self._buckets: BucketsInterface = (
            BucketsS3Impl(settings.buckets_prefix, settings.aws_region, settings.s3_endpoint_url, timeout)
            if settings.buckets_backend == "s3"
            else BucketsLocalImpl(settings.buckets_root)
        )
        self._topics: TopicsInterface = (
            TopicsPostgresImpl(settings.topics_url, timeout)
            if settings.topics_backend == "postgres"
            else TopicsMemoryImpl()
        )
        self._queues: QueuesInterface = (
            QueuesSqsImpl(settings.queues_prefix, settings.aws_region, settings.sqs_endpoint_url, timeout)
            if settings.queues_backend == "sqs"
            else QueuesMemoryImpl(settings.queue_max_receives)
        )
        self._secrets: SecretsInterface = (
            SecretsAwsImpl(settings.secrets_prefix, settings.aws_region, timeout)
            if settings.secrets_backend == "aws"
            else SecretsFileImpl(settings.secrets_file, settings.secrets_prefix)
        )

    def get_cache(self, scope: CacheScope) -> CacheInterface:
        return self._caches[scope]

    def get_buckets(self) -> BucketsInterface:
        return self._buckets

    def get_topics(self) -> TopicsInterface:
        return self._topics

    def get_queues(self) -> QueuesInterface:
        return self._queues

    def get_secrets(self) -> SecretsInterface:
        return self._secrets

    def describe(self) -> list[str]:
        return [
            *(c.describe() for c in self._caches.values()),
            self._buckets.describe(),
            self._topics.describe(),
            self._queues.describe(),
            self._secrets.describe(),
        ]

    async def start(self) -> None:
        if self._valkey is not None:
            await self._valkey.start()
        for capability in (self._buckets, self._topics, self._queues, self._secrets):
            await capability.start()

    async def close(self) -> None:
        for capability in (self._secrets, self._queues, self._topics, self._buckets):
            await capability.close()
        if self._valkey is not None:
            await self._valkey.close()
