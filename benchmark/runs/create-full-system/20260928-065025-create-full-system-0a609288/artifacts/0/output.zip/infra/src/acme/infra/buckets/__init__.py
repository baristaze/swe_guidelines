"""The buckets capability: large blobs, keyed by tenant, moved by presigned forms where the backend signs."""

from abc import ABC, abstractmethod
from datetime import timedelta
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class Buckets(StrEnum):
    REPORT_ATTACHMENTS = "report-attachments"  # ciphertext only: attachments are encrypted on the sender's device
    PROFILE_MEDIA = "profile-media"


class PresignedPost(BaseModel):  # a form the browser posts: the fields in order, then the file
    model_config = ConfigDict(frozen=True)

    url: str
    fields: tuple[tuple[str, str], ...]


class BucketsInterface(ABC):
    """Every call takes org_id first, and the impl prefixes every stored key with it."""

    @abstractmethod
    async def put(self, org_id: UUID, bucket: Buckets, key: str, data: bytes, content_type: str) -> None: ...

    @abstractmethod
    async def get(self, org_id: UUID, bucket: Buckets, key: str) -> bytes: ...

    @abstractmethod
    async def exists(self, org_id: UUID, bucket: Buckets, key: str) -> bool: ...

    @abstractmethod
    async def list(
        self, org_id: UUID, bucket: Buckets, prefix: str, limit: int, after: str | None = None
    ) -> list[str]: ...

    @abstractmethod
    async def delete(self, org_id: UUID, bucket: Buckets, key: str) -> None: ...

    @abstractmethod
    async def presign_get(self, org_id: UUID, bucket: Buckets, key: str, ttl: timedelta) -> str | None: ...

    @abstractmethod
    async def presign_post(
        self, org_id: UUID, bucket: Buckets, key: str, content_type: str, max_bytes: int, ttl: timedelta
    ) -> PresignedPost | None: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...
