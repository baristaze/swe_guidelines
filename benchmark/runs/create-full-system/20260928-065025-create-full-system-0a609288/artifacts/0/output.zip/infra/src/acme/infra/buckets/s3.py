"""The S3 bucket store: one bucket per `Buckets` member under a prefix, keys prefixed by tenant."""

from datetime import timedelta
from typing import Any
from uuid import UUID

import aioboto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

from acme.infra.buckets import Buckets, BucketsInterface, PresignedPost
from acme.infra.exceptions import InfraException, InfraNotFound
from acme.infra.observability import OUTCOMES


class BucketsS3Impl(BucketsInterface):
    def __init__(self, prefix: str, region: str, endpoint_url: str | None, timeout_seconds: float) -> None:
        self._prefix = prefix
        self._region = region
        self._endpoint = endpoint_url or None
        self._config = Config(
            connect_timeout=timeout_seconds, read_timeout=timeout_seconds, retries={"max_attempts": 2}
        )
        self._session = aioboto3.Session()
        self._client: Any = None
        self._client_cm: Any = None

    def _bucket(self, bucket: Buckets) -> str:
        return f"{self._prefix}-{bucket.value}"

    @staticmethod
    def _key(org_id: UUID, key: str) -> str:
        return f"{org_id}/{key}"

    async def start(self) -> None:
        self._client_cm = self._session.client(
            "s3", region_name=self._region, endpoint_url=self._endpoint, config=self._config
        )
        self._client = await self._client_cm.__aenter__()

    async def close(self) -> None:
        if self._client_cm is not None:
            await self._client_cm.__aexit__(None, None, None)
            self._client_cm = None
            self._client = None

    async def _call(self, operation: str, **kwargs: Any) -> Any:
        try:
            result = await getattr(self._client, operation)(**kwargs)
        except ClientError as exc:
            code = exc.response.get("Error", {}).get("Code", "")
            OUTCOMES.labels("buckets", operation, "not_found" if code in {"NoSuchKey", "404"} else "error").inc()
            if code in {"NoSuchKey", "404"}:
                raise InfraNotFound(f"no object in {kwargs.get('Bucket')}") from exc
            raise InfraException(f"object store refused {operation}: {code}") from exc
        except BotoCoreError as exc:
            OUTCOMES.labels("buckets", operation, "error").inc()
            raise InfraException(f"object store unreachable on {operation}") from exc
        OUTCOMES.labels("buckets", operation, "ok").inc()
        return result

    async def put(self, org_id: UUID, bucket: Buckets, key: str, data: bytes, content_type: str) -> None:
        await self._call(
            "put_object", Bucket=self._bucket(bucket), Key=self._key(org_id, key), Body=data, ContentType=content_type
        )

    async def get(self, org_id: UUID, bucket: Buckets, key: str) -> bytes:
        result = await self._call("get_object", Bucket=self._bucket(bucket), Key=self._key(org_id, key))
        async with result["Body"] as body:
            return await body.read()

    async def exists(self, org_id: UUID, bucket: Buckets, key: str) -> bool:
        try:
            await self._call("head_object", Bucket=self._bucket(bucket), Key=self._key(org_id, key))
        except InfraNotFound:
            return False
        return True

    async def list(self, org_id: UUID, bucket: Buckets, prefix: str, limit: int, after: str | None = None) -> list[str]:
        kwargs: dict[str, Any] = {
            "Bucket": self._bucket(bucket),
            "Prefix": self._key(org_id, prefix),
            "MaxKeys": limit,
        }
        if after is not None:
            kwargs["StartAfter"] = self._key(org_id, after)
        result = await self._call("list_objects_v2", **kwargs)
        strip = len(f"{org_id}/")
        return [item["Key"][strip:] for item in result.get("Contents", [])][:limit]

    async def delete(self, org_id: UUID, bucket: Buckets, key: str) -> None:
        await self._call("delete_object", Bucket=self._bucket(bucket), Key=self._key(org_id, key))

    async def presign_get(self, org_id: UUID, bucket: Buckets, key: str, ttl: timedelta) -> str | None:
        return await self._client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self._bucket(bucket), "Key": self._key(org_id, key)},
            ExpiresIn=int(ttl.total_seconds()),
        )

    async def presign_post(
        self, org_id: UUID, bucket: Buckets, key: str, content_type: str, max_bytes: int, ttl: timedelta
    ) -> PresignedPost | None:
        form = await self._client.generate_presigned_post(
            Bucket=self._bucket(bucket),
            Key=self._key(org_id, key),
            Fields={"Content-Type": content_type},
            Conditions=[{"Content-Type": content_type}, ["content-length-range", 0, max_bytes]],
            ExpiresIn=int(ttl.total_seconds()),
        )
        return PresignedPost(url=form["url"], fields=tuple((k, str(v)) for k, v in form["fields"].items()))

    def describe(self) -> str:
        return f"buckets: s3 under prefix {self._prefix} in {self._region}"
