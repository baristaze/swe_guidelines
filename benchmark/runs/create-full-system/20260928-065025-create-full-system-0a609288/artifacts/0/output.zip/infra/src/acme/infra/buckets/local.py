"""The local filesystem bucket store: the same layout as the cloud's, refusing keys that climb out."""

import asyncio
from datetime import timedelta
from pathlib import Path, PurePosixPath
from uuid import UUID

from acme.infra.buckets import Buckets, BucketsInterface, PresignedPost
from acme.infra.exceptions import InfraNotFound, InfraRefused


class BucketsLocalImpl(BucketsInterface):
    def __init__(self, root: Path) -> None:
        self._root = root

    def _path(self, org_id: UUID, bucket: Buckets, key: str) -> Path:
        pure = PurePosixPath(key)
        if pure.is_absolute() or ".." in pure.parts or not key:
            raise InfraRefused(f"bucket key {key!r} is absolute or climbs out of its root")
        return self._root / bucket.value / str(org_id) / pure

    async def put(self, org_id: UUID, bucket: Buckets, key: str, data: bytes, content_type: str) -> None:
        path = self._path(org_id, bucket, key)

        def write() -> None:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)

        await asyncio.to_thread(write)

    async def get(self, org_id: UUID, bucket: Buckets, key: str) -> bytes:
        path = self._path(org_id, bucket, key)
        if not path.is_file():
            raise InfraNotFound(f"no object {key!r} in {bucket.value}")
        return await asyncio.to_thread(path.read_bytes)

    async def exists(self, org_id: UUID, bucket: Buckets, key: str) -> bool:
        return self._path(org_id, bucket, key).is_file()

    async def list(self, org_id: UUID, bucket: Buckets, prefix: str, limit: int, after: str | None = None) -> list[str]:
        base = self._root / bucket.value / str(org_id)
        if not base.is_dir():
            return []
        keys = sorted(p.relative_to(base).as_posix() for p in base.rglob("*") if p.is_file())
        keys = [k for k in keys if k.startswith(prefix) and (after is None or k > after)]
        return keys[:limit]

    async def delete(self, org_id: UUID, bucket: Buckets, key: str) -> None:
        self._path(org_id, bucket, key).unlink(missing_ok=True)

    async def presign_get(self, org_id: UUID, bucket: Buckets, key: str, ttl: timedelta) -> str | None:
        return None  # a filesystem signs nothing; the caller moves the bytes through get

    async def presign_post(
        self, org_id: UUID, bucket: Buckets, key: str, content_type: str, max_bytes: int, ttl: timedelta
    ) -> PresignedPost | None:
        self._path(org_id, bucket, key)  # the same refusal a signed form would meet
        return None

    async def start(self) -> None:
        self._root.mkdir(parents=True, exist_ok=True)

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return f"buckets: local filesystem at {self._root}"
