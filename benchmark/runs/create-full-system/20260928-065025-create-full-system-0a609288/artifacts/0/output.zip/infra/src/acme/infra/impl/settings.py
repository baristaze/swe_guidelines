"""The infra settings: every backend is chosen here and nowhere else."""

from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict

Environment = Literal["local", "staging", "production"]
CLOUD_ENVIRONMENTS: frozenset[str] = frozenset({"staging", "production"})


class InfraSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ACME_", env_file=".env", extra="ignore", env_ignore_empty=True)

    environment: Environment = "local"
    service_name: str = "acme"
    release: str = "dev"

    cache_backend: Literal["memory", "valkey"] = "memory"
    cache_url: str = "redis://localhost:56379"
    cache_timeout_ms: int = 250

    buckets_backend: Literal["local", "s3"] = "local"
    buckets_root: Path = Path(".data/buckets")
    buckets_prefix: str = "acme-local"
    s3_endpoint_url: str = ""

    topics_backend: Literal["memory", "postgres"] = "memory"
    topics_url: str = ""

    queues_backend: Literal["memory", "sqs"] = "memory"
    queues_prefix: str = "acme-local"
    sqs_endpoint_url: str = ""
    queue_max_receives: int = 5

    secrets_backend: Literal["file", "aws"] = "file"
    secrets_file: Path = Path(".data/secrets.json")
    secrets_prefix: str = "acme-local"

    aws_region: str = "eu-central-1"
    call_timeout_seconds: float = 5.0

    log_json: bool = False
    log_level: str = "INFO"
    error_tracking_dsn: str = ""
    otel_exporter_endpoint: str = ""
