"""The operating system's trust store, installed by each console script's entry module before any other import.

Never a side effect of importing a module: a library that bound `ssl.SSLContext` first would build a
context whose settings recurse, so the entry module calls `install()` and only then imports the process.
"""

import truststore


def install() -> None:
    truststore.inject_into_ssl()
