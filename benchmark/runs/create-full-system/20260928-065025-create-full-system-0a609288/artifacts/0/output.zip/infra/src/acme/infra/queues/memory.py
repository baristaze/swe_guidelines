"""The in-process queue twin: visibility timeouts, receive counts, a dead-letter list, and no deduplication."""

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from datetime import timedelta

from acme.infra.exceptions import InfraNotFound
from acme.infra.queues import QueueDepth, QueueMessage, Queues, QueuesInterface


@dataclass
class _Held:
    body: bytes
    receive_count: int = 0
    visible_at: float = 0.0
    receipt: str | None = None


@dataclass
class _Queue:
    messages: list[_Held] = field(default_factory=list)
    dead: list[_Held] = field(default_factory=list)


class QueuesMemoryImpl(QueuesInterface):
    def __init__(self, max_receives: int) -> None:
        self._max_receives = max_receives
        self._queues: dict[Queues, _Queue] = {q: _Queue() for q in Queues}

    async def send(self, queue: Queues, body: bytes) -> None:
        self._queues[queue].messages.append(_Held(body=body))

    async def receive(
        self, queue: Queues, max_messages: int, wait: timedelta, visibility: timedelta
    ) -> list[QueueMessage]:
        deadline = time.monotonic() + wait.total_seconds()
        while True:
            now = time.monotonic()
            state = self._queues[queue]
            out: list[QueueMessage] = []
            for held in list(state.messages):
                if len(out) >= max_messages:
                    break
                if held.visible_at > now:
                    continue
                if held.receive_count >= self._max_receives:
                    state.messages.remove(held)
                    state.dead.append(held)
                    continue
                held.receive_count += 1
                held.visible_at = now + visibility.total_seconds()
                held.receipt = uuid.uuid4().hex
                out.append(QueueMessage(body=held.body, receipt=held.receipt, receive_count=held.receive_count))
            if out or now >= deadline:
                return out
            await asyncio.sleep(min(0.05, max(0.0, deadline - now)))

    def _find(self, queue: Queues, receipt: str) -> _Held:
        for held in self._queues[queue].messages:
            if held.receipt == receipt:
                return held
        raise InfraNotFound(f"no delivery with that receipt on {queue.value}")

    async def delete(self, queue: Queues, receipt: str) -> None:
        self._queues[queue].messages.remove(self._find(queue, receipt))

    async def change_visibility(self, queue: Queues, receipt: str, visibility: timedelta) -> None:
        self._find(queue, receipt).visible_at = time.monotonic() + visibility.total_seconds()

    async def depth(self, queue: Queues) -> QueueDepth:
        now = time.monotonic()
        state = self._queues[queue]
        visible = sum(1 for h in state.messages if h.visible_at <= now)
        return QueueDepth(visible=visible, in_flight=len(state.messages) - visible, dead_lettered=len(state.dead))

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return "queues: in-process twin"
