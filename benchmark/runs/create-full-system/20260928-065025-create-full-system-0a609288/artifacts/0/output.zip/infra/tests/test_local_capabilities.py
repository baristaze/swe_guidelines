"""Every capability of the local infra root, one test per operation of its interface."""

from datetime import timedelta
from pathlib import Path
from uuid import UUID, uuid4

import pytest

from acme.infra.buckets import Buckets
from acme.infra.cache import CacheScope
from acme.infra.exceptions import InfraNotFound, InfraRefused, SecretNotFound
from acme.infra.impl.local import InfraLocalImpl
from acme.infra.queues import Queues
from acme.infra.topics import EntityChangedPayload, TopicPayload, Topics

SYSTEM = UUID(int=0)


@pytest.fixture
async def infra(tmp_path: Path):  # type: ignore[no-untyped-def]
    root = InfraLocalImpl(tmp_path)
    await root.start()
    yield root
    await root.close()


def payload(org_id: UUID) -> EntityChangedPayload:
    from datetime import UTC, datetime

    return EntityChangedPayload(
        idempotency_key=uuid4(),
        produced_at=datetime.now(UTC),
        org_id=org_id,
        kind="k",
        target_id=uuid4(),
        seq=1,
        actor_id=SYSTEM,
    )


async def test_cache_get_put(infra: InfraLocalImpl) -> None:
    cache = infra.get_cache(CacheScope.NETWORK_RESPONSE)
    org = uuid4()
    assert await cache.get(org, "k") is None
    await cache.put(org, "k", b"v", timedelta(minutes=1))
    assert await cache.get(org, "k") == b"v"
    assert await cache.get(uuid4(), "k") is None  # another tenant's key never collides


async def test_cache_scopes_are_disjoint(infra: InfraLocalImpl) -> None:
    org = uuid4()
    await infra.get_cache(CacheScope.NETWORK_RESPONSE).put(org, "k", b"v", timedelta(minutes=1))
    assert await infra.get_cache(CacheScope.RATE_LIMIT).get(org, "k") is None


async def test_cache_ttl_expires(infra: InfraLocalImpl) -> None:
    cache = infra.get_cache(CacheScope.NETWORK_RESPONSE)
    org = uuid4()
    await cache.put(org, "k", b"v", timedelta(seconds=-1))
    assert await cache.get(org, "k") is None


async def test_cache_invalidate(infra: InfraLocalImpl) -> None:
    cache = infra.get_cache(CacheScope.NETWORK_RESPONSE)
    org = uuid4()
    await cache.put(org, "k", b"v", timedelta(minutes=1))
    await cache.invalidate(org, "k")
    assert await cache.get(org, "k") is None


async def test_cache_increment_counts_within_the_window(infra: InfraLocalImpl) -> None:
    cache = infra.get_cache(CacheScope.RATE_LIMIT)
    org = uuid4()
    first, _ = await cache.increment(org, "subject", timedelta(minutes=1))
    second, left = await cache.increment(org, "subject", timedelta(minutes=1))
    assert (first, second) == (1, 2)
    assert timedelta(0) < left <= timedelta(minutes=1)


async def test_buckets_put_get_exists_delete(infra: InfraLocalImpl) -> None:
    buckets = infra.get_buckets()
    org = uuid4()
    await buckets.put(org, Buckets.REPORT_ATTACHMENTS, "r/1.bin", b"ciphertext", "application/octet-stream")
    assert await buckets.exists(org, Buckets.REPORT_ATTACHMENTS, "r/1.bin")
    assert await buckets.get(org, Buckets.REPORT_ATTACHMENTS, "r/1.bin") == b"ciphertext"
    assert not await buckets.exists(uuid4(), Buckets.REPORT_ATTACHMENTS, "r/1.bin")
    await buckets.delete(org, Buckets.REPORT_ATTACHMENTS, "r/1.bin")
    with pytest.raises(InfraNotFound):
        await buckets.get(org, Buckets.REPORT_ATTACHMENTS, "r/1.bin")


async def test_buckets_list_is_bounded_and_ordered(infra: InfraLocalImpl) -> None:
    buckets = infra.get_buckets()
    org = uuid4()
    for name in ("b", "a", "c"):
        await buckets.put(org, Buckets.PROFILE_MEDIA, f"p/{name}", b"x", "image/png")
    assert await buckets.list(org, Buckets.PROFILE_MEDIA, "p/", 2) == ["p/a", "p/b"]
    assert await buckets.list(org, Buckets.PROFILE_MEDIA, "p/", 10, after="p/b") == ["p/c"]


async def test_buckets_refuse_a_key_that_climbs_out(infra: InfraLocalImpl) -> None:
    with pytest.raises(InfraRefused):
        await infra.get_buckets().put(uuid4(), Buckets.PROFILE_MEDIA, "../escape", b"x", "text/plain")
    with pytest.raises(InfraRefused):
        await infra.get_buckets().presign_post(
            uuid4(), Buckets.PROFILE_MEDIA, "/abs", "text/plain", 10, timedelta(minutes=1)
        )


async def test_buckets_presign_answers_none_locally(infra: InfraLocalImpl) -> None:
    buckets = infra.get_buckets()
    assert await buckets.presign_get(uuid4(), Buckets.PROFILE_MEDIA, "k", timedelta(minutes=1)) is None
    assert (
        await buckets.presign_post(uuid4(), Buckets.PROFILE_MEDIA, "k", "image/png", 10, timedelta(minutes=1)) is None
    )


async def test_topics_publish_reaches_subscribers(infra: InfraLocalImpl) -> None:
    topics = infra.get_topics()
    got: list[TopicPayload] = []

    async def handler(p: TopicPayload) -> None:
        got.append(p)

    unsubscribe = topics.subscribe(Topics.ENTITY_CHANGED, "test", handler)
    assert await topics.publish(Topics.ENTITY_CHANGED, payload(uuid4()))
    unsubscribe()
    assert await topics.publish(Topics.ENTITY_CHANGED, payload(uuid4()))
    assert len(got) == 1


async def test_queue_send_receive_delete(infra: InfraLocalImpl) -> None:
    queues = infra.get_queues()
    await queues.send(Queues.WEBHOOKS, b"delivery")
    got = await queues.receive(Queues.WEBHOOKS, 10, timedelta(0), timedelta(seconds=30))
    assert [m.body for m in got] == [b"delivery"]
    assert await queues.receive(Queues.WEBHOOKS, 10, timedelta(0), timedelta(seconds=30)) == []  # in flight
    await queues.delete(Queues.WEBHOOKS, got[0].receipt)
    depth = await queues.depth(Queues.WEBHOOKS)
    assert (depth.visible, depth.in_flight) == (0, 0)


async def test_queue_change_visibility_redelivers_and_never_dedupes(infra: InfraLocalImpl) -> None:
    queues = infra.get_queues()
    await queues.send(Queues.WEBHOOKS, b"same")
    await queues.send(Queues.WEBHOOKS, b"same")
    got = await queues.receive(Queues.WEBHOOKS, 1, timedelta(0), timedelta(seconds=30))
    await queues.change_visibility(Queues.WEBHOOKS, got[0].receipt, timedelta(0))
    again = await queues.receive(Queues.WEBHOOKS, 10, timedelta(0), timedelta(seconds=30))
    assert len(again) == 2 and max(m.receive_count for m in again) == 2


async def test_queue_dead_letters_after_the_last_attempt(tmp_path: Path) -> None:
    root = InfraLocalImpl(tmp_path, max_receives=1)
    queues = root.get_queues()
    await queues.send(Queues.WEBHOOKS, b"poison")
    first = await queues.receive(Queues.WEBHOOKS, 1, timedelta(0), timedelta(0))
    assert len(first) == 1
    assert await queues.receive(Queues.WEBHOOKS, 1, timedelta(0), timedelta(0)) == []
    assert (await queues.depth(Queues.WEBHOOKS)).dead_lettered == 1


async def test_secrets_put_get_has_delete(infra: InfraLocalImpl) -> None:
    secrets = infra.get_secrets()
    org = uuid4()
    assert not await secrets.has(org, "stripe-account")
    await secrets.put(org, "stripe-account", "value")
    assert await secrets.get(org, "stripe-account") == "value"
    assert not await secrets.has(uuid4(), "stripe-account")  # a name never resolves across tenants
    await secrets.delete(org, "stripe-account")
    with pytest.raises(SecretNotFound):
        await secrets.get(org, "stripe-account")


async def test_secrets_file_must_be_owner_only(tmp_path: Path) -> None:
    root = InfraLocalImpl(tmp_path)
    await root.get_secrets().put(SYSTEM, "k", "v")
    (tmp_path / "secrets.json").chmod(0o644)
    with pytest.raises(InfraRefused):
        await root.get_secrets().get(SYSTEM, "k")


def test_every_backend_describes_itself(tmp_path: Path) -> None:
    assert all(line for line in InfraLocalImpl(tmp_path).describe())
