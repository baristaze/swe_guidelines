"""The infra root: one getter per capability, with the lifecycle some capabilities have."""

from abc import ABC, abstractmethod

from acme.infra.buckets import BucketsInterface
from acme.infra.cache import CacheInterface, CacheScope
from acme.infra.queues import QueuesInterface
from acme.infra.secrets import SecretsInterface
from acme.infra.topics import TopicsInterface


class InfraInterface(ABC):
    @abstractmethod
    def get_cache(self, scope: CacheScope) -> CacheInterface: ...

    @abstractmethod
    def get_buckets(self) -> BucketsInterface: ...

    @abstractmethod
    def get_topics(self) -> TopicsInterface: ...

    @abstractmethod
    def get_queues(self) -> QueuesInterface: ...

    @abstractmethod
    def get_secrets(self) -> SecretsInterface: ...

    @abstractmethod
    def describe(self) -> list[str]: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...
