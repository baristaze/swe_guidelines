"""The inbound queue for producers outside the platform: at-least-once, never deduplicated."""

from abc import ABC, abstractmethod
from datetime import timedelta
from enum import StrEnum

from pydantic import BaseModel, ConfigDict


class Queues(StrEnum):
    WEBHOOKS = "webhooks"  # payment processor and identity provider deliveries, verified before they are sent here


class QueueMessage(BaseModel):
    model_config = ConfigDict(frozen=True)

    body: bytes
    receipt: str  # the handle of this delivery, which delete and change_visibility take; never an id
    receive_count: int


class QueueDepth(BaseModel):
    model_config = ConfigDict(frozen=True)

    visible: int
    in_flight: int
    dead_lettered: int


class QueuesInterface(ABC):
    @abstractmethod
    async def send(self, queue: Queues, body: bytes) -> None: ...

    @abstractmethod
    async def receive(
        self, queue: Queues, max_messages: int, wait: timedelta, visibility: timedelta
    ) -> list[QueueMessage]: ...

    @abstractmethod
    async def delete(self, queue: Queues, receipt: str) -> None: ...

    @abstractmethod
    async def change_visibility(self, queue: Queues, receipt: str, visibility: timedelta) -> None: ...

    @abstractmethod
    async def depth(self, queue: Queues) -> QueueDepth: ...  # visible, in flight, dead-lettered

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...
