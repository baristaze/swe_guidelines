"""Tenant secrets: the OM holds references, the store holds values, each tenant under a prefix of its own."""

from abc import ABC, abstractmethod
from uuid import UUID


class SecretsInterface(ABC):
    @abstractmethod
    async def get(self, org_id: UUID, name: str) -> str: ...  # raises SecretNotFound

    @abstractmethod
    async def has(self, org_id: UUID, name: str) -> bool: ...

    @abstractmethod
    async def put(self, org_id: UUID, name: str, value: str) -> None: ...

    @abstractmethod
    async def delete(self, org_id: UUID, name: str) -> None: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...


def secret_path(prefix: str, org_id: UUID, name: str) -> str:
    """The stored name: the prefix, the tenant, the caller's name, so no name crosses a tenant."""
    if not name or "/" in name or name.startswith("."):
        raise ValueError("a secret name is one plain segment")
    return f"{prefix}/{org_id}/{name}"
