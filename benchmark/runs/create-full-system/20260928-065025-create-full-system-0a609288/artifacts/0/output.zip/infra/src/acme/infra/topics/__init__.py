"""The topic bus: wake-ups and live updates, best effort, at most once. Durable effects never ride it alone."""

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from datetime import datetime
from enum import StrEnum
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class TopicPayload(BaseModel):
    model_config = ConfigDict(frozen=True, extra="ignore")  # a tolerant reader

    idempotency_key: UUID  # uuid_v7, set by the producer
    produced_at: datetime
    truncated: bool = False  # set by a bus that trims; the consumer re-reads the record
    org_id: UUID


class Topics(StrEnum):
    WORK_AVAILABLE = "work_available"
    ENTITY_CHANGED = "entity_changed"  # org_id, kind, target_id, seq, actor_id: the realtime producer


SESSION_REVOKED = "SESSION_REVOKED"  # the one control kind ENTITY_CHANGED carries: never forwarded as a frame


class WorkAvailablePayload(TopicPayload):
    kind: str
    lane: str = "default"


class EntityChangedPayload(TopicPayload):
    """A hint: the identity of a change and never a field of the entity. SESSION_REVOKED carries no seq."""

    kind: str
    target_id: UUID
    seq: int | None = None
    actor_id: UUID
    version: int | None = None


TOPIC_PAYLOADS: dict[Topics, type[TopicPayload]] = {
    Topics.WORK_AVAILABLE: WorkAvailablePayload,
    Topics.ENTITY_CHANGED: EntityChangedPayload,
}


class TopicsInterface(ABC):
    @abstractmethod
    async def publish(self, topic: Topics, payload: TopicPayload) -> bool: ...  # the bus took it or not

    @abstractmethod
    def subscribe(
        self,
        topic: Topics,
        consumer: str,
        handler: Callable[[TopicPayload], Awaitable[None]],
    ) -> Callable[[], None]: ...  # returns an unsubscribe

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...
