"""The root of every exception infra raises. Infra imports nothing from the OM, so it has a root of its own."""


class InfraException(Exception):
    """Root of every exception raised by an infrastructure capability."""

    http_status: int = 503
    code: str = "infra_unavailable"


class InfraNotFound(InfraException):
    http_status = 404
    code = "not_found"


class InfraRefused(InfraException):
    """The backend refused the call as the caller shaped it: a key that climbs out, a body too long."""

    http_status = 422
    code = "validation_failed"


class SecretNotFound(InfraNotFound):
    code = "secret_not_found"


class UnsafeConfiguration(InfraException):
    """A setting that is only safe locally, chosen in an environment that is not local."""

    http_status = 500
    code = "unsafe_configuration"
