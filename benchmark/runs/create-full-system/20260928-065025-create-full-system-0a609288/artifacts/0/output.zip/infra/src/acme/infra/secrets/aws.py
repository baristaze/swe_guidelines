"""The managed secret store over AWS Secrets Manager. An error names the secret and the store, never the value."""

from typing import Any
from uuid import UUID

import aioboto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

from acme.infra.exceptions import InfraException, SecretNotFound
from acme.infra.observability import OUTCOMES
from acme.infra.secrets import SecretsInterface, secret_path


class SecretsAwsImpl(SecretsInterface):
    def __init__(self, prefix: str, region: str, timeout_seconds: float) -> None:
        self._prefix = prefix
        self._region = region
        self._config = Config(connect_timeout=timeout_seconds, read_timeout=timeout_seconds)
        self._session = aioboto3.Session()
        self._client: Any = None
        self._client_cm: Any = None

    async def start(self) -> None:
        self._client_cm = self._session.client("secretsmanager", region_name=self._region, config=self._config)
        self._client = await self._client_cm.__aenter__()

    async def close(self) -> None:
        if self._client_cm is not None:
            await self._client_cm.__aexit__(None, None, None)
            self._client_cm = None
            self._client = None

    async def get(self, org_id: UUID, name: str) -> str:
        try:
            result = await self._client.get_secret_value(SecretId=secret_path(self._prefix, org_id, name))
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") == "ResourceNotFoundException":
                OUTCOMES.labels("secrets", "get", "not_found").inc()
                raise SecretNotFound(f"secret {name!r} not found in secrets manager") from exc
            OUTCOMES.labels("secrets", "get", "error").inc()
            raise InfraException(f"secrets manager refused reading {name!r}") from exc
        except BotoCoreError as exc:
            OUTCOMES.labels("secrets", "get", "error").inc()
            raise InfraException(f"secrets manager unreachable reading {name!r}") from exc
        OUTCOMES.labels("secrets", "get", "ok").inc()
        return result["SecretString"]

    async def has(self, org_id: UUID, name: str) -> bool:
        try:
            await self.get(org_id, name)
        except SecretNotFound:
            return False
        return True

    async def put(self, org_id: UUID, name: str, value: str) -> None:
        path = secret_path(self._prefix, org_id, name)
        try:
            try:
                await self._client.put_secret_value(SecretId=path, SecretString=value)
            except ClientError as exc:
                if exc.response.get("Error", {}).get("Code") != "ResourceNotFoundException":
                    raise
                await self._client.create_secret(Name=path, SecretString=value)
        except (ClientError, BotoCoreError) as exc:
            OUTCOMES.labels("secrets", "put", "error").inc()
            raise InfraException(f"secrets manager refused writing {name!r}") from exc
        OUTCOMES.labels("secrets", "put", "ok").inc()

    async def delete(self, org_id: UUID, name: str) -> None:
        try:
            await self._client.delete_secret(
                SecretId=secret_path(self._prefix, org_id, name), ForceDeleteWithoutRecovery=True
            )
        except ClientError as exc:
            if exc.response.get("Error", {}).get("Code") == "ResourceNotFoundException":
                return
            OUTCOMES.labels("secrets", "delete", "error").inc()
            raise InfraException(f"secrets manager refused deleting {name!r}") from exc
        OUTCOMES.labels("secrets", "delete", "ok").inc()

    def describe(self) -> str:
        return f"secrets: aws secrets manager under {self._prefix} in {self._region}"


async def write_process_secret(name: str, value: str, region: str) -> None:
    """Writes a process credential into the secret the environment root created by name (an operator token the
    grant job mints). Not the tenant capability: the name is the platform's, and no tenant prefix applies."""
    session = aioboto3.Session()
    client_cm: Any = session.client("secretsmanager", region_name=region)
    async with client_cm as client:
        try:
            await client.put_secret_value(SecretId=name, SecretString=value)
        except (ClientError, BotoCoreError) as exc:
            OUTCOMES.labels("secrets", "put_process", "error").inc()
            raise InfraException(f"secrets manager refused writing {name!r}") from exc
    OUTCOMES.labels("secrets", "put_process", "ok").inc()
