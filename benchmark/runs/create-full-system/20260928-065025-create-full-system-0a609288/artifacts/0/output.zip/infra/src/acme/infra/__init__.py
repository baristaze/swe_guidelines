"""Infrastructure capabilities: cache, buckets, topics, queues, secrets. Imports nothing from the OM."""
