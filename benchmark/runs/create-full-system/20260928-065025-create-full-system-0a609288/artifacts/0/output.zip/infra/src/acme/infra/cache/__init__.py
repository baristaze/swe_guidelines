"""The cache capability: scoped, tenant-keyed, failing open."""

from abc import ABC, abstractmethod
from datetime import timedelta
from enum import StrEnum
from uuid import UUID


class CacheScope(StrEnum):
    NETWORK_RESPONSE = "network_response"
    RATE_LIMIT = "rate_limit"
    WORKER_LIVENESS = "worker_liveness"


class CacheInterface(ABC):
    """Every call takes org_id first; the system scope is the zero UUID. A backend out of reach is a miss."""

    @abstractmethod
    async def get(self, org_id: UUID, key: str) -> bytes | None: ...

    @abstractmethod
    async def put(self, org_id: UUID, key: str, value: bytes, ttl: timedelta) -> None: ...

    @abstractmethod
    async def invalidate(self, org_id: UUID, key: str) -> None: ...

    @abstractmethod
    async def increment(self, org_id: UUID, key: str, ttl: timedelta) -> tuple[int, timedelta]: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...


def full_key(scope: CacheScope, org_id: UUID, key: str) -> str:
    """The key a backend stores: the scope, then the tenant, then the caller's key."""
    return f"{scope.value}:{org_id}:{key}"
