"""The OS trust store installs before anything else, and a cloud client's TLS context still opens afterwards."""

import subprocess
import sys

REPLAY = """
from acme.infra import trust
trust.install()
import ssl
import botocore.httpsession
context = botocore.httpsession.create_urllib3_context()
context.load_default_certs()
assert isinstance(context, ssl.SSLContext)
print("ok")
"""


def test_a_fresh_interpreter_installs_the_store_and_opens_a_cloud_tls_context() -> None:
    result = subprocess.run([sys.executable, "-c", REPLAY], capture_output=True, text=True, timeout=60)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "ok"
