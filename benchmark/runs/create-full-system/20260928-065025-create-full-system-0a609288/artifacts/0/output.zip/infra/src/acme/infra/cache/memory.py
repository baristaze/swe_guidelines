"""The in-process cache: the local impl, behaving like the hosted one, TTLs included."""

import time
from datetime import timedelta
from uuid import UUID

from acme.infra.cache import CacheInterface, CacheScope, full_key


class CacheMemoryImpl(CacheInterface):
    def __init__(self, scope: CacheScope, store: dict[str, tuple[bytes, float]] | None = None) -> None:
        self._scope = scope
        self._store: dict[str, tuple[bytes, float]] = {} if store is None else store

    def _live(self, k: str) -> tuple[bytes, float] | None:
        entry = self._store.get(k)
        if entry is None:
            return None
        if entry[1] <= time.monotonic():
            del self._store[k]
            return None
        return entry

    async def get(self, org_id: UUID, key: str) -> bytes | None:
        entry = self._live(full_key(self._scope, org_id, key))
        return None if entry is None else entry[0]

    async def put(self, org_id: UUID, key: str, value: bytes, ttl: timedelta) -> None:
        self._store[full_key(self._scope, org_id, key)] = (value, time.monotonic() + ttl.total_seconds())

    async def invalidate(self, org_id: UUID, key: str) -> None:
        self._store.pop(full_key(self._scope, org_id, key), None)

    async def increment(self, org_id: UUID, key: str, ttl: timedelta) -> tuple[int, timedelta]:
        k = full_key(self._scope, org_id, key)
        entry = self._live(k)
        if entry is None:
            expires = time.monotonic() + ttl.total_seconds()
            count = 1
        else:
            count = int(entry[0]) + 1
            expires = entry[1]
        self._store[k] = (str(count).encode(), expires)
        return count, timedelta(seconds=max(0.0, expires - time.monotonic()))

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return f"cache[{self._scope.value}]: in-process memory"
