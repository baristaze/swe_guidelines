"""The local secret store: one owner-only JSON file, refused unless its mode is 0600. Local only."""

import json
import os
import stat
from pathlib import Path
from uuid import UUID

from acme.infra.exceptions import InfraRefused, SecretNotFound
from acme.infra.secrets import SecretsInterface, secret_path


def _check_owner_only(path: Path) -> None:
    mode = path.stat().st_mode
    if mode & (stat.S_IRWXG | stat.S_IRWXO):
        raise InfraRefused(f"secrets file {path} must be owner-only (0600)")


class SecretsFileImpl(SecretsInterface):
    def __init__(self, path: Path, prefix: str) -> None:
        self._path = path
        self._prefix = prefix

    def _read(self) -> dict[str, str]:
        if not self._path.exists():
            return {}
        _check_owner_only(self._path)
        return json.loads(self._path.read_text() or "{}")

    def _write(self, data: dict[str, str]) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(self._path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
        os.chmod(self._path, 0o600)

    async def get(self, org_id: UUID, name: str) -> str:
        key = secret_path(self._prefix, org_id, name)
        value = self._read().get(key)
        if value is None:
            raise SecretNotFound(f"secret {name!r} not found in the file store")
        return value

    async def has(self, org_id: UUID, name: str) -> bool:
        return secret_path(self._prefix, org_id, name) in self._read()

    async def put(self, org_id: UUID, name: str, value: str) -> None:
        data = self._read()
        data[secret_path(self._prefix, org_id, name)] = value
        self._write(data)

    async def delete(self, org_id: UUID, name: str) -> None:
        data = self._read()
        data.pop(secret_path(self._prefix, org_id, name), None)
        self._write(data)

    async def start(self) -> None:
        if self._path.exists():
            _check_owner_only(self._path)

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return f"secrets: owner-only file {self._path}"
