"""The topic bus over Postgres LISTEN/NOTIFY, on the queue role's database. Trims past the cap, marks truncated."""

import asyncio
import json
import logging
from collections.abc import Awaitable, Callable

import asyncpg

from acme.infra.observability import OUTCOMES
from acme.infra.topics import TOPIC_PAYLOADS, TopicPayload, Topics, TopicsInterface

logger = logging.getLogger(__name__)


PAYLOAD_CAP = 7900  # Postgres refuses a NOTIFY payload of 8000 bytes or more
BASE_FIELDS = ("idempotency_key", "produced_at", "org_id")

Handler = Callable[[TopicPayload], Awaitable[None]]


def channel(topic: Topics) -> str:
    return f"acme_{topic.value}"


class TopicsPostgresImpl(TopicsInterface):
    def __init__(self, url: str, timeout_seconds: float) -> None:
        self._url = url
        self._timeout = timeout_seconds
        self._subscribers: dict[Topics, list[tuple[str, Handler]]] = {}
        self._listener: asyncpg.Connection | None = None
        self._publisher: asyncpg.Connection | None = None
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        self._publisher = await asyncio.wait_for(asyncpg.connect(self._url), self._timeout)
        listener = await asyncio.wait_for(asyncpg.connect(self._url), self._timeout)
        for topic in Topics:
            await listener.add_listener(channel(topic), self._on_notify)
        self._listener = listener

    async def close(self) -> None:
        for conn in (self._listener, self._publisher):
            if conn is not None:
                await conn.close()
        self._listener = None
        self._publisher = None

    def _on_notify(self, _conn: object, _pid: int, chan: str, raw: str) -> None:
        topic = next((t for t in Topics if channel(t) == chan), None)
        if topic is None:
            return
        try:
            payload = TOPIC_PAYLOADS[topic].model_validate_json(raw)
        except ValueError:
            OUTCOMES.labels("topics", "deliver", "malformed").inc()
            return
        for consumer, handler in list(self._subscribers.get(topic, [])):
            asyncio.get_running_loop().create_task(self._deliver(topic, consumer, handler, payload))

    async def _deliver(self, topic: Topics, consumer: str, handler: Handler, payload: TopicPayload) -> None:
        try:
            await handler(payload)
            OUTCOMES.labels("topics", "deliver", "ok").inc()
        except Exception:
            OUTCOMES.labels("topics", "deliver", "error").inc()
            logger.exception("topic handler failed", extra={"consumer": consumer, "topic": topic.value})

    async def publish(self, topic: Topics, payload: TopicPayload) -> bool:
        body = payload.model_dump_json()
        if len(body.encode()) > PAYLOAD_CAP:
            trimmed = {k: v for k, v in json.loads(body).items() if k in BASE_FIELDS}
            trimmed["truncated"] = True
            body = json.dumps(trimmed)
        if self._publisher is None:
            OUTCOMES.labels("topics", "publish", "unavailable").inc()
            return False
        try:
            async with self._lock:
                await self._publisher.execute("SELECT pg_notify($1, $2)", channel(topic), body, timeout=self._timeout)
        except asyncpg.PostgresError, OSError, TimeoutError:
            OUTCOMES.labels("topics", "publish", "error").inc()
            logger.warning("topic publish failed", extra={"topic": topic.value})
            return False
        OUTCOMES.labels("topics", "publish", "ok").inc()
        return True

    def subscribe(self, topic: Topics, consumer: str, handler: Handler) -> Callable[[], None]:
        entry = (consumer, handler)
        self._subscribers.setdefault(topic, []).append(entry)

        def unsubscribe() -> None:
            subscribers = self._subscribers.get(topic, [])
            if entry in subscribers:
                subscribers.remove(entry)

        return unsubscribe

    def describe(self) -> str:
        return "topics: postgres LISTEN/NOTIFY on the queue role's database"
