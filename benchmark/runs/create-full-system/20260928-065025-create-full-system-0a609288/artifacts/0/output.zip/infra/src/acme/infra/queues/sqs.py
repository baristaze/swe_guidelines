"""The hosted queue over SQS: a thin translation, driver errors as InfraException, outcomes counted."""

from datetime import timedelta
from typing import Any

import aioboto3
from botocore.config import Config
from botocore.exceptions import BotoCoreError, ClientError

from acme.infra.exceptions import InfraException
from acme.infra.observability import OUTCOMES
from acme.infra.queues import QueueDepth, QueueMessage, Queues, QueuesInterface


class QueuesSqsImpl(QueuesInterface):
    def __init__(self, prefix: str, region: str, endpoint_url: str | None, timeout_seconds: float) -> None:
        self._prefix = prefix
        self._region = region
        self._endpoint = endpoint_url or None
        self._config = Config(connect_timeout=timeout_seconds, read_timeout=timeout_seconds + 20)
        self._session = aioboto3.Session()
        self._client: Any = None
        self._client_cm: Any = None
        self._urls: dict[Queues, str] = {}

    async def start(self) -> None:
        self._client_cm = self._session.client(
            "sqs", region_name=self._region, endpoint_url=self._endpoint, config=self._config
        )
        self._client = await self._client_cm.__aenter__()

    async def close(self) -> None:
        if self._client_cm is not None:
            await self._client_cm.__aexit__(None, None, None)
            self._client_cm = None
            self._client = None

    async def _call(self, queue: Queues, operation: str, **kwargs: Any) -> Any:
        try:
            if queue not in self._urls:
                found = await self._client.get_queue_url(QueueName=f"{self._prefix}-{queue.value}")
                self._urls[queue] = found["QueueUrl"]
            result = await getattr(self._client, operation)(QueueUrl=self._urls[queue], **kwargs)
        except (ClientError, BotoCoreError) as exc:
            OUTCOMES.labels("queue", operation, "error").inc()
            raise InfraException(f"queue {queue.value} refused {operation}") from exc
        OUTCOMES.labels("queue", operation, "ok").inc()
        return result

    async def send(self, queue: Queues, body: bytes) -> None:
        await self._call(queue, "send_message", MessageBody=body.decode())

    async def receive(
        self, queue: Queues, max_messages: int, wait: timedelta, visibility: timedelta
    ) -> list[QueueMessage]:
        result = await self._call(
            queue,
            "receive_message",
            MaxNumberOfMessages=max(1, min(10, max_messages)),
            WaitTimeSeconds=int(wait.total_seconds()),
            VisibilityTimeout=int(visibility.total_seconds()),
            MessageSystemAttributeNames=["ApproximateReceiveCount"],
        )
        return [
            QueueMessage(
                body=m["Body"].encode(),
                receipt=m["ReceiptHandle"],
                receive_count=int(m.get("Attributes", {}).get("ApproximateReceiveCount", "1")),
            )
            for m in result.get("Messages", [])
        ]

    async def delete(self, queue: Queues, receipt: str) -> None:
        await self._call(queue, "delete_message", ReceiptHandle=receipt)

    async def change_visibility(self, queue: Queues, receipt: str, visibility: timedelta) -> None:
        await self._call(
            queue, "change_message_visibility", ReceiptHandle=receipt, VisibilityTimeout=int(visibility.total_seconds())
        )

    async def depth(self, queue: Queues) -> QueueDepth:
        result = await self._call(
            queue,
            "get_queue_attributes",
            AttributeNames=["ApproximateNumberOfMessages", "ApproximateNumberOfMessagesNotVisible"],
        )
        attrs = result.get("Attributes", {})
        dead = 0
        try:
            dead_url = await self._client.get_queue_url(QueueName=f"{self._prefix}-{queue.value}-dlq")
            dead_attrs = await self._client.get_queue_attributes(
                QueueUrl=dead_url["QueueUrl"], AttributeNames=["ApproximateNumberOfMessages"]
            )
            dead = int(dead_attrs.get("Attributes", {}).get("ApproximateNumberOfMessages", "0"))
        except ClientError, BotoCoreError:
            OUTCOMES.labels("queue", "depth_dead_letter", "error").inc()
        return QueueDepth(
            visible=int(attrs.get("ApproximateNumberOfMessages", "0")),
            in_flight=int(attrs.get("ApproximateNumberOfMessagesNotVisible", "0")),
            dead_lettered=dead,
        )

    def describe(self) -> str:
        return f"queues: sqs under prefix {self._prefix} in {self._region}"
