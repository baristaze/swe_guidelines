"""The hosted cache over Valkey. A backend out of reach is a miss, counted, never an error."""

import logging
from datetime import timedelta
from urllib.parse import urlparse
from uuid import UUID

from glide import ExpirySet, ExpiryType, GlideClient, GlideClientConfiguration, NodeAddress

from acme.infra.cache import CacheInterface, CacheScope, full_key
from acme.infra.observability import OUTCOMES

logger = logging.getLogger(__name__)


class ValkeyConnection:
    """The one client a process holds, opened at start and shared by every scope."""

    def __init__(self, url: str, request_timeout_ms: int) -> None:
        self._url = url
        self._timeout = request_timeout_ms
        self.client: GlideClient | None = None

    @property
    def host(self) -> str:
        return urlparse(self._url).hostname or "localhost"

    async def start(self) -> None:
        parsed = urlparse(self._url)
        config = GlideClientConfiguration(
            [NodeAddress(parsed.hostname or "localhost", parsed.port or 6379)],
            use_tls=parsed.scheme == "rediss",
            request_timeout=self._timeout,
        )
        try:
            self.client = await GlideClient.create(config)
        except Exception:  # a cache fails open: the process starts and every read misses
            logger.warning("cache unreachable at start; reads miss until it answers")
            self.client = None

    async def close(self) -> None:
        if self.client is not None:
            await self.client.close()
            self.client = None


class CacheValkeyImpl(CacheInterface):
    def __init__(self, scope: CacheScope, connection: ValkeyConnection) -> None:
        self._scope = scope
        self._conn = connection

    def _count(self, operation: str, outcome: str) -> None:
        OUTCOMES.labels("cache", operation, outcome).inc()

    async def get(self, org_id: UUID, key: str) -> bytes | None:
        client = self._conn.client
        if client is None:
            self._count("get", "unavailable")
            return None
        try:
            value = await client.get(full_key(self._scope, org_id, key))
        except Exception:
            self._count("get", "error")
            return None
        self._count("get", "hit" if value is not None else "miss")
        return value

    async def put(self, org_id: UUID, key: str, value: bytes, ttl: timedelta) -> None:
        client = self._conn.client
        if client is None:
            self._count("put", "unavailable")
            return
        try:
            expiry = ExpirySet(ExpiryType.MILLSEC, max(1, int(ttl.total_seconds() * 1000)))
            await client.set(full_key(self._scope, org_id, key), value, expiry=expiry)
            self._count("put", "ok")
        except Exception:
            self._count("put", "error")

    async def invalidate(self, org_id: UUID, key: str) -> None:
        client = self._conn.client
        if client is None:
            self._count("invalidate", "unavailable")
            return
        try:
            await client.delete([full_key(self._scope, org_id, key)])
            self._count("invalidate", "ok")
        except Exception:
            self._count("invalidate", "error")

    async def increment(self, org_id: UUID, key: str, ttl: timedelta) -> tuple[int, timedelta]:
        client = self._conn.client
        if client is None:
            self._count("increment", "unavailable")
            return 0, ttl  # fails open: a limit that cannot count admits
        k = full_key(self._scope, org_id, key)
        try:
            count = await client.incr(k)
            if count == 1:
                await client.pexpire(k, max(1, int(ttl.total_seconds() * 1000)))
                remaining = ttl
            else:
                left = await client.pttl(k)
                remaining = timedelta(milliseconds=left) if left and left > 0 else ttl
            self._count("increment", "ok")
            return int(count), remaining
        except Exception:
            self._count("increment", "error")
            return 0, ttl

    async def start(self) -> None:
        return None  # the shared connection starts with the root

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return f"cache[{self._scope.value}]: valkey at {self._conn.host}"
