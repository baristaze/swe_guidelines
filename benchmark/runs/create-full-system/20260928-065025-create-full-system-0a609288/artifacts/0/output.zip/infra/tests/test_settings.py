"""Every infra knob is documented in .env.example; the configured root refuses what is only safe locally."""

from pathlib import Path

import pytest

from acme.infra.exceptions import UnsafeConfiguration
from acme.infra.impl.configured import InfraConfiguredImpl, refuse_unsafe
from acme.infra.impl.settings import InfraSettings

ENV_EXAMPLE = Path(__file__).resolve().parents[2] / ".env.example"


def documented() -> set[str]:
    return {
        line.split("=", 1)[0].strip()
        for line in ENV_EXAMPLE.read_text().splitlines()
        if "=" in line and not line.startswith("#")
    }


def test_every_field_is_in_env_example() -> None:
    missing = {f"ACME_{name.upper()}" for name in InfraSettings.model_fields} - documented()
    assert not missing, f"undocumented infra settings: {sorted(missing)}"


@pytest.mark.parametrize(
    ("override", "names"),
    [
        ({"secrets_backend": "file"}, "ACME_SECRETS_BACKEND"),
        ({"cache_backend": "memory"}, "ACME_CACHE_BACKEND"),
        ({"cache_url": "redis://cache:6379"}, "ACME_CACHE_URL"),
        ({"topics_backend": "memory"}, "ACME_TOPICS_BACKEND"),
        ({"queues_backend": "memory"}, "ACME_QUEUES_BACKEND"),
        ({"buckets_backend": "local"}, "ACME_BUCKETS_BACKEND"),
    ],
)
def test_a_cloud_environment_refuses_local_only_settings(override: dict[str, str], names: str) -> None:
    safe = {
        "environment": "staging",
        "secrets_backend": "aws",
        "cache_backend": "valkey",
        "cache_url": "rediss://cache:6379",
        "topics_backend": "postgres",
        "queues_backend": "sqs",
        "buckets_backend": "s3",
    }
    refuse_unsafe(InfraSettings(**safe))  # type: ignore[arg-type]
    with pytest.raises(UnsafeConfiguration, match=names):
        InfraConfiguredImpl(InfraSettings(**{**safe, **override}))  # type: ignore[arg-type]


def test_local_accepts_every_twin(tmp_path: Path) -> None:
    root = InfraConfiguredImpl(
        InfraSettings(
            _env_file=None,  # type: ignore[call-arg]
            environment="local",
            cache_backend="memory",
            buckets_backend="local",
            topics_backend="memory",
            queues_backend="memory",
            secrets_backend="file",
            buckets_root=tmp_path,
            secrets_file=tmp_path / "s.json",
        )
    )
    assert "in-process" in " ".join(root.describe())
