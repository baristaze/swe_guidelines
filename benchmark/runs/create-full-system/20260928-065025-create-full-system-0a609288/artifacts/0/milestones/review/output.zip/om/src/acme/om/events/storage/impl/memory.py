"""The event stream in memory: one list and one cursor per tenant, numbered the way the engine numbers."""

from datetime import datetime
from uuid import UUID

from acme.om.events.storage import EventsStorageInterface, uuid7_floor
from acme.om.events.types import Event
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase


class EventsStorageMemoryImpl(MemoryStorageBase, EventsStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._events: dict[UUID, dict[UUID, Event]] = {}
        self._heads: dict[UUID, int] = {}

    async def append_event(self, org_id: UUID, event: Event) -> Event:
        """Named atomic: assigns `seq` from the tenant's cursor row in the append's own transaction.
        An id already written returns the stored event and moves no cursor."""
        tenant = self._events.setdefault(org_id, {})
        if event.id in tenant:
            return tenant[event.id]
        seq = self._heads.get(org_id, 0) + 1
        self._heads[org_id] = seq
        stored = event.model_copy(update={"org_id": org_id, "seq": seq})
        tenant[event.id] = stored
        return stored

    async def read_head(self, org_id: UUID) -> int:
        return self._heads.get(org_id, 0)

    async def read_after(self, org_id: UUID, after_seq: int, limit: int) -> list[Event]:
        found = [e for e in self._events.get(org_id, {}).values() if e.seq > after_seq]
        return sorted(found, key=lambda e: e.seq)[:limit]

    async def count_since(self, since: datetime, excluded: tuple[UUID, ...]) -> int:
        """Tenant-less: the operator plane's count of events across tenants, in the system scope,
        leaving out the tenants named (the ones a traffic run provisioned)."""
        floor = uuid7_floor(since).int
        return sum(
            1
            for org_id, tenant in self._events.items()
            if org_id not in excluded
            for e in tenant.values()
            if e.id.int >= floor
        )
