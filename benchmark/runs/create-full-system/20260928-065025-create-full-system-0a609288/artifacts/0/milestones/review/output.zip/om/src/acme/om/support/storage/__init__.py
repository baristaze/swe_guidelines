"""The support storage: pledges in the supporter's account, contributions in the desk's. Every method runs under the
tenant it names."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.outbox.types import OutboxRow
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge


class SupportStorageInterface(ABC):
    @abstractmethod
    async def read_pledges(self, org_id: UUID, limit: int) -> list[Pledge]:
        """The account's pledges, the newest first (by id, descending), at most `limit`."""
        ...

    @abstractmethod
    async def read_pledge(self, org_id: UUID, pledge_id: UUID) -> Pledge | None: ...

    @abstractmethod
    async def create_pledge(self, org_id: UUID, pledge: Pledge, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        """False when the id is already written, under any tenant; nothing changes then."""
        ...

    @abstractmethod
    async def write_pledge(self, org_id: UUID, pledge: Pledge, outbox_rows: tuple[OutboxRow, ...]) -> None:
        """Writes the pledge onto its row under the tenant; an id another tenant holds is a Conflict."""
        ...

    @abstractmethod
    async def read_contributions(self, org_id: UUID, limit: int) -> list[Contribution]:
        """The desk's contributions, the newest first (by id, descending), at most `limit`."""
        ...

    @abstractmethod
    async def read_contribution(self, org_id: UUID, contribution_id: UUID) -> Contribution | None: ...

    @abstractmethod
    async def append_contribution(self, org_id: UUID, contribution: Contribution) -> bool:
        """Appends once: False when the id is already written, under any tenant; nothing changes then."""
        ...
