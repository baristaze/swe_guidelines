"""The events storage: one named atomic append that assigns a gapless per-tenant sequence."""

from abc import ABC, abstractmethod
from datetime import datetime
from uuid import UUID

from acme.om.events.types import Event


class EventsStorageInterface(ABC):
    @abstractmethod
    async def append_event(self, org_id: UUID, event: Event) -> Event:
        """Named atomic: assigns `seq` from the tenant's cursor row in the append's own transaction.
        An id already written returns the stored event and moves no cursor."""
        ...

    @abstractmethod
    async def read_head(self, org_id: UUID) -> int: ...

    @abstractmethod
    async def read_after(self, org_id: UUID, after_seq: int, limit: int) -> list[Event]: ...

    @abstractmethod
    async def count_since(self, since: datetime, excluded: tuple[UUID, ...]) -> int:
        """Tenant-less: the operator plane's count of events across tenants, in the system scope,
        leaving out the tenants named (the ones a traffic run provisioned)."""
        ...


def uuid7_floor(moment: datetime) -> UUID:
    """The smallest UUID v7 minted at or after `moment`, so a time range is a range scan on the id."""
    millis = int(moment.timestamp() * 1000)
    return UUID(int=(millis << 80) | (0x7 << 76) | (0x2 << 62))
