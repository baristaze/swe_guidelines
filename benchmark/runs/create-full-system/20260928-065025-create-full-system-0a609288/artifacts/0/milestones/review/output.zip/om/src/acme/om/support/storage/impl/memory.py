"""The support storage in memory: the same filters, order, tenancy rule, and refusals as the engine."""

from uuid import UUID

from acme.om.exceptions import Conflict
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase, by_uuid
from acme.om.support.storage import SupportStorageInterface
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge


class SupportStorageMemoryImpl(MemoryStorageBase, SupportStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._pledges: dict[UUID, tuple[UUID, Pledge]] = {}
        self._contributions: dict[UUID, tuple[UUID, Contribution]] = {}

    async def read_pledges(self, org_id: UUID, limit: int) -> list[Pledge]:
        return list(reversed(by_uuid(p for o, p in self._pledges.values() if o == org_id)))[:limit]

    async def read_pledge(self, org_id: UUID, pledge_id: UUID) -> Pledge | None:
        found = self._pledges.get(pledge_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def create_pledge(self, org_id: UUID, pledge: Pledge, outbox_rows: tuple[OutboxRow, ...]) -> bool:
        if pledge.id in self._pledges:
            return False
        self._land(org_id, outbox_rows)
        self._pledges[pledge.id] = (org_id, pledge)
        return True

    async def write_pledge(self, org_id: UUID, pledge: Pledge, outbox_rows: tuple[OutboxRow, ...]) -> None:
        found = self._pledges.get(pledge.id)
        if found is not None and found[0] != org_id:
            raise Conflict("the row is held under another key")
        self._land(org_id, outbox_rows)
        self._pledges[pledge.id] = (org_id, pledge)

    async def read_contributions(self, org_id: UUID, limit: int) -> list[Contribution]:
        return list(reversed(by_uuid(c for o, c in self._contributions.values() if o == org_id)))[:limit]

    async def read_contribution(self, org_id: UUID, contribution_id: UUID) -> Contribution | None:
        found = self._contributions.get(contribution_id)
        return found[1] if found is not None and found[0] == org_id else None

    async def append_contribution(self, org_id: UUID, contribution: Contribution) -> bool:
        if contribution.id in self._contributions:
            return False
        self._contributions[contribution.id] = (org_id, contribution)
        return True
