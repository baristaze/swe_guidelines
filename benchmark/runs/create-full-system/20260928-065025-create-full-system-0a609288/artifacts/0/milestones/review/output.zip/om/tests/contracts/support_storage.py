"""Contract cases of the support storage: pledges and contributions, each under another tenant, the id, the race."""

import asyncio

import pytest

from acme.om.base import new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.storage.root import StorageInterface
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge, PledgeStatus, SupportMode
from contracts import factories as f


def pledge(mode: SupportMode = SupportMode.MONTHLY) -> Pledge:
    now = utcnow()
    actor = new_id()
    return Pledge(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=actor,
        updated_by=actor,
        desk_id=new_id(),
        journalist_id=new_id(),
        amount_minor=500,
        currency="eur",
        mode=mode,
        supporter_name="A reader",
        platform_fee_minor=25,
    )


def contribution() -> Contribution:
    return Contribution(
        id=new_id(),
        journalist_id=new_id(),
        pledge_id=new_id(),
        supporter_org_id=new_id(),
        supporter_name="A reader",
        amount_minor=500,
        currency="eur",
        mode=SupportMode.ONE_TIME,
        platform_fee_minor=25,
        received_at=utcnow(),
    )


async def case_create_then_read_list_and_write_a_pledge(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id = new_id()
    p = pledge()
    r = f.row(org_id, "support.pledge.created", p.id)
    assert await s.create_pledge(org_id, p, (r,)) is True
    assert await s.read_pledge(org_id, p.id) == p
    assert await s.read_pledges(org_id, 10) == [p]
    settled = p.model_copy(update={"status": PledgeStatus.ACTIVE, "subscription_id": "sub_1", "settled_at": utcnow()})
    w = f.row(org_id, "support.pledge.updated", p.id)
    await s.write_pledge(org_id, settled, (w,))
    assert await s.read_pledge(org_id, p.id) == settled
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r
    assert await storage.get_outbox_storage().read_row(org_id, w.id) == w


async def case_pledges_list_the_newest_first(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id = new_id()
    made = [pledge() for _ in range(3)]
    for p in made:
        await s.create_pledge(org_id, p, ())
    newest = sorted(made, key=lambda p: p.id.int, reverse=True)
    assert await s.read_pledges(org_id, 2) == newest[:2]


async def case_a_second_pledge_create_under_the_same_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id = new_id()
    p = pledge()
    await s.create_pledge(org_id, p, ())
    again = f.row(org_id, "support.pledge.created", p.id)
    assert await s.create_pledge(org_id, p.model_copy(update={"amount_minor": 9}), (again,)) is False
    assert await s.read_pledge(org_id, p.id) == p
    assert await storage.get_outbox_storage().read_row(org_id, again.id) is None


async def case_pledges_under_another_account_are_not_found_and_not_changed(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id, other = new_id(), new_id()
    p = pledge()
    await s.create_pledge(org_id, p, ())
    assert await s.read_pledges(other, 10) == []
    assert await s.read_pledge(other, p.id) is None
    taken = f.row(other, "support.pledge.created", p.id)
    assert await s.create_pledge(other, p, (taken,)) is False
    assert await storage.get_outbox_storage().read_row(other, taken.id) is None
    w = f.row(other, "support.pledge.updated", p.id)
    with pytest.raises(Conflict):
        await s.write_pledge(other, p.model_copy(update={"status": PledgeStatus.PAID}), (w,))
    assert await s.read_pledge(org_id, p.id) == p
    assert await storage.get_outbox_storage().read_row(other, w.id) is None


async def case_append_then_read_and_list_contributions_the_newest_first(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id = new_id()
    made = [contribution() for _ in range(3)]
    for c in made:
        assert await s.append_contribution(org_id, c) is True
    newest = sorted(made, key=lambda c: c.id.int, reverse=True)
    assert await s.read_contributions(org_id, 2) == newest[:2]
    assert await s.read_contribution(org_id, made[0].id) == made[0]


async def case_a_contribution_is_appended_once(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id = new_id()
    c = contribution()
    assert await s.append_contribution(org_id, c) is True
    assert await s.append_contribution(org_id, c.model_copy(update={"amount_minor": 1})) is False
    assert await s.read_contributions(org_id, 10) == [c]


async def case_contributions_under_another_desk_are_not_found_and_not_changed(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id, other = new_id(), new_id()
    c = contribution()
    await s.append_contribution(org_id, c)
    assert await s.read_contributions(other, 10) == []
    assert await s.read_contribution(other, c.id) is None
    assert await s.append_contribution(other, c) is False
    assert await s.read_contribution(other, c.id) is None
    assert await s.read_contribution(org_id, c.id) == c


async def case_create_and_append_races_have_one_winner(storage: StorageInterface) -> None:
    s = storage.get_support_storage()
    org_id = new_id()
    p, c = pledge(), contribution()
    created = await asyncio.gather(s.create_pledge(org_id, p, ()), s.create_pledge(org_id, p, ()))
    appended = await asyncio.gather(s.append_contribution(org_id, c), s.append_contribution(org_id, c))
    assert sorted(created) == [False, True] and sorted(appended) == [False, True]
    assert await s.read_contributions(org_id, 10) == [c]


CASES = [
    case_create_then_read_list_and_write_a_pledge,
    case_pledges_list_the_newest_first,
    case_a_second_pledge_create_under_the_same_id_changes_nothing,
    case_pledges_under_another_account_are_not_found_and_not_changed,
    case_append_then_read_and_list_contributions_the_newest_first,
    case_a_contribution_is_appended_once,
    case_contributions_under_another_desk_are_not_found_and_not_changed,
    case_create_and_append_races_have_one_winner,
]
