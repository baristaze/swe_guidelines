"""The integration suites run only against the local compose stack: every database URL must be a local address."""

from collections.abc import AsyncIterator

import pytest
from local_stack import local_settings

from acme.om.storage.impl.postgres import StoragePostgresImpl


@pytest.fixture
async def pg_storage() -> AsyncIterator[StoragePostgresImpl]:
    root = StoragePostgresImpl(local_settings())
    yield root
    await root.close()
