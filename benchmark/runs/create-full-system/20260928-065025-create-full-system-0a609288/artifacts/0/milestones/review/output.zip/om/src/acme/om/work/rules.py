"""The work queue's arithmetic: the retry delay, exhaustion, and the stale cut-off. Plain functions over values."""

from datetime import datetime, timedelta


def retry_delay(attempts: int, base: timedelta, cap: timedelta) -> timedelta:
    """A growing delay before a failed item is claimable again: base, twice base, four times, up to the cap."""
    return min(cap, base * (2 ** max(0, attempts - 1)))


def is_exhausted(attempts: int, max_attempts: int) -> bool:
    """A failure at max_attempts is final: the item is a dead letter."""
    return attempts >= max_attempts


def stale_before(now: datetime) -> datetime:
    """A claimed item whose lease expired before this instant is stale. `requeue_stale`'s statement spells the same
    rule once more (`lease_expires_at < :before`), and the contract case holds the two together."""
    return now
