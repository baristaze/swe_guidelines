"""Postmark's transactional stream."""

import httpx

from acme.integrations.email import Delivery, EmailInterface, OutboundEmail
from acme.integrations.exceptions import IntegrationRefused
from acme.integrations.http import call

POSTMARK_API = "https://api.postmarkapp.com"


class EmailPostmarkImpl(EmailInterface):
    def __init__(
        self,
        server_token: str,
        sender: str,
        timeout_seconds: float,
        api_base: str = POSTMARK_API,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self._token = server_token
        self._sender = sender
        self._timeout = timeout_seconds
        self._base = api_base.rstrip("/")
        self._transport = transport  # a recorded-fixture test hands one in; None is the network
        self._http: httpx.AsyncClient | None = None

    async def start(self) -> None:
        self._http = httpx.AsyncClient(
            transport=self._transport,
            timeout=self._timeout,
            headers={"X-Postmark-Server-Token": self._token, "Accept": "application/json"},
        )

    async def close(self) -> None:
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def send(self, message: OutboundEmail) -> Delivery:
        if self._http is None:
            raise IntegrationRefused("the email client is not started")
        response = await call(
            self._http,
            "POST",
            f"{self._base}/email",
            json={
                "From": self._sender,
                "To": message.to,
                "Subject": message.subject,
                "TextBody": message.text,
                "Tag": message.tag,
                "MessageStream": "outbound",
                "Metadata": {"idempotency_key": message.idempotency_key},
            },
        )
        return Delivery(message_id=str(response.json()["MessageID"]), provenance="postmark")

    def describe(self) -> str:
        return "email: postmark"
