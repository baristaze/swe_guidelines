# Staging's account: the state and artifacts buckets, the registry, the trust of
# the repository host, the push-only build role and the deploy role, the
# investigate role, the boundary, the trail, the budget, and the zones.
module "account" {
  source = "../../modules/account"

  environment       = local.environment
  other_environment = local.other
  account_id        = local.env.account_id
  region            = local.region
  public_names      = local.env.public_names

  github_repository          = var.github_repository
  github_repository_id       = var.github_repository_id
  github_repository_owner_id = var.github_repository_owner_id

  pipeline_roles = {
    build  = { github_environment = "staging", branch = local.env.branch, kind = "build" }
    deploy = { github_environment = "staging", branch = local.env.branch, kind = "deploy" }
  }

  ecr_repositories        = ["acme-api", "acme-maintenance", "acme-notifier"]
  bundle_object_lock      = false
  replicate_to_production = var.replicate_to_production
  production_account_id   = local.layout.environments.production.account_id

  everyday_permission_set = var.everyday_permission_set
  monthly_budget_usd      = var.monthly_budget_usd
  owner_email             = var.owner_email
}
