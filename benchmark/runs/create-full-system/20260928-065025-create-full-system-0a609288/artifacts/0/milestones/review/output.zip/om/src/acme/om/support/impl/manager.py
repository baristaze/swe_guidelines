"""The support manager impl: authorize, verify, copy, write with the outbox rows, relay at once."""

from dataclasses import dataclass
from uuid import UUID

from acme.om.base import EMPTY_UUID, utcnow
from acme.om.exceptions import Conflict, NotFound, ValidationFailed
from acme.om.journalists.manager import JournalistsManagerInterface
from acme.om.opcontext import OpContext, Permission, RequestContext
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, outbox_row, platform_outbox_row
from acme.om.support import rules
from acme.om.support.manager import SupportManagerInterface
from acme.om.support.storage import SupportStorageInterface
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge, PledgeStatus
from acme.om.work.types.work_item import SEND_NOTIFICATION_ROW, NotificationTopic


@dataclass(frozen=True)
class SupportOptions:
    page_size: int  # the most one list answers
    platform_fee_basis_points: int  # the platform's share, configured apart from the processor's fees
    minimum_minor: int
    maximum_minor: int


class SupportManagerImpl(SupportManagerInterface):
    def __init__(
        self,
        storage: SupportStorageInterface,
        relay: OutboxRelayInterface,
        journalists: JournalistsManagerInterface,
        options: SupportOptions,
    ) -> None:
        self._storage = storage
        self._relay = relay
        self._journalists = journalists
        self._options = options

    async def get_pledges(self, ctx: OpContext, limit: int) -> list[Pledge]:
        ctx.require(Permission.READ)
        return await self._storage.read_pledges(ctx.org_id, self._clamp(limit))

    async def get_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge:
        ctx.require(Permission.READ)
        found = await self._storage.read_pledge(ctx.org_id, pledge_id)
        if found is None:
            raise NotFound("no such pledge")
        return found

    async def create_pledge(self, ctx: OpContext, pledge: Pledge) -> Pledge:
        ctx.require(Permission.WRITE)
        problem = rules.pledge_problem(
            pledge.amount_minor, pledge.currency, self._options.minimum_minor, self._options.maximum_minor
        )
        if problem is not None:
            raise ValidationFailed(problem)
        journalist = await self._journalists.get_published_journalist(ctx, pledge.desk_id, pledge.journalist_id)
        if journalist.payout_account_id is None:
            raise ValidationFailed("this journalist does not take support yet")
        copy = pledge.model_copy(
            update={
                "created_by": ctx.user_id,
                "updated_by": ctx.user_id,
                "status": PledgeStatus.PENDING,
                "platform_fee_minor": rules.platform_fee_minor(
                    pledge.amount_minor, self._options.platform_fee_basis_points
                ),
                "checkout_session_id": None,
                "subscription_id": None,
                "settled_at": None,
            }
        )
        rows = (outbox_row(ctx, "support.pledge.created", copy.id, {}),)
        if not await self._storage.create_pledge(ctx.org_id, copy, rows):
            stored = await self._storage.read_pledge(ctx.org_id, copy.id)
            if stored is None:
                raise Conflict("that pledge id is taken")
            return stored
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def attach_checkout(self, ctx: OpContext, pledge_id: UUID, checkout_session_id: str) -> Pledge:
        ctx.require(Permission.WRITE)
        current = await self.get_pledge(ctx, pledge_id)
        if current.status != PledgeStatus.PENDING:
            raise Conflict("the pledge is no longer pending")
        copy = current.model_copy(
            update={"checkout_session_id": checkout_session_id, "updated_at": utcnow(), "updated_by": ctx.user_id}
        )
        rows = (outbox_row(ctx, "support.pledge.updated", copy.id, {}),)
        await self._storage.write_pledge(ctx.org_id, copy, rows)
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def cancel_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge:
        ctx.require(Permission.WRITE)
        current = await self.get_pledge(ctx, pledge_id)
        if current.status == PledgeStatus.CANCELLED:
            return current
        if not rules.cancellable(current.status, current.mode):
            raise Conflict("only a pending pledge or an active monthly one can be cancelled")
        copy = current.model_copy(
            update={"status": PledgeStatus.CANCELLED, "updated_at": utcnow(), "updated_by": ctx.user_id}
        )
        rows = (outbox_row(ctx, "support.pledge.updated", copy.id, {}),)
        await self._storage.write_pledge(ctx.org_id, copy, rows)
        await self._relay_all(ctx.org_id, rows)
        return copy

    async def get_contributions(self, ctx: OpContext, limit: int) -> list[Contribution]:
        ctx.require(Permission.READ)
        return await self._storage.read_contributions(ctx.org_id, self._clamp(limit))

    async def get_contribution(self, ctx: OpContext, contribution_id: UUID) -> Contribution:
        ctx.require(Permission.READ)
        found = await self._storage.read_contribution(ctx.org_id, contribution_id)
        if found is None:
            raise NotFound("no such contribution")
        return found

    async def settle_checkout(
        self,
        rctx: RequestContext,
        org_id: UUID,
        pledge_id: UUID,
        delivery_key: UUID,
        subscription_id: str | None,
    ) -> Pledge:
        current = await self._storage.read_pledge(org_id, pledge_id)
        if current is None:
            raise NotFound("no such pledge")
        settled = current
        if current.status == PledgeStatus.PENDING:
            now = utcnow()
            settled = current.model_copy(
                update={
                    "status": rules.settled_status(current.mode),
                    "subscription_id": subscription_id,
                    "settled_at": now,
                    "updated_at": now,
                    "updated_by": EMPTY_UUID,  # the platform, on the processor's signed word
                }
            )
            rows = (
                platform_outbox_row(rctx, org_id, "support.pledge.updated", settled.id, {}),
                platform_outbox_row(
                    rctx, org_id, SEND_NOTIFICATION_ROW, settled.id, {"topic": NotificationTopic.SUPPORT_RECEIPT.value}
                ),
            )
            await self._storage.write_pledge(org_id, settled, rows)
            await self._relay_all(org_id, rows)
        # The desk's record, appended once per delivery; a redelivery finds its id and adds nothing.
        await self._storage.append_contribution(
            settled.desk_id,
            Contribution(
                id=delivery_key,
                journalist_id=settled.journalist_id,
                pledge_id=settled.id,
                supporter_org_id=org_id,
                supporter_name=settled.supporter_name,
                amount_minor=settled.amount_minor,
                currency=settled.currency,
                mode=settled.mode,
                platform_fee_minor=settled.platform_fee_minor,
                received_at=settled.settled_at or utcnow(),
            ),
        )
        return settled

    def _clamp(self, limit: int) -> int:
        return max(1, min(limit, self._options.page_size))

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; the write has committed, a failure is the sweep's
