"""The work items table, in the queue role."""
