"""Contract cases of the reports storage: the sealed report once, submissions and messages under another desk, the
inbox filters, the notes the source never reads, the id, the race."""

import asyncio
from uuid import UUID

import pytest

from acme.om.base import new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.reports.types.message import Message, MessageDirection
from acme.om.reports.types.sealed_report import SealedReport
from acme.om.reports.types.submission import Submission, SubmissionState
from acme.om.storage.root import StorageInterface
from contracts import factories as f


def sealed() -> SealedReport:
    return SealedReport(id=new_id(), created_at=utcnow(), ciphertext="c2VhbGVk", algorithm="test")


def submission(report_id: UUID | None = None, tags: tuple[str, ...] = ()) -> Submission:
    now = utcnow()
    return Submission(
        id=new_id(),
        created_at=now,
        updated_at=now,
        created_by=new_id(),
        updated_by=new_id(),
        report_id=report_id or new_id(),
        journalist_id=new_id(),
        wrapped_key="d3JhcHBlZA",
        source_public_key="c291cmNl",
        reply_digest="0" * 64,
        tags=tags,
    )


def message(submission_id: UUID, direction: MessageDirection = MessageDirection.TO_SOURCE) -> Message:
    return Message(
        id=new_id(), created_at=utcnow(), submission_id=submission_id, direction=direction, sealed_body="Ym9keQ"
    )


async def case_a_sealed_report_is_written_once_and_read_by_id(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    r = sealed()
    assert await s.create_sealed_report(r) is True
    assert await s.create_sealed_report(r.model_copy(update={"ciphertext": "b3RoZXI"})) is False
    assert await s.read_sealed_report(r.id) == r
    assert await s.read_sealed_report(new_id()) is None


async def case_create_then_read_list_and_write_a_submission(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id = new_id()
    sub = submission()
    r = f.row(org_id, "reports.submission.created", sub.id)
    assert await s.create_submission(org_id, sub, (r,)) is True
    assert await s.read_submission(org_id, sub.id) == sub
    assert await s.read_submissions(org_id, 10) == [sub]
    worked = sub.model_copy(update={"state": SubmissionState.REVIEWING, "tags": ("water",)})
    w = f.row(org_id, "reports.submission.updated", sub.id)
    await s.write_submission(org_id, worked, (w,))
    assert await s.read_submission(org_id, sub.id) == worked
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r
    assert await storage.get_outbox_storage().read_row(org_id, w.id) == w


async def case_the_inbox_is_the_newest_first_and_filters_by_state_and_tag(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id = new_id()
    a, b = submission(tags=("water", "city")), submission(tags=("city",))
    c = submission().model_copy(update={"state": SubmissionState.USEFUL})
    for sub in (a, b, c):
        await s.create_submission(org_id, sub, ())
    newest = sorted([a, b, c], key=lambda x: x.id.int, reverse=True)
    assert await s.read_submissions(org_id, 10) == newest
    assert await s.read_submissions(org_id, 1) == newest[:1]
    assert await s.read_submissions(org_id, 10, state=SubmissionState.USEFUL) == [c]
    assert await s.read_submissions(org_id, 10, tag="water") == [a]
    assert await s.read_submissions(org_id, 10, state=SubmissionState.NEW, tag="city") == sorted(
        [a, b], key=lambda x: x.id.int, reverse=True
    )


async def case_a_second_submission_create_under_the_same_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id = new_id()
    sub = submission()
    await s.create_submission(org_id, sub, ())
    again = f.row(org_id, "reports.submission.created", sub.id)
    assert await s.create_submission(org_id, sub.model_copy(update={"wrapped_key": "eA"}), (again,)) is False
    assert await s.read_submission(org_id, sub.id) == sub
    assert await storage.get_outbox_storage().read_row(org_id, again.id) is None


async def case_submissions_under_another_desk_are_not_found_and_not_changed(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id, other = new_id(), new_id()
    sub = submission(tags=("water",))
    await s.create_submission(org_id, sub, ())
    assert await s.read_submissions(other, 10) == []
    assert await s.read_submissions(other, 10, state=SubmissionState.NEW, tag="water") == []
    assert await s.read_submission(other, sub.id) is None
    taken = f.row(other, "reports.submission.created", sub.id)
    assert await s.create_submission(other, sub, (taken,)) is False
    assert await storage.get_outbox_storage().read_row(other, taken.id) is None
    w = f.row(other, "reports.submission.updated", sub.id)
    with pytest.raises(Conflict):
        await s.write_submission(other, sub.model_copy(update={"state": SubmissionState.ARCHIVED}), (w,))
    assert await s.read_submission(org_id, sub.id) == sub
    assert await storage.get_outbox_storage().read_row(other, w.id) is None


async def case_messages_list_the_oldest_first_and_leave_out_notes_when_asked(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id = new_id()
    sub_id = new_id()
    reply = message(sub_id)
    note = message(sub_id, MessageDirection.NOTE)
    answer = message(sub_id, MessageDirection.FROM_SOURCE)
    elsewhere = message(new_id())
    r = f.row(org_id, "reports.message.created", reply.id)
    assert await s.create_message(org_id, reply, (r,)) is True
    for m in (note, answer, elsewhere):
        await s.create_message(org_id, m, ())
    assert await s.read_messages(org_id, sub_id, 10) == [reply, note, answer]
    assert await s.read_messages(org_id, sub_id, 2) == [reply, note]
    assert await s.read_messages(org_id, sub_id, 10, without_notes=True) == [reply, answer]
    assert await s.read_message(org_id, note.id) == note
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r


async def case_a_second_message_create_under_the_same_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id = new_id()
    m = message(new_id())
    await s.create_message(org_id, m, ())
    again = f.row(org_id, "reports.message.created", m.id)
    assert await s.create_message(org_id, m.model_copy(update={"sealed_body": "eA"}), (again,)) is False
    assert await s.read_message(org_id, m.id) == m
    assert await storage.get_outbox_storage().read_row(org_id, again.id) is None


async def case_messages_under_another_desk_are_not_found_and_not_changed(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id, other = new_id(), new_id()
    m = message(new_id())
    await s.create_message(org_id, m, ())
    assert await s.read_messages(other, m.submission_id, 10) == []
    assert await s.read_messages(other, m.submission_id, 10, without_notes=True) == []
    assert await s.read_message(other, m.id) is None
    taken = f.row(other, "reports.message.created", m.id)
    assert await s.create_message(other, m, (taken,)) is False
    assert await s.read_message(other, m.id) is None
    assert await storage.get_outbox_storage().read_row(other, taken.id) is None


async def case_create_races_have_one_winner(storage: StorageInterface) -> None:
    s = storage.get_report_storage()
    org_id = new_id()
    r, sub = sealed(), submission()
    m = message(sub.id)
    sealed_results = await asyncio.gather(s.create_sealed_report(r), s.create_sealed_report(r))
    sub_results = await asyncio.gather(s.create_submission(org_id, sub, ()), s.create_submission(org_id, sub, ()))
    msg_results = await asyncio.gather(s.create_message(org_id, m, ()), s.create_message(org_id, m, ()))
    assert sorted(sealed_results) == sorted(sub_results) == sorted(msg_results) == [False, True]
    assert await s.read_messages(org_id, sub.id, 10) == [m]


CASES = [
    case_a_sealed_report_is_written_once_and_read_by_id,
    case_create_then_read_list_and_write_a_submission,
    case_the_inbox_is_the_newest_first_and_filters_by_state_and_tag,
    case_a_second_submission_create_under_the_same_id_changes_nothing,
    case_submissions_under_another_desk_are_not_found_and_not_changed,
    case_messages_list_the_oldest_first_and_leave_out_notes_when_asked,
    case_a_second_message_create_under_the_same_id_changes_nothing,
    case_messages_under_another_desk_are_not_found_and_not_changed,
    case_create_races_have_one_winner,
]
