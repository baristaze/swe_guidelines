// The API's routes as typed calls over the one transport. Configured once, before the first
// render, by main.tsx; nothing else constructs a transport.
import { createTransport, type Transport, type TransportOptions } from "./client";
import type {
  AddApiKeyRequest,
  AddFollowRequest,
  AddJournalistRequest,
  AddMessageRequest,
  AddPledgeRequest,
  AddUpdateRequest,
  ApiKeyView,
  ContributionView,
  EventView,
  FeedItemView,
  FollowView,
  IssuedApiKeyView,
  IssuedSessionView,
  IssuedSignInView,
  JournalistView,
  MemberView,
  MembershipChoiceView,
  MessageView,
  OpenedSubmissionView,
  OrgView,
  PayoutOnboardingView,
  PledgeView,
  PublishedJournalistView,
  RealtimeTicketView,
  Role,
  SignInRequest,
  SignUpRequest,
  SourceMessageRequest,
  SourceThreadView,
  StartedPledgeView,
  StartPayoutsRequest,
  SubmissionReceiptView,
  SubmissionState,
  SubmissionView,
  SubmitReportRequest,
  UpdateJournalistRequest,
  UpdateSubmissionRequest,
  UpdateUserRequest,
  UpdateView,
  UserView,
} from "./types";

let transport: Transport | null = null;

export function configureApi(options: TransportOptions): void {
  transport = createTransport(options);
}

function t(): Transport {
  if (transport === null) throw new Error("the API client is used before configureApi");
  return transport;
}

const enc = encodeURIComponent;

/** The source's follow-up credential; the platform keeps only its digest. */
const REPLY_SECRET_HEADER = "x-reply-secret";

export const api = {
  auth: {
    signUp: (body: SignUpRequest) => t().request<IssuedSignInView>("POST", "/auth/signup", { body, anonymous: true }),
    login: (body: SignInRequest) => t().request<IssuedSignInView>("POST", "/auth/login", { body, anonymous: true }),
    memberships: (limit?: number) => t().request<MembershipChoiceView[]>("GET", "/auth/memberships", { query: { limit } }),
    exchange: (orgId: string) => t().request<IssuedSessionView>("POST", "/auth/exchange", { body: { org_id: orgId } }),
    logout: () => t().request<void>("POST", "/auth/logout"),
  },
  org: {
    get: () => t().request<OrgView>("GET", "/org"),
  },
  me: {
    get: () => t().request<UserView>("GET", "/me"),
    update: (body: UpdateUserRequest) => t().request<UserView>("PATCH", "/me", { body }),
  },
  members: {
    list: (limit?: number) => t().request<MemberView[]>("GET", "/members", { query: { limit } }),
    updateRole: (userId: string, role: Role) => t().request<MemberView>("PATCH", `/members/${enc(userId)}`, { body: { role } }),
    remove: (userId: string) => t().request<void>("DELETE", `/members/${enc(userId)}`),
  },
  apiKeys: {
    list: (limit?: number) => t().request<ApiKeyView[]>("GET", "/api-keys", { query: { limit } }),
    create: (body: AddApiKeyRequest) => t().request<IssuedApiKeyView>("POST", "/api-keys", { body, creates: true }),
    revoke: (keyId: string) => t().request<void>("DELETE", `/api-keys/${enc(keyId)}`),
  },
  events: {
    list: (afterSeq: number, limit?: number) =>
      t().request<EventView[]>("GET", "/events", { query: { after_seq: afterSeq, limit } }),
  },
  realtime: {
    ticket: () => t().request<RealtimeTicketView>("POST", "/realtime/tickets", { creates: true }),
    socketUrl: (ticket: string) => t().socketUrl("/realtime/socket", { ticket }),
  },
  journalists: {
    list: (limit?: number) => t().request<JournalistView[]>("GET", "/journalists", { query: { limit } }),
    get: (id: string) => t().request<JournalistView>("GET", `/journalists/${enc(id)}`),
    create: (body: AddJournalistRequest) => t().request<JournalistView>("POST", "/journalists", { body, creates: true }),
    update: (id: string, body: UpdateJournalistRequest) =>
      t().request<JournalistView>("PATCH", `/journalists/${enc(id)}`, { body }),
    remove: (id: string) => t().request<void>("DELETE", `/journalists/${enc(id)}`),
    startPayouts: (id: string, body: StartPayoutsRequest) =>
      t().request<PayoutOnboardingView>("POST", `/journalists/${enc(id)}/payouts`, { body }),
  },
  follows: {
    list: (limit?: number) => t().request<FollowView[]>("GET", "/follows", { query: { limit } }),
    get: (id: string) => t().request<FollowView>("GET", `/follows/${enc(id)}`),
    create: (body: AddFollowRequest) => t().request<FollowView>("POST", "/follows", { body, creates: true }),
    remove: (id: string) => t().request<void>("DELETE", `/follows/${enc(id)}`),
    feed: (limit?: number) => t().request<FeedItemView[]>("GET", "/feed", { query: { limit } }),
  },
  updates: {
    list: (limit?: number) => t().request<UpdateView[]>("GET", "/updates", { query: { limit } }),
    get: (id: string) => t().request<UpdateView>("GET", `/updates/${enc(id)}`),
    create: (body: AddUpdateRequest) => t().request<UpdateView>("POST", "/updates", { body, creates: true }),
  },
  support: {
    pledges: (limit?: number) => t().request<PledgeView[]>("GET", "/pledges", { query: { limit } }),
    pledge: (id: string) => t().request<PledgeView>("GET", `/pledges/${enc(id)}`),
    pledgeTo: (body: AddPledgeRequest) => t().request<StartedPledgeView>("POST", "/pledges", { body, creates: true }),
    cancel: (id: string) => t().request<PledgeView>("POST", `/pledges/${enc(id)}/cancel`),
    contributions: (limit?: number) => t().request<ContributionView[]>("GET", "/contributions", { query: { limit } }),
  },
  reports: {
    /** A signed-in reader's report under their own name. */
    submitNamed: (body: SubmitReportRequest) => t().request<SubmissionReceiptView[]>("POST", "/reports", { body, creates: true }),
    submissions: (filter: { state?: SubmissionState; tag?: string; limit?: number } = {}) =>
      t().request<SubmissionView[]>("GET", "/submissions", { query: { state: filter.state, tag: filter.tag, limit: filter.limit } }),
    submission: (id: string) => t().request<SubmissionView>("GET", `/submissions/${enc(id)}`),
    sealed: (id: string) => t().request<OpenedSubmissionView>("GET", `/submissions/${enc(id)}/sealed`),
    update: (id: string, body: UpdateSubmissionRequest) =>
      t().request<SubmissionView>("PATCH", `/submissions/${enc(id)}`, { body }),
    messages: (id: string, limit?: number) =>
      t().request<MessageView[]>("GET", `/submissions/${enc(id)}/messages`, { query: { limit } }),
    addMessage: (id: string, body: AddMessageRequest) =>
      t().request<MessageView>("POST", `/submissions/${enc(id)}/messages`, { body, creates: true }),
  },
  /** The routes anyone reaches by a desk's link: no bearer is sent, whoever is signed in. */
  public: {
    journalist: (deskId: string, journalistId: string) =>
      t().request<PublishedJournalistView>("GET", `/public/desks/${enc(deskId)}/journalists/${enc(journalistId)}`, { anonymous: true }),
    updates: (deskId: string, journalistId: string, limit?: number) =>
      t().request<UpdateView[]>("GET", `/public/desks/${enc(deskId)}/journalists/${enc(journalistId)}/updates`, {
        query: { limit },
        anonymous: true,
      }),
    /** The anonymous intake: the ids are minted on the device, so a retry lands once. */
    submit: (body: SubmitReportRequest) =>
      t().request<SubmissionReceiptView[]>("POST", "/public/reports", { body, anonymous: true, repeatable: true }),
    thread: (deskId: string, submissionId: string, replySecret: string) =>
      t().request<SourceThreadView>("GET", `/public/reports/${enc(deskId)}/${enc(submissionId)}`, {
        anonymous: true,
        headers: { [REPLY_SECRET_HEADER]: replySecret },
      }),
    answer: (deskId: string, submissionId: string, replySecret: string, body: SourceMessageRequest) =>
      t().request<MessageView>("POST", `/public/reports/${enc(deskId)}/${enc(submissionId)}/messages`, {
        body,
        anonymous: true,
        repeatable: true,
        headers: { [REPLY_SECRET_HEADER]: replySecret },
      }),
  },
};

export type Api = typeof api;
