import { describe, expect, it, vi } from "vitest";
import { ApiError, createTransport } from "./client";
import { backoffDelay, MAX_ATTEMPTS, MAX_DELAY_MS, retryAfterDelay, shouldRetry } from "./retry";

function json(status: number, body: unknown, headers: Record<string, string> = {}): Response {
  return new Response(body === undefined ? null : JSON.stringify(body), { status, headers: { "content-type": "application/json", ...headers } });
}

function transport(responses: Array<Response | Error>, overrides: { getToken?: () => string | null; onUnauthorized?: () => void } = {}) {
  const calls: Array<{ url: string; init: RequestInit }> = [];
  const fetchImpl = vi.fn(async (url: string | URL | Request, init?: RequestInit) => {
    calls.push({ url: String(url), init: init ?? {} });
    const next = responses.shift();
    if (next === undefined) throw new Error("no more responses");
    if (next instanceof Error) throw next;
    return next;
  });
  let n = 0;
  const t = createTransport({
    apiOrigin: "http://api.test",
    requestTimeoutMs: 1000,
    getToken: overrides.getToken ?? (() => "tok"),
    onUnauthorized: overrides.onUnauthorized ?? (() => {}),
    fetchImpl: fetchImpl as unknown as typeof fetch,
    sleep: async () => {},
    newKey: () => `key-${++n}`,
  });
  return { t, calls };
}

describe("retry policy", () => {
  it("retries a read on a timeout, a dropped connection, and an unavailable answer", () => {
    for (const outcome of [{ kind: "timeout" }, { kind: "network" }, { kind: "status", status: 503 }] as const) {
      expect(shouldRetry({ method: "GET", idempotencyKey: false, outcome, attempt: 1 })).toBe(true);
    }
  });

  it("never retries an answer that would not differ", () => {
    for (const status of [400, 401, 403, 404, 409, 422, 429, 500]) {
      expect(shouldRetry({ method: "GET", idempotencyKey: false, outcome: { kind: "status", status }, attempt: 1 })).toBe(false);
    }
  });

  it("retries a POST after a timeout only when it carries an Idempotency-Key", () => {
    expect(shouldRetry({ method: "POST", idempotencyKey: false, outcome: { kind: "timeout" }, attempt: 1 })).toBe(false);
    expect(shouldRetry({ method: "POST", idempotencyKey: true, outcome: { kind: "timeout" }, attempt: 1 })).toBe(true);
    expect(shouldRetry({ method: "POST", idempotencyKey: false, outcome: { kind: "status", status: 503 }, attempt: 1 })).toBe(true);
  });

  it("is bounded", () => {
    expect(shouldRetry({ method: "GET", idempotencyKey: false, outcome: { kind: "network" }, attempt: MAX_ATTEMPTS })).toBe(false);
  });

  it("grows the delay, keeps jitter, and caps it", () => {
    expect(backoffDelay(1, () => 0)).toBeLessThan(backoffDelay(2, () => 0));
    expect(backoffDelay(2, () => 0)).not.toBe(backoffDelay(2, () => 1));
    expect(backoffDelay(20, () => 1)).toBeLessThanOrEqual(MAX_DELAY_MS);
    expect(retryAfterDelay("1")).toBe(1000);
    expect(retryAfterDelay("600")).toBeNull();
  });
});

describe("transport", () => {
  it("sends the app header and the bearer, and parses the answer", async () => {
    const { t, calls } = transport([json(200, { id: "o", name: "Desk", slug: "desk" })]);
    await expect(t.request("GET", "/org")).resolves.toEqual({ id: "o", name: "Desk", slug: "desk" });
    const headers = new Headers(calls[0]?.init.headers);
    expect(calls[0]?.url).toBe("http://api.test/v1/org");
    expect(headers.get("x-app-type")).toBe("portal");
    expect(headers.get("x-app-version")).toBe("portal@0.1.0");
    expect(headers.get("authorization")).toBe("Bearer tok");
  });

  it("parses the error envelope into an ApiError carrying the request id", async () => {
    const { t } = transport([json(409, { error: { code: "conflict", message: "taken", request_id: "req-1" } })]);
    const error = await t.request("GET", "/org").catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ApiError);
    expect(error).toMatchObject({ status: 409, code: "conflict", requestId: "req-1" });
  });

  it("clears authentication on a 401, except on an anonymous sign-in call", async () => {
    const onUnauthorized = vi.fn();
    const envelope = { error: { code: "unauthorized", message: "no", request_id: "r" } };
    const { t } = transport([json(401, envelope), json(401, envelope)], { onUnauthorized });
    await t.request("GET", "/org").catch(() => {});
    expect(onUnauthorized).toHaveBeenCalledTimes(1);
    await t.request("POST", "/auth/login", { anonymous: true }).catch(() => {});
    expect(onUnauthorized).toHaveBeenCalledTimes(1);
  });

  it("sends the same Idempotency-Key on every retry of one create, and a new one per create", async () => {
    const { t, calls } = transport([
      json(503, { error: { code: "unavailable", message: "busy", request_id: "r" } }),
      json(201, { id: "j" }),
      json(201, { id: "k" }),
    ]);
    await t.request("POST", "/journalists", { body: { display_name: "A" }, creates: true });
    await t.request("POST", "/journalists", { body: { display_name: "B" }, creates: true });
    const keys = calls.map((c) => new Headers(c.init.headers).get("idempotency-key"));
    expect(keys).toEqual(["key-1", "key-1", "key-2"]);
  });

  it("gives up after the bounded attempts with a typed network error", async () => {
    const { t, calls } = transport([new TypeError("refused"), new TypeError("refused"), new TypeError("refused")]);
    await expect(t.request("GET", "/org")).rejects.toMatchObject({ code: "network" });
    expect(calls).toHaveLength(MAX_ATTEMPTS);
  });

  it("sends a public create with its headers, no bearer and no key, and repeats it after a dropped connection", async () => {
    const { t, calls } = transport([new TypeError("refused"), json(201, { id: "m" })]);
    await t.request("POST", "/public/reports/d/s/messages", {
      body: { id: "m" },
      anonymous: true,
      repeatable: true,
      headers: { "x-reply-secret": "secret" },
    });
    expect(calls).toHaveLength(2);
    const headers = new Headers(calls[1]?.init.headers);
    expect(headers.get("x-reply-secret")).toBe("secret");
    expect(headers.get("authorization")).toBeNull();
    expect(headers.get("idempotency-key")).toBeNull();
  });

  it("builds the socket URL on the API origin", () => {
    const { t } = transport([]);
    expect(t.socketUrl("/realtime/socket", { ticket: "abc" })).toBe("ws://api.test/v1/realtime/socket?ticket=abc");
  });
});
