"""The support rules: the platform fee, and what a pledge may ask for. Plain functions over values."""

from acme.om.support.types.pledge import PledgeStatus, SupportMode

CURRENCIES = frozenset({"eur", "usd", "gbp"})


def platform_fee_minor(amount_minor: int, fee_basis_points: int) -> int:
    """The platform's share in minor units, rounded down, configured apart from the processor's fees."""
    return amount_minor * fee_basis_points // 10_000


def pledge_problem(amount_minor: int, currency: str, minimum_minor: int, maximum_minor: int) -> str | None:
    """Why a pledge cannot be taken, or None."""
    if currency not in CURRENCIES:
        return f"the currency must be one of {sorted(CURRENCIES)}"
    if not minimum_minor <= amount_minor <= maximum_minor:
        return f"the amount must be between {minimum_minor} and {maximum_minor} minor units"
    return None


def settled_status(mode: SupportMode) -> PledgeStatus:
    return PledgeStatus.ACTIVE if mode == SupportMode.MONTHLY else PledgeStatus.PAID


def cancellable(status: PledgeStatus, mode: SupportMode) -> bool:
    """A pending pledge may be abandoned; a settled one only when it is monthly and still active."""
    return status == PledgeStatus.PENDING or (mode == SupportMode.MONTHLY and status == PledgeStatus.ACTIVE)
