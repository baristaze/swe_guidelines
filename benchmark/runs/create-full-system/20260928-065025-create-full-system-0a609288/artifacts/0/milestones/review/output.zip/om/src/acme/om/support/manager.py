"""The support manager: the swimlane of a reader's pledges and the contributions a desk receives."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.opcontext import OpContext, RequestContext
from acme.om.support.types.contribution import Contribution
from acme.om.support.types.pledge import Pledge


class SupportManagerInterface(ABC):
    # --- the supporter's account

    @abstractmethod
    async def get_pledges(self, ctx: OpContext, limit: int) -> list[Pledge]:
        """The account's payment history, the newest first."""
        ...

    @abstractmethod
    async def get_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge: ...

    @abstractmethod
    async def create_pledge(self, ctx: OpContext, pledge: Pledge) -> Pledge:
        """Opens a pledge to a published journalist whose desk takes payouts, pending until the processor settles it;
        a rerun under the same id returns it as stored."""
        ...

    @abstractmethod
    async def attach_checkout(self, ctx: OpContext, pledge_id: UUID, checkout_session_id: str) -> Pledge:
        """Records the processor's checkout opened for a pending pledge."""
        ...

    @abstractmethod
    async def cancel_pledge(self, ctx: OpContext, pledge_id: UUID) -> Pledge:
        """Ends an active monthly pledge, or abandons a pending one; Conflict for any other."""
        ...

    # --- the desk

    @abstractmethod
    async def get_contributions(self, ctx: OpContext, limit: int) -> list[Contribution]:
        """The desk's received contributions, the newest first."""
        ...

    @abstractmethod
    async def get_contribution(self, ctx: OpContext, contribution_id: UUID) -> Contribution: ...

    # --- the request stage: a payment delivery whose signature the edge verified (ADR 0010)

    @abstractmethod
    async def settle_checkout(
        self,
        rctx: RequestContext,
        org_id: UUID,
        pledge_id: UUID,
        delivery_key: UUID,
        subscription_id: str | None,
    ) -> Pledge:
        """Settles the pledge in the supporter's account `org_id` and appends the contribution to its desk, the
        contribution's id the delivery key, so a redelivery changes nothing. NotFound for an unknown pledge."""
        ...
