# Handoff

## Session 2 (2026-09-28): the Initial MVP

Task: build the three MVP loops of the product spec (follow and support; a tip, anonymous or not, encrypted on the
device per recipient; the journalist's inbox and reply), each namespace and entity through the namespace and entity
scaffolds, each worker kind through the worker scaffold. Done when `make check` and `make test-integration` pass and
each loop has an end-to-end integration test. Gate bound: one run, then at most three more.

### Decisions (see ADRs)

- ADR 0009: every account is a tenant; published profile and updates are request-stage reads by desk id; the
  intake and the source side of the thread are request-stage operations naming the desk; the report ciphertext is
  stored once in the system-scoped `sealed_reports`; one `submissions` row per recipient desk; reply secret digest;
  one work kind `SEND_NOTIFICATION` on a `notifier` worker.
- ADR 0010 (a deviation): the payment webhook settles in the request instead of the inbound queue.
- "The gates" means `make check` and `make test-integration`; single tools (ruff, pyright, pytest on a file,
  arch-check) are run freely while writing.

### Status

Done (unit tests green, pyright and ruff clean, `make migrate` + `make migrate-check` in step):
- `journalists`: `Journalist` gains `bio`, `public_key`, `published`, and the manager-owned `payout_account_id`
  (migration `core/202609281700`); `set_payout_account`, `get_published_journalist` (request stage).
- Namespaces with their entities, storage (Postgres + memory), contract cases (unit + integration), manager tests:
  `follows`/`Follow`, `updates`/`Update`, `support`/`Pledge` + `Contribution` (activity role),
  `reports`/`SealedReport` (system scope) + `Submission` + `Message`.
- `tenancy.get_member_addresses`, `outbox.platform_outbox_row`, `WorkKind.SEND_NOTIFICATION` with
  `SendNotificationPayload`, `PaymentsInterface.cancel_subscription` (Stripe + twin + recorded fixture).
- API: types, services, impls, routers for all of the above, including `/v1/public/...` (published profile and
  updates, the intake, the source's thread), `/v1/webhooks/payments`, and the intake rate limit
  (`ACME_API_RATE_LIMIT_INTAKE`). New settings are in `.env.example`.

- API suites per namespace (memory): `services/api/tests/test_{follows_follow,updates_update,support_pledge,
  reports_submission}_api.py`, payouts and the public read in the journalists suite, the intake's rate limit.
- The `notifier` worker (`workers/notifier`, kind `SEND_NOTIFICATION`, env prefix `ACME_NOTIFIER_`, port 9101): copied
  from the maintenance worker's loop without the sweep; Terraform module instance per environment (validated),
  observability alarm, ECR repository, Dockerfile, CI image matrix, both deploy workflows, `scripts/dev.sh`,
  Prometheus scrape.
- Device crypto: `clients/python/src/acme/clients/api/sealing.py` (P-256 ECDH + HKDF-SHA256 + AES-256-GCM).
- The three end-to-end loops (integration, over Postgres, API in-process + the notifier's real loop):
  `services/api/tests/test_loop_follow_and_support.py`, `test_loop_tip.py`, `test_loop_inbox_and_reply.py`
  (stack in `loop_stack.py`, parties in `parties.py`). All green when run on their own.

- `arch-check` findings closed: the delivery key (UUID v5) moved to `integrations/payments` (`WebhookDelivery.key`);
  the payment signature and the reply secret are read by the gateway (`gateway/webhooks.py`, `gateway/auth.py`); the
  public intake routes moved to `routers/intake.py` with a scoped NET-09 exception (ADR 0009, `specs/architecture.md`
  Deviations, root `pyproject.toml`).
- `make openapi` run; the portal (subagent) has facade types, query hooks, screens (journalists extended, updates,
  inbox + submission detail, contributions, following, pledges, public profile `/p/:deskId/:journalistId`, source
  thread `/r/:deskId/:submissionId`), WebCrypto sealing interoperable with the Python client (fixture test), keys in
  IndexedDB as non-extractable CryptoKeys. Attachments/EXIF stripping and key backup are not built.
- Docs: `om/README.md`, the namespace READMEs, `docs/architecture.md`, `llms.txt`, `deployment/README.md`.

### Gates

Run 1 (of at most 4), 2026-09-28: `make check` passed (ruff, format, pyright, arch-check with 3 accepted exceptions,
377 Python unit tests, the portal's lint/typecheck/112 tests); `make test-integration` passed (117 tests, the four
loop tests among them). No rerun was needed. `make migrate-check` was in step after the last migration.

### Left (outside the MVP, or noticed and not done)

- Not built: attachments in the bucket and EXIF stripping on the device, refunds, journalist verification, opt-in
  SMS, the in-app notification center, update fan-out by email, retention purges of archived submissions, key
  backup, a public directory, follower counts.
- `scripts/cloud_create.sh` / `cloud_nuke.sh` still name only the api and maintenance images; the notifier's
  repository comes from the bootstrap roots' `ecr_repositories`, but the scripts' printed summaries do not list it.
- Session 1's stop (`make test-telemetry`, the request log line's null request id) was outside this task and is
  untouched.
- Nothing is committed (the folder is not a git repository); the scaffold skills' per-step gate runs were folded into
  the one gate run above, to stay inside the bound the user set.

## Session 1 (the scaffold run), summary

`arch-scaffold-new free-journalism acme ... --first journalists Journalist display_name:str` against guideline
v0.37.0: skeleton, API, maintenance worker, portal, `journalists` namespace, ADRs 0001–0008. It stopped at
`make test-telemetry` (the request log line carried `request_id: null` because `RequestIdMiddleware` reset the
context var before logging, in `services/api/src/acme/services/api/gateway/observability.py`). That telemetry step
is outside this session's task and was left as it was.
