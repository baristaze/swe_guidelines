"""The tenancy manager impl: every transition that builds a stage above the request stage lives here."""

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from uuid import UUID

from acme.infra.topics import SESSION_REVOKED, EntityChangedPayload, Topics, TopicsInterface
from acme.om.base import EMPTY_UUID, PROVENANCE_FIELDS, new_id, utcnow
from acme.om.events.manager import EventsManagerInterface
from acme.om.exceptions import (
    Conflict,
    NotAuthenticated,
    NotAuthorized,
    NotFound,
    SecondFactorRequired,
    TooManyRequests,
    Unavailable,
    ValidationFailed,
)
from acme.om.opcontext import (
    CredentialKind,
    IdentityContext,
    OpContext,
    OperatorContext,
    OperatorPermission,
    Permission,
    RequestContext,
    Role,
    SecurityContext,
)
from acme.om.outbox.manager import OutboxRelayInterface
from acme.om.outbox.types import OutboxRow, operator_outbox_row, outbox_row
from acme.om.storage.root import InsertOutcome
from acme.om.tenancy import rules
from acme.om.tenancy.impl.credentials import (
    TokenPrefix,
    TotpCipher,
    base32,
    digest,
    email_digest,
    hash_password,
    mint,
    new_totp_secret,
    verify_password,
)
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.om.tenancy.storage import TenancyStorageInterface
from acme.om.tenancy.types import (
    ApiKey,
    ApiKeyInsert,
    Identity,
    IssuedApiKey,
    IssuedCredential,
    MarkerGuard,
    Member,
    MemberAddress,
    Membership,
    MembershipChoice,
    OperatorEntry,
    Org,
    PlatformSize,
    Session,
    SessionKind,
    SignedIn,
    SocketGrant,
    SocketTicket,
    TotpEnrolment,
    User,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TenancyOptions:
    signup_enabled: bool
    session_idle: timedelta
    session_absolute: timedelta
    login_ttl: timedelta
    socket_ticket_ttl: timedelta
    api_key_max_expiry: timedelta
    operator_token_max: timedelta
    touch_interval: timedelta
    sign_in_delay_base: timedelta
    sign_in_delay_cap: timedelta
    page_size: int
    purge_batch: int
    totp_encryption_key: str | None  # None in a process that never enrols a second factor (a worker)
    totp_issuer: str


class TenancyManagerImpl(TenancyManagerInterface):
    def __init__(
        self,
        storage: TenancyStorageInterface,
        events: EventsManagerInterface,
        relay: OutboxRelayInterface,
        topics: TopicsInterface,
        options: TenancyOptions,
    ) -> None:
        self._storage = storage
        self._events = events
        self._relay = relay
        self._topics = topics
        self._options = options
        self._cipher = None if options.totp_encryption_key is None else TotpCipher(options.totp_encryption_key)

    # --- helpers

    def _clamp(self, limit: int) -> int:
        return max(1, min(limit, self._options.page_size))

    async def _relay_all(self, org_id: UUID, rows: tuple[OutboxRow, ...]) -> None:
        for row in rows:
            await self._relay.relay(org_id, row)  # never raises; a failure is left to the sweep

    async def _publish_revoked(self, org_id: UUID, session_id: UUID, identity_id: UUID) -> None:
        await self._topics.publish(
            Topics.ENTITY_CHANGED,
            EntityChangedPayload(
                idempotency_key=new_id(),
                produced_at=utcnow(),
                org_id=org_id,
                kind=SESSION_REVOKED,
                target_id=session_id,
                seq=None,
                actor_id=identity_id,
            ),
        )

    def _session_live(self, session: Session | None, kind: SessionKind, now: datetime) -> bool:
        if session is None or session.kind != kind or session.ended_at is not None:
            return False
        if session.expires_at <= now:
            return False
        return session.last_seen_at + self._options.session_idle > now

    async def _touch(self, session: Session, now: datetime) -> None:
        if now - session.last_seen_at >= self._options.touch_interval:
            await self._storage.touch_session(session.identity_id, session.id, now)

    async def _new_session(
        self,
        identity_id: UUID,
        kind: SessionKind,
        ttl: timedelta,
        *,
        tenant_id: UUID = EMPTY_UUID,
        user_id: UUID | None = None,
        permission: OperatorPermission | None = None,
        second_factor: bool = False,
    ) -> tuple[Session, str]:
        prefix = {
            SessionKind.LOGIN: TokenPrefix.LOGIN,
            SessionKind.TENANT: TokenPrefix.TENANT_SESSION,
            SessionKind.OPERATOR: TokenPrefix.OPERATOR_TOKEN,
        }[kind]
        token = mint(prefix)
        now = utcnow()
        session = Session(
            id=new_id(),
            created_at=now,
            identity_id=identity_id,
            kind=kind,
            tenant_id=tenant_id,
            user_id=user_id,
            permission=permission,
            digest=digest(token),
            second_factor=second_factor,
            last_seen_at=now,
            expires_at=now + ttl,
        )
        return session, token

    async def _choices(self, identity_id: UUID, limit: int) -> tuple[MembershipChoice, ...]:
        out: list[MembershipChoice] = []
        for m in await self._storage.read_identity_memberships(identity_id, self._clamp(limit)):
            org = await self._storage.read_org(m.tenant_id)
            if org is None or org.deleted_at is not None:
                continue
            out.append(
                MembershipChoice(org_id=org.id, org_name=org.name, org_slug=org.slug, user_id=m.user_id, role=m.role)
            )
        return tuple(out)

    def _new_identity(self, email: str, display_name: str, password: str | None, now: datetime) -> Identity:
        identity_id = new_id()
        return Identity(
            id=identity_id,
            created_at=now,
            updated_at=now,
            created_by=identity_id,
            updated_by=identity_id,
            email=email.strip().lower(),
            email_digest=email_digest(email),
            display_name=display_name,
            password_hash=None if password is None else hash_password(password),
        )

    @staticmethod
    def _member_rows(
        org_id: UUID, identity_id: UUID, name: str, role: Role, actor: UUID, now: datetime, user_id: UUID | None = None
    ) -> tuple[User, Membership]:
        user = User(
            id=user_id or new_id(),
            name=name,
            created_at=now,
            updated_at=now,
            created_by=actor,
            updated_by=actor,
            identity_id=identity_id,
        )
        membership = Membership(
            id=new_id(), created_at=now, updated_at=now, created_by=actor, updated_by=actor, user_id=user.id, role=role
        )
        return user, membership

    # --- the request stage

    async def sign_up(
        self, rctx: RequestContext, email: str, password: str, display_name: str, org_name: str, org_slug: str
    ) -> SignedIn:
        if not self._options.signup_enabled:
            raise NotFound("not found")
        now = utcnow()
        identity = self._new_identity(email, display_name, password, now)
        org_id = new_id()
        user, membership = self._member_rows(org_id, identity.id, display_name, Role.OWNER, EMPTY_UUID, now)
        user = user.model_copy(update={"created_by": user.id, "updated_by": user.id})
        membership = membership.model_copy(update={"created_by": user.id, "updated_by": user.id})
        org = Org(
            id=org_id,
            name=org_name,
            slug=org_slug.strip().lower(),
            created_at=now,
            updated_at=now,
            created_by=user.id,
            updated_by=user.id,
        )
        rows = (
            OutboxRow(
                id=new_id(),
                created_at=now,
                org_id=org_id,
                kind="tenancy.org.created",
                target_id=org_id,
                actor_id=user.id,
                request_id=rctx.request_id,
                traceparent=rctx.traceparent,
                app=rctx.app,
            ),
        )
        outcome = await self._storage.create_signup(org_id, org, identity, user, membership, rows)
        if outcome != InsertOutcome.INSERTED:
            raise Conflict("that email or that slug is already taken")
        await self._relay_all(org_id, rows)
        session, token = await self._new_session(identity.id, SessionKind.LOGIN, self._options.login_ttl)
        await self._storage.create_session(identity.id, session)
        ictx = IdentityContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            identity_id=identity.id,
            email=identity.email,
            credential_kind=CredentialKind.PASSWORD,
            credential_id=session.id,
        )
        return SignedIn(
            identity=ictx,
            credential=IssuedCredential(credential_id=session.id, token=token, expires_at=session.expires_at),
            memberships=(
                MembershipChoice(org_id=org_id, org_name=org.name, org_slug=org.slug, user_id=user.id, role=Role.OWNER),
            ),
        )

    async def sign_in(self, rctx: RequestContext, email: str, password: str, totp_code: str | None) -> SignedIn:
        now = utcnow()
        key = email_digest(email)
        throttle = await self._storage.read_sign_in_failures(key)
        if throttle is not None and throttle.retry_at > now:
            raise TooManyRequests(
                "too many failed sign-ins", retry_after=int((throttle.retry_at - now).total_seconds()) + 1
            )
        identity = await self._storage.read_identity_by_email_digest(key)
        ok = verify_password(password, identity.password_hash if identity is not None else None)
        second_factor = False
        if ok and identity is not None and totp_code:
            step = self._verify_totp(identity, totp_code, now)
            if step is None:
                ok = False
            else:
                second_factor = True
                await self._storage.write_identity(
                    identity.id, identity.model_copy(update={"totp_last_step": step, "updated_at": now})
                )
        if not ok or identity is None:
            await self._storage.record_sign_in_failure(
                key,
                new_id(),
                now,
                self._options.sign_in_delay_base.total_seconds(),
                self._options.sign_in_delay_cap.total_seconds(),
            )
            raise NotAuthenticated("the email or the password is wrong")
        await self._storage.clear_sign_in_failures(key)
        session, token = await self._new_session(
            identity.id, SessionKind.LOGIN, self._options.login_ttl, second_factor=second_factor
        )
        await self._storage.create_session(identity.id, session)
        ictx = IdentityContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            identity_id=identity.id,
            email=identity.email,
            credential_kind=CredentialKind.PASSWORD,
            credential_id=session.id,
        )
        return SignedIn(
            identity=ictx,
            credential=IssuedCredential(credential_id=session.id, token=token, expires_at=session.expires_at),
            memberships=await self._choices(identity.id, self._options.page_size),
        )

    async def sign_in_external(
        self, rctx: RequestContext, issuer: str, subject: str, email: str, display_name: str
    ) -> SignedIn:
        identity = await self._storage.read_identity_by_issuer_subject(issuer, subject)
        if identity is None:
            now = utcnow()
            fresh = self._new_identity(email, display_name, None, now).model_copy(
                update={"issuer": issuer, "subject": subject}
            )
            outcome = await self._storage.create_identity(fresh.id, fresh)
            if outcome == InsertOutcome.KEY_EXISTS:
                # The address is held by an identity that signs in otherwise; it is never linked silently.
                raise Conflict("that email already holds an identity; sign in with it first")
            identity = await self._storage.read_identity_by_issuer_subject(issuer, subject)
            if identity is None:
                raise Conflict("the identity could not be created")
        session, token = await self._new_session(identity.id, SessionKind.LOGIN, self._options.login_ttl)
        await self._storage.create_session(identity.id, session)
        ictx = IdentityContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            identity_id=identity.id,
            email=identity.email,
            credential_kind=CredentialKind.PASSWORD,
            credential_id=session.id,
        )
        return SignedIn(
            identity=ictx,
            credential=IssuedCredential(credential_id=session.id, token=token, expires_at=session.expires_at),
            memberships=await self._choices(identity.id, self._options.page_size),
        )

    async def authenticate(self, rctx: RequestContext, bearer: str) -> OpContext:
        now = utcnow()
        if bearer.startswith(TokenPrefix.TENANT_SESSION.value):
            session = await self._storage.read_session_by_digest(digest(bearer))
            if session is None or not self._session_live(session, SessionKind.TENANT, now) or session.user_id is None:
                raise NotAuthenticated("the session has ended")
            membership = await self._storage.read_membership(session.tenant_id, session.user_id)
            if membership is None:
                raise NotAuthenticated("the membership has ended")
            await self._touch(session, now)
            return OpContext(
                request_id=rctx.request_id,
                app=rctx.app,
                trace_id=rctx.trace_id,
                traceparent=rctx.traceparent,
                security=SecurityContext(
                    user_id=session.user_id,
                    org_id=session.tenant_id,
                    role=membership.role,
                    permissions=rules.permissions_of(membership.role),
                    credential_kind=CredentialKind.TENANT_SESSION,
                    credential_id=session.id,
                ),
            )
        if bearer.startswith(TokenPrefix.API_KEY.value):
            found = await self._storage.read_api_key_by_digest(digest(bearer))
            if found is None:
                raise NotAuthenticated("the key is not known")
            org_id, key = found
            if key.revoked_at is not None or key.expires_at <= now:
                raise NotAuthenticated("the key is revoked or expired")
            issuer = await self._storage.read_membership(org_id, key.issued_by)
            if issuer is None:
                raise NotAuthenticated("the key's issuer is no longer a member")
            role = rules.lower_role(key.role, issuer.role)  # capped at the issuer's current role, at every use
            return OpContext(
                request_id=rctx.request_id,
                app=rctx.app,
                trace_id=rctx.trace_id,
                traceparent=rctx.traceparent,
                security=SecurityContext(
                    user_id=key.issued_by,
                    org_id=org_id,
                    role=role,
                    permissions=rules.permissions_of(role),
                    credential_kind=CredentialKind.API_KEY,
                    credential_id=key.id,
                ),
            )
        raise NotAuthenticated("a tenant credential is required")

    async def authenticate_internal(
        self, rctx: RequestContext, org_id: UUID, user_id: UUID, credential_id: UUID
    ) -> OpContext:
        membership = await self._storage.read_membership(org_id, user_id)
        if membership is None and user_id != EMPTY_UUID:
            raise NotAuthenticated("the principal the internal credential names is not a member")
        role = Role.SERVICE if membership is None else membership.role  # the role is read here, never carried
        return OpContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            caused_by_request_id=rctx.caused_by_request_id,
            security=SecurityContext(
                user_id=user_id,
                org_id=org_id,
                role=role,
                permissions=rules.permissions_of(role),
                credential_kind=CredentialKind.INTERNAL,
                credential_id=credential_id,
            ),
        )

    async def authenticate_login(self, rctx: RequestContext, bearer: str) -> IdentityContext:
        now = utcnow()
        kinds = {
            TokenPrefix.LOGIN.value: (SessionKind.LOGIN, CredentialKind.PASSWORD),
            TokenPrefix.TENANT_SESSION.value: (SessionKind.TENANT, CredentialKind.TENANT_SESSION),
            TokenPrefix.OPERATOR_TOKEN.value: (SessionKind.OPERATOR, CredentialKind.OPERATOR_TOKEN),
        }
        kind = next((v for p, v in kinds.items() if bearer.startswith(p)), None)
        if kind is None:
            raise NotAuthenticated("a sign-in credential is required")
        session = await self._storage.read_session_by_digest(digest(bearer))
        if session is None or not self._session_live(session, kind[0], now):
            raise NotAuthenticated("the credential has ended")
        identity = await self._storage.read_identity(session.identity_id)
        if identity is None:
            raise NotAuthenticated("the identity is gone")
        await self._touch(session, now)
        return IdentityContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            identity_id=identity.id,
            email=identity.email,
            credential_kind=kind[1],
            credential_id=session.id,
        )

    async def redeem_socket_ticket(self, rctx: RequestContext, ticket: str) -> SocketGrant:
        now = utcnow()
        if not ticket.startswith(TokenPrefix.SOCKET_TICKET.value):
            raise NotAuthenticated("a socket ticket is required")
        redeemed = await self._storage.redeem_socket_ticket(digest(ticket), now)
        if redeemed is None:
            raise NotAuthenticated("the ticket is spent or expired")
        # Redeeming re-checks the credential behind the ticket, by its id.
        if redeemed.credential_kind == CredentialKind.TENANT_SESSION:
            session = await self._storage.read_session(redeemed.identity_id, redeemed.credential_id)
            if session is None or not self._session_live(session, SessionKind.TENANT, now):
                raise NotAuthenticated("the session behind the ticket has ended")
            expires_at = min(session.expires_at, session.created_at + self._options.session_absolute)
        else:
            key = await self._storage.read_api_key(redeemed.tenant_id, redeemed.credential_id)
            if key is None or key.revoked_at is not None or key.expires_at <= now:
                raise NotAuthenticated("the key behind the ticket has ended")
            expires_at = key.expires_at
        membership = await self._storage.read_membership(redeemed.tenant_id, redeemed.user_id)
        if membership is None:
            raise NotAuthenticated("the membership behind the ticket has ended")
        ctx = OpContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            security=SecurityContext(
                user_id=redeemed.user_id,
                org_id=redeemed.tenant_id,
                role=membership.role,
                permissions=rules.permissions_of(membership.role),
                credential_kind=redeemed.credential_kind,
                credential_id=redeemed.credential_id,
            ),
        )
        return SocketGrant(ctx=ctx, expires_at=expires_at)

    async def bootstrap(
        self, rctx: RequestContext, org_name: str, org_slug: str, owner_email: str, owner_password: str, owner_name: str
    ) -> OpContext:
        slug = org_slug.strip().lower()
        identity = await self._storage.read_identity_by_email_digest(email_digest(owner_email))
        if identity is None:
            now = utcnow()
            identity = self._new_identity(owner_email, owner_name, owner_password, now)
            org_id = new_id()
            user, membership = self._member_rows(org_id, identity.id, owner_name, Role.OWNER, EMPTY_UUID, now)
            org = Org(
                id=org_id,
                name=org_name,
                slug=slug,
                created_at=now,
                updated_at=now,
                created_by=EMPTY_UUID,
                updated_by=EMPTY_UUID,
            )
            if await self._storage.create_signup(org_id, org, identity, user, membership, ()) != InsertOutcome.INSERTED:
                raise Conflict("the seed's email or slug is held by another identity")
        choices = await self._choices(identity.id, self._options.page_size)
        choice = next((c for c in choices if c.org_slug == slug), None)
        if choice is None:
            raise Conflict("the seed owner exists without the seed org; reset the local database")
        return OpContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            security=SecurityContext(
                user_id=choice.user_id,
                org_id=choice.org_id,
                role=choice.role,
                permissions=rules.permissions_of(choice.role),
                credential_kind=CredentialKind.INTERNAL,
                credential_id=rctx.request_id,
            ),
        )

    async def ensure_identity(self, rctx: RequestContext, email: str, password: str, display_name: str) -> UUID:
        found = await self._storage.read_identity_by_email_digest(email_digest(email))
        if found is not None:
            return found.id
        identity = self._new_identity(email, display_name, password, utcnow())
        if await self._storage.create_identity(identity.id, identity) != InsertOutcome.INSERTED:
            found = await self._storage.read_identity_by_email_digest(email_digest(email))
            if found is None:
                raise Conflict("the identity could not be created")
            return found.id
        return identity.id

    async def grant_operator(self, rctx: RequestContext, email: str, permission: OperatorPermission) -> OperatorEntry:
        if permission == OperatorPermission.ENROL:
            raise ValidationFailed("an allowlist entry grants read or write")
        identity = await self._storage.read_identity_by_email_digest(email_digest(email))
        if identity is None:
            raise NotFound("no identity holds that email; it signs up first")
        now = utcnow()
        current = await self._storage.read_operator_entry(identity.id)
        entry = OperatorEntry(
            id=current.id if current is not None else new_id(),
            created_at=current.created_at if current is not None else now,
            created_by=current.created_by if current is not None else EMPTY_UUID,
            updated_at=now,
            updated_by=EMPTY_UUID,
            identity_id=identity.id,
            permission=permission,
            disabled_at=None,
        )
        await self._storage.write_operator_entry(entry)
        return entry

    async def disable_operator(self, rctx: RequestContext, email: str) -> OperatorEntry:
        identity = await self._storage.read_identity_by_email_digest(email_digest(email))
        current = None if identity is None else await self._storage.read_operator_entry(identity.id)
        if current is None:
            raise NotFound("that email holds no operator entry")
        now = utcnow()
        disabled = current.model_copy(update={"disabled_at": now, "updated_at": now, "updated_by": EMPTY_UUID})
        await self._storage.write_operator_entry(disabled)
        return disabled

    def _token_ttl(self, expires_in: timedelta | None) -> timedelta:
        cap = self._options.operator_token_max
        return cap if expires_in is None else max(timedelta(seconds=1), min(expires_in, cap))

    async def grant_operator_token(
        self, rctx: RequestContext, email: str, expires_in: timedelta | None
    ) -> IssuedCredential:
        identity = await self._storage.read_identity_by_email_digest(email_digest(email))
        entry = None if identity is None else await self._storage.read_operator_entry(identity.id)
        if identity is None or entry is None or entry.disabled_at is not None:
            raise NotFound("that email holds no live operator entry")
        session, token = await self._new_session(
            identity.id, SessionKind.OPERATOR, self._token_ttl(expires_in), permission=entry.permission
        )
        await self._storage.create_session(identity.id, session)
        return IssuedCredential(credential_id=session.id, token=token, expires_at=session.expires_at)

    async def service_contexts(self, rctx: RequestContext, after: UUID | None, limit: int) -> list[OpContext]:
        return [
            OpContext(
                request_id=rctx.request_id,
                app=rctx.app,
                trace_id=rctx.trace_id,
                traceparent=rctx.traceparent,
                caused_by_request_id=rctx.caused_by_request_id,
                security=SecurityContext(
                    user_id=EMPTY_UUID,
                    org_id=org_id,
                    role=Role.SERVICE,
                    permissions=rules.permissions_of(Role.SERVICE),
                    credential_kind=CredentialKind.INTERNAL,
                    credential_id=rctx.request_id,
                ),
            )
            for org_id in await self._storage.read_live_org_ids(after, limit)
        ]

    async def claim_context(
        self, rctx: RequestContext, org_id: UUID, user_id: UUID, caused_by_request_id: UUID
    ) -> OpContext:
        org = await self._storage.read_org(org_id)
        if org is None or org.deleted_at is not None:
            raise NotFound("the tenant of the work item is gone")
        membership = None if user_id == EMPTY_UUID else await self._storage.read_membership(org_id, user_id)
        return OpContext(
            request_id=rctx.request_id,
            app=rctx.app,
            trace_id=rctx.trace_id,
            traceparent=rctx.traceparent,
            caused_by_request_id=caused_by_request_id,
            security=SecurityContext(
                # The enqueuer's attribution under the service role's authority; the tenant's service context
                # when the creator is the platform or holds no live membership.
                user_id=user_id if membership is not None else EMPTY_UUID,
                org_id=org_id,
                role=Role.SERVICE,
                permissions=rules.permissions_of(Role.SERVICE),
                credential_kind=CredentialKind.INTERNAL,
                credential_id=rctx.request_id,
            ),
        )

    async def purge_socket_tickets(self, rctx: RequestContext) -> int:
        return await self._storage.purge_socket_tickets(utcnow(), self._options.purge_batch)

    async def purge_sessions(self, rctx: RequestContext) -> int:
        now = utcnow()
        return await self._storage.purge_sessions(now, now - self._options.session_idle, self._options.purge_batch)

    # --- the identity stage

    async def get_memberships(self, ictx: IdentityContext, limit: int) -> list[MembershipChoice]:
        return list(await self._choices(ictx.identity_id, limit))

    async def exchange(self, ictx: IdentityContext, org_id: UUID) -> IssuedCredential:
        user = await self._storage.read_user_by_identity(org_id, ictx.identity_id)
        membership = None if user is None else await self._storage.read_membership(org_id, user.id)
        org = await self._storage.read_org(org_id)
        if user is None or membership is None or org is None or org.deleted_at is not None:
            raise NotFound("no membership in that org")
        session, token = await self._new_session(
            ictx.identity_id, SessionKind.TENANT, self._options.session_absolute, tenant_id=org_id, user_id=user.id
        )
        if ictx.credential_kind == CredentialKind.TENANT_SESSION:
            # An exchange presented with a session ends that session in the same write.
            if not await self._storage.exchange_session(ictx.identity_id, ictx.credential_id, session, utcnow()):
                raise NotAuthenticated("the presented session has ended")
            previous = await self._storage.read_session(ictx.identity_id, ictx.credential_id)
            if previous is not None:
                await self._publish_revoked(previous.tenant_id, previous.id, ictx.identity_id)
        else:
            await self._storage.create_session(ictx.identity_id, session)
        return IssuedCredential(credential_id=session.id, token=token, expires_at=session.expires_at)

    async def sign_out(self, ictx: IdentityContext) -> None:
        session = await self._storage.read_session(ictx.identity_id, ictx.credential_id)
        if session is None:
            return
        if (
            await self._storage.end_session(ictx.identity_id, session.id, utcnow())
            and session.kind == SessionKind.TENANT
        ):
            await self._publish_revoked(session.tenant_id, session.id, ictx.identity_id)

    async def admit_operator(self, ictx: IdentityContext) -> OperatorContext:
        if ictx.credential_kind in (CredentialKind.TENANT_SESSION, CredentialKind.API_KEY, CredentialKind.INTERNAL):
            raise NotAuthorized("the operator plane admits only a sign-in or an operator token")
        entry = await self._storage.read_operator_entry(ictx.identity_id)
        if entry is None or entry.disabled_at is not None:
            raise NotAuthorized("not on the operator allowlist")
        session = await self._storage.read_session(ictx.identity_id, ictx.credential_id)
        if session is None:
            raise NotAuthenticated("the credential has ended")
        if ictx.credential_kind == CredentialKind.OPERATOR_TOKEN:
            granted = session.permission or OperatorPermission.READ
            if not rules.operator_permission_at_most(granted, entry.permission):
                granted = OperatorPermission.READ  # the entry was narrowed after the token was minted
            permissions = rules.OPERATOR_PERMISSIONS[granted]
        else:
            identity = await self._storage.read_identity(ictx.identity_id)
            if identity is None:
                raise NotAuthenticated("the identity is gone")
            if identity.totp_confirmed_at is None:
                permissions = rules.OPERATOR_PERMISSIONS[OperatorPermission.ENROL]
            elif not session.second_factor:
                raise SecondFactorRequired("the operator plane requires a second factor at sign-in")
            else:
                permissions = rules.OPERATOR_PERMISSIONS[entry.permission]
        return OperatorContext(
            request_id=ictx.request_id,
            app=ictx.app,
            trace_id=ictx.trace_id,
            traceparent=ictx.traceparent,
            identity_id=ictx.identity_id,
            email=ictx.email,
            credential_kind=ictx.credential_kind,
            credential_id=ictx.credential_id,
            permissions=permissions,
        )

    # --- tenant operations

    async def _identity_of(self, ctx: OpContext, user_id: UUID) -> UUID:
        user = await self._storage.read_user(ctx.org_id, user_id)
        if user is None:
            raise NotFound("no such user")
        return user.identity_id

    async def issue_socket_ticket(self, ctx: OpContext) -> IssuedCredential:
        ctx.require(Permission.READ)
        identity_id = await self._identity_of(ctx, ctx.user_id)
        token = mint(TokenPrefix.SOCKET_TICKET)
        now = utcnow()
        ticket = SocketTicket(
            id=new_id(),
            created_at=now,
            identity_id=identity_id,
            tenant_id=ctx.org_id,
            user_id=ctx.user_id,
            credential_kind=ctx.credential_kind,
            credential_id=ctx.credential_id,
            digest=digest(token),
            expires_at=now + self._options.socket_ticket_ttl,
        )
        await self._storage.create_socket_ticket(identity_id, ticket)
        return IssuedCredential(credential_id=ticket.id, token=token, expires_at=ticket.expires_at)

    async def recheck_session(self, ctx: OpContext) -> None:
        now = utcnow()
        if ctx.credential_kind == CredentialKind.TENANT_SESSION:
            identity_id = await self._identity_of(ctx, ctx.user_id)
            session = await self._storage.read_session(identity_id, ctx.credential_id)
            # The recheck is not activity: it never moves last_seen_at.
            if session is None or session.ended_at is not None or session.expires_at <= now:
                raise NotAuthenticated("the session has ended")
        elif ctx.credential_kind == CredentialKind.API_KEY:
            key = await self._storage.read_api_key(ctx.org_id, ctx.credential_id)
            if key is None or key.revoked_at is not None or key.expires_at <= now:
                raise NotAuthenticated("the key has ended")
        membership = await self._storage.read_membership(ctx.org_id, ctx.user_id)
        if membership is None:
            raise NotAuthenticated("the membership has ended")
        if ctx.credential_kind == CredentialKind.TENANT_SESSION and membership.role != ctx.security.role:
            raise NotAuthenticated("the role has changed")

    async def get_org(self, ctx: OpContext) -> Org:
        ctx.require(Permission.READ)
        org = await self._storage.read_org(ctx.org_id)
        if org is None or org.deleted_at is not None:
            raise NotFound("no such org")
        return org

    async def _members(self, org_id: UUID, limit: int) -> list[Member]:
        users = {u.id: u for u in await self._storage.read_users(org_id, limit)}
        out: list[Member] = []
        for m in await self._storage.read_memberships(org_id, limit):
            user = users.get(m.user_id) or await self._storage.read_user(org_id, m.user_id)
            if user is not None:
                out.append(Member(user_id=user.id, identity_id=user.identity_id, name=user.name, role=m.role))
        return out

    async def get_members(self, ctx: OpContext, limit: int) -> list[Member]:
        ctx.require(Permission.READ)
        return await self._members(ctx.org_id, self._clamp(limit))

    async def get_member_addresses(self, ctx: OpContext, limit: int) -> list[MemberAddress]:
        ctx.require(Permission.READ)
        out: list[MemberAddress] = []
        for member in await self._members(ctx.org_id, self._clamp(limit)):
            identity = await self._storage.read_identity(member.identity_id)
            if identity is not None:
                out.append(MemberAddress(user_id=member.user_id, email=identity.email))
        return out

    async def get_user(self, ctx: OpContext, user_id: UUID) -> User:
        ctx.require(Permission.READ)
        user = await self._storage.read_user(ctx.org_id, user_id)
        if user is None:
            raise NotFound("no such user")
        return user

    async def update_user(self, ctx: OpContext, user: User) -> User:
        ctx.require(Permission.READ)
        if user.id != ctx.user_id and not ctx.has(Permission.MANAGE_MEMBERS):
            raise NotAuthorized("a member changes their own name; managing members changes another's")
        current = await self.get_user(ctx, user.id)
        caller_owned = set(PROVENANCE_FIELDS) | set(User.MANAGER_OWNED_FIELDS)
        updated = User.model_validate(
            {
                **current.model_dump(),
                **user.model_dump(exclude=caller_owned),
                "updated_at": utcnow(),
                "updated_by": ctx.user_id,
            }
        )
        rows = (outbox_row(ctx, "tenancy.user.updated", updated.id, {}),)
        await self._storage.write_user(ctx.org_id, updated, rows)
        await self._relay_all(ctx.org_id, rows)
        return updated

    async def update_member_role(self, ctx: OpContext, user_id: UUID, role: Role) -> Membership:
        ctx.require(Permission.MANAGE_MEMBERS)
        if role == Role.SERVICE:
            raise NotAuthorized("the service role is never granted to a person")
        if not rules.role_at_most(role, ctx.security.role):
            raise NotAuthorized("a role above your own cannot be granted")
        current = await self._storage.read_membership(ctx.org_id, user_id)
        if current is None:
            raise NotFound("no such member")
        if not rules.role_at_most(current.role, ctx.security.role):
            raise NotAuthorized("a member above your own role cannot be changed")
        identity_id = await self._identity_of(ctx, user_id)
        updated = current.model_copy(update={"role": role, "updated_at": utcnow(), "updated_by": ctx.user_id})
        rows = (outbox_row(ctx, "tenancy.membership.updated", updated.id, {}),)
        await self._storage.write_membership(ctx.org_id, identity_id, updated, rows)
        await self._relay_all(ctx.org_id, rows)
        return updated

    async def remove_member(self, ctx: OpContext, user_id: UUID) -> None:
        ctx.require(Permission.MANAGE_MEMBERS)
        current = await self._storage.read_membership(ctx.org_id, user_id)
        if current is None:
            raise NotFound("no such member")
        if not rules.role_at_most(current.role, ctx.security.role):
            raise NotAuthorized("a member above your own role cannot be removed")
        identity_id = await self._identity_of(ctx, user_id)
        rows = (outbox_row(ctx, "tenancy.membership.deleted", current.id, {}),)
        ended = await self._storage.remove_membership(ctx.org_id, user_id, identity_id, utcnow(), rows)
        await self._relay_all(ctx.org_id, rows)
        for session_id in ended:
            await self._publish_revoked(ctx.org_id, session_id, identity_id)

    async def create_api_key(
        self, ctx: OpContext, key_id: UUID, name: str, role: Role, expires_in: timedelta, guard: MarkerGuard | None
    ) -> IssuedApiKey:
        ctx.require(Permission.MANAGE_KEYS)
        if role == Role.SERVICE:
            raise NotAuthorized("the service role is never issued to a key")
        if not rules.role_at_most(role, ctx.security.role):
            raise NotAuthorized("a key never carries a role above its issuer's")
        if expires_in <= timedelta(0) or expires_in > self._options.api_key_max_expiry:
            raise ValidationFailed("expires_in must be positive and within the configured cap")
        token = mint(TokenPrefix.API_KEY)
        now = utcnow()
        key = ApiKey(
            id=key_id,
            name=name,
            created_at=now,
            issued_by=ctx.user_id,
            digest=digest(token),
            role=role,
            expires_at=now + expires_in,
        )
        rows = (outbox_row(ctx, "tenancy.api_key.created", key_id, {}),)
        outcome = await self._storage.create_api_key(ctx.org_id, key, rows)
        if outcome == ApiKeyInsert.NO_MEMBERSHIP:
            raise NotAuthorized("the issuer is no longer a member")
        if outcome == ApiKeyInsert.INSERTED:
            await self._relay_all(ctx.org_id, rows)
            return IssuedApiKey(api_key=key, token=token)
        stored = await self._storage.read_api_key(ctx.org_id, key_id)
        if stored is None or stored.issued_by != ctx.user_id or guard is None:
            raise Conflict("that key id is taken")
        # A rerun: re-mint the secret on the row it found, while the marker still holds this attempt.
        if not await self._storage.remint_api_key(
            ctx.org_id, key_id, digest(token), guard.marker_id, guard.attempt_token
        ):
            raise Conflict("another attempt holds this request")
        return IssuedApiKey(api_key=stored.model_copy(update={"digest": digest(token)}), token=token)

    async def get_api_keys(self, ctx: OpContext, limit: int) -> list[ApiKey]:
        ctx.require(Permission.MANAGE_KEYS)
        return await self._storage.read_api_keys(ctx.org_id, self._clamp(limit))

    async def revoke_api_key(self, ctx: OpContext, key_id: UUID) -> None:
        ctx.require(Permission.MANAGE_KEYS)
        key = await self._storage.read_api_key(ctx.org_id, key_id)
        if key is None:
            raise NotFound("no such key")
        rows = (outbox_row(ctx, "tenancy.api_key.deleted", key_id, {}),)
        if await self._storage.revoke_api_key(ctx.org_id, key_id, utcnow(), rows):
            await self._relay_all(ctx.org_id, rows)

    async def revoke_session(self, ctx: OpContext, session_id: UUID) -> None:
        ctx.require(Permission.READ)
        identity_id = await self._identity_of(ctx, ctx.user_id)
        session = await self._storage.read_session(identity_id, session_id)
        if session is None:
            raise NotFound("no such session")
        if await self._storage.end_session(identity_id, session_id, utcnow()) and session.kind == SessionKind.TENANT:
            await self._publish_revoked(session.tenant_id, session_id, identity_id)

    # --- the operator plane

    async def get_operator(self, octx: OperatorContext) -> OperatorEntry:
        entry = await self._storage.read_operator_entry(octx.identity_id)
        if entry is None:
            raise NotAuthorized("not on the operator allowlist")
        return entry

    async def get_size(self, octx: OperatorContext) -> PlatformSize:
        octx.require(OperatorPermission.READ)
        size = await self._storage.read_size()
        excluded = tuple(await self._storage.read_provisioned_org_ids(self._options.page_size * 100))
        events = await self._events.count_events_for_operator(octx, utcnow() - timedelta(days=1), excluded)
        return PlatformSize(tenants=size.tenants, users=size.users, events_last_day=events)

    async def get_orgs(self, octx: OperatorContext, limit: int) -> list[Org]:
        octx.require(OperatorPermission.READ)
        return await self._storage.read_orgs(self._clamp(limit))

    def _log_read(self, octx: OperatorContext, org_id: UUID, what: str) -> None:
        logger.info(
            "operator read a tenant's %s",
            what,
            extra={"org_id": str(org_id), "operator_identity_id": str(octx.identity_id)},
        )

    async def get_org_for_operator(self, octx: OperatorContext, org_id: UUID) -> Org:
        octx.require(OperatorPermission.READ)
        self._log_read(octx, org_id, "org")
        org = await self._storage.read_org(org_id)
        if org is None:
            raise NotFound("no such org")
        return org

    async def get_members_for_operator(self, octx: OperatorContext, org_id: UUID, limit: int) -> list[Member]:
        octx.require(OperatorPermission.READ)
        self._log_read(octx, org_id, "members")
        return await self._members(org_id, self._clamp(limit))

    async def create_org(self, octx: OperatorContext, org_id: UUID, name: str, slug: str) -> Org:
        octx.require(OperatorPermission.WRITE)
        now = utcnow()
        org = Org(
            id=org_id,
            name=name,
            slug=slug.strip().lower(),
            created_at=now,
            updated_at=now,
            created_by=EMPTY_UUID,
            updated_by=EMPTY_UUID,
            provisioned_by=octx.identity_id,
        )
        rows = (operator_outbox_row(octx, org_id, "tenancy.org.created", org_id),)
        outcome = await self._storage.create_org(org_id, org, rows)
        if outcome == InsertOutcome.KEY_EXISTS:
            raise Conflict("that slug is taken")
        if outcome == InsertOutcome.ID_EXISTS:
            stored = await self._storage.read_org(org_id)
            if stored is None:
                raise Conflict("that org id is taken")
            return stored
        await self._relay_all(org_id, rows)
        return org

    async def add_member(
        self,
        octx: OperatorContext,
        org_id: UUID,
        user_id: UUID,
        email: str,
        display_name: str,
        role: Role,
        password: str | None,
    ) -> Member:
        octx.require(OperatorPermission.WRITE)
        if role == Role.SERVICE:
            raise NotAuthorized("the service role is never granted to a person")
        if await self._storage.read_org(org_id) is None:
            raise NotFound("no such org")
        now = utcnow()
        identity = await self._storage.read_identity_by_email_digest(email_digest(email))
        if identity is None:
            identity = self._new_identity(email, display_name, password, now)
            if await self._storage.create_identity(identity.id, identity) != InsertOutcome.INSERTED:
                raise Conflict("that email could not be claimed")
        user, membership = self._member_rows(org_id, identity.id, display_name, role, EMPTY_UUID, now, user_id=user_id)
        rows = (operator_outbox_row(octx, org_id, "tenancy.membership.created", membership.id),)
        outcome = await self._storage.create_member(org_id, identity.id, user, membership, rows)
        if outcome != InsertOutcome.INSERTED:
            existing = await self._storage.read_user(org_id, user_id)
            held = None if existing is None else await self._storage.read_membership(org_id, existing.id)
            if existing is None or held is None or existing.identity_id != identity.id:
                raise Conflict("that identity is already a member")
            return Member(user_id=existing.id, identity_id=identity.id, name=existing.name, role=held.role)
        await self._relay_all(org_id, rows)
        return Member(user_id=user.id, identity_id=identity.id, name=user.name, role=role)

    async def delete_org(self, octx: OperatorContext, org_id: UUID) -> None:
        octx.require(OperatorPermission.WRITE)
        current = await self._storage.read_org(org_id)
        if current is None:
            raise NotFound("no such org")
        if current.deleted_at is not None:
            return
        now = utcnow()
        deleted = current.model_copy(update={"deleted_at": now, "deleted_by": EMPTY_UUID, "updated_at": now})
        rows = (operator_outbox_row(octx, org_id, "tenancy.org.deleted", org_id),)
        await self._storage.write_org(org_id, deleted, rows)
        await self._relay_all(org_id, rows)

    def _totp(self) -> TotpCipher:
        if self._cipher is None:
            raise Unavailable("this process holds no TOTP encryption key")
        return self._cipher

    def _verify_totp(self, identity: Identity, code: str, now: datetime) -> int | None:
        if identity.totp_secret is None:
            return None
        secret = self._totp().decrypt(identity.totp_secret)
        if secret is None:
            return None
        return rules.totp_match(secret, code, rules.totp_step(now.timestamp()), identity.totp_last_step)

    async def enrol_totp(self, octx: OperatorContext) -> TotpEnrolment:
        octx.require(OperatorPermission.ENROL)
        identity = await self._storage.read_identity(octx.identity_id)
        if identity is None:
            raise NotAuthenticated("the identity is gone")
        secret = new_totp_secret()
        now = utcnow()
        await self._storage.write_identity(
            identity.id,
            identity.model_copy(
                update={"totp_secret": self._totp().encrypt(secret), "totp_confirmed_at": None, "updated_at": now}
            ),
        )
        label = f"{self._options.totp_issuer}:{identity.email}"
        uri = f"otpauth://totp/{label}?secret={base32(secret)}&issuer={self._options.totp_issuer}"
        return TotpEnrolment(secret=base32(secret), uri=uri)

    async def confirm_totp(self, octx: OperatorContext, totp_code: str) -> None:
        octx.require(OperatorPermission.ENROL)
        identity = await self._storage.read_identity(octx.identity_id)
        if identity is None:
            raise NotAuthenticated("the identity is gone")
        now = utcnow()
        step = self._verify_totp(identity, totp_code, now)
        if step is None:
            raise ValidationFailed("the code does not match")
        await self._storage.write_identity(
            identity.id,
            identity.model_copy(update={"totp_confirmed_at": now, "totp_last_step": step, "updated_at": now}),
        )

    async def issue_operator_token(
        self, octx: OperatorContext, permission: OperatorPermission, expires_in: timedelta | None
    ) -> IssuedCredential:
        octx.require(OperatorPermission.READ)
        if octx.credential_kind != CredentialKind.PASSWORD:
            raise NotAuthorized("a token never mints a token; sign in with the second factor")
        session = await self._storage.read_session(octx.identity_id, octx.credential_id)
        if session is None or not session.second_factor:
            raise NotAuthorized("minting a token requires a sign-in with a verified second factor")
        entry = await self.get_operator(octx)
        if permission == OperatorPermission.ENROL or not rules.operator_permission_at_most(
            permission, entry.permission
        ):
            raise NotAuthorized("a token carries at most what the allowlist entry grants")
        minted, token = await self._new_session(
            octx.identity_id, SessionKind.OPERATOR, self._token_ttl(expires_in), permission=permission
        )
        await self._storage.create_session(octx.identity_id, minted)
        return IssuedCredential(credential_id=minted.id, token=token, expires_at=minted.expires_at)
