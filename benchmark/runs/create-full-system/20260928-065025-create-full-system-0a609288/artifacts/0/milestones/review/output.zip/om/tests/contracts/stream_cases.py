"""Contract cases of the append-only streams (events, audit) and of the outbox's storage."""

import asyncio
from datetime import timedelta

from acme.om.audit.types import AuditEntry
from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.events.types import Event
from acme.om.storage.root import StorageInterface
from contracts import factories as f


def event(org_id=None) -> Event:  # type: ignore[no-untyped-def]
    return Event(
        id=new_id(),
        org_id=org_id or EMPTY_UUID,
        seq=0,
        kind="tenancy.user.updated",
        target_id=new_id(),
        actor_id=EMPTY_UUID,
        request_id=new_id(),
        app=f.APP,
    )


def entry() -> AuditEntry:
    return AuditEntry(
        id=new_id(), seq=0, kind="report.read", target_id=new_id(), actor_id=new_id(), request_id=new_id(), app=f.APP
    )


async def case_append_event_numbers_per_tenant(storage: StorageInterface) -> None:
    s = storage.get_events_storage()
    a, b = new_id(), new_id()
    first = await s.append_event(a, event())
    second = await s.append_event(a, event())
    other = await s.append_event(b, event())
    assert (first.seq, second.seq, other.seq) == (1, 2, 1)
    assert first.org_id == a
    assert await s.read_head(a) == 2
    assert await s.read_head(b) == 1


async def case_append_event_twice_leaves_one_event(storage: StorageInterface) -> None:
    s = storage.get_events_storage()
    org_id = new_id()
    e = event()
    first = await s.append_event(org_id, e)
    again = await s.append_event(org_id, e)
    assert again == first
    assert await s.read_head(org_id) == 1


async def case_read_after_is_fenced_by_tenant(storage: StorageInterface) -> None:
    s = storage.get_events_storage()
    a, b = new_id(), new_id()
    for _ in range(3):
        await s.append_event(a, event())
    assert [e.seq for e in await s.read_after(a, 1, 10)] == [2, 3]
    assert [e.seq for e in await s.read_after(a, 0, 2)] == [1, 2]
    assert await s.read_after(b, 0, 10) == []
    assert await s.read_head(b) == 0


async def case_count_since_counts_across_tenants(storage: StorageInterface) -> None:
    s = storage.get_events_storage()
    before = utcnow() - timedelta(seconds=1)
    kept, left_out = new_id(), new_id()
    await s.append_event(kept, event())
    await s.append_event(left_out, event())
    everything = await s.count_since(before, ())
    assert everything >= 2
    assert await s.count_since(before, (left_out,)) == everything - 1
    assert await s.count_since(utcnow() + timedelta(hours=1), ()) == 0


async def case_append_event_race_numbers_without_gaps(storage: StorageInterface) -> None:
    s = storage.get_events_storage()
    org_id = new_id()
    appended = await asyncio.gather(*(s.append_event(org_id, event()) for _ in range(4)))
    assert sorted(e.seq for e in appended) == [1, 2, 3, 4]


async def case_append_same_event_race_leaves_one(storage: StorageInterface) -> None:
    s = storage.get_events_storage()
    org_id = new_id()
    e = event()
    results = await asyncio.gather(*(s.append_event(org_id, e) for _ in range(2)))
    assert results[0] == results[1]
    assert await s.read_head(org_id) == 1


async def case_audit_appends_numbered_and_fenced(storage: StorageInterface) -> None:
    s = storage.get_audit_storage()
    a, b = new_id(), new_id()
    e = entry()
    first = await s.append_audit_entry(a, e)
    assert (await s.append_audit_entry(a, e)) == first
    second = await s.append_audit_entry(a, entry())
    assert (first.seq, second.seq) == (1, 2)
    assert [x.seq for x in await s.read_after(a, 0, 10)] == [1, 2]
    assert await s.read_after(b, 0, 10) == []


async def case_outbox_row_reads_and_marks_under_its_tenant(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    other = await f.tenant(storage)
    r = f.row(t.org_id)
    await storage.get_tenancy_storage().write_user(t.org_id, t.user, (r,))
    s = storage.get_outbox_storage()
    assert (await s.read_row(t.org_id, r.id)) == r
    assert await s.read_row(other.org_id, r.id) is None
    assert not await s.mark_done(other.org_id, r.id, utcnow())
    assert (await s.read_row(t.org_id, r.id)).done_at is None  # type: ignore[union-attr]
    assert await s.mark_done(t.org_id, r.id, utcnow())
    assert not await s.mark_done(t.org_id, r.id, utcnow())


async def case_outbox_pending_oldest_and_purge(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    r = f.row(t.org_id)
    await storage.get_tenancy_storage().write_user(t.org_id, t.user, (r,))
    s = storage.get_outbox_storage()
    assert r.id in [p.id for p in await s.read_pending(100_000)]
    assert len(await s.read_pending(1)) == 1
    oldest = await s.read_oldest_pending()
    assert oldest is not None and oldest <= r.created_at
    await s.mark_done(t.org_id, r.id, utcnow() - timedelta(days=30))
    assert r.id not in [p.id for p in await s.read_pending(100_000)]
    while await s.purge_done(utcnow() - timedelta(days=1), 500):
        pass
    assert await s.read_row(t.org_id, r.id) is None


CASES = [v for k, v in sorted(globals().items()) if k.startswith("case_")]
