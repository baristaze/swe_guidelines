"""Contract cases of the idempotency marker: every move of its table, the take-over, and the race."""

import asyncio
from datetime import timedelta
from uuid import UUID

from acme.om.base import new_id, utcnow
from acme.om.idempotency.types import BeginOutcome, IdempotencyMarker, MarkerOutcome
from acme.om.storage.root import StorageInterface
from contracts import factories as f

LEASE = timedelta(minutes=1)


def marker(user_id: UUID, key: str, digest: str = "digest-a") -> IdempotencyMarker:
    return IdempotencyMarker(
        id=new_id(),
        created_at=utcnow(),
        user_id=user_id,
        key=key,
        request_digest=digest,
        target_id=new_id(),
        attempt_token=new_id(),
    )


async def begin_marker(storage: StorageInterface, org_id: UUID, user_id: UUID, key: str | None = None) -> MarkerOutcome:
    return await storage.get_idempotency_storage().begin(
        org_id, marker(user_id, key or f.unique("key")), utcnow() - LEASE
    )


async def case_begin_then_running_then_mismatch(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    first = await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)
    assert first.outcome == BeginOutcome.STARTED
    again = await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)
    assert again.outcome == BeginOutcome.RUNNING
    other = await s.begin(org_id, marker(user_id, key, "digest-b"), utcnow() - LEASE)
    assert other.outcome == BeginOutcome.MISMATCH


async def case_finish_then_replay(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    started = (await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)).marker
    assert started.attempt_token is not None
    assert not await s.finish(org_id, user_id, started.id, new_id(), 201, "{}")
    assert await s.finish(org_id, user_id, started.id, started.attempt_token, 201, '{"ok": true}')
    replay = await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)
    assert replay.outcome == BeginOutcome.REPLAY
    assert (replay.marker.status, replay.marker.body) == (201, '{"ok": true}')
    assert not await s.finish(org_id, user_id, started.id, started.attempt_token, 500, "{}")


async def case_release_lets_a_retry_rerun_on_the_same_target(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    started = (await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)).marker
    assert started.attempt_token is not None
    assert await s.release(org_id, user_id, started.id, started.attempt_token)
    assert not await s.release(org_id, user_id, started.id, started.attempt_token)
    rerun = await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)
    assert rerun.outcome == BeginOutcome.STARTED
    assert rerun.marker.target_id == started.target_id
    assert rerun.marker.attempt_token != started.attempt_token


async def case_a_stale_attempt_is_taken_over(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    started = (await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)).marker
    takeover = await s.begin(org_id, marker(user_id, key), utcnow() + timedelta(seconds=1))
    assert takeover.outcome == BeginOutcome.STARTED
    assert takeover.marker.target_id == started.target_id
    assert started.attempt_token is not None
    assert not await s.finish(org_id, user_id, started.id, started.attempt_token, 201, "{}")


async def case_markers_are_fenced_by_tenant(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    a, b, user_id, key = new_id(), new_id(), new_id(), f.unique("key")
    started = (await s.begin(a, marker(user_id, key), utcnow() - LEASE)).marker
    assert started.attempt_token is not None
    assert (await s.begin(b, marker(user_id, key), utcnow() - LEASE)).outcome == BeginOutcome.STARTED
    assert not await s.finish(b, user_id, started.id, started.attempt_token, 201, "{}")
    assert not await s.release(b, user_id, started.id, started.attempt_token)
    assert not await s.holds_attempt(b, started.id, started.attempt_token)
    assert (await s.read_marker(b, user_id, key)).id != started.id  # type: ignore[union-attr]
    assert await s.holds_attempt(a, started.id, started.attempt_token)
    assert (await s.read_marker(a, user_id, key)).id == started.id  # type: ignore[union-attr]


async def case_read_marker_finds_the_key(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    assert await s.read_marker(org_id, user_id, key) is None
    started = (await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)).marker
    assert (await s.read_marker(org_id, user_id, key)) == started


async def case_purge_markers_past_retention(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)
    while await s.purge_markers(utcnow() + timedelta(seconds=1), 500):
        pass
    assert await s.read_marker(org_id, user_id, key) is None


async def case_begin_race_has_one_winner(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    results = await asyncio.gather(*(s.begin(org_id, marker(user_id, key), utcnow() - LEASE) for _ in range(2)))
    assert sorted(r.outcome for r in results) == [BeginOutcome.RUNNING, BeginOutcome.STARTED]


async def case_take_over_race_has_one_winner(storage: StorageInterface) -> None:
    s = storage.get_idempotency_storage()
    org_id, user_id, key = new_id(), new_id(), f.unique("key")
    started = (await s.begin(org_id, marker(user_id, key), utcnow() - LEASE)).marker
    assert started.attempt_token is not None
    await s.release(org_id, user_id, started.id, started.attempt_token)
    results = await asyncio.gather(*(s.begin(org_id, marker(user_id, key), utcnow() - LEASE) for _ in range(2)))
    assert sorted(r.outcome for r in results) == [BeginOutcome.RUNNING, BeginOutcome.STARTED]


CASES = [v for k, v in sorted(globals().items()) if k.startswith("case_")]
