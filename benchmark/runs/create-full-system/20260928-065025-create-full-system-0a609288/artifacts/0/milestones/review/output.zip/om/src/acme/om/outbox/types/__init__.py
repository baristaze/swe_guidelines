"""The outbox row: written with the core row it announces, relayed afterwards, kept for a retention period."""

from datetime import datetime
from typing import ClassVar
from uuid import UUID

from pydantic import Field

from acme.om.base import EMPTY_UUID, Created, FrozenMapping, Identifiable, new_id, utcnow
from acme.om.opcontext import AppContext, OperatorContext, ProvenanceScope, RequestScope

WORK_KIND_PREFIX = "work."


class OutboxRow(Identifiable, Created):  # written with the core row, in the same transaction
    MANAGER_OWNED_FIELDS: ClassVar[tuple[str, ...]] = ()

    org_id: UUID  # carried on the entity: the relay runs with no context
    kind: str  # "<namespace>.<entity>.<created|updated|deleted>", or "work.<kind>"
    target_id: UUID
    payload: FrozenMapping = Field(default_factory=dict, validate_default=True)  # ids only, never a field value
    actor_id: UUID  # the principal of the write it announces; EMPTY_UUID for the platform
    request_id: UUID  # the request that made the write
    traceparent: str | None = None  # the trace context of that request, for a link
    app: AppContext  # the app that made it
    done_at: datetime | None = None


def outbox_row(ctx: ProvenanceScope, kind: str, target_id: UUID, payload: FrozenMapping) -> OutboxRow:
    """The row a tenant write lands beside its core row, stamped with the write's provenance."""
    return OutboxRow(
        id=new_id(),
        created_at=utcnow(),
        org_id=ctx.org_id,
        kind=kind,
        target_id=target_id,
        payload=payload,
        actor_id=ctx.user_id,
        request_id=ctx.request_id,
        traceparent=ctx.traceparent,
        app=ctx.app,
    )


def operator_outbox_row(octx: OperatorContext, org_id: UUID, kind: str, target_id: UUID) -> OutboxRow:
    """The operator plane's row: stamped from the operator's identity and request, never through outbox_row."""
    return OutboxRow(
        id=new_id(),
        created_at=utcnow(),
        org_id=org_id,
        kind=kind,
        target_id=target_id,
        payload={"operator_identity_id": str(octx.identity_id)},
        actor_id=EMPTY_UUID,  # the platform acts; the operator is named in the payload by id
        request_id=octx.request_id,
        traceparent=octx.traceparent,
        app=octx.app,
    )


def platform_outbox_row(
    rctx: RequestScope, org_id: UUID, kind: str, target_id: UUID, payload: FrozenMapping
) -> OutboxRow:
    """The row of a request-stage write into a tenant (the desk's public intake, a verified payment delivery): no
    principal exists, so the platform is the actor; the request and its trace are the intake's (ADR 0009)."""
    return OutboxRow(
        id=new_id(),
        created_at=utcnow(),
        org_id=org_id,
        kind=kind,
        target_id=target_id,
        payload=payload,
        actor_id=EMPTY_UUID,
        request_id=rctx.request_id,
        traceparent=rctx.traceparent,
        app=rctx.app,
    )
