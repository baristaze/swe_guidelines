"""Contract cases of the journalists storage: every method under another tenant, the page, the soft delete, the id."""

import asyncio
from uuid import UUID

import pytest

from acme.om.base import new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.journalists.types.journalist import Journalist
from acme.om.storage.root import StorageInterface
from contracts import factories as f


def journalist(display_name: str = "Reporter", journalist_id: UUID | None = None) -> Journalist:
    now = utcnow()
    actor = new_id()
    return Journalist(
        id=journalist_id or new_id(),
        created_at=now,
        updated_at=now,
        created_by=actor,
        updated_by=actor,
        display_name=display_name,
    )


async def case_create_then_read_and_list(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    j = journalist()
    r = f.row(org_id, "journalists.journalist.created", j.id)
    assert await s.create_journalist(org_id, j, (r,)) is True
    assert await s.read_journalist(org_id, j.id) == j
    assert await s.read_journalists(org_id, 10) == [j]
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r


async def case_list_pages_in_id_order(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    made = [journalist(f"Reporter {n}") for n in range(3)]
    for j in made:
        await s.create_journalist(org_id, j, ())
    ordered = sorted(made, key=lambda j: j.id.int)
    assert await s.read_journalists(org_id, 2) == ordered[:2]
    assert await s.read_journalists(org_id, 10) == ordered


async def case_a_second_create_under_the_same_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    j = journalist()
    await s.create_journalist(org_id, j, ())
    again = f.row(org_id, "journalists.journalist.created", j.id)
    assert await s.create_journalist(org_id, j.model_copy(update={"display_name": "Other"}), (again,)) is False
    assert await s.read_journalist(org_id, j.id) == j
    assert await storage.get_outbox_storage().read_row(org_id, again.id) is None  # lands only when the insert won


async def case_the_list_leaves_out_the_deleted(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    kept, gone = journalist("Kept"), journalist("Gone")
    await s.create_journalist(org_id, kept, ())
    await s.create_journalist(org_id, gone, ())
    deleted = gone.model_copy(update={"deleted_at": utcnow(), "deleted_by": new_id()})
    await s.write_journalist(org_id, deleted, ())
    assert await s.read_journalists(org_id, 10) == [kept]
    assert await s.read_journalist(org_id, gone.id) == deleted  # still read by id: the manager decides


async def case_write_applies_under_the_tenant_and_lands_its_row(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    j = journalist()
    await s.create_journalist(org_id, j, ())
    renamed = j.model_copy(update={"display_name": "Renamed", "updated_at": utcnow()})
    r = f.row(org_id, "journalists.journalist.updated", j.id)
    await s.write_journalist(org_id, renamed, (r,))
    assert await s.read_journalist(org_id, j.id) == renamed
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r


async def case_list_under_another_tenant_finds_nothing(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id, other = new_id(), new_id()
    await s.create_journalist(org_id, journalist(), ())
    assert await s.read_journalists(other, 10) == []


async def case_read_under_another_tenant_finds_nothing(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    j = journalist()
    await s.create_journalist(org_id, j, ())
    assert await s.read_journalist(new_id(), j.id) is None


async def case_create_under_another_tenant_with_a_taken_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id, other = new_id(), new_id()
    j = journalist()
    await s.create_journalist(org_id, j, ())
    r = f.row(other, "journalists.journalist.created", j.id)
    assert await s.create_journalist(other, j.model_copy(update={"display_name": "Taken"}), (r,)) is False
    assert await s.read_journalist(org_id, j.id) == j
    assert await s.read_journalist(other, j.id) is None
    assert await storage.get_outbox_storage().read_row(other, r.id) is None


async def case_write_under_another_tenant_is_refused_and_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id, other = new_id(), new_id()
    j = journalist()
    await s.create_journalist(org_id, j, ())
    r = f.row(other, "journalists.journalist.updated", j.id)
    with pytest.raises(Conflict):
        await s.write_journalist(other, j.model_copy(update={"display_name": "Hijacked"}), (r,))
    assert await s.read_journalist(org_id, j.id) == j
    assert await s.read_journalists(other, 10) == []
    assert await storage.get_outbox_storage().read_row(other, r.id) is None


async def case_a_create_race_has_one_winner(storage: StorageInterface) -> None:
    s = storage.get_journalist_storage()
    org_id = new_id()
    j = journalist()
    results = await asyncio.gather(s.create_journalist(org_id, j, ()), s.create_journalist(org_id, j, ()))
    assert sorted(results) == [False, True]
    assert await s.read_journalists(org_id, 10) == [j]


CASES = [
    case_create_then_read_and_list,
    case_list_pages_in_id_order,
    case_a_second_create_under_the_same_id_changes_nothing,
    case_the_list_leaves_out_the_deleted,
    case_write_applies_under_the_tenant_and_lands_its_row,
    case_list_under_another_tenant_finds_nothing,
    case_read_under_another_tenant_finds_nothing,
    case_create_under_another_tenant_with_a_taken_id_changes_nothing,
    case_write_under_another_tenant_is_refused_and_changes_nothing,
    case_a_create_race_has_one_winner,
]
