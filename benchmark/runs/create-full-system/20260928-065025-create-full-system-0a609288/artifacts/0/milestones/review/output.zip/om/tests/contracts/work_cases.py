"""Contract cases of the work storage: claim exclusivity, the token fence, requeue, purge, keys, and tenants."""

import asyncio
from datetime import timedelta
from uuid import UUID

from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.storage.root import InsertOutcome, StorageInterface
from acme.om.work.types.work_item import WorkItem, WorkKind, WorkStatus
from contracts import factories as f

LANE = "contract"


def item(lane: str | None = None, key: UUID | None = None, item_id: UUID | None = None) -> WorkItem:
    now = utcnow()
    return WorkItem(
        id=item_id or new_id(),
        created_at=now,
        updated_at=now,
        created_by=EMPTY_UUID,
        updated_by=EMPTY_UUID,
        kind=WorkKind.NOOP,
        target_id=new_id(),
        idempotency_key=key or new_id(),
        request_id=new_id(),
        lane=lane or f.unique(LANE),
        available_at=now - timedelta(seconds=1),
    )


async def claim(storage: StorageInterface, lane: str, lease: timedelta = timedelta(minutes=1)):  # type: ignore[no-untyped-def]
    now = utcnow()
    return await storage.get_work_storage().claim_next(lane, (WorkKind.NOOP,), "w1", new_id(), now + lease, now)


async def case_create_reports_the_colliding_key(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    first = item()
    assert await s.create_item(org_id, first) == InsertOutcome.INSERTED
    assert await s.create_item(org_id, first) == InsertOutcome.ID_EXISTS
    same_key = item(key=first.idempotency_key)
    assert await s.create_item(org_id, same_key) == InsertOutcome.KEY_EXISTS
    assert (await s.read_item_by_key(org_id, first.idempotency_key)) == first
    assert await s.create_item(new_id(), same_key) == InsertOutcome.INSERTED  # the key is unique per tenant only


async def case_reads_are_fenced_by_tenant(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    it = item()
    await s.create_item(org_id, it)
    assert await s.read_item(new_id(), it.id) is None
    assert await s.read_item_by_key(new_id(), it.idempotency_key) is None
    assert (await s.read_item(org_id, it.id)) == it


async def case_claim_stamps_the_token_and_returns_the_tenant(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    it = item()
    await s.create_item(org_id, it)
    claimed = await claim(storage, it.lane)
    assert claimed is not None
    claimed_org, claimed_item = claimed
    assert claimed_org == org_id and claimed_item.id == it.id
    assert claimed_item.status == WorkStatus.CLAIMED and claimed_item.claim_token is not None
    assert await claim(storage, it.lane) is None  # one holder per claim


async def case_claim_race_has_one_winner(storage: StorageInterface) -> None:
    lane = f.unique(LANE)
    await storage.get_work_storage().create_item(new_id(), item(lane))
    results = await asyncio.gather(claim(storage, lane), claim(storage, lane))
    assert sum(1 for r in results if r is not None) == 1


async def case_a_write_holds_only_with_the_current_token(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    it = item()
    await s.create_item(org_id, it)
    claimed = await claim(storage, it.lane)
    assert claimed is not None and claimed[1].claim_token is not None
    done = claimed[1].model_copy(update={"status": WorkStatus.DONE, "claim_token": None})
    assert not await s.write_item(org_id, done, new_id())  # an earlier claim's token is refused
    assert not await s.write_item(new_id(), done, claimed[1].claim_token)  # another tenant finds nothing
    assert (await s.read_item(org_id, it.id)).status == WorkStatus.CLAIMED  # type: ignore[union-attr]
    assert await s.write_item(org_id, done, claimed[1].claim_token)
    assert (await s.read_item(org_id, it.id)).status == WorkStatus.DONE  # type: ignore[union-attr]


async def case_requeue_stale_hands_back_only_this_tenants_expired_leases(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    mine, other = new_id(), new_id()
    lane = f.unique(LANE)
    await s.create_item(mine, item(lane))
    await s.create_item(other, item(lane))
    first = await claim(storage, lane, lease=timedelta(seconds=-1))
    second = await claim(storage, lane, lease=timedelta(seconds=-1))
    assert first is not None and second is not None
    mine_item = first[1] if first[0] == mine else second[1]
    other_item = second[1] if first[0] == mine else first[1]
    assert await s.requeue_stale(mine, utcnow(), 10, utcnow()) == 1
    assert (await s.read_item(mine, mine_item.id)).status == WorkStatus.QUEUED  # type: ignore[union-attr]
    assert (await s.read_item(other, other_item.id)).status == WorkStatus.CLAIMED  # type: ignore[union-attr]


async def case_fail_orphaned_holds_to_the_token(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    it = item()
    await s.create_item(org_id, it)
    claimed = await claim(storage, it.lane)
    assert claimed is not None and claimed[1].claim_token is not None
    assert not await s.fail_orphaned(it.id, new_id(), "gone", utcnow())
    assert await s.fail_orphaned(it.id, claimed[1].claim_token, "gone", utcnow())
    assert (await s.read_item(org_id, it.id)).status == WorkStatus.FAILED  # type: ignore[union-attr]


async def case_gauges_see_the_oldest_waiting_and_the_failed(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    it = item()
    await s.create_item(org_id, it)
    gauges = await s.read_gauges()
    assert gauges.oldest_waiting_at is not None and gauges.oldest_waiting_at <= it.available_at


async def case_purge_items_takes_only_finished_items_past_the_cutoff(storage: StorageInterface) -> None:
    s = storage.get_work_storage()
    org_id = new_id()
    lane = f.unique(LANE)
    waiting = item(lane)
    finished = item(lane)
    await s.create_item(org_id, finished)
    claimed = await claim(storage, lane)
    assert claimed is not None and claimed[1].claim_token is not None
    old = utcnow() - timedelta(days=30)
    done = claimed[1].model_copy(update={"status": WorkStatus.DONE, "claim_token": None, "updated_at": old})
    await s.write_item(org_id, done, claimed[1].claim_token)
    await s.create_item(org_id, waiting)
    while await s.purge_items(utcnow() - timedelta(days=1), 500):
        pass
    assert await s.read_item(org_id, finished.id) is None
    assert await s.read_item(org_id, waiting.id) is not None


CASES = [v for k, v in sorted(globals().items()) if k.startswith("case_")]
