"""The event stream over Postgres: the append takes the next number from the tenant's cursor row."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import func, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError

from acme.om.base import EMPTY_UUID
from acme.om.events.storage import EventsStorageInterface, uuid7_floor
from acme.om.events.storage.tables.events import EventCursors, Events
from acme.om.events.types import Event
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.utils.translation import to_model, to_values


class EventsStoragePostgresImpl(PgStorageBase, EventsStorageInterface):
    async def _read_by_id(self, org_id: UUID, event_id: UUID) -> Event | None:
        stmt = select(Events).where(Events.org_id == org_id, Events.id == event_id)
        async with self._session_for(stmt, org_id=org_id) as session:
            row = (await session.execute(stmt)).scalar_one_or_none()
            return None if row is None else to_model(row, Event)

    async def append_event(self, org_id: UUID, event: Event) -> Event:
        """Named atomic: assigns `seq` from the tenant's cursor row in the append's own transaction.
        An id already written returns the stored event and moves no cursor."""
        existing = await self._read_by_id(org_id, event.id)
        if existing is not None:
            return existing
        seed = pg_insert(EventCursors).values(id=org_id, org_id=org_id, head=0).on_conflict_do_nothing()
        bump = (
            update(EventCursors)
            .where(EventCursors.org_id == org_id)
            .values(head=EventCursors.head + 1)
            .returning(EventCursors.head)
        )
        try:
            async with self._session_for(bump, org_id=org_id) as session:
                await session.execute(seed)
                seq = (await session.execute(bump)).scalar_one()
                stored = event.model_copy(update={"org_id": org_id, "seq": seq})
                await session.execute(pg_insert(Events).values(**to_values(stored, Events)))
        except IntegrityError:
            # A concurrent relay of the same row won; the rollback took this seq back with it.
            again = await self._read_by_id(org_id, event.id)
            if again is None:
                raise
            return again
        return stored

    async def read_head(self, org_id: UUID) -> int:
        stmt = select(EventCursors.head).where(EventCursors.org_id == org_id)
        async with self._session_for(stmt, org_id=org_id) as session:
            return (await session.execute(stmt)).scalar_one_or_none() or 0

    async def read_after(self, org_id: UUID, after_seq: int, limit: int) -> list[Event]:
        stmt = select(Events).where(Events.org_id == org_id, Events.seq > after_seq).order_by(Events.seq).limit(limit)
        async with self._session_for(stmt, org_id=org_id) as session:
            return [to_model(r, Event) for r in (await session.execute(stmt)).scalars()]

    async def count_since(self, since: datetime, excluded: tuple[UUID, ...]) -> int:
        """Tenant-less: the operator plane's count of events across tenants, in the system scope,
        leaving out the tenants named (the ones a traffic run provisioned)."""
        stmt = select(func.count()).select_from(Events).where(Events.id >= uuid7_floor(since))
        if excluded:
            stmt = stmt.where(Events.org_id.not_in(excluded))
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            return int((await session.execute(stmt)).scalar_one())
