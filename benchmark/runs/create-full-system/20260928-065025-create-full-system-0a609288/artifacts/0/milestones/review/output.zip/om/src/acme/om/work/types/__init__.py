"""The work item, its kinds and statuses, the payload map, and the handler interface."""
