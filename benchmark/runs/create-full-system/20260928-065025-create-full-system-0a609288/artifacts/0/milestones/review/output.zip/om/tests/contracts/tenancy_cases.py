"""Contract cases of the tenancy storage: one per method, each with the case that presents another tenant's id."""

import asyncio
from datetime import timedelta

import pytest

from acme.om.base import new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.opcontext import OperatorPermission, Role
from acme.om.storage.root import InsertOutcome, StorageInterface
from acme.om.tenancy.types import ApiKeyInsert, SessionKind
from contracts import factories as f
from contracts.idempotency_cases import begin_marker


async def case_signup_lands_every_row(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    assert (await s.read_org(t.org_id)) == t.org
    assert (await s.read_identity(t.identity.id)) == t.identity
    assert (await s.read_user(t.org_id, t.user.id)) == t.user
    assert (await s.read_membership(t.org_id, t.user.id)) == t.membership
    mirrors = await s.read_identity_memberships(t.identity.id, 10)
    assert [m.tenant_id for m in mirrors] == [t.org_id]


async def case_signup_refuses_a_held_email_and_writes_nothing(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    o = f.org()
    i = f.identity(email=t.identity.email)
    u, m = f.member(i.id)
    assert await s.create_signup(o.id, o, i, u, m, (f.row(o.id),)) == InsertOutcome.KEY_EXISTS
    assert await s.read_org(o.id) is None
    assert await storage.get_outbox_storage().read_row(o.id, o.id) is None


async def case_signup_refuses_a_held_slug(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    o = f.org(slug=t.org.slug)
    i = f.identity()
    u, m = f.member(i.id)
    assert await s.create_signup(o.id, o, i, u, m, ()) == InsertOutcome.KEY_EXISTS
    assert await s.read_identity(i.id) is None


async def case_a_deleted_org_frees_its_slug(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    first = f.org()
    assert await s.create_org(first.id, first, ()) == InsertOutcome.INSERTED
    deleted = first.model_copy(update={"deleted_at": utcnow()})
    await s.write_org(first.id, deleted, ())
    again = f.org(slug=first.slug)
    assert await s.create_org(again.id, again, ()) == InsertOutcome.INSERTED


async def case_create_org_reports_the_collision(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    o = f.org()
    assert await s.create_org(o.id, o, ()) == InsertOutcome.INSERTED
    assert await s.create_org(o.id, o, ()) == InsertOutcome.ID_EXISTS
    other = f.org(slug=o.slug)
    assert await s.create_org(other.id, other, ()) == InsertOutcome.KEY_EXISTS


async def case_create_org_lands_its_outbox_row(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    o = f.org()
    r = f.row(o.id, "tenancy.org.created", o.id)
    await s.create_org(o.id, o, (r,))
    assert (await storage.get_outbox_storage().read_row(o.id, r.id)) == r


async def case_read_orgs_lists_live_orgs(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    ids = [o.id for o in await s.read_orgs(10_000)]
    assert t.org_id in ids
    assert len(await s.read_orgs(1)) == 1


async def case_read_live_org_ids_pages_in_uuid_order(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    page = await s.read_live_org_ids(None, 100_000)
    assert a.org_id in page
    assert page == sorted(page, key=lambda i: i.int)
    after = await s.read_live_org_ids(a.org_id, 100_000)
    assert all(i.int > a.org_id.int for i in after)


async def case_read_size_counts_across_tenants(storage: StorageInterface) -> None:
    await f.tenant(storage)
    size = await storage.get_tenancy_storage().read_size()
    assert size.tenants >= 1 and size.users >= 1


async def case_identity_create_read_write(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    i = f.identity()
    assert await s.create_identity(i.id, i) == InsertOutcome.INSERTED
    assert await s.create_identity(i.id, i) == InsertOutcome.ID_EXISTS
    held = f.identity(email=i.email)
    assert await s.create_identity(held.id, held) == InsertOutcome.KEY_EXISTS
    renamed = i.model_copy(update={"display_name": "Renamed"})
    await s.write_identity(i.id, renamed)
    assert (await s.read_identity(i.id)) == renamed


async def case_identity_reads_see_only_their_identity(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    assert (await s.read_identity(b.identity.id)).id == b.identity.id  # type: ignore[union-attr]
    assert await s.read_identity_memberships(a.identity.id, 10) != await s.read_identity_memberships(b.identity.id, 10)
    assert all(m.tenant_id == b.org_id for m in await s.read_identity_memberships(b.identity.id, 10))


async def case_lookups_find_by_digest_and_subject(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    i = f.identity().model_copy(update={"issuer": "https://idp.example", "subject": f.unique("sub")})
    await s.create_identity(i.id, i)
    assert (await s.read_identity_by_email_digest(i.email_digest)) == i
    assert (await s.read_identity_by_issuer_subject("https://idp.example", i.subject or "")) == i
    assert await s.read_identity_by_email_digest("absent") is None


async def case_create_member_and_its_collision(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    i = f.identity()
    await s.create_identity(i.id, i)
    u, m = f.member(i.id, Role.MEMBER)
    r = f.row(t.org_id)
    assert await s.create_member(t.org_id, i.id, u, m, (r,)) == InsertOutcome.INSERTED
    assert (await s.read_user_by_identity(t.org_id, i.id)) == u
    assert await storage.get_outbox_storage().read_row(t.org_id, r.id) == r
    u2, m2 = f.member(i.id, Role.VIEWER)
    assert await s.create_member(t.org_id, i.id, u2, m2, ()) == InsertOutcome.KEY_EXISTS


async def case_user_and_membership_reads_are_fenced_by_tenant(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    assert await s.read_user(b.org_id, a.user.id) is None
    assert await s.read_user_by_identity(b.org_id, a.identity.id) is None
    assert a.user.id not in [u.id for u in await s.read_users(b.org_id, 100)]
    assert await s.read_membership(b.org_id, a.user.id) is None
    assert a.membership.id not in [m.id for m in await s.read_memberships(b.org_id, 100)]
    assert [u.id for u in await s.read_users(a.org_id, 100)] == [a.user.id]


async def case_write_user_under_another_tenant_changes_nothing(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    renamed = a.user.model_copy(update={"name": "Taken"})
    with pytest.raises(Conflict):
        await s.write_user(b.org_id, renamed, ())
    assert (await s.read_user(a.org_id, a.user.id)) == a.user
    await s.write_user(a.org_id, renamed, ())
    assert (await s.read_user(a.org_id, a.user.id)) == renamed


async def case_write_membership_under_another_tenant_changes_nothing(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    demoted = a.membership.model_copy(update={"role": Role.VIEWER})
    await s.write_membership(b.org_id, a.identity.id, demoted, ())
    assert (await s.read_membership(a.org_id, a.user.id)).role == Role.OWNER  # type: ignore[union-attr]
    await s.write_membership(a.org_id, a.identity.id, demoted, ())
    assert (await s.read_membership(a.org_id, a.user.id)).role == Role.VIEWER  # type: ignore[union-attr]
    assert (await s.read_identity_memberships(a.identity.id, 10))[0].role == Role.VIEWER


async def case_remove_membership_ends_keys_and_sessions(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    key = f.api_key(t.user.id)
    assert await s.create_api_key(t.org_id, key, ()) == ApiKeyInsert.INSERTED
    live = f.session(t.identity.id, SessionKind.TENANT, t.org_id)
    await s.create_session(t.identity.id, live)
    assert await s.remove_membership(b.org_id, t.user.id, t.identity.id, utcnow(), ()) == []
    assert await s.read_membership(t.org_id, t.user.id) is not None
    ended = await s.remove_membership(t.org_id, t.user.id, t.identity.id, utcnow(), ())
    assert ended == [live.id]
    assert await s.read_membership(t.org_id, t.user.id) is None
    assert (await s.read_api_key(t.org_id, key.id)).revoked_at is not None  # type: ignore[union-attr]
    assert (await s.read_session(t.identity.id, live.id)).ended_at is not None  # type: ignore[union-attr]
    assert await s.read_identity_memberships(t.identity.id, 10) == []


async def case_sessions_create_read_touch_end(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    sess = f.session(t.identity.id)
    assert await s.create_session(t.identity.id, sess)
    assert (await s.read_session(t.identity.id, sess.id)) == sess
    assert (await s.read_session_by_digest(sess.digest)) == sess
    later = utcnow() + timedelta(minutes=1)
    assert await s.touch_session(t.identity.id, sess.id, later)
    assert await s.end_session(t.identity.id, sess.id, later)
    assert not await s.end_session(t.identity.id, sess.id, later)
    assert not await s.touch_session(t.identity.id, sess.id, later)


async def case_sessions_are_fenced_by_identity(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    sess = f.session(a.identity.id)
    await s.create_session(a.identity.id, sess)
    assert await s.read_session(b.identity.id, sess.id) is None
    assert not await s.touch_session(b.identity.id, sess.id, utcnow())
    assert not await s.end_session(b.identity.id, sess.id, utcnow())
    assert not await s.exchange_session(b.identity.id, sess.id, f.session(b.identity.id), utcnow())
    assert (await s.read_session(a.identity.id, sess.id)).ended_at is None  # type: ignore[union-attr]


async def case_exchange_ends_the_presented_session(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    old = f.session(t.identity.id, SessionKind.TENANT, t.org_id)
    await s.create_session(t.identity.id, old)
    new = f.session(t.identity.id, SessionKind.TENANT, t.org_id)
    assert await s.exchange_session(t.identity.id, old.id, new, utcnow())
    assert (await s.read_session(t.identity.id, old.id)).ended_at is not None  # type: ignore[union-attr]
    assert (await s.read_session(t.identity.id, new.id)) == new
    assert not await s.exchange_session(t.identity.id, old.id, f.session(t.identity.id), utcnow())


async def case_purge_sessions_removes_ended_and_expired(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    ended = f.session(t.identity.id)
    fresh = f.session(t.identity.id)
    await s.create_session(t.identity.id, ended)
    await s.create_session(t.identity.id, fresh)
    await s.end_session(t.identity.id, ended.id, utcnow())
    while await s.purge_sessions(utcnow(), utcnow() - timedelta(days=1), 500):
        pass
    assert await s.read_session(t.identity.id, ended.id) is None
    assert await s.read_session(t.identity.id, fresh.id) is not None


async def case_api_keys_land_only_for_a_live_member(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    key = f.api_key(a.user.id)
    assert await s.create_api_key(b.org_id, key, ()) == ApiKeyInsert.NO_MEMBERSHIP
    r = f.row(a.org_id)
    assert await s.create_api_key(a.org_id, key, (r,)) == ApiKeyInsert.INSERTED
    assert await s.create_api_key(a.org_id, key, ()) == ApiKeyInsert.ID_EXISTS
    assert await storage.get_outbox_storage().read_row(a.org_id, r.id) == r
    assert (await s.read_api_key(a.org_id, key.id)) == key
    assert (await s.read_api_key_by_digest(key.digest)) == (a.org_id, key)


async def case_api_key_reads_and_writes_are_fenced_by_tenant(storage: StorageInterface) -> None:
    a = await f.tenant(storage)
    b = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    key = f.api_key(a.user.id)
    await s.create_api_key(a.org_id, key, ())
    assert await s.read_api_key(b.org_id, key.id) is None
    assert await s.read_api_keys(b.org_id, 100) == []
    assert not await s.revoke_api_key(b.org_id, key.id, utcnow(), ())
    assert not await s.remint_api_key(b.org_id, key.id, f.unique("other"), new_id(), new_id())
    assert (await s.read_api_key(a.org_id, key.id)) == key
    assert await s.revoke_api_key(a.org_id, key.id, utcnow(), ())
    assert not await s.revoke_api_key(a.org_id, key.id, utcnow(), ())


async def case_remint_writes_only_under_the_marker_attempt(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    key = f.api_key(t.user.id)
    await s.create_api_key(t.org_id, key, ())
    outcome = await begin_marker(storage, t.org_id, t.user.id)
    marker = outcome.marker
    assert marker.attempt_token is not None
    fresh = f.unique("fresh")
    assert not await s.remint_api_key(t.org_id, key.id, f.unique("stale"), marker.id, new_id())
    assert await s.remint_api_key(t.org_id, key.id, fresh, marker.id, marker.attempt_token)
    assert (await s.read_api_key(t.org_id, key.id)).digest == fresh  # type: ignore[union-attr]


async def case_socket_ticket_redeems_once(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    tk = f.ticket(t.identity.id, t.org_id, t.user.id)
    assert await s.create_socket_ticket(t.identity.id, tk)
    redeemed = await s.redeem_socket_ticket(tk.digest, utcnow())
    assert redeemed is not None and redeemed.id == tk.id
    assert await s.redeem_socket_ticket(tk.digest, utcnow()) is None


async def case_expired_socket_ticket_is_refused_and_purged(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    tk = f.ticket(t.identity.id, t.org_id, t.user.id, ttl=timedelta(seconds=-1))
    await s.create_socket_ticket(t.identity.id, tk)
    assert await s.redeem_socket_ticket(tk.digest, utcnow()) is None
    while await s.purge_socket_tickets(utcnow(), 500):
        pass
    assert await s.redeem_socket_ticket(tk.digest, utcnow() - timedelta(minutes=5)) is None


async def case_socket_ticket_redemption_race_has_one_winner(storage: StorageInterface) -> None:
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    tk = f.ticket(t.identity.id, t.org_id, t.user.id)
    await s.create_socket_ticket(t.identity.id, tk)
    results = await asyncio.gather(*(s.redeem_socket_ticket(tk.digest, utcnow()) for _ in range(2)))
    assert sum(1 for r in results if r is not None) == 1


async def case_sign_in_failures_double_and_clear(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    key = f.unique("email-digest")
    assert await s.read_sign_in_failures(key) is None
    now = utcnow()
    first = await s.record_sign_in_failure(key, new_id(), now, 1.0, 60.0)
    second = await s.record_sign_in_failure(key, new_id(), now, 1.0, 60.0)
    assert (first.failures, second.failures) == (1, 2)
    assert abs((second.retry_at - now).total_seconds() - 2.0) < 0.5
    assert (await s.read_sign_in_failures(key)).failures == 2  # type: ignore[union-attr]
    await s.clear_sign_in_failures(key)
    assert await s.read_sign_in_failures(key) is None


async def case_operator_entries_upsert_by_identity(storage: StorageInterface) -> None:
    s = storage.get_tenancy_storage()
    i = f.identity()
    await s.create_identity(i.id, i)
    entry = f.operator_entry(i.id)
    await s.write_operator_entry(entry)
    assert (await s.read_operator_entry(i.id)) == entry
    widened = entry.model_copy(update={"permission": OperatorPermission.WRITE})
    await s.write_operator_entry(widened)
    assert (await s.read_operator_entry(i.id)).permission == OperatorPermission.WRITE  # type: ignore[union-attr]
    assert await s.read_operator_entry(new_id()) is None


async def case_remove_membership_races_key_issue(storage: StorageInterface) -> None:
    """Two callers at once: the member removed and the same member issuing a key. No key of theirs stays live."""
    t = await f.tenant(storage)
    s = storage.get_tenancy_storage()
    key = f.api_key(t.user.id)
    await asyncio.gather(
        s.remove_membership(t.org_id, t.user.id, t.identity.id, utcnow(), ()),
        s.create_api_key(t.org_id, key, ()),
    )
    stored = await s.read_api_key(t.org_id, key.id)
    assert stored is None or stored.revoked_at is not None


CASES = [v for k, v in sorted(globals().items()) if k.startswith("case_")]
