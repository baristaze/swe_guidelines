"""The email twin: a mailbox in memory, one message per idempotency key."""

import hashlib

from acme.integrations.email import Delivery, EmailInterface, OutboundEmail
from acme.integrations.twin import TWIN_PROVENANCE, refuse_outside_local


class EmailTwinImpl(EmailInterface):
    def __init__(self, environment: str) -> None:
        refuse_outside_local(environment, "email")
        self.sent: dict[str, OutboundEmail] = {}

    async def send(self, message: OutboundEmail) -> Delivery:
        self.sent.setdefault(message.idempotency_key, message)
        message_id = hashlib.sha256(message.idempotency_key.encode()).hexdigest()[:32]
        return Delivery(message_id=f"twin-{message_id}", provenance=TWIN_PROVENANCE)

    async def start(self) -> None:
        return None

    async def close(self) -> None:
        return None

    def describe(self) -> str:
        return "email: twin"
