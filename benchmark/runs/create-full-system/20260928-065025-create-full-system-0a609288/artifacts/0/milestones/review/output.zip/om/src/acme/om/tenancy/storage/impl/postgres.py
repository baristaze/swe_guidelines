"""The tenancy storage over Postgres. Every query carries its own tenant or identity predicate."""

from datetime import datetime, timedelta
from uuid import UUID

from sqlalchemy import delete, exists, func, insert, literal, or_, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert

from acme.om.base import EMPTY_UUID
from acme.om.idempotency.storage.tables.idempotency_markers import IdempotencyMarkers
from acme.om.outbox.types import OutboxRow
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome
from acme.om.storage.utils.translation import to_model, to_values
from acme.om.tenancy.storage import TenancyStorageInterface
from acme.om.tenancy.storage.tables.tenancy import (
    ApiKeys,
    Identities,
    IdentityMemberships,
    Memberships,
    Operators,
    Orgs,
    Sessions,
    SignInFailures,
    SocketTickets,
    Users,
)
from acme.om.tenancy.types import (
    ApiKey,
    ApiKeyInsert,
    Identity,
    IdentityMembership,
    Membership,
    OperatorEntry,
    Org,
    Session,
    SessionKind,
    SignInThrottle,
    SocketTicket,
    TenancySize,
    User,
)


class _KeyHeld(Exception):
    """Aborts a named atomic write whose insert met a held unique key; the transaction rolls back."""


class TenancyStoragePostgresImpl(PgStorageBase, TenancyStorageInterface):
    # --- orgs

    async def create_signup(
        self,
        org_id: UUID,
        org: Org,
        identity: Identity,
        user: User,
        membership: Membership,
        outbox_rows: tuple[OutboxRow, ...],
    ) -> InsertOutcome:
        """Named atomic: the identity, its first org, the owner's user and membership, in one transaction.
        KEY_EXISTS when the email or the slug is held; nothing is written then."""
        try:
            async with self._session_for(Orgs, org_id=org_id, identity_id=identity.id) as session:
                for stmt in (
                    pg_insert(Identities).values(**to_values(identity, Identities, identity_id=identity.id)),
                    pg_insert(Orgs).values(**to_values(org, Orgs)),
                ):
                    if (await session.execute(stmt.on_conflict_do_nothing().returning(literal(1)))).first() is None:
                        raise _KeyHeld
                await session.execute(insert(Users).values(**to_values(user, Users, org_id=org_id)))
                await session.execute(insert(Memberships).values(**to_values(membership, Memberships, org_id=org_id)))
                await session.execute(insert(IdentityMemberships).values(**_mirror(identity.id, org_id, membership)))
                await self._land(session, outbox_rows)
        except _KeyHeld:
            return InsertOutcome.KEY_EXISTS
        return InsertOutcome.INSERTED

    async def create_org(self, org_id: UUID, org: Org, outbox_rows: tuple[OutboxRow, ...]) -> InsertOutcome:
        return await self._insert(Orgs, org, outbox_rows, org_id=org_id)

    async def read_org(self, org_id: UUID) -> Org | None:
        return await self._read_one(select(Orgs).where(Orgs.id == org_id), Org, org_id=org_id)

    async def write_org(self, org_id: UUID, org: Org, outbox_rows: tuple[OutboxRow, ...]) -> None:
        if org.id != org_id:
            raise ValueError("an org is written under its own id")
        await self._upsert(Orgs, org, outbox_rows, org_id=org_id)

    async def read_orgs(self, limit: int) -> list[Org]:
        """Tenant-less: the global list of live tenants, for the operator plane."""
        stmt = select(Orgs).where(Orgs.deleted_at.is_(None)).order_by(Orgs.id).limit(limit)
        return await self._read_all(stmt, Org)

    async def read_live_org_ids(self, after: UUID | None, limit: int) -> list[UUID]:
        """Tenant-less: a page of live tenant ids after `after`, for the sweeps' service contexts."""
        stmt = select(Orgs.id).where(Orgs.deleted_at.is_(None))
        if after is not None:
            stmt = stmt.where(Orgs.id > after)
        stmt = stmt.order_by(Orgs.id).limit(limit)
        async with self._session_for(stmt) as session:
            return list((await session.execute(stmt)).scalars())

    async def read_size(self) -> TenancySize:
        """Tenant-less: the operator plane's count of live tenants and users, across tenants, in the system scope."""
        tenants = select(func.count()).select_from(Orgs).where(Orgs.deleted_at.is_(None), Orgs.provisioned_by.is_(None))
        provisioned = select(Orgs.id).where(Orgs.provisioned_by.is_not(None)).scalar_subquery()
        users = select(func.count()).select_from(Users).where(Users.org_id.not_in(provisioned))
        async with self._session_for(users, org_id=EMPTY_UUID) as session:
            user_count = int((await session.execute(users)).scalar_one())
            tenant_count = int((await session.execute(tenants)).scalar_one())
        return TenancySize(tenants=tenant_count, users=user_count)

    async def read_provisioned_org_ids(self, limit: int) -> list[UUID]:
        """Tenant-less: the live tenants an operator provisioned, which the operator plane's counts leave out."""
        stmt = (
            select(Orgs.id)
            .where(Orgs.deleted_at.is_(None), Orgs.provisioned_by.is_not(None))
            .order_by(Orgs.id)
            .limit(limit)
        )
        async with self._session_for(stmt) as session:
            return list((await session.execute(stmt)).scalars())

    # --- identities

    async def create_identity(self, identity_id: UUID, identity: Identity) -> InsertOutcome:
        return await self._insert(Identities, identity, identity_id=identity_id)

    async def read_identity(self, identity_id: UUID) -> Identity | None:
        stmt = select(Identities).where(Identities.identity_id == identity_id, Identities.id == identity_id)
        return await self._read_one(stmt, Identity, identity_id=identity_id)

    async def write_identity(self, identity_id: UUID, identity: Identity) -> None:
        if identity.id != identity_id:
            raise ValueError("an identity is written under its own id")
        await self._upsert(Identities, identity, identity_id=identity_id)

    async def read_identity_by_email_digest(self, email_digest: str) -> Identity | None:
        """Tenant-less: the sign-in lookup, before an identity is known, in the system scope."""
        stmt = select(Identities).where(Identities.email_digest == email_digest)
        return await self._read_one(stmt, Identity, org_id=EMPTY_UUID)

    async def read_identity_by_issuer_subject(self, issuer: str, subject: str) -> Identity | None:
        """Tenant-less: the external provider's find-or-create lookup, before an identity is known."""
        stmt = select(Identities).where(Identities.issuer == issuer, Identities.subject == subject)
        return await self._read_one(stmt, Identity, org_id=EMPTY_UUID)

    async def read_identity_memberships(self, identity_id: UUID, limit: int) -> list[IdentityMembership]:
        stmt = (
            select(IdentityMemberships)
            .where(IdentityMemberships.identity_id == identity_id)
            .order_by(IdentityMemberships.tenant_id)
            .limit(limit)
        )
        return await self._read_all(stmt, IdentityMembership, identity_id=identity_id)

    # --- users and memberships

    async def create_member(
        self, org_id: UUID, identity_id: UUID, user: User, membership: Membership, outbox_rows: tuple[OutboxRow, ...]
    ) -> InsertOutcome:
        """Named atomic: the user, the membership, and the identity's copy of it; KEY_EXISTS when already a member."""
        try:
            async with self._session_for(Users, org_id=org_id, identity_id=identity_id) as session:
                for stmt in (
                    pg_insert(Users).values(**to_values(user, Users, org_id=org_id)),
                    pg_insert(Memberships).values(**to_values(membership, Memberships, org_id=org_id)),
                    pg_insert(IdentityMemberships).values(**_mirror(identity_id, org_id, membership)),
                ):
                    if (await session.execute(stmt.on_conflict_do_nothing().returning(literal(1)))).first() is None:
                        raise _KeyHeld
                await self._land(session, outbox_rows)
        except _KeyHeld:
            return InsertOutcome.KEY_EXISTS
        return InsertOutcome.INSERTED

    async def read_user(self, org_id: UUID, user_id: UUID) -> User | None:
        stmt = select(Users).where(Users.org_id == org_id, Users.id == user_id)
        return await self._read_one(stmt, User, org_id=org_id)

    async def read_user_by_identity(self, org_id: UUID, identity_id: UUID) -> User | None:
        stmt = select(Users).where(Users.org_id == org_id, Users.identity_id == identity_id)
        return await self._read_one(stmt, User, org_id=org_id)

    async def read_users(self, org_id: UUID, limit: int) -> list[User]:
        stmt = select(Users).where(Users.org_id == org_id).order_by(Users.id).limit(limit)
        return await self._read_all(stmt, User, org_id=org_id)

    async def write_user(self, org_id: UUID, user: User, outbox_rows: tuple[OutboxRow, ...]) -> None:
        await self._upsert(Users, user, outbox_rows, org_id=org_id)

    async def read_membership(self, org_id: UUID, user_id: UUID) -> Membership | None:
        stmt = select(Memberships).where(Memberships.org_id == org_id, Memberships.user_id == user_id)
        return await self._read_one(stmt, Membership, org_id=org_id)

    async def read_memberships(self, org_id: UUID, limit: int) -> list[Membership]:
        stmt = select(Memberships).where(Memberships.org_id == org_id).order_by(Memberships.id).limit(limit)
        return await self._read_all(stmt, Membership, org_id=org_id)

    async def write_membership(
        self, org_id: UUID, identity_id: UUID, membership: Membership, outbox_rows: tuple[OutboxRow, ...]
    ) -> None:
        """Named atomic: the membership and the identity's copy of it together."""
        stmt = (
            update(Memberships)
            .where(Memberships.org_id == org_id, Memberships.id == membership.id)
            .values(role=membership.role.value, updated_at=membership.updated_at, updated_by=membership.updated_by)
            .returning(Memberships.id)
        )
        mirror = (
            update(IdentityMemberships)
            .where(IdentityMemberships.identity_id == identity_id, IdentityMemberships.tenant_id == org_id)
            .values(role=membership.role.value)
        )
        async with self._session_for(stmt, org_id=org_id, identity_id=identity_id) as session:
            if (await session.execute(stmt)).first() is None:
                return
            await session.execute(mirror)
            await self._land(session, outbox_rows)

    async def remove_membership(
        self, org_id: UUID, user_id: UUID, identity_id: UUID, ended_at: datetime, outbox_rows: tuple[OutboxRow, ...]
    ) -> list[UUID]:
        """Named atomic: deletes the membership and its copy, revokes every key the member issued in the tenant,
        and ends the member's sessions there; returns the ended sessions' ids, empty when not a member."""
        gone = (
            delete(Memberships)
            .where(Memberships.org_id == org_id, Memberships.user_id == user_id)
            .returning(Memberships.id)
        )
        async with self._session_for(gone, org_id=org_id, identity_id=identity_id) as session:
            if (await session.execute(gone)).first() is None:
                return []
            await session.execute(
                delete(IdentityMemberships).where(
                    IdentityMemberships.identity_id == identity_id, IdentityMemberships.tenant_id == org_id
                )
            )
            await session.execute(
                update(ApiKeys)
                .where(ApiKeys.org_id == org_id, ApiKeys.issued_by == user_id, ApiKeys.revoked_at.is_(None))
                .values(revoked_at=ended_at)
            )
            ended = await session.execute(
                update(Sessions)
                .where(
                    Sessions.identity_id == identity_id,
                    Sessions.tenant_id == org_id,
                    Sessions.kind == SessionKind.TENANT.value,
                    Sessions.ended_at.is_(None),
                )
                .values(ended_at=ended_at)
                .returning(Sessions.id)
            )
            ended_ids = list(ended.scalars())
            await self._land(session, outbox_rows)
            return ended_ids

    # --- sessions

    async def create_session(self, identity_id: UUID, session: Session) -> bool:
        return await self._insert(Sessions, session, identity_id=identity_id) == InsertOutcome.INSERTED

    async def exchange_session(self, identity_id: UUID, ended_id: UUID, session: Session, ended_at: datetime) -> bool:
        """Named atomic: ends the presented session and creates its successor; False when it had already ended."""
        end = (
            update(Sessions)
            .where(Sessions.identity_id == identity_id, Sessions.id == ended_id, Sessions.ended_at.is_(None))
            .values(ended_at=ended_at)
            .returning(Sessions.id)
        )
        async with self._session_for(end, identity_id=identity_id) as db:
            if (await db.execute(end)).first() is None:
                return False
            await db.execute(insert(Sessions).values(**to_values(session, Sessions, identity_id=identity_id)))
        return True

    async def read_session(self, identity_id: UUID, session_id: UUID) -> Session | None:
        stmt = select(Sessions).where(Sessions.identity_id == identity_id, Sessions.id == session_id)
        return await self._read_one(stmt, Session, identity_id=identity_id)

    async def read_session_by_digest(self, digest: str) -> Session | None:
        """Tenant-less: the lookup of a presented session or operator token by its digest, in the system scope."""
        return await self._read_one(select(Sessions).where(Sessions.digest == digest), Session, org_id=EMPTY_UUID)

    async def touch_session(self, identity_id: UUID, session_id: UUID, seen_at: datetime) -> bool:
        stmt = (
            update(Sessions)
            .where(Sessions.identity_id == identity_id, Sessions.id == session_id, Sessions.ended_at.is_(None))
            .values(last_seen_at=seen_at)
            .returning(Sessions.id)
        )
        return await self._returned(stmt, identity_id=identity_id) == 1

    async def end_session(self, identity_id: UUID, session_id: UUID, ended_at: datetime) -> bool:
        stmt = (
            update(Sessions)
            .where(Sessions.identity_id == identity_id, Sessions.id == session_id, Sessions.ended_at.is_(None))
            .values(ended_at=ended_at)
            .returning(Sessions.id)
        )
        return await self._returned(stmt, identity_id=identity_id) == 1

    async def purge_sessions(self, now: datetime, idle_before: datetime, limit: int) -> int:
        """Tenant-less: purges sessions ended, expired, or idle since before `idle_before`, across identities."""
        doomed = (
            select(Sessions.id)
            .where(or_(Sessions.ended_at.is_not(None), Sessions.expires_at < now, Sessions.last_seen_at < idle_before))
            .limit(limit)
        )
        stmt = delete(Sessions).where(Sessions.id.in_(doomed.scalar_subquery())).returning(Sessions.id)
        return await self._returned(stmt, org_id=EMPTY_UUID)

    # --- API keys

    async def create_api_key(self, org_id: UUID, api_key: ApiKey, outbox_rows: tuple[OutboxRow, ...]) -> ApiKeyInsert:
        """Named atomic: lands the key only while its issuer's membership is live, holding that row meanwhile."""
        live = (
            select(Memberships.id)
            .where(Memberships.org_id == org_id, Memberships.user_id == api_key.issued_by)
            .with_for_update(read=True)
        )
        write = (
            pg_insert(ApiKeys)
            .values(**to_values(api_key, ApiKeys, org_id=org_id))
            .on_conflict_do_nothing()
            .returning(ApiKeys.id)
        )
        async with self._session_for(write, org_id=org_id) as session:
            if (await session.execute(live)).first() is None:
                return ApiKeyInsert.NO_MEMBERSHIP
            if (await session.execute(write)).first() is None:
                return ApiKeyInsert.ID_EXISTS
            await self._land(session, outbox_rows)
        return ApiKeyInsert.INSERTED

    async def remint_api_key(
        self, org_id: UUID, key_id: UUID, digest: str, marker_id: UUID, attempt_token: UUID
    ) -> bool:
        """Named atomic: writes the new digest only while the idempotency marker still holds this attempt."""
        held = exists().where(
            IdempotencyMarkers.org_id == org_id,
            IdempotencyMarkers.id == marker_id,
            IdempotencyMarkers.attempt_token == attempt_token,
            IdempotencyMarkers.status.is_(None),
        )
        stmt = (
            update(ApiKeys)
            .where(ApiKeys.org_id == org_id, ApiKeys.id == key_id, ApiKeys.revoked_at.is_(None), held)
            .values(digest=digest)
            .returning(ApiKeys.id)
        )
        return await self._returned(stmt, org_id=org_id) == 1

    async def read_api_key(self, org_id: UUID, key_id: UUID) -> ApiKey | None:
        stmt = select(ApiKeys).where(ApiKeys.org_id == org_id, ApiKeys.id == key_id)
        return await self._read_one(stmt, ApiKey, org_id=org_id)

    async def read_api_keys(self, org_id: UUID, limit: int) -> list[ApiKey]:
        stmt = select(ApiKeys).where(ApiKeys.org_id == org_id).order_by(ApiKeys.id).limit(limit)
        return await self._read_all(stmt, ApiKey, org_id=org_id)

    async def read_api_key_by_digest(self, digest: str) -> tuple[UUID, ApiKey] | None:
        """Tenant-less: the lookup of a presented key by its digest; the tenant travels back with the key."""
        stmt = select(ApiKeys).where(ApiKeys.digest == digest)
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            row = (await session.execute(stmt)).scalars().first()
            return None if row is None else (row.org_id, to_model(row, ApiKey))

    async def revoke_api_key(
        self, org_id: UUID, key_id: UUID, revoked_at: datetime, outbox_rows: tuple[OutboxRow, ...]
    ) -> bool:
        stmt = (
            update(ApiKeys)
            .where(ApiKeys.org_id == org_id, ApiKeys.id == key_id, ApiKeys.revoked_at.is_(None))
            .values(revoked_at=revoked_at)
            .returning(ApiKeys.id)
        )
        async with self._session_for(stmt, org_id=org_id) as session:
            if (await session.execute(stmt)).first() is None:
                return False
            await self._land(session, outbox_rows)
        return True

    # --- socket tickets

    async def create_socket_ticket(self, identity_id: UUID, ticket: SocketTicket) -> bool:
        return await self._insert(SocketTickets, ticket, identity_id=identity_id) == InsertOutcome.INSERTED

    async def redeem_socket_ticket(self, digest: str, now: datetime) -> SocketTicket | None:
        """Tenant-less, named atomic: redeems an unexpired ticket once, found by its digest; exactly one caller wins."""
        stmt = (
            update(SocketTickets)
            .where(SocketTickets.digest == digest, SocketTickets.redeemed_at.is_(None), SocketTickets.expires_at > now)
            .values(redeemed_at=now)
            .returning(SocketTickets)
        )
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            row = (await session.execute(stmt)).scalars().first()
            return None if row is None else to_model(row, SocketTicket)

    async def purge_socket_tickets(self, now: datetime, limit: int) -> int:
        """Tenant-less: purges tickets redeemed or past their expiry, across identities, in the system scope."""
        doomed = (
            select(SocketTickets.id)
            .where(or_(SocketTickets.redeemed_at.is_not(None), SocketTickets.expires_at < now))
            .limit(limit)
        )
        stmt = delete(SocketTickets).where(SocketTickets.id.in_(doomed.scalar_subquery())).returning(SocketTickets.id)
        return await self._returned(stmt, org_id=EMPTY_UUID)

    # --- the sign-in delay

    async def read_sign_in_failures(self, email_digest: str) -> SignInThrottle | None:
        """Tenant-less: a system table keyed by the email's digest, read before an identity is known."""
        stmt = select(SignInFailures).where(SignInFailures.email_digest == email_digest)
        return await self._read_one(stmt, SignInThrottle)

    async def record_sign_in_failure(
        self, email_digest: str, row_id: UUID, now: datetime, base_seconds: float, cap_seconds: float
    ) -> SignInThrottle:
        """Tenant-less: counts one failure and moves the retry time, in one statement."""
        # The doubling of rules.sign_in_delay_seconds, spelled once more inside the statement.
        stmt = pg_insert(SignInFailures).values(
            id=row_id,
            created_at=now,
            email_digest=email_digest,
            failures=1,
            retry_at=now + timedelta(seconds=base_seconds),
        )
        stmt = stmt.on_conflict_do_update(
            index_elements=[SignInFailures.email_digest],
            set_={
                "failures": SignInFailures.failures + 1,
                "retry_at": literal(now)
                + func.make_interval(
                    0, 0, 0, 0, 0, 0, func.least(cap_seconds, base_seconds * func.power(2, SignInFailures.failures))
                ),
            },
        ).returning(SignInFailures)
        async with self._session_for(stmt) as session:
            row = (await session.execute(stmt)).scalars().one()
            return to_model(row, SignInThrottle)

    async def clear_sign_in_failures(self, email_digest: str) -> None:
        """Tenant-less: a success resets the delay."""
        stmt = delete(SignInFailures).where(SignInFailures.email_digest == email_digest)
        async with self._session_for(stmt) as session:
            await session.execute(stmt)

    # --- the operator allowlist

    async def read_operator_entry(self, identity_id: UUID) -> OperatorEntry | None:
        """Tenant-less: the allowlist is a system table of the operator plane."""
        return await self._read_one(select(Operators).where(Operators.identity_id == identity_id), OperatorEntry)

    async def write_operator_entry(self, entry: OperatorEntry) -> None:
        """Tenant-less: the allowlist is a system table of the operator plane."""
        await self._upsert(Operators, entry)


def _mirror(identity_id: UUID, org_id: UUID, membership: Membership) -> dict[str, object]:
    return {
        "id": membership.id,
        "identity_id": identity_id,
        "created_at": membership.created_at,
        "tenant_id": org_id,
        "user_id": membership.user_id,
        "role": membership.role.value,
    }
