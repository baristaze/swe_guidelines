"""Flows the manager tests share: a signed-up tenant's context, and an admitted operator's."""

from datetime import timedelta

from conftest import rctx

from acme.om.base import new_id, utcnow
from acme.om.journalists.types.journalist import Journalist
from acme.om.opcontext import OpContext, OperatorContext, OperatorPermission, Role
from acme.om.root import Managers
from acme.om.tenancy.types import IssuedCredential, SignedIn


async def signed_up(m: Managers, email: str = "owner@acme.example", slug: str = "desk") -> SignedIn:
    return await m.tenancy.sign_up(rctx(), email, "pswd_1234", "Owner", "Desk", slug)


async def tenant_ctx(
    m: Managers, email: str = "owner@acme.example", slug: str = "desk"
) -> tuple[OpContext, IssuedCredential]:
    signed = await signed_up(m, email, slug)
    login = await m.tenancy.authenticate_login(rctx(), signed.credential.token)
    session = await m.tenancy.exchange(login, signed.memberships[0].org_id)
    return await m.tenancy.authenticate(rctx(), session.token), session


async def operator_ctx(m: Managers, permission: OperatorPermission) -> OperatorContext:
    email = f"op-{new_id().hex[:8]}@acme.example"
    await m.tenancy.ensure_identity(rctx(), email, "pswd_operator", "Operator")
    await m.tenancy.grant_operator(rctx(), email, permission)
    token = await m.tenancy.grant_operator_token(rctx(), email, None)
    return await m.tenancy.admit_operator(await m.tenancy.authenticate_login(rctx(), token.token))


async def published_journalist(m: Managers, desk: OpContext, *, payouts: bool = True) -> Journalist:
    """A profile the desk published, with a public key, and a payout account unless told otherwise."""
    now = utcnow()
    made = await m.journalists.create_journalist(
        desk,
        Journalist(
            id=new_id(),
            created_at=now,
            updated_at=now,
            created_by=desk.user_id,
            updated_by=desk.user_id,
            display_name="Reporter",
            public_key="cHVibGlj",
            published=True,
        ),
    )
    return await m.journalists.set_payout_account(desk, made.id, "acct_test") if payouts else made


async def viewer_of(m: Managers, owner: OpContext) -> OpContext:
    key = await m.tenancy.create_api_key(owner, new_id(), "viewer", Role.VIEWER, timedelta(days=1), None)
    return await m.tenancy.authenticate(rctx(), key.token)
