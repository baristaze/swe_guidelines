"""Transactional email: follows, journalist updates, support receipts, source replies. Never coupled to a manager's
logic: a notification rides a work item, and its handler sends through this interface."""

from abc import ABC, abstractmethod

from pydantic import BaseModel, ConfigDict


class OutboundEmail(BaseModel):
    model_config = ConfigDict(frozen=True)

    to: str
    subject: str
    text: str
    tag: str  # the kind of notification, for the provider's own stream and a metric label
    idempotency_key: str  # the work item's key, so a retried send is one message


class Delivery(BaseModel):
    model_config = ConfigDict(frozen=True)

    message_id: str
    provenance: str


class EmailInterface(ABC):
    @abstractmethod
    async def send(self, message: OutboundEmail) -> Delivery: ...

    @abstractmethod
    async def start(self) -> None: ...

    @abstractmethod
    async def close(self) -> None: ...

    @abstractmethod
    def describe(self) -> str: ...
