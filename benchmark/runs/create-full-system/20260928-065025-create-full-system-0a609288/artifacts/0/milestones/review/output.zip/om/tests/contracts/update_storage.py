"""Contract cases of the updates storage: the newest first, the profile filter, another desk, the id."""

import asyncio
from uuid import UUID

from acme.om.base import new_id, utcnow
from acme.om.storage.root import StorageInterface
from acme.om.updates.types.update import Update
from contracts import factories as f


def update(journalist_id: UUID | None = None, body: str = "An update") -> Update:
    return Update(id=new_id(), created_at=utcnow(), journalist_id=journalist_id or new_id(), body=body)


async def case_create_then_read_and_list(storage: StorageInterface) -> None:
    s = storage.get_update_storage()
    org_id = new_id()
    u = update()
    r = f.row(org_id, "updates.update.created", u.id)
    assert await s.create_update(org_id, u, (r,)) is True
    assert await s.read_update(org_id, u.id) == u
    assert await s.read_updates(org_id, 10) == [u]
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r


async def case_list_is_the_newest_first_and_filters_by_profile(storage: StorageInterface) -> None:
    s = storage.get_update_storage()
    org_id = new_id()
    journalist = new_id()
    made = [update(journalist, f"n{n}") for n in range(3)]
    elsewhere = update()
    for u in [*made, elsewhere]:
        await s.create_update(org_id, u, ())
    newest = sorted(made, key=lambda u: u.id.int, reverse=True)
    assert await s.read_updates(org_id, 2, journalist) == newest[:2]
    assert await s.read_updates(org_id, 10, journalist) == newest
    assert len(await s.read_updates(org_id, 10)) == 4


async def case_a_second_create_under_the_same_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_update_storage()
    org_id = new_id()
    u = update()
    await s.create_update(org_id, u, ())
    again = f.row(org_id, "updates.update.created", u.id)
    assert await s.create_update(org_id, u.model_copy(update={"body": "Other"}), (again,)) is False
    assert await s.read_update(org_id, u.id) == u
    assert await storage.get_outbox_storage().read_row(org_id, again.id) is None


async def case_list_and_read_under_another_desk_find_nothing(storage: StorageInterface) -> None:
    s = storage.get_update_storage()
    org_id, other = new_id(), new_id()
    u = update()
    await s.create_update(org_id, u, ())
    assert await s.read_updates(other, 10) == []
    assert await s.read_updates(other, 10, u.journalist_id) == []
    assert await s.read_update(other, u.id) is None


async def case_create_under_another_desk_with_a_taken_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_update_storage()
    org_id, other = new_id(), new_id()
    u = update()
    await s.create_update(org_id, u, ())
    r = f.row(other, "updates.update.created", u.id)
    assert await s.create_update(other, u.model_copy(update={"body": "Taken"}), (r,)) is False
    assert await s.read_update(org_id, u.id) == u
    assert await s.read_update(other, u.id) is None
    assert await storage.get_outbox_storage().read_row(other, r.id) is None


async def case_a_create_race_has_one_winner(storage: StorageInterface) -> None:
    s = storage.get_update_storage()
    org_id = new_id()
    u = update()
    results = await asyncio.gather(s.create_update(org_id, u, ()), s.create_update(org_id, u, ()))
    assert sorted(results) == [False, True]
    assert await s.read_updates(org_id, 10) == [u]


CASES = [
    case_create_then_read_and_list,
    case_list_is_the_newest_first_and_filters_by_profile,
    case_a_second_create_under_the_same_id_changes_nothing,
    case_list_and_read_under_another_desk_find_nothing,
    case_create_under_another_desk_with_a_taken_id_changes_nothing,
    case_a_create_race_has_one_winner,
]
