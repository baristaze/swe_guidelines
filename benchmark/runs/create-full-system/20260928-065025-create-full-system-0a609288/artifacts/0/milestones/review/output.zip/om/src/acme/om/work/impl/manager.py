"""The work manager impl. Every write after the enqueue is the platform's and signs `updated_by` with EMPTY_UUID:
the context is the attribution of the work, never of the bookkeeping on its row."""

import logging
from dataclasses import dataclass
from datetime import timedelta
from uuid import UUID

from prometheus_client import Counter

from acme.infra.topics import Topics, TopicsInterface, WorkAvailablePayload
from acme.om.audit.manager import AuditManagerInterface
from acme.om.base import EMPTY_UUID, new_id, utcnow
from acme.om.exceptions import Conflict, NotFound
from acme.om.opcontext import OpContext, Permission, RequestContext
from acme.om.outbox.types import WORK_KIND_PREFIX, OutboxRow
from acme.om.storage.root import InsertOutcome
from acme.om.tenancy.manager import TenancyManagerInterface
from acme.om.work import rules
from acme.om.work.manager import WorkManagerInterface
from acme.om.work.storage import WorkStorageInterface
from acme.om.work.types.work_item import WorkGauges, WorkItem, WorkKind, WorkStatus

logger = logging.getLogger(__name__)

DEAD_LETTERS = Counter("acme_work_dead_letters_total", "Work items failed for good, by kind", ["kind"])
ORPHANS = Counter("acme_work_orphans_total", "Work items failed because their tenant is gone", ["kind"])


@dataclass(frozen=True)
class WorkOptions:
    item_retention: timedelta
    retry_base: timedelta
    retry_cap: timedelta
    purge_batch: int
    sweep_batch: int


class WorkManagerImpl(WorkManagerInterface):
    def __init__(
        self,
        storage: WorkStorageInterface,
        tenancy: TenancyManagerInterface,
        audit: AuditManagerInterface,
        topics: TopicsInterface,
        options: WorkOptions,
    ) -> None:
        self._storage = storage
        self._tenancy = tenancy
        self._audit = audit
        self._topics = topics
        self._options = options

    async def _announce(self, org_id: UUID, item: WorkItem) -> None:
        # A wake-up and nothing more: a worker also polls, so a dropped wake delays the item by one poll at most.
        await self._topics.publish(
            Topics.WORK_AVAILABLE,
            WorkAvailablePayload(
                idempotency_key=new_id(), produced_at=utcnow(), org_id=org_id, kind=item.kind.value, lane=item.lane
            ),
        )

    async def _create(self, org_id: UUID, item: WorkItem) -> WorkItem:
        outcome = await self._storage.create_item(org_id, item)
        if outcome == InsertOutcome.INSERTED:
            await self._announce(org_id, item)
            return item
        stored = (
            await self._storage.read_item(org_id, item.id)
            if outcome == InsertOutcome.ID_EXISTS
            else await self._storage.read_item_by_key(org_id, item.idempotency_key)
        )
        if stored is None:
            raise Conflict("that work item's id or key is held")
        return stored  # the item was announced when it landed

    def _queued(self, item: WorkItem, actor: UUID) -> WorkItem:
        """The manager's copy on enqueue: the actor, the status, the attempts, no claim; id and times as constructed."""
        return item.model_copy(
            update={
                "created_by": actor,
                "updated_by": actor,
                "status": WorkStatus.QUEUED,
                "claimed_by": None,
                "claim_token": None,
                "lease_expires_at": None,
                "attempts": 0,
                "last_error": None,
            }
        )

    async def enqueue(self, ctx: OpContext, item: WorkItem) -> WorkItem:
        ctx.require(Permission.WRITE)
        return await self._create(ctx.org_id, self._queued(item, ctx.user_id))

    async def enqueue_relayed(self, org_id: UUID, row: OutboxRow) -> WorkItem:
        payload = dict(row.payload)
        lane = str(payload.pop("lane", "default"))
        now = utcnow()
        item = WorkItem(
            id=row.id,  # the row's own id, the same on every run of the relay
            created_at=now,
            updated_at=now,
            created_by=row.actor_id,
            updated_by=row.actor_id,
            kind=WorkKind(row.kind.removeprefix(WORK_KIND_PREFIX).upper()),
            target_id=row.target_id,
            idempotency_key=row.id,
            request_id=row.request_id,
            traceparent=row.traceparent,
            payload=payload,
            lane=lane,
            available_at=now,
        )
        return await self._create(org_id, self._queued(item, row.actor_id))

    async def claim(
        self, rctx: RequestContext, lane: str, kinds: tuple[WorkKind, ...], worker_id: str, lease: timedelta
    ) -> tuple[OpContext, WorkItem] | None:
        while True:
            now = utcnow()
            claimed = await self._storage.claim_next(lane, kinds, worker_id, new_id(), now + lease, now)
            if claimed is None:
                return None
            org_id, item = claimed
            try:
                ctx = await self._tenancy.claim_context(rctx, org_id, item.created_by, item.request_id)
            except NotFound:
                # The tenant is gone: no stage exists for the item, so it is failed, never run, and counted.
                if item.claim_token is not None:
                    await self._storage.fail_orphaned(item.id, item.claim_token, "the tenant is gone", now)
                ORPHANS.labels(item.kind.value).inc()
                continue
            return ctx, item

    async def _write(self, ctx: OpContext, item: WorkItem, changes: dict[str, object]) -> WorkItem:
        """A holder's write: from the stored row, conditional on the holder's claim token in the statement."""
        if item.claim_token is None:
            raise Conflict("the item holds no claim")
        current = await self._storage.read_item(ctx.org_id, item.id)
        if current is None:
            raise NotFound("no such work item")
        updated = WorkItem.model_validate(
            {**current.model_dump(), **changes, "updated_at": utcnow(), "updated_by": EMPTY_UUID}
        )
        if not await self._storage.write_item(ctx.org_id, updated, item.claim_token):
            raise Conflict("another worker holds the item now")
        return updated

    async def complete(self, ctx: OpContext, item: WorkItem) -> WorkItem:
        ctx.require(Permission.WRITE)
        return await self._write(ctx, item, {"status": WorkStatus.DONE, "claim_token": None, "lease_expires_at": None})

    async def fail(self, ctx: OpContext, item: WorkItem, error: str) -> WorkItem:
        ctx.require(Permission.WRITE)
        attempts = item.attempts + 1
        if rules.is_exhausted(attempts, item.max_attempts):
            failed = await self._write(
                ctx,
                item,
                {
                    "status": WorkStatus.FAILED,
                    "attempts": attempts,
                    "last_error": error[:500],
                    "claim_token": None,
                    "lease_expires_at": None,
                },
            )
            DEAD_LETTERS.labels(item.kind.value).inc()
            await self._audit.record(ctx, "work.dead_letter", item.id, {"kind": item.kind.value, "attempts": attempts})
            return failed
        delay = rules.retry_delay(attempts, self._options.retry_base, self._options.retry_cap)
        return await self._write(
            ctx,
            item,
            {
                "status": WorkStatus.QUEUED,
                "attempts": attempts,
                "last_error": error[:500],
                "available_at": utcnow() + delay,
                "claim_token": None,
                "claimed_by": None,
                "lease_expires_at": None,
            },
        )

    async def defer(self, ctx: OpContext, item: WorkItem, delay: timedelta) -> WorkItem:
        ctx.require(Permission.WRITE)
        return await self._write(
            ctx,
            item,
            {
                "status": WorkStatus.QUEUED,
                "available_at": utcnow() + delay,
                "claim_token": None,
                "claimed_by": None,
                "lease_expires_at": None,
            },
        )

    async def release(self, ctx: OpContext, item: WorkItem, note: str) -> WorkItem:
        ctx.require(Permission.WRITE)
        return await self._write(
            ctx,
            item,
            {
                "status": WorkStatus.QUEUED,
                "available_at": utcnow(),
                "last_error": note[:500],
                "claim_token": None,
                "claimed_by": None,
                "lease_expires_at": None,
            },
        )

    async def extend_lease(self, ctx: OpContext, item: WorkItem, lease: timedelta) -> WorkItem:
        ctx.require(Permission.WRITE)
        return await self._write(ctx, item, {"lease_expires_at": utcnow() + lease})

    async def requeue_stale(self, ctx: OpContext) -> int:
        ctx.require(Permission.WRITE)
        now = utcnow()
        return await self._storage.requeue_stale(ctx.org_id, rules.stale_before(now), self._options.sweep_batch, now)

    async def purge_items(self, rctx: RequestContext) -> int:
        return await self._storage.purge_items(utcnow() - self._options.item_retention, self._options.purge_batch)

    async def read_gauges(self, rctx: RequestContext) -> WorkGauges:
        return await self._storage.read_gauges()

    async def maintenance_contexts(self, rctx: RequestContext) -> list[OpContext]:
        contexts: list[OpContext] = []
        after: UUID | None = None
        while True:
            page = await self._tenancy.service_contexts(rctx, after, self._options.sweep_batch)
            contexts.extend(page)
            if len(page) < self._options.sweep_batch:
                return contexts
            after = page[-1].org_id
