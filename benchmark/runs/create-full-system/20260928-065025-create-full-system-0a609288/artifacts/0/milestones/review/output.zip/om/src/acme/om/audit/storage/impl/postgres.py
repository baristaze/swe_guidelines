"""The audit stream over Postgres."""

from uuid import UUID

from sqlalchemy import select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.exc import IntegrityError

from acme.om.audit.storage import AuditStorageInterface
from acme.om.audit.storage.tables.audit_entries import AuditCursors, AuditEntries
from acme.om.audit.types import AuditEntry
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.utils.translation import to_model, to_values


class AuditStoragePostgresImpl(PgStorageBase, AuditStorageInterface):
    async def _read_by_id(self, org_id: UUID, entry_id: UUID) -> AuditEntry | None:
        stmt = select(AuditEntries).where(AuditEntries.org_id == org_id, AuditEntries.id == entry_id)
        async with self._session_for(stmt, org_id=org_id) as session:
            row = (await session.execute(stmt)).scalar_one_or_none()
            return None if row is None else to_model(row, AuditEntry)

    async def append_audit_entry(self, org_id: UUID, entry: AuditEntry) -> AuditEntry:
        """Named atomic: assigns `seq` from the tenant's audit cursor; an id already written returns it."""
        existing = await self._read_by_id(org_id, entry.id)
        if existing is not None:
            return existing
        seed = pg_insert(AuditCursors).values(id=org_id, org_id=org_id, head=0).on_conflict_do_nothing()
        bump = (
            update(AuditCursors)
            .where(AuditCursors.org_id == org_id)
            .values(head=AuditCursors.head + 1)
            .returning(AuditCursors.head)
        )
        try:
            async with self._session_for(bump, org_id=org_id) as session:
                await session.execute(seed)
                seq = (await session.execute(bump)).scalar_one()
                stored = entry.model_copy(update={"seq": seq})
                await session.execute(pg_insert(AuditEntries).values(**to_values(stored, AuditEntries, org_id=org_id)))
        except IntegrityError:
            again = await self._read_by_id(org_id, entry.id)
            if again is None:
                raise
            return again
        return stored

    async def read_after(self, org_id: UUID, after_seq: int, limit: int) -> list[AuditEntry]:
        stmt = (
            select(AuditEntries)
            .where(AuditEntries.org_id == org_id, AuditEntries.seq > after_seq)
            .order_by(AuditEntries.seq)
            .limit(limit)
        )
        async with self._session_for(stmt, org_id=org_id) as session:
            return [to_model(r, AuditEntry) for r in (await session.execute(stmt)).scalars()]
