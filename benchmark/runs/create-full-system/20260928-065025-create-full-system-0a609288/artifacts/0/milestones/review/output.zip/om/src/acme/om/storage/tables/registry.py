"""Imports every table module, so the metadata the migration check compares is whole."""

import importlib

TABLE_MODULES = (
    "acme.om.tenancy.storage.tables.tenancy",
    "acme.om.outbox.storage.tables.outbox",
    "acme.om.idempotency.storage.tables.idempotency_markers",
    "acme.om.events.storage.tables.events",
    "acme.om.audit.storage.tables.audit_entries",
    "acme.om.work.storage.tables.work_items",
    "acme.om.journalists.storage.tables.journalists",
    "acme.om.follows.storage.tables.follows",
    "acme.om.updates.storage.tables.updates",
    "acme.om.support.storage.tables.pledges",
    "acme.om.support.storage.tables.contributions",
    "acme.om.reports.storage.tables.sealed_reports",
    "acme.om.reports.storage.tables.submissions",
    "acme.om.reports.storage.tables.messages",
)


def import_all_tables() -> None:
    for module in TABLE_MODULES:
        importlib.import_module(module)
