"""Every contract case, for the two suites that run them."""

from contracts import idempotency_cases, stream_cases, tenancy_cases, work_cases

ALL_CASES = [*tenancy_cases.CASES, *idempotency_cases.CASES, *stream_cases.CASES, *work_cases.CASES]
