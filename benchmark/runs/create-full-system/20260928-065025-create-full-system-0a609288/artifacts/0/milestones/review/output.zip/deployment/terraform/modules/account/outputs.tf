output "state_bucket" {
  description = "The state bucket (TF_STATE_BUCKET)."
  value       = aws_s3_bucket.state.id
}

output "artifacts_bucket" {
  description = "The artifacts bucket (ARTIFACTS_BUCKET)."
  value       = aws_s3_bucket.artifacts.id
}

output "trail_bucket" {
  description = "The bucket the account's trail writes to."
  value       = aws_s3_bucket.trail.id
}

output "ecr_repository_urls" {
  description = "Image repository URLs by name."
  value       = { for k, r in aws_ecr_repository.this : k => r.repository_url }
}

output "ecr_registry" {
  description = "The registry host."
  value       = "${var.account_id}.dkr.ecr.${var.region}.amazonaws.com"
}

output "pipeline_role_arns" {
  description = "The pipeline roles by verb (build, deploy, plan)."
  value       = { for k, r in aws_iam_role.pipeline : k => r.arn }
}

output "investigate_role_arn" {
  description = "The investigate role the acme-<env>-investigate profile chains to."
  value       = aws_iam_role.investigate.arn
}

output "permissions_boundary_arn" {
  description = "The boundary every role a pipeline role creates must carry."
  value       = aws_iam_policy.boundary.arn
}

output "zone_name_servers" {
  description = "Each public name's zone name servers, for the NS delegation at the domain's DNS host."
  value       = { for k, z in aws_route53_zone.public : k => z.name_servers }
}

output "zone_ids" {
  description = "Each public name's hosted zone id."
  value       = { for k, z in aws_route53_zone.public : k => z.zone_id }
}
