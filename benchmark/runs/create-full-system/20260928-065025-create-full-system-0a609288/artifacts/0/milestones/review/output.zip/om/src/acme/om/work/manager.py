"""The work manager: enqueue, claim, and the transitions a holder takes, each fenced by the claim token."""

from abc import ABC, abstractmethod
from datetime import timedelta
from uuid import UUID

from acme.om.opcontext import OpContext, RequestContext
from acme.om.outbox.types import OutboxRow
from acme.om.work.types.work_item import WorkGauges, WorkItem, WorkKind


class WorkManagerInterface(ABC):
    @abstractmethod
    async def enqueue(self, ctx: OpContext, item: WorkItem) -> WorkItem:
        """A work item that follows no core write: a direct create under a context, which stamps the actor."""
        ...

    @abstractmethod
    async def enqueue_relayed(self, org_id: UUID, row: OutboxRow) -> WorkItem:
        """A handoff by tenant id, the outbox relay's: the item a core write asked for, under the row's own id."""
        ...

    @abstractmethod
    async def claim(
        self, rctx: RequestContext, lane: str, kinds: tuple[WorkKind, ...], worker_id: str, lease: timedelta
    ) -> tuple[OpContext, WorkItem] | None:
        """A transition's caller: the oldest available item, and the context the work runs under."""
        ...

    @abstractmethod
    async def complete(self, ctx: OpContext, item: WorkItem) -> WorkItem: ...

    @abstractmethod
    async def fail(self, ctx: OpContext, item: WorkItem, error: str) -> WorkItem:
        """Requeues with a growing delay, or, at max_attempts, fails for good: a dead letter, audited and counted."""
        ...

    @abstractmethod
    async def defer(self, ctx: OpContext, item: WorkItem, delay: timedelta) -> WorkItem: ...

    @abstractmethod
    async def release(self, ctx: OpContext, item: WorkItem, note: str) -> WorkItem: ...

    @abstractmethod
    async def extend_lease(self, ctx: OpContext, item: WorkItem, lease: timedelta) -> WorkItem: ...

    @abstractmethod
    async def requeue_stale(self, ctx: OpContext) -> int: ...

    @abstractmethod
    async def purge_items(self, rctx: RequestContext) -> int:
        """Bookkeeping with no principal: done and failed items past the retention."""
        ...

    @abstractmethod
    async def read_gauges(self, rctx: RequestContext) -> WorkGauges: ...

    @abstractmethod
    async def maintenance_contexts(self, rctx: RequestContext) -> list[OpContext]:
        """One service context per live tenant, for the sweep steps that act inside tenants."""
        ...
