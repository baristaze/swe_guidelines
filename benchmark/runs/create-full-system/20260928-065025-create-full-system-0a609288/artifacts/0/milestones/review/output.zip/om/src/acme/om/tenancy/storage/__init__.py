"""The tenancy storage.

Tenant tables take `org_id` first; identity tables take `identity_id` in its place; the system tables
(`orgs`, `sign_in_failures`, `operators`) hold no tenant's rows. The lookups before an identity is known,
the global reads, and the sweeps' purges take no tenant, each documented where it is declared.
"""

from abc import ABC, abstractmethod
from datetime import datetime
from uuid import UUID

from acme.om.outbox.types import OutboxRow
from acme.om.storage.root import InsertOutcome
from acme.om.tenancy.types import (
    ApiKey,
    ApiKeyInsert,
    Identity,
    IdentityMembership,
    Membership,
    OperatorEntry,
    Org,
    Session,
    SignInThrottle,
    SocketTicket,
    TenancySize,
    User,
)


class TenancyStorageInterface(ABC):
    # --- orgs: the global list of tenants

    @abstractmethod
    async def create_signup(
        self,
        org_id: UUID,
        org: Org,
        identity: Identity,
        user: User,
        membership: Membership,
        outbox_rows: tuple[OutboxRow, ...],
    ) -> InsertOutcome:
        """Named atomic: the identity, its first org, the owner's user and membership, in one transaction.
        KEY_EXISTS when the email or the slug is held; nothing is written then."""
        ...

    @abstractmethod
    async def create_org(self, org_id: UUID, org: Org, outbox_rows: tuple[OutboxRow, ...]) -> InsertOutcome: ...

    @abstractmethod
    async def read_org(self, org_id: UUID) -> Org | None: ...

    @abstractmethod
    async def write_org(self, org_id: UUID, org: Org, outbox_rows: tuple[OutboxRow, ...]) -> None: ...

    @abstractmethod
    async def read_orgs(self, limit: int) -> list[Org]:
        """Tenant-less: the global list of live tenants, for the operator plane."""
        ...

    @abstractmethod
    async def read_live_org_ids(self, after: UUID | None, limit: int) -> list[UUID]:
        """Tenant-less: a page of live tenant ids after `after`, for the sweeps' service contexts."""
        ...

    @abstractmethod
    async def read_size(self) -> TenancySize:
        """Tenant-less: the operator plane's count of live tenants and users, across tenants, in the system scope,
        leaving out the tenants an operator provisioned (a traffic run's) and their users."""
        ...

    @abstractmethod
    async def read_provisioned_org_ids(self, limit: int) -> list[UUID]:
        """Tenant-less: the live tenants an operator provisioned, which the operator plane's counts leave out."""
        ...

    # --- identities

    @abstractmethod
    async def create_identity(self, identity_id: UUID, identity: Identity) -> InsertOutcome:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def read_identity(self, identity_id: UUID) -> Identity | None:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def write_identity(self, identity_id: UUID, identity: Identity) -> None:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def read_identity_by_email_digest(self, email_digest: str) -> Identity | None:
        """Tenant-less: the sign-in lookup, before an identity is known, in the system scope."""
        ...

    @abstractmethod
    async def read_identity_by_issuer_subject(self, issuer: str, subject: str) -> Identity | None:
        """Tenant-less: the external provider's find-or-create lookup, before an identity is known."""
        ...

    @abstractmethod
    async def read_identity_memberships(self, identity_id: UUID, limit: int) -> list[IdentityMembership]:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    # --- users and memberships

    @abstractmethod
    async def create_member(
        self, org_id: UUID, identity_id: UUID, user: User, membership: Membership, outbox_rows: tuple[OutboxRow, ...]
    ) -> InsertOutcome:
        """Named atomic: the user, the membership, and the identity's copy of it; KEY_EXISTS when already a member."""
        ...

    @abstractmethod
    async def read_user(self, org_id: UUID, user_id: UUID) -> User | None: ...

    @abstractmethod
    async def read_user_by_identity(self, org_id: UUID, identity_id: UUID) -> User | None: ...

    @abstractmethod
    async def read_users(self, org_id: UUID, limit: int) -> list[User]: ...

    @abstractmethod
    async def write_user(self, org_id: UUID, user: User, outbox_rows: tuple[OutboxRow, ...]) -> None: ...

    @abstractmethod
    async def read_membership(self, org_id: UUID, user_id: UUID) -> Membership | None: ...

    @abstractmethod
    async def read_memberships(self, org_id: UUID, limit: int) -> list[Membership]: ...

    @abstractmethod
    async def write_membership(
        self, org_id: UUID, identity_id: UUID, membership: Membership, outbox_rows: tuple[OutboxRow, ...]
    ) -> None:
        """Named atomic: the membership and the identity's copy of it together."""
        ...

    @abstractmethod
    async def remove_membership(
        self, org_id: UUID, user_id: UUID, identity_id: UUID, ended_at: datetime, outbox_rows: tuple[OutboxRow, ...]
    ) -> list[UUID]:
        """Named atomic: deletes the membership and its copy, revokes every key the member issued in the tenant,
        and ends the member's sessions there; returns the ended sessions' ids, empty when not a member."""
        ...

    # --- sessions: sign-ins, tenant sessions, operator tokens

    @abstractmethod
    async def create_session(self, identity_id: UUID, session: Session) -> bool:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def exchange_session(self, identity_id: UUID, ended_id: UUID, session: Session, ended_at: datetime) -> bool:
        """Identity-scoped, named atomic: ends the presented session and creates its successor under the identity;
        False when it had already ended."""
        ...

    @abstractmethod
    async def read_session(self, identity_id: UUID, session_id: UUID) -> Session | None:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def read_session_by_digest(self, digest: str) -> Session | None:
        """Tenant-less: the lookup of a presented session or operator token by its digest, in the system scope."""
        ...

    @abstractmethod
    async def touch_session(self, identity_id: UUID, session_id: UUID, seen_at: datetime) -> bool:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def end_session(self, identity_id: UUID, session_id: UUID, ended_at: datetime) -> bool:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def purge_sessions(self, now: datetime, idle_before: datetime, limit: int) -> int:
        """Tenant-less: purges sessions ended, expired, or idle since before `idle_before`, across identities."""
        ...

    # --- API keys

    @abstractmethod
    async def create_api_key(self, org_id: UUID, api_key: ApiKey, outbox_rows: tuple[OutboxRow, ...]) -> ApiKeyInsert:
        """Named atomic: lands the key only while its issuer's membership is live, holding that row meanwhile."""
        ...

    @abstractmethod
    async def remint_api_key(
        self, org_id: UUID, key_id: UUID, digest: str, marker_id: UUID, attempt_token: UUID
    ) -> bool:
        """Named atomic: writes the new digest only while the idempotency marker still holds this attempt."""
        ...

    @abstractmethod
    async def read_api_key(self, org_id: UUID, key_id: UUID) -> ApiKey | None: ...

    @abstractmethod
    async def read_api_keys(self, org_id: UUID, limit: int) -> list[ApiKey]: ...

    @abstractmethod
    async def read_api_key_by_digest(self, digest: str) -> tuple[UUID, ApiKey] | None:
        """Tenant-less: the lookup of a presented key by its digest; the tenant travels back with the key."""
        ...

    @abstractmethod
    async def revoke_api_key(
        self, org_id: UUID, key_id: UUID, revoked_at: datetime, outbox_rows: tuple[OutboxRow, ...]
    ) -> bool: ...

    # --- socket tickets

    @abstractmethod
    async def create_socket_ticket(self, identity_id: UUID, ticket: SocketTicket) -> bool:
        """Identity-scoped: takes identity_id in place of org_id; the table's policy rests on identity_id."""
        ...

    @abstractmethod
    async def redeem_socket_ticket(self, digest: str, now: datetime) -> SocketTicket | None:
        """Tenant-less, named atomic: redeems an unexpired ticket once, found by its digest; exactly one caller wins."""
        ...

    @abstractmethod
    async def purge_socket_tickets(self, now: datetime, limit: int) -> int:
        """Tenant-less: purges tickets redeemed or past their expiry, across identities, in the system scope."""
        ...

    # --- the sign-in delay, per email digest

    @abstractmethod
    async def read_sign_in_failures(self, email_digest: str) -> SignInThrottle | None:
        """Tenant-less: a system table keyed by the email's digest, read before an identity is known."""
        ...

    @abstractmethod
    async def record_sign_in_failure(
        self, email_digest: str, row_id: UUID, now: datetime, base_seconds: float, cap_seconds: float
    ) -> SignInThrottle:
        """Tenant-less: counts one failure and moves the retry time, in one statement."""
        ...

    @abstractmethod
    async def clear_sign_in_failures(self, email_digest: str) -> None:
        """Tenant-less: a success resets the delay."""
        ...

    # --- the operator allowlist

    @abstractmethod
    async def read_operator_entry(self, identity_id: UUID) -> OperatorEntry | None:
        """Tenant-less: the allowlist is a system table of the operator plane."""
        ...

    @abstractmethod
    async def write_operator_entry(self, entry: OperatorEntry) -> None:
        """Tenant-less: the allowlist is a system table of the operator plane."""
        ...
