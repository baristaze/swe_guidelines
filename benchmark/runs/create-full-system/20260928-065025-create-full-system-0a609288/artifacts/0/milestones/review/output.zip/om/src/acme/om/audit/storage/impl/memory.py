"""The audit stream in memory."""

from uuid import UUID

from acme.om.audit.storage import AuditStorageInterface
from acme.om.audit.types import AuditEntry
from acme.om.storage.impl.memory_base import MemoryOutboxLedger, MemoryStorageBase


class AuditStorageMemoryImpl(MemoryStorageBase, AuditStorageInterface):
    def __init__(self, ledger: MemoryOutboxLedger) -> None:
        super().__init__(ledger)
        self._entries: dict[UUID, dict[UUID, AuditEntry]] = {}
        self._heads: dict[UUID, int] = {}

    async def append_audit_entry(self, org_id: UUID, entry: AuditEntry) -> AuditEntry:
        """Named atomic: assigns `seq` from the tenant's audit cursor; an id already written returns it."""
        tenant = self._entries.setdefault(org_id, {})
        if entry.id in tenant:
            return tenant[entry.id]
        seq = self._heads.get(org_id, 0) + 1
        self._heads[org_id] = seq
        stored = entry.model_copy(update={"seq": seq})
        tenant[entry.id] = stored
        return stored

    async def read_after(self, org_id: UUID, after_seq: int, limit: int) -> list[AuditEntry]:
        found = [e for e in self._entries.get(org_id, {}).values() if e.seq > after_seq]
        return sorted(found, key=lambda e: e.seq)[:limit]
