# 0010. A payment delivery settles in the webhook request, not through the inbound queue

Date: 2026-09-28

Status: accepted (a deviation)

## Context

The guideline (Infrastructure, Queues) sends an inbound webhook, once its signature and timestamp verify, to the
inbound queue, and a consumer works it. The MVP's one delivery is the payment processor's
`checkout.session.completed`: it settles a pledge in the reader's account and appends a contribution to the desk.
No consumer of `Queues.WEBHOOKS` exists yet.

## Decision

- The webhook route verifies the delivery's signature and replay window first, then calls
  `SupportManagerImpl.settle_checkout(rctx, ...)`, a request-stage operation whose authority is the verified
  delivery. It writes the pledge's settlement in the reader's account and appends the contribution to the desk.
  Each write keys on a UUID v5 of the provider's name and the delivery id, so a redelivery changes nothing.
- The provider's redelivery on any non-2xx answer is the retry. Both writes are single statements in the platform's
  own database.

## Consequences

- A delivery that needs slow work (a renewal cascade, a dispute) moves to the inbound queue with a consumer, and
  this decision is superseded then.
- A delivery whose pledge cannot be found is answered `2xx` and logged, so the provider does not retry it forever.
