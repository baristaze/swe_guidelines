"""The work queue over Postgres: the claim is one `SELECT ... FOR UPDATE SKIP LOCKED` and one update."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import delete, func, select, update

from acme.om.base import EMPTY_UUID
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.root import InsertOutcome
from acme.om.storage.utils.translation import to_model
from acme.om.work.storage import WorkStorageInterface
from acme.om.work.storage.tables.work_items import WorkItems
from acme.om.work.types.work_item import WorkGauges, WorkItem, WorkKind, WorkStatus


class WorkStoragePostgresImpl(PgStorageBase, WorkStorageInterface):
    async def create_item(self, org_id: UUID, item: WorkItem) -> InsertOutcome:
        """The insert that reports which key collided; nothing changes on a collision."""
        return await self._insert(WorkItems, item, org_id=org_id)

    async def read_item(self, org_id: UUID, item_id: UUID) -> WorkItem | None:
        stmt = select(WorkItems).where(WorkItems.org_id == org_id, WorkItems.id == item_id)
        return await self._read_one(stmt, WorkItem, org_id=org_id)

    async def read_item_by_key(self, org_id: UUID, idempotency_key: UUID) -> WorkItem | None:
        stmt = select(WorkItems).where(WorkItems.org_id == org_id, WorkItems.idempotency_key == idempotency_key)
        return await self._read_one(stmt, WorkItem, org_id=org_id)

    async def write_item(self, org_id: UUID, item: WorkItem, claim_token: UUID) -> bool:
        """Writes only while the row still carries `claim_token`; False means another holder has it now."""
        stmt = (
            update(WorkItems)
            .where(WorkItems.org_id == org_id, WorkItems.id == item.id, WorkItems.claim_token == claim_token)
            .values(
                status=item.status.value,
                available_at=item.available_at,
                claimed_by=item.claimed_by,
                claim_token=item.claim_token,
                lease_expires_at=item.lease_expires_at,
                attempts=item.attempts,
                last_error=item.last_error,
                updated_at=item.updated_at,
                updated_by=item.updated_by,
            )
            .returning(WorkItems.id)
        )
        return await self._returned(stmt, org_id=org_id) == 1

    async def requeue_stale(self, org_id: UUID, before: datetime, limit: int, now: datetime) -> int:
        """Hands back the tenant's claimed items whose lease passed before `before`, at most `limit`."""
        # rules.stale_before, spelled once more inside the statement: `lease_expires_at < :before`.
        stale = (
            select(WorkItems.id)
            .where(
                WorkItems.org_id == org_id,
                WorkItems.status == WorkStatus.CLAIMED.value,
                WorkItems.lease_expires_at < before,
            )
            .limit(limit)
            .with_for_update(skip_locked=True)
        )
        stmt = (
            update(WorkItems)
            .where(WorkItems.org_id == org_id, WorkItems.id.in_(stale.scalar_subquery()))
            .values(
                status=WorkStatus.QUEUED.value,
                claimed_by=None,
                claim_token=None,
                lease_expires_at=None,
                available_at=now,
                updated_at=now,
                updated_by=EMPTY_UUID,
            )
            .returning(WorkItems.id)
        )
        return await self._returned(stmt, org_id=org_id)

    async def claim_next(
        self,
        lane: str,
        kinds: tuple[WorkKind, ...],
        worker_id: str,
        claim_token: UUID,
        lease_until: datetime,
        now: datetime,
    ) -> tuple[UUID, WorkItem] | None:
        """Tenant-less, named atomic: the oldest available item of the lane across tenants, locked past the others,
        stamped with the claim and the lease in the same statement; the tenant travels back beside the row."""
        candidate = (
            select(WorkItems.id)
            .where(
                WorkItems.lane == lane,
                WorkItems.status == WorkStatus.QUEUED.value,
                WorkItems.available_at <= now,
                WorkItems.kind.in_([k.value for k in kinds]),
            )
            .order_by(WorkItems.available_at, WorkItems.id)
            .limit(1)
            .with_for_update(skip_locked=True)
        )
        stmt = (
            update(WorkItems)
            .where(WorkItems.id == candidate.scalar_subquery())
            .values(
                status=WorkStatus.CLAIMED.value,
                claimed_by=worker_id,
                claim_token=claim_token,
                lease_expires_at=lease_until,
                updated_at=now,
                updated_by=EMPTY_UUID,
            )
            .returning(WorkItems)
        )
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            row = (await session.execute(stmt)).scalars().first()
            return None if row is None else (row.org_id, to_model(row, WorkItem))

    async def fail_orphaned(self, item_id: UUID, claim_token: UUID, error: str, now: datetime) -> bool:
        """Tenant-less: fails an item whose tenant is gone, conditional on the token, needing no stage."""
        stmt = (
            update(WorkItems)
            .where(WorkItems.id == item_id, WorkItems.claim_token == claim_token)
            .values(status=WorkStatus.FAILED.value, last_error=error[:500], updated_at=now, updated_by=EMPTY_UUID)
            .returning(WorkItems.id)
        )
        return await self._returned(stmt, org_id=EMPTY_UUID) == 1

    async def read_gauges(self) -> WorkGauges:
        """Tenant-less: the oldest waiting item and the count of failed items, across tenants."""
        oldest = select(func.min(WorkItems.available_at)).where(WorkItems.status == WorkStatus.QUEUED.value)
        failed = select(func.count()).select_from(WorkItems).where(WorkItems.status == WorkStatus.FAILED.value)
        async with self._session_for(oldest, org_id=EMPTY_UUID) as session:
            waiting = (await session.execute(oldest)).scalar_one_or_none()
            count = int((await session.execute(failed)).scalar_one())
        return WorkGauges(oldest_waiting_at=waiting, failed=count)

    async def purge_items(self, before: datetime, limit: int) -> int:
        """Tenant-less: purges done and failed items last touched before `before`, across tenants, at most `limit`."""
        doomed = (
            select(WorkItems.id)
            .where(
                WorkItems.status.in_([WorkStatus.DONE.value, WorkStatus.FAILED.value]), WorkItems.updated_at < before
            )
            .limit(limit)
        )
        stmt = delete(WorkItems).where(WorkItems.id.in_(doomed.scalar_subquery())).returning(WorkItems.id)
        return await self._returned(stmt, org_id=EMPTY_UUID)
