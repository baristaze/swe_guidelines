"""A reader's pledges, in the core role, fenced by the reader's own account."""

from datetime import datetime
from uuid import UUID

from sqlalchemy.orm import Mapped

from acme.om.storage.tables.base import Base, IdentifiableMixin, TrackableMixin


class Pledges(IdentifiableMixin, TrackableMixin, Base):
    __tablename__ = "pledges"

    desk_id: Mapped[UUID]
    journalist_id: Mapped[UUID]
    amount_minor: Mapped[int]
    currency: Mapped[str]
    mode: Mapped[str]
    supporter_name: Mapped[str]
    status: Mapped[str]
    platform_fee_minor: Mapped[int]
    checkout_session_id: Mapped[str | None]
    subscription_id: Mapped[str | None]
    settled_at: Mapped[datetime | None]
