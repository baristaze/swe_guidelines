"""Contract cases of the follows storage: every method under another account, the page, the unique key, the id."""

import asyncio
from uuid import UUID

import pytest

from acme.om.base import new_id, utcnow
from acme.om.exceptions import Conflict
from acme.om.follows.types.follow import Follow
from acme.om.storage.root import InsertOutcome, StorageInterface
from contracts import factories as f


def follow(journalist_id: UUID | None = None, desk_id: UUID | None = None) -> Follow:
    return Follow(
        id=new_id(), created_at=utcnow(), desk_id=desk_id or new_id(), journalist_id=journalist_id or new_id()
    )


def ended(fw: Follow) -> Follow:
    return fw.model_copy(update={"deleted_at": utcnow(), "deleted_by": new_id()})


async def case_create_then_read_list_and_find_by_journalist(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    fw = follow()
    r = f.row(org_id, "follows.follow.created", fw.id)
    assert await s.create_follow(org_id, fw, (r,)) == InsertOutcome.INSERTED
    assert await s.read_follow(org_id, fw.id) == fw
    assert await s.read_follows(org_id, 10) == [fw]
    assert await s.read_follow_by_journalist(org_id, fw.journalist_id) == fw
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r


async def case_list_pages_in_id_order(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    made = [follow() for _ in range(3)]
    for fw in made:
        await s.create_follow(org_id, fw, ())
    ordered = sorted(made, key=lambda x: x.id.int)
    assert await s.read_follows(org_id, 2) == ordered[:2]
    assert await s.read_follows(org_id, 10) == ordered


async def case_a_second_create_under_the_same_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    fw = follow()
    await s.create_follow(org_id, fw, ())
    again = f.row(org_id, "follows.follow.created", fw.id)
    assert await s.create_follow(org_id, fw.model_copy(update={"journalist_id": new_id()}), (again,)) == (
        InsertOutcome.ID_EXISTS
    )
    assert await s.read_follow(org_id, fw.id) == fw
    assert await storage.get_outbox_storage().read_row(org_id, again.id) is None


async def case_a_second_follow_of_the_same_journalist_is_refused_until_the_first_ends(
    storage: StorageInterface,
) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    first = follow()
    await s.create_follow(org_id, first, ())
    second = follow(first.journalist_id, first.desk_id)
    r = f.row(org_id, "follows.follow.created", second.id)
    assert await s.create_follow(org_id, second, (r,)) == InsertOutcome.KEY_EXISTS
    assert await s.read_follow(org_id, second.id) is None
    assert await storage.get_outbox_storage().read_row(org_id, r.id) is None
    await s.write_follow(org_id, ended(first), ())
    assert await s.read_follow_by_journalist(org_id, first.journalist_id) is None
    assert await s.create_follow(org_id, second, ()) == InsertOutcome.INSERTED  # the key holds among the living
    assert await s.read_follow_by_journalist(org_id, first.journalist_id) == second


async def case_the_list_leaves_out_the_ended(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    kept, gone = follow(), follow()
    await s.create_follow(org_id, kept, ())
    await s.create_follow(org_id, gone, ())
    r = f.row(org_id, "follows.follow.deleted", gone.id)
    await s.write_follow(org_id, ended(gone), (r,))
    assert await s.read_follows(org_id, 10) == [kept]
    assert (await s.read_follow(org_id, gone.id)) is not None  # still read by id: the manager decides
    assert await storage.get_outbox_storage().read_row(org_id, r.id) == r


async def case_list_under_another_account_finds_nothing(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    await s.create_follow(org_id, follow(), ())
    assert await s.read_follows(new_id(), 10) == []


async def case_reads_under_another_account_find_nothing(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id, other = new_id(), new_id()
    fw = follow()
    await s.create_follow(org_id, fw, ())
    assert await s.read_follow(other, fw.id) is None
    assert await s.read_follow_by_journalist(other, fw.journalist_id) is None


async def case_create_under_another_account_with_a_taken_id_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id, other = new_id(), new_id()
    fw = follow()
    await s.create_follow(org_id, fw, ())
    r = f.row(other, "follows.follow.created", fw.id)
    # The engine cannot see another tenant's id under the policy, so it may name either key; nothing lands.
    assert await s.create_follow(other, fw, (r,)) != InsertOutcome.INSERTED
    assert await s.read_follow(other, fw.id) is None
    assert await s.read_follow(org_id, fw.id) == fw
    assert await storage.get_outbox_storage().read_row(other, r.id) is None


async def case_another_account_may_follow_the_same_journalist(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id, other = new_id(), new_id()
    fw = follow()
    await s.create_follow(org_id, fw, ())
    theirs = follow(fw.journalist_id, fw.desk_id)
    assert await s.create_follow(other, theirs, ()) == InsertOutcome.INSERTED
    assert await s.read_follow_by_journalist(org_id, fw.journalist_id) == fw


async def case_write_under_another_account_is_refused_and_changes_nothing(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id, other = new_id(), new_id()
    fw = follow()
    await s.create_follow(org_id, fw, ())
    r = f.row(other, "follows.follow.deleted", fw.id)
    with pytest.raises(Conflict):
        await s.write_follow(other, ended(fw), (r,))
    assert await s.read_follow(org_id, fw.id) == fw
    assert await storage.get_outbox_storage().read_row(other, r.id) is None


async def case_a_create_race_has_one_winner(storage: StorageInterface) -> None:
    s = storage.get_follow_storage()
    org_id = new_id()
    a = follow()
    b = follow(a.journalist_id, a.desk_id)
    results = await asyncio.gather(s.create_follow(org_id, a, ()), s.create_follow(org_id, b, ()))
    assert sorted(results) == sorted([InsertOutcome.INSERTED, InsertOutcome.KEY_EXISTS])
    assert len(await s.read_follows(org_id, 10)) == 1


CASES = [
    case_create_then_read_list_and_find_by_journalist,
    case_list_pages_in_id_order,
    case_a_second_create_under_the_same_id_changes_nothing,
    case_a_second_follow_of_the_same_journalist_is_refused_until_the_first_ends,
    case_the_list_leaves_out_the_ended,
    case_list_under_another_account_finds_nothing,
    case_reads_under_another_account_find_nothing,
    case_create_under_another_account_with_a_taken_id_changes_nothing,
    case_another_account_may_follow_the_same_journalist,
    case_write_under_another_account_is_refused_and_changes_nothing,
    case_a_create_race_has_one_winner,
]
