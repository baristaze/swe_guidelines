"""The audit storage: a named atomic append with its own per-tenant sequence."""

from abc import ABC, abstractmethod
from uuid import UUID

from acme.om.audit.types import AuditEntry


class AuditStorageInterface(ABC):
    @abstractmethod
    async def append_audit_entry(self, org_id: UUID, entry: AuditEntry) -> AuditEntry:
        """Named atomic: assigns `seq` from the tenant's audit cursor; an id already written returns it."""
        ...

    @abstractmethod
    async def read_after(self, org_id: UUID, after_seq: int, limit: int) -> list[AuditEntry]: ...
