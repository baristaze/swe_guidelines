"""Generated from the OpenAPI document by clients/python/generate.py. Do not edit."""

from uuid import UUID

from acme.clients.api.generated import models as m
from acme.clients.api.transport import Transport


class Operations:
    """One method per operation of the API, named by its operation id."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    async def admin_get_me(self) -> m.OperatorView:
        """GET /v1/admin/me: Get Me."""
        answer = await self._transport.request("GET", f"/v1/admin/me")
        return m.OperatorView.model_validate(answer)

    async def admin_issue_token(self, body: m.AddOperatorTokenRequest, idempotency_key: str | None = None) -> m.IssuedOperatorTokenView:
        """POST /v1/admin/me/tokens: Issue Token."""
        answer = await self._transport.request("POST", f"/v1/admin/me/tokens", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.IssuedOperatorTokenView.model_validate(answer)

    async def admin_enrol_totp(self) -> m.TotpEnrolmentView:
        """POST /v1/admin/me/totp: Enrol Totp."""
        answer = await self._transport.request("POST", f"/v1/admin/me/totp")
        return m.TotpEnrolmentView.model_validate(answer)

    async def admin_confirm_totp(self, body: m.ConfirmTotpRequest) -> None:
        """POST /v1/admin/me/totp/confirm: Confirm Totp."""
        answer = await self._transport.request("POST", f"/v1/admin/me/totp/confirm", body=body.model_dump(mode="json", exclude_unset=True))
        del answer

    async def admin_get_orgs(self, limit: int | None = 50) -> list[m.AdminOrgView]:
        """GET /v1/admin/orgs: Get Orgs."""
        answer = await self._transport.request("GET", f"/v1/admin/orgs", params={"limit": limit})
        return [m.AdminOrgView.model_validate(x) for x in answer]

    async def admin_create_org(self, body: m.AddOrgRequest, idempotency_key: str | None = None) -> m.AdminOrgView:
        """POST /v1/admin/orgs: Create Org."""
        answer = await self._transport.request("POST", f"/v1/admin/orgs", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.AdminOrgView.model_validate(answer)

    async def admin_delete_org(self, org_id: UUID) -> None:
        """DELETE /v1/admin/orgs/{org_id}: Delete Org."""
        answer = await self._transport.request("DELETE", f"/v1/admin/orgs/{org_id}")
        del answer

    async def admin_get_org(self, org_id: UUID) -> m.AdminOrgView:
        """GET /v1/admin/orgs/{org_id}: Get Org."""
        answer = await self._transport.request("GET", f"/v1/admin/orgs/{org_id}")
        return m.AdminOrgView.model_validate(answer)

    async def admin_get_events(self, org_id: UUID, after_seq: int | None = 0, limit: int | None = 100) -> list[m.AdminEventView]:
        """GET /v1/admin/orgs/{org_id}/events: Get Events."""
        answer = await self._transport.request("GET", f"/v1/admin/orgs/{org_id}/events", params={"after_seq": after_seq, "limit": limit})
        return [m.AdminEventView.model_validate(x) for x in answer]

    async def admin_get_members(self, org_id: UUID, limit: int | None = 50) -> list[m.AdminMemberView]:
        """GET /v1/admin/orgs/{org_id}/members: Get Members."""
        answer = await self._transport.request("GET", f"/v1/admin/orgs/{org_id}/members", params={"limit": limit})
        return [m.AdminMemberView.model_validate(x) for x in answer]

    async def admin_add_member(self, org_id: UUID, body: m.AddMemberRequest, idempotency_key: str | None = None) -> m.AdminMemberView:
        """POST /v1/admin/orgs/{org_id}/members: Add Member."""
        answer = await self._transport.request("POST", f"/v1/admin/orgs/{org_id}/members", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.AdminMemberView.model_validate(answer)

    async def admin_get_size(self) -> m.SizeView:
        """GET /v1/admin/size: Get Size."""
        answer = await self._transport.request("GET", f"/v1/admin/size")
        return m.SizeView.model_validate(answer)

    async def tenancy_get_api_keys(self, limit: int | None = 50) -> list[m.ApiKeyView]:
        """GET /v1/api-keys: Get Api Keys."""
        answer = await self._transport.request("GET", f"/v1/api-keys", params={"limit": limit})
        return [m.ApiKeyView.model_validate(x) for x in answer]

    async def tenancy_create_api_key(self, body: m.AddApiKeyRequest, idempotency_key: str | None = None) -> m.IssuedApiKeyView:
        """POST /v1/api-keys: Create Api Key."""
        answer = await self._transport.request("POST", f"/v1/api-keys", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.IssuedApiKeyView.model_validate(answer)

    async def tenancy_revoke_api_key(self, key_id: UUID) -> None:
        """DELETE /v1/api-keys/{key_id}: Revoke Api Key."""
        answer = await self._transport.request("DELETE", f"/v1/api-keys/{key_id}")
        del answer

    async def tenancy_exchange(self, body: m.ExchangeRequest) -> m.IssuedSessionView:
        """POST /v1/auth/exchange: Exchange."""
        answer = await self._transport.request("POST", f"/v1/auth/exchange", body=body.model_dump(mode="json", exclude_unset=True))
        return m.IssuedSessionView.model_validate(answer)

    async def tenancy_sign_in_external(self, body: m.ExternalSignInRequest) -> m.IssuedSignInView:
        """POST /v1/auth/external: Sign In External."""
        answer = await self._transport.request("POST", f"/v1/auth/external", body=body.model_dump(mode="json", exclude_unset=True))
        return m.IssuedSignInView.model_validate(answer)

    async def tenancy_sign_in(self, body: m.SignInRequest) -> m.IssuedSignInView:
        """POST /v1/auth/login: Sign In."""
        answer = await self._transport.request("POST", f"/v1/auth/login", body=body.model_dump(mode="json", exclude_unset=True))
        return m.IssuedSignInView.model_validate(answer)

    async def tenancy_sign_out(self) -> None:
        """POST /v1/auth/logout: Sign Out."""
        answer = await self._transport.request("POST", f"/v1/auth/logout")
        del answer

    async def tenancy_get_memberships(self, limit: int | None = 50) -> list[m.MembershipChoiceView]:
        """GET /v1/auth/memberships: Get Memberships."""
        answer = await self._transport.request("GET", f"/v1/auth/memberships", params={"limit": limit})
        return [m.MembershipChoiceView.model_validate(x) for x in answer]

    async def tenancy_sign_up(self, body: m.SignUpRequest) -> m.IssuedSignInView:
        """POST /v1/auth/signup: Sign Up."""
        answer = await self._transport.request("POST", f"/v1/auth/signup", body=body.model_dump(mode="json", exclude_unset=True))
        return m.IssuedSignInView.model_validate(answer)

    async def support_get_contributions(self, limit: int | None = 50) -> list[m.ContributionView]:
        """GET /v1/contributions: Get Contributions."""
        answer = await self._transport.request("GET", f"/v1/contributions", params={"limit": limit})
        return [m.ContributionView.model_validate(x) for x in answer]

    async def support_get_contribution(self, contribution_id: UUID) -> m.ContributionView:
        """GET /v1/contributions/{contribution_id}: Get Contribution."""
        answer = await self._transport.request("GET", f"/v1/contributions/{contribution_id}")
        return m.ContributionView.model_validate(answer)

    async def events_get_events(self, after_seq: int | None = 0, limit: int | None = 100) -> list[m.EventView]:
        """GET /v1/events: Get Events."""
        answer = await self._transport.request("GET", f"/v1/events", params={"after_seq": after_seq, "limit": limit})
        return [m.EventView.model_validate(x) for x in answer]

    async def follows_get_feed(self, limit: int | None = 50) -> list[m.FeedItemView]:
        """GET /v1/feed: Get Feed."""
        answer = await self._transport.request("GET", f"/v1/feed", params={"limit": limit})
        return [m.FeedItemView.model_validate(x) for x in answer]

    async def follows_get_follows(self, limit: int | None = 50) -> list[m.FollowView]:
        """GET /v1/follows: Get Follows."""
        answer = await self._transport.request("GET", f"/v1/follows", params={"limit": limit})
        return [m.FollowView.model_validate(x) for x in answer]

    async def follows_create_follow(self, body: m.AddFollowRequest, idempotency_key: str | None = None) -> m.FollowView:
        """POST /v1/follows: Create Follow."""
        answer = await self._transport.request("POST", f"/v1/follows", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.FollowView.model_validate(answer)

    async def follows_delete_follow(self, follow_id: UUID) -> None:
        """DELETE /v1/follows/{follow_id}: Delete Follow."""
        answer = await self._transport.request("DELETE", f"/v1/follows/{follow_id}")
        del answer

    async def follows_get_follow(self, follow_id: UUID) -> m.FollowView:
        """GET /v1/follows/{follow_id}: Get Follow."""
        answer = await self._transport.request("GET", f"/v1/follows/{follow_id}")
        return m.FollowView.model_validate(answer)

    async def journalists_get_journalists(self, limit: int | None = 50) -> list[m.JournalistView]:
        """GET /v1/journalists: Get Journalists."""
        answer = await self._transport.request("GET", f"/v1/journalists", params={"limit": limit})
        return [m.JournalistView.model_validate(x) for x in answer]

    async def journalists_create_journalist(self, body: m.AddJournalistRequest, idempotency_key: str | None = None) -> m.JournalistView:
        """POST /v1/journalists: Create Journalist."""
        answer = await self._transport.request("POST", f"/v1/journalists", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.JournalistView.model_validate(answer)

    async def journalists_delete_journalist(self, journalist_id: UUID) -> None:
        """DELETE /v1/journalists/{journalist_id}: Delete Journalist."""
        answer = await self._transport.request("DELETE", f"/v1/journalists/{journalist_id}")
        del answer

    async def journalists_get_journalist(self, journalist_id: UUID) -> m.JournalistView:
        """GET /v1/journalists/{journalist_id}: Get Journalist."""
        answer = await self._transport.request("GET", f"/v1/journalists/{journalist_id}")
        return m.JournalistView.model_validate(answer)

    async def journalists_update_journalist(self, journalist_id: UUID, body: m.UpdateJournalistRequest) -> m.JournalistView:
        """PATCH /v1/journalists/{journalist_id}: Update Journalist."""
        answer = await self._transport.request("PATCH", f"/v1/journalists/{journalist_id}", body=body.model_dump(mode="json", exclude_unset=True))
        return m.JournalistView.model_validate(answer)

    async def journalists_start_payouts(self, journalist_id: UUID, body: m.StartPayoutsRequest) -> m.PayoutOnboardingView:
        """POST /v1/journalists/{journalist_id}/payouts: Start Payouts."""
        answer = await self._transport.request("POST", f"/v1/journalists/{journalist_id}/payouts", body=body.model_dump(mode="json", exclude_unset=True))
        return m.PayoutOnboardingView.model_validate(answer)

    async def tenancy_get_me(self) -> m.UserView:
        """GET /v1/me: Get Me."""
        answer = await self._transport.request("GET", f"/v1/me")
        return m.UserView.model_validate(answer)

    async def tenancy_update_me(self, body: m.UpdateUserRequest) -> m.UserView:
        """PATCH /v1/me: Update Me."""
        answer = await self._transport.request("PATCH", f"/v1/me", body=body.model_dump(mode="json", exclude_unset=True))
        return m.UserView.model_validate(answer)

    async def tenancy_get_members(self, limit: int | None = 50) -> list[m.MemberView]:
        """GET /v1/members: Get Members."""
        answer = await self._transport.request("GET", f"/v1/members", params={"limit": limit})
        return [m.MemberView.model_validate(x) for x in answer]

    async def tenancy_remove_member(self, user_id: UUID) -> None:
        """DELETE /v1/members/{user_id}: Remove Member."""
        answer = await self._transport.request("DELETE", f"/v1/members/{user_id}")
        del answer

    async def tenancy_update_member_role(self, user_id: UUID, body: m.UpdateMemberRoleRequest) -> m.MembershipView:
        """PATCH /v1/members/{user_id}: Update Member Role."""
        answer = await self._transport.request("PATCH", f"/v1/members/{user_id}", body=body.model_dump(mode="json", exclude_unset=True))
        return m.MembershipView.model_validate(answer)

    async def tenancy_get_org(self) -> m.OrgView:
        """GET /v1/org: Get Org."""
        answer = await self._transport.request("GET", f"/v1/org")
        return m.OrgView.model_validate(answer)

    async def support_get_pledges(self, limit: int | None = 50) -> list[m.PledgeView]:
        """GET /v1/pledges: Get Pledges."""
        answer = await self._transport.request("GET", f"/v1/pledges", params={"limit": limit})
        return [m.PledgeView.model_validate(x) for x in answer]

    async def support_create_pledge(self, body: m.AddPledgeRequest, idempotency_key: str | None = None) -> m.StartedPledgeView:
        """POST /v1/pledges: Create Pledge."""
        answer = await self._transport.request("POST", f"/v1/pledges", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.StartedPledgeView.model_validate(answer)

    async def support_get_pledge(self, pledge_id: UUID) -> m.PledgeView:
        """GET /v1/pledges/{pledge_id}: Get Pledge."""
        answer = await self._transport.request("GET", f"/v1/pledges/{pledge_id}")
        return m.PledgeView.model_validate(answer)

    async def support_cancel_pledge(self, pledge_id: UUID) -> m.PledgeView:
        """POST /v1/pledges/{pledge_id}/cancel: Cancel Pledge."""
        answer = await self._transport.request("POST", f"/v1/pledges/{pledge_id}/cancel")
        return m.PledgeView.model_validate(answer)

    async def journalists_get_published_journalist(self, desk_id: UUID, journalist_id: UUID) -> m.PublishedJournalistView:
        """GET /v1/public/desks/{desk_id}/journalists/{journalist_id}: Get Published Journalist."""
        answer = await self._transport.request("GET", f"/v1/public/desks/{desk_id}/journalists/{journalist_id}")
        return m.PublishedJournalistView.model_validate(answer)

    async def updates_get_published_updates(self, desk_id: UUID, journalist_id: UUID, limit: int | None = 50) -> list[m.UpdateView]:
        """GET /v1/public/desks/{desk_id}/journalists/{journalist_id}/updates: Get Published Updates."""
        answer = await self._transport.request("GET", f"/v1/public/desks/{desk_id}/journalists/{journalist_id}/updates", params={"limit": limit})
        return [m.UpdateView.model_validate(x) for x in answer]

    async def intake_submit_report(self, body: m.SubmitReportRequest, idempotency_key: str | None = None) -> list[m.SubmissionReceiptView]:
        """POST /v1/public/reports: Submit Report."""
        answer = await self._transport.request("POST", f"/v1/public/reports", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return [m.SubmissionReceiptView.model_validate(x) for x in answer]

    async def intake_get_source_thread(self, desk_id: UUID, submission_id: UUID) -> m.SourceThreadView:
        """GET /v1/public/reports/{desk_id}/{submission_id}: Get Source Thread."""
        answer = await self._transport.request("GET", f"/v1/public/reports/{desk_id}/{submission_id}")
        return m.SourceThreadView.model_validate(answer)

    async def intake_post_source_message(self, desk_id: UUID, submission_id: UUID, body: m.SourceMessageRequest, idempotency_key: str | None = None) -> m.MessageView:
        """POST /v1/public/reports/{desk_id}/{submission_id}/messages: Post Source Message."""
        answer = await self._transport.request("POST", f"/v1/public/reports/{desk_id}/{submission_id}/messages", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.MessageView.model_validate(answer)

    async def realtime_issue_ticket(self, idempotency_key: str | None = None) -> m.RealtimeTicketView:
        """POST /v1/realtime/tickets: Issue Ticket."""
        answer = await self._transport.request("POST", f"/v1/realtime/tickets", creating=True, idempotency_key=idempotency_key)
        return m.RealtimeTicketView.model_validate(answer)

    async def reports_submit_named_report(self, body: m.SubmitReportRequest, idempotency_key: str | None = None) -> list[m.SubmissionReceiptView]:
        """POST /v1/reports: Submit Named Report."""
        answer = await self._transport.request("POST", f"/v1/reports", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return [m.SubmissionReceiptView.model_validate(x) for x in answer]

    async def reports_get_submissions(self, state: m.SubmissionState | None | None = None, tag: str | None | None = None, limit: int | None = 50) -> list[m.SubmissionView]:
        """GET /v1/submissions: Get Submissions."""
        answer = await self._transport.request("GET", f"/v1/submissions", params={"state": state, "tag": tag, "limit": limit})
        return [m.SubmissionView.model_validate(x) for x in answer]

    async def reports_get_submission(self, submission_id: UUID) -> m.SubmissionView:
        """GET /v1/submissions/{submission_id}: Get Submission."""
        answer = await self._transport.request("GET", f"/v1/submissions/{submission_id}")
        return m.SubmissionView.model_validate(answer)

    async def reports_update_submission(self, submission_id: UUID, body: m.UpdateSubmissionRequest) -> m.SubmissionView:
        """PATCH /v1/submissions/{submission_id}: Update Submission."""
        answer = await self._transport.request("PATCH", f"/v1/submissions/{submission_id}", body=body.model_dump(mode="json", exclude_unset=True))
        return m.SubmissionView.model_validate(answer)

    async def reports_get_messages(self, submission_id: UUID, limit: int | None = 100) -> list[m.MessageView]:
        """GET /v1/submissions/{submission_id}/messages: Get Messages."""
        answer = await self._transport.request("GET", f"/v1/submissions/{submission_id}/messages", params={"limit": limit})
        return [m.MessageView.model_validate(x) for x in answer]

    async def reports_create_message(self, submission_id: UUID, body: m.AddMessageRequest, idempotency_key: str | None = None) -> m.MessageView:
        """POST /v1/submissions/{submission_id}/messages: Create Message."""
        answer = await self._transport.request("POST", f"/v1/submissions/{submission_id}/messages", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.MessageView.model_validate(answer)

    async def reports_open_submission(self, submission_id: UUID) -> m.OpenedSubmissionView:
        """GET /v1/submissions/{submission_id}/sealed: Open Submission."""
        answer = await self._transport.request("GET", f"/v1/submissions/{submission_id}/sealed")
        return m.OpenedSubmissionView.model_validate(answer)

    async def updates_get_updates(self, limit: int | None = 50) -> list[m.UpdateView]:
        """GET /v1/updates: Get Updates."""
        answer = await self._transport.request("GET", f"/v1/updates", params={"limit": limit})
        return [m.UpdateView.model_validate(x) for x in answer]

    async def updates_create_update(self, body: m.AddUpdateRequest, idempotency_key: str | None = None) -> m.UpdateView:
        """POST /v1/updates: Create Update."""
        answer = await self._transport.request("POST", f"/v1/updates", body=body.model_dump(mode="json", exclude_unset=True), creating=True, idempotency_key=idempotency_key)
        return m.UpdateView.model_validate(answer)

    async def updates_get_update(self, update_id: UUID) -> m.UpdateView:
        """GET /v1/updates/{update_id}: Get Update."""
        answer = await self._transport.request("GET", f"/v1/updates/{update_id}")
        return m.UpdateView.model_validate(answer)

    async def support_accept_payment_delivery(self) -> m.DeliveryReceivedView:
        """POST /v1/webhooks/payments: Accept Payment Delivery."""
        answer = await self._transport.request("POST", f"/v1/webhooks/payments")
        return m.DeliveryReceivedView.model_validate(answer)
