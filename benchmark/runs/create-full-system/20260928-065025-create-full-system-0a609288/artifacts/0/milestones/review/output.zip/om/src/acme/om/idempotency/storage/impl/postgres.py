"""The marker over Postgres. The operator plane's markers sit under EMPTY_UUID and run on the system login."""

from datetime import datetime
from uuid import UUID

from sqlalchemy import delete, select, update
from sqlalchemy.dialects.postgresql import insert as pg_insert

from acme.om.base import EMPTY_UUID
from acme.om.idempotency.storage import IdempotencyStorageInterface
from acme.om.idempotency.storage.tables.idempotency_markers import IdempotencyMarkers
from acme.om.idempotency.types import BeginOutcome, IdempotencyMarker, MarkerOutcome, attempt_started_at
from acme.om.storage.impl.pg_base import PgStorageBase
from acme.om.storage.utils.translation import to_model, to_values


class IdempotencyStoragePostgresImpl(PgStorageBase, IdempotencyStorageInterface):
    async def begin(self, org_id: UUID, marker: IdempotencyMarker, stale_before: datetime) -> MarkerOutcome:
        """Named atomic: writes the marker pending, or takes over a released one or one whose attempt began
        before `stale_before`, keeping its digest and target id; exactly one of two racing callers starts."""
        write = (
            pg_insert(IdempotencyMarkers)
            .values(**to_values(marker, IdempotencyMarkers, org_id=org_id))
            .on_conflict_do_nothing()
            .returning(IdempotencyMarkers.id)
        )
        found = select(IdempotencyMarkers).where(
            IdempotencyMarkers.org_id == org_id,
            IdempotencyMarkers.user_id == marker.user_id,
            IdempotencyMarkers.key == marker.key,
        )
        async with self._session_for(write, org_id=org_id, user_id=marker.user_id) as session:
            if (await session.execute(write)).scalar_one_or_none() is not None:
                return MarkerOutcome(outcome=BeginOutcome.STARTED, marker=marker)
            row = (await session.execute(found.with_for_update())).scalar_one_or_none()
            if row is None:  # the key is held under another tenant's id: the key is unique per tenant, so never
                raise RuntimeError("marker insert collided and no marker was found under the tenant")
            current = to_model(row, IdempotencyMarker)
            if current.request_digest != marker.request_digest:
                return MarkerOutcome(outcome=BeginOutcome.MISMATCH, marker=current)
            if current.status is not None:
                return MarkerOutcome(outcome=BeginOutcome.REPLAY, marker=current)
            held = current.attempt_token
            if held is not None and attempt_started_at(held) >= stale_before:
                return MarkerOutcome(outcome=BeginOutcome.RUNNING, marker=current)
            guard = [IdempotencyMarkers.id == current.id, IdempotencyMarkers.status.is_(None)]
            guard.append(
                IdempotencyMarkers.attempt_token.is_(None) if held is None else IdempotencyMarkers.attempt_token == held
            )
            taken = (
                await session.execute(
                    update(IdempotencyMarkers)
                    .where(IdempotencyMarkers.org_id == org_id, *guard)
                    .values(attempt_token=marker.attempt_token)
                    .returning(IdempotencyMarkers.id)
                )
            ).scalar_one_or_none()
            if taken is None:
                return MarkerOutcome(outcome=BeginOutcome.RUNNING, marker=current)
            return MarkerOutcome(
                outcome=BeginOutcome.STARTED, marker=current.model_copy(update={"attempt_token": marker.attempt_token})
            )

    async def finish(
        self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID, status: int, body: str
    ) -> bool:
        stmt = (
            update(IdempotencyMarkers)
            .where(
                IdempotencyMarkers.org_id == org_id,
                IdempotencyMarkers.user_id == user_id,
                IdempotencyMarkers.id == marker_id,
                IdempotencyMarkers.attempt_token == attempt_token,
                IdempotencyMarkers.status.is_(None),
            )
            .values(status=status, body=body)
            .returning(IdempotencyMarkers.id)
        )
        async with self._session_for(stmt, org_id=org_id, user_id=user_id) as session:
            return (await session.execute(stmt)).scalar_one_or_none() is not None

    async def release(self, org_id: UUID, user_id: UUID, marker_id: UUID, attempt_token: UUID) -> bool:
        stmt = (
            update(IdempotencyMarkers)
            .where(
                IdempotencyMarkers.org_id == org_id,
                IdempotencyMarkers.user_id == user_id,
                IdempotencyMarkers.id == marker_id,
                IdempotencyMarkers.attempt_token == attempt_token,
                IdempotencyMarkers.status.is_(None),
            )
            .values(attempt_token=None)
            .returning(IdempotencyMarkers.id)
        )
        async with self._session_for(stmt, org_id=org_id, user_id=user_id) as session:
            return (await session.execute(stmt)).scalar_one_or_none() is not None

    async def holds_attempt(self, org_id: UUID, marker_id: UUID, attempt_token: UUID) -> bool:
        """Whether the marker is still pending under this attempt: the guard a rerun's re-mint reads."""
        stmt = select(IdempotencyMarkers.id).where(
            IdempotencyMarkers.org_id == org_id,
            IdempotencyMarkers.id == marker_id,
            IdempotencyMarkers.attempt_token == attempt_token,
            IdempotencyMarkers.status.is_(None),
        )
        async with self._session_for(stmt, org_id=org_id) as session:
            return (await session.execute(stmt)).first() is not None

    async def read_marker(self, org_id: UUID, user_id: UUID, key: str) -> IdempotencyMarker | None:
        stmt = select(IdempotencyMarkers).where(
            IdempotencyMarkers.org_id == org_id, IdempotencyMarkers.user_id == user_id, IdempotencyMarkers.key == key
        )
        async with self._session_for(stmt, org_id=org_id, user_id=user_id) as session:
            row = (await session.execute(stmt)).scalar_one_or_none()
            return None if row is None else to_model(row, IdempotencyMarker)

    async def purge_markers(self, before: datetime, limit: int) -> int:
        """Tenant-less: the sweep's purge of markers created before `before`, across tenants, in the system scope."""
        doomed = select(IdempotencyMarkers.id).where(IdempotencyMarkers.created_at < before).limit(limit)
        stmt = (
            delete(IdempotencyMarkers)
            .where(IdempotencyMarkers.id.in_(doomed.scalar_subquery()))
            .returning(IdempotencyMarkers.id)
        )
        async with self._session_for(stmt, org_id=EMPTY_UUID) as session:
            return len((await session.execute(stmt)).scalars().all())
